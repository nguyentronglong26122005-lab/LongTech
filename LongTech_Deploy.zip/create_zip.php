<?php
$zipFile = 'E:/LongTech/LongTech_Deploy.zip';
if (file_exists($zipFile)) {
    unlink($zipFile);
}

$zip = new ZipArchive();
if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
    $dir = realpath('E:/LongTech');
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );

    foreach ($files as $name => $file) {
        if (!$file->isDir()) {
            $filePath = $file->getRealPath();
            $relativePath = substr($filePath, strlen($dir) + 1);
            if (str_contains($relativePath, 'LongTech_Deploy.zip')) {
                continue;
            }
            $zip->addFile($filePath, $relativePath);
        }
    }
    $zip->close();
    echo "SUCCESS: " . filesize($zipFile) . " bytes\n";
} else {
    echo "FAILED TO CREATE ZIP\n";
}
