<?php
/**
 * ========================================================
 * LONGTECH - CỔNG VÀO CHÍNH CỦA TRANG USER (index.php)
 * ========================================================
 * Routing trung tâm điều hướng người dùng:
 * 1. Nạp cấu hình hệ thống config.php
 * 2. Nạp thư viện hàm tiện ích functions.php
 * 3. Kết nối CSDL MySQL (Bắt buộc - nếu chưa kết nối sẽ ngắt và hiện trang hướng dẫn)
 * 4. Phân tích URL và gọi Controller / Method tương ứng
 */

// 1. Nạp cấu hình và các hàm bổ trợ
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';

// 2. Kiểm tra và kết nối Cơ sở dữ liệu ngay khi khởi động
// Nếu máy chủ MySQL chưa bật hoặc sai cấu hình trong .env,
// hàm connect() sẽ lập tức hiển thị giao diện báo lỗi và ngắt chương trình (exit).
require_once __DIR__ . '/models/Database.php';
$db = Database::connect();

// 2.0 Tự động phát hiện và chuẩn hóa dữ liệu tiếng Việt UTF-8, 8 danh mục & 24 siêu phẩm gốc sắc nét
try {
    $checkCat = $db->query("SELECT name FROM `categories` WHERE `id` = 1 LIMIT 1")->fetchColumn();
    $checkThumb = $db->query("SELECT thumbnail FROM `products` WHERE `id` = 1 LIMIT 1")->fetchColumn();
    $catCount = (int)$db->query("SELECT COUNT(*) FROM `categories`")->fetchColumn();
    $prodCount = (int)$db->query("SELECT COUNT(*) FROM `products`")->fetchColumn();
    $bannerCount = (int)$db->query("SELECT COUNT(*) FROM `banners`")->fetchColumn();
    if (
        ($checkCat && (str_contains($checkCat, 'Ä') || str_contains($checkCat, 'Ă'))) ||
        ($checkThumb && (str_contains($checkThumb, 'cellphones.com.vn') || str_contains($checkThumb, '1793809625'))) ||
        $catCount < 8 ||
        $prodCount < 24 ||
        $bannerCount < 8
    ) {
        require_once __DIR__ . '/includes/repair_db.php';
        repair_database_utf8($db);
    }
} catch (Throwable $e) {
    // Bỏ qua nếu bảng chưa sẵn sàng
}

// 2.1 Kiểm tra chế độ bảo trì hệ thống (Maintenance Mode)
require_once __DIR__ . '/models/SiteSettingModel.php';
$siteSettingModel = new SiteSettingModel();
$maintenanceMode = $siteSettingModel->getSetting('maintenance_mode', '0');

if ($maintenanceMode === '1' && !has_role(['super_admin', 'admin'])) {
    // Cho phép truy cập vào trang đăng nhập để admin vào tắt bảo trì
    $currentUri = $_SERVER['REQUEST_URI'] ?? '';
    if (!str_contains($currentUri, 'dang-nhap') && !str_contains($currentUri, 'admin.php')) {
        http_response_code(503);
        ?>
        <!DOCTYPE html>
        <html lang="vi">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Website Đang Bảo Trì Nâng Cấp | LongTech</title>
            <style>
                body { margin:0; display:flex; align-items:center; justify-content:center; min-height:100vh; background:#0f172a; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; color:#f8fafc; text-align:center; padding:20px; box-sizing:border-box; }
                .card { background:#1e293b; padding:40px; border-radius:16px; max-width:520px; box-shadow:0 20px 40px rgba(0,0,0,0.4); border-top:5px solid #D70018; }
                h1 { color:#fff; font-size:24px; margin-bottom:12px; }
                p { color:#94a3b8; font-size:15px; line-height:1.6; margin-bottom:24px; }
                .btn { display:inline-block; padding:10px 24px; background:#D70018; color:#fff; text-decoration:none; border-radius:8px; font-weight:600; }
            </style>
        </head>
        <body>
            <div class="card">
                <div style="font-size:48px; margin-bottom:16px;">🛠️</div>
                <h1>Hệ Thống Đang Bảo Trì Nâng Cấp</h1>
                <p>Website LongTech đang được nâng cấp định kỳ để nâng cao trải nghiệm mua sắm của quý khách. Hệ thống sẽ sớm mở lại trong ít phút!</p>
                <a href="<?= APP_URL ?>/dang-nhap" class="btn">Dành cho Quản trị viên Đăng nhập</a>
            </div>
        </body>
        </html>
        <?php
        exit();
    }
}

// 3. Phân tích đường dẫn URL chuẩn xác đa nền tảng (Windows & Linux / Docker)
$requestUri = $_SERVER['REQUEST_URI'] ?? '/';
$requestPath = parse_url($requestUri, PHP_URL_PATH) ?? '/';

// Lấy base directory từ SCRIPT_NAME (ví dụ: '/LongTech' trên XAMPP hoặc '' trên Render)
$scriptDir = dirname($_SERVER['SCRIPT_NAME'] ?? '');
$baseDir = ($scriptDir === '/' || $scriptDir === '\\') ? '' : str_replace('\\', '/', $scriptDir);
$baseDir = rtrim($baseDir, '/');

$route = $requestPath;
if (!empty($baseDir) && str_starts_with($route, $baseDir)) {
    $route = substr($route, strlen($baseDir));
}
$route = trim($route, '/');
if ($route === 'index.php') {
    $route = '';
} elseif (str_starts_with($route, 'index.php/')) {
    $route = substr($route, strlen('index.php/'));
}

// 4. Bảng điều hướng Routing trung tâm
switch (true) {
    // A. Trang chủ
    case empty($route):
        require_once __DIR__ . '/controllers/HomeController.php';
        $controller = new HomeController();
        $controller->index();
        break;

    // B. Trang liên hệ & Hỗ trợ
    case ($route === 'lien-he'):
        require_once __DIR__ . '/controllers/CartController.php';
        $controller = new CartController();
        $controller->contact();
        break;

    // API TÌM KIẾM TỨC THÌ & XEM NHANH SẢN PHẨM (INSTANT SEARCH & QUICK VIEW)
    case ($route === 'api/live-search' || (isset($_GET['route']) && $_GET['route'] === 'api/live-search')):
        header('Content-Type: application/json; charset=UTF-8');
        require_once __DIR__ . '/models/ProductModel.php';
        $pm = new ProductModel();
        $kw = trim($_GET['q'] ?? '');
        $slug = trim($_GET['slug'] ?? '');
        if ($slug !== '') {
            $prod = $pm->getBySlug($slug);
            if ($prod) {
                $prod['price_formatted'] = format_money(!empty($prod['sale_price']) ? $prod['sale_price'] : $prod['price']);
                $prod['orig_formatted']  = (!empty($prod['sale_price']) && $prod['sale_price'] < $prod['price']) ? format_money($prod['price']) : '';
                echo json_encode(['status' => true, 'product' => $prod], JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode(['status' => false]);
            }
            exit();
        }
        $items = $pm->getFilteredProducts(['keyword' => $kw, 'sort' => 'newest'], 1, 6);
        $results = [];
        foreach ($items as $it) {
            $results[] = [
                'id'              => (int)$it['id'],
                'name'            => $it['name'],
                'slug'            => $it['slug'],
                'brand_name'      => $it['brand_name'] ?? 'Chính hãng',
                'thumbnail'       => $it['thumbnail'],
                'price_formatted' => format_money(!empty($it['sale_price']) ? $it['sale_price'] : $it['price']),
                'orig_formatted'  => (!empty($it['sale_price']) && $it['sale_price'] < $it['price']) ? format_money($it['price']) : '',
                'url'             => APP_URL . '/san-pham/' . $it['slug']
            ];
        }
        echo json_encode(['status' => true, 'items' => $results], JSON_UNESCAPED_UNICODE);
        exit();

    // API HỎI VÀ ĐÁP (Q&A THEO CELLPHONES)
    case (str_starts_with($route, 'api/faq') || (isset($_GET['route']) && str_starts_with($_GET['route'], 'api/faq'))):
        header('Content-Type: application/json; charset=UTF-8');
        verify_csrf_token();
        require_once __DIR__ . '/models/FaqModel.php';
        $faqModel = new FaqModel();
        $targetRoute = $_GET['route'] ?? $route;

        if ($targetRoute === 'api/faq/add') {
            $name = trim($_POST['author_name'] ?? '');
            $qText = trim($_POST['question'] ?? '');
            $phone = trim($_POST['author_phone'] ?? '');
            $pid = !empty($_POST['product_id']) ? (int)$_POST['product_id'] : null;
            $uid = current_user_id();

            if (empty($name) || empty($qText)) {
                echo json_encode(['status' => false, 'message' => 'Vui lòng nhập tên và nội dung câu hỏi.']);
                exit();
            }

            $newId = $faqModel->addQuestion($name, $qText, $phone, $pid, $uid);
            log_activity('ask_question', "Khách gửi câu hỏi: $qText", $newId);
            echo json_encode(['status' => ($newId > 0), 'message' => 'Đã gửi câu hỏi thành công!']);
            exit();
        }

        if ($targetRoute === 'api/faq/reply') {
            require_admin();
            $qid = (int)($_POST['question_id'] ?? 0);
            $rText = trim($_POST['reply_text'] ?? '');
            $uid = current_user_id();

            if ($qid <= 0 || empty($rText)) {
                echo json_encode(['status' => false, 'message' => 'Nội dung phản hồi không hợp lệ.']);
                exit();
            }

            $success = $faqModel->addReply($qid, $rText, $uid);
            log_activity('reply_question', "QTV trả lời câu hỏi #$qid", $qid);
            echo json_encode(['status' => $success, 'message' => 'Đã gửi phản hồi thành công!']);
            exit();
        }
        break;

    // C. Trang xác thực tài khoản (Đăng nhập, Đăng ký, Đăng xuất)
    case ($route === 'dang-nhap'):
    case ($route === 'dang-ky'):
    case ($route === 'dang-xuat'):
        if (file_exists(__DIR__ . '/controllers/AuthController.php')) {
            require_once __DIR__ . '/controllers/AuthController.php';
            $controller = new AuthController();
            if ($route === 'dang-nhap') $controller->login();
            elseif ($route === 'dang-ky') $controller->register();
            elseif ($route === 'dang-xuat') $controller->logout();
        } else {
            render_view('client/pages/login', ['pageTitle' => 'Đăng nhập tài khoản - LongTech']);
        }
        break;

    // D. Giỏ hàng & Thanh toán
    case (str_starts_with($route, 'gio-hang')):
    case ($route === 'thanh-toan'):
        require_once __DIR__ . '/controllers/CartController.php';
        $controller = new CartController();
        if ($route === 'gio-hang') $controller->index();
        elseif ($route === 'gio-hang/them') $controller->add();
        elseif ($route === 'gio-hang/cap-nhat') $controller->update();
        elseif ($route === 'gio-hang/xoa') $controller->delete();
        elseif ($route === 'gio-hang/coupon') $controller->applyCoupon();
        elseif ($route === 'gio-hang/xoa-coupon') $controller->removeCoupon();
        elseif ($route === 'thanh-toan') $controller->checkout();
        break;

    // E. Danh mục sản phẩm (8 ngành hàng + khuyen-mai, san-pham, tim-kiem)
    case in_array($route, ['dien-thoai', 'may-tinh-bang', 'laptop', 'phu-kien', 'dong-ho-thong-minh', 'am-thanh', 'gaming-gear', 'man-hinh-pc', 'khuyen-mai', 'san-pham', 'tim-kiem']):
        if (file_exists(__DIR__ . '/controllers/ProductController.php')) {
            require_once __DIR__ . '/controllers/ProductController.php';
            $controller = new ProductController();
            $controller->index($route);
        } else {
            set_flash('info', 'Trang danh mục sản phẩm đang được cập nhật.');
            redirect('/');
        }
        break;

    // F. Chi tiết sản phẩm & Đánh giá (/san-pham/{slug}, /san-pham/danh-gia)
    case (str_starts_with($route, 'san-pham/')):
        $slug = substr($route, strlen('san-pham/'));
        require_once __DIR__ . '/controllers/ProductController.php';
        $controller = new ProductController();
        if ($slug === 'danh-gia') {
            $controller->review();
        } else {
            $controller->detail($slug);
        }
        break;

    // G. Khu vực tài khoản cá nhân (/tai-khoan, /tai-khoan/don-hang, /tai-khoan/cai-dat)
    case (str_starts_with($route, 'tai-khoan')):
        require_once __DIR__ . '/controllers/UserController.php';
        $controller = new UserController();
        if ($route === 'tai-khoan/don-hang') {
            $controller->orders();
        } elseif ($route === 'tai-khoan/cai-dat' || $route === 'tai-khoan/doi-mat-khau') {
            $controller->settings();
        } else {
            $controller->dashboard();
        }
        break;

    // F2. HỖ TRỢ ĐƯỜNG DẪN DẠNG /{category_slug}/{product_slug} (VD: dien-thoai/iphone-15-pro-max-256gb)
    case (str_contains($route, '/') && count(explode('/', $route)) === 2 && in_array(explode('/', $route)[0], ['dien-thoai', 'may-tinh-bang', 'laptop', 'phu-kien', 'dong-ho-thong-minh', 'am-thanh', 'gaming-gear', 'man-hinh-pc', 'khuyen-mai'])):
        $parts = explode('/', $route);
        $prodSlug = $parts[1];
        require_once __DIR__ . '/controllers/ProductController.php';
        $controller = new ProductController();
        $controller->detail($prodSlug);
        break;

    // Quản trị viên LongTech (/admin hoặc /admin.php)
    case ($route === 'admin' || $route === 'admin.php'):
        require_once __DIR__ . '/admin.php';
        exit();

    // Trang Review & Tin tức công nghệ LongStudio (/tin-tuc và /tin-tuc/{slug})
    case ($route === 'tin-tuc' || str_starts_with($route, 'tin-tuc/')):
        require_once __DIR__ . '/models/ProductModel.php';
        $productModel = new ProductModel();
        $posts = $productModel->getLatestPosts(20);
        $featuredProducts = $productModel->getFeatured(8);
        $recentReviews = $productModel->getRecentProductReviews(6);
        $postSlug = '';
        $currentPost = null;

        if (str_starts_with($route, 'tin-tuc/')) {
            $postSlug = trim(substr($route, strlen('tin-tuc/')), '/');
            if ($postSlug !== '') {
                $currentPost = $productModel->getPostBySlug($postSlug);
            }
        }

        $pageTitle = $currentPost
            ? ($currentPost['title'] . ' | LongStudio Review')
            : 'LongStudio 🎥 - Chuyên Trang Review & Đánh Giá Sản Phẩm Công Nghệ | LongTech';

        render_view('client/pages/news', [
            'pageTitle'        => $pageTitle,
            'posts'            => $posts,
            'featuredProducts' => $featuredProducts,
            'recentReviews'    => $recentReviews,
            'currentPost'      => $currentPost,
            'postSlug'         => $postSlug
        ]);
        break;

    // Các trang Chính sách & Hướng dẫn ở Footer
    case in_array($route, ['chinh-sach-bao-hanh', 'chinh-sach-doi-tra', 'chinh-sach-van-chuyen', 'chinh-sach-bao-mat', 'huong-dan-tra-gop', 'tuyen-dung'], true):
        $policyMap = [
            'chinh-sach-bao-hanh' => [
                'title' => 'Chính Sách Bảo Hành Chính Hãng & Trung Tâm LongCare',
                'content' => '<p>100% sản phẩm bán ra tại <strong>LongTech</strong> đều là hàng chính hãng phân phối tại Việt Nam (VN/A), được hưởng chế độ bảo hành tiêu chuẩn từ <strong>12 đến 24 tháng</strong> tại hệ thống trung tâm ủy quyền LongCare toàn quốc.</p><ul><li><strong>Lỗi 1 đổi 1 trong 30 ngày đầu:</strong> Đổi ngay máy mới nguyên seal nếu phát sinh lỗi phần cứng từ nhà sản xuất.</li><li><strong>Hỗ trợ máy dùng tạm:</strong> Cung cấp thiết bị dùng thay thế miễn phí trong thời gian chờ bảo hành chính hãng.</li></ul>'
            ],
            'chinh-sach-doi-tra' => [
                'title' => 'Chính Sách Đổi Trả 1-1 Trong 30 Ngày',
                'content' => '<p>Khách hàng mua sắm tại <strong>LongTech</strong> được quyền đổi mới 1-1 miễn phí trong <strong>30 ngày đầu tiên</strong> nếu sản phẩm có lỗi kỹ thuật từ nhà sản xuất, hoặc hỗ trợ thu lại đổi sang dòng máy khác theo nhu cầu.</p>'
            ],
            'chinh-sach-van-chuyen' => [
                'title' => 'Chính Sách Giao Hàng Hỏa Tốc 2H & Thanh Toán Online',
                'content' => '<p>LongTech miễn phí giao hàng toàn quốc cho đơn hàng từ <strong>2.000.000đ</strong>. Nội thành Hà Nội & TP.HCM hỗ trợ giao siêu tốc trong vòng <strong>2 giờ</strong> kể từ khi xác nhận đơn hàng, cho phép đồng kiểm trước khi thanh toán.</p>'
            ],
            'chinh-sach-bao-mat' => [
                'title' => 'Chính Sách Bảo Mật Thông Tin Khách Hàng',
                'content' => '<p>Mọi thông tin cá nhân, lịch sử đơn hàng và dữ liệu thanh toán của quý khách tại <strong>LongTech</strong> đều được mã hóa bảo mật tuyệt đối và chỉ sử dụng cho mục đích chăm sóc khách hàng, bảo hành điện tử.</p>'
            ],
            'huong-dan-tra-gop' => [
                'title' => 'Hướng Dẫn Mua Hàng Trả Góp 0% Lãi Suất',
                'content' => '<p>LongTech hỗ trợ trả góp <strong>0% lãi suất</strong> qua thẻ tín dụng của hơn 25 ngân hàng hoặc duyệt hồ sơ nhanh qua CCCD gắn chip chỉ trong 15 phút, kỳ hạn linh hoạt từ 3 đến 12 tháng.</p>'
            ],
            'tuyen-dung' => [
                'title' => 'Cơ Hội Việc Làm & Tuyển Dụng Tại LongTech',
                'content' => '<p>Gia nhập đội ngũ trẻ trung, năng động tại <strong>LongTech</strong> ở các vị trí: Chuyên viên Tư vấn Công nghệ, Kỹ thuật viên LongCare, Reviewer LongStudio. Gửi CV trực tiếp về email: <strong>' . e(CONTACT_EMAIL) . '</strong>.</p>'
            ],
        ];
        $info = $policyMap[$route];
        render_view('client/pages/policy', [
            'pageTitle'     => $info['title'] . ' | LongTech',
            'policyTitle'   => $info['title'],
            'policyContent' => $info['content']
        ]);
        break;

    // Công cụ sửa lỗi dữ liệu và chuẩn hóa tiếng Việt thủ công nếu cần
    case ($route === 'fix-db' || $route === 'repair-db'):
        require_once __DIR__ . '/includes/repair_db.php';
        $res = repair_database_utf8($db);
        echo '<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><title>Chuẩn Hóa CSDL UTF-8 - LongTech</title></head>';
        echo '<body style="font-family:sans-serif;background:#0f172a;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:20px;">';
        echo '<div style="background:#1e293b;padding:40px;border-radius:16px;text-align:center;max-width:500px;box-shadow:0 10px 30px rgba(0,0,0,0.5);border-top:4px solid #16a34a;">';
        echo '<h2 style="color:#22c55e;margin-bottom:12px;">' . ($res ? '✔ Chuẩn Hóa CSDL UTF-8 Thành Công!' : '✖ Có lỗi khi nạp lại dữ liệu.') . '</h2>';
        echo '<p style="color:#94a3b8;line-height:1.6;margin-bottom:24px;">Toàn bộ bảng mã tiếng Việt, danh mục, sản phẩm và tài khoản mẫu (admin: <b>admin123</b> / customer: <b>123456</b>) đã sẵn sàng.</p>';
        echo '<a href="' . APP_URL . '" style="display:inline-block;padding:12px 28px;background:#D70018;color:#fff;border-radius:8px;text-decoration:none;font-weight:700;">Về Trang Chủ LongTech</a>';
        echo '</div></body></html>';
        exit();

    // H. Tuyến đường 404 Không tìm thấy trang
    default:
        http_response_code(404);
        ?>
        <!DOCTYPE html>
        <html lang="vi">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>404 - Không Tìm Thấy Trang | LongTech</title>
            <link rel="stylesheet" href="<?= ASSET_URL ?>/css/main.css">
        </head>
        <body style="display:flex;align-items:center;justify-content:center;min-height:100vh;text-align:center;background:#f8fafc;">
            <div style="background:#fff;padding:40px;border-radius:16px;box-shadow:0 10px 25px rgba(0,0,0,0.06);max-width:500px;">
                <div style="font-size:72px;font-weight:900;color:#0A2540;line-height:1;">404</div>
                <h2 style="font-size:20px;color:#D70018;margin:12px 0;">Không Tìm Thấy Trang</h2>
                <p style="color:#64748b;font-size:14px;margin-bottom:24px;">Địa chỉ bạn truy cập không tồn tại hoặc đã được thay đổi trên hệ thống LongTech.</p>
                <a href="<?= APP_URL ?>" style="display:inline-block;background:#0A2540;color:#fff;padding:12px 26px;border-radius:24px;font-weight:700;text-decoration:none;">Về Trang Chủ</a>
            </div>
        </body>
        </html>
        <?php
        break;
}

