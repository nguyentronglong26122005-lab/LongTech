@echo off
chcp 65001 >nul
echo ========================================================
echo  LONGTECH - TIẾN HÀNH SEED DỮ LIỆU TÀI KHOẢN & ĐƠN HÀNG
echo ========================================================
echo.
if exist "D:\XamPP\php\php.exe" (
    "D:\XamPP\php\php.exe" "E:\LongTech\scripts\seed_accounts.php"
) else (
    php "E:\LongTech\scripts\seed_accounts.php"
)
echo.
pause

