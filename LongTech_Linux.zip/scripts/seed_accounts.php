<?php
/**
 * ========================================================
 * LONGTECH - SCRIPT SEED DỮ LIỆU TÀI KHOẢN MẪU & ĐƠN HÀNG
 * Chạy được nhiều lần không sợ trùng lặp
 * Mật khẩu băm chuẩn BCRYPT 100%
 * ========================================================
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Database.php';

try {
    $db = Database::connect();
    echo "=== BẮT ĐẦU SEED DỮ LIỆU TÀI KHOẢN LONGTECH ===\n";

    // 1. Kiểm tra và thêm cột require_password_change vào users nếu chưa có
    try {
        $db->query("ALTER TABLE `users` ADD COLUMN `require_password_change` TINYINT(1) DEFAULT 0 AFTER `status`");
        echo "[+] Đã thêm cột `require_password_change` vào bảng `users`.\n";
    } catch (PDOException $e) {
        // Cột đã tồn tại, bỏ qua
    }

    // 2. Danh sách tài khoản mẫu cần seed
    $accounts = [
        [
            'role_id'   => 2, // admin
            'username'  => 'admin2',
            'email'     => 'admin2@longtech.vn',
            'password'  => 'Admin@12345',
            'full_name' => 'Trần Thị Thu Admin',
            'phone'     => '0981234567',
            'address'   => 'Tòa nhà LongTech, Cầu Giấy, Hà Nội',
            'req_change'=> 1
        ],
        [
            'role_id'   => 3, // product_manager
            'username'  => 'nvsanpham',
            'email'     => 'sanpham@longtech.vn',
            'password'  => 'Staff@12345',
            'full_name' => 'Lê Văn Kho (Sản Phẩm)',
            'phone'     => '0971234568',
            'address'   => 'Kho tổng LongTech, Mỹ Đình, Hà Nội',
            'req_change'=> 1
        ],
        [
            'role_id'   => 3, // product_manager
            'username'  => 'nvsanpham2',
            'email'     => 'sanpham2@longtech.vn',
            'password'  => 'Staff@12345',
            'full_name' => 'Nguyễn Thị Hàng (Sản Phẩm 2)',
            'phone'     => '0979876543',
            'address'   => 'Chi nhánh LongTech Đống Đa, Hà Nội',
            'req_change'=> 1
        ],
        [
            'role_id'   => 4, // order_manager
            'username'  => 'nvdonhang',
            'email'     => 'donhang@longtech.vn',
            'password'  => 'Staff@12345',
            'full_name' => 'Phạm Hoàng Giao (Đơn Hàng)',
            'phone'     => '0961234569',
            'address'   => 'Trung tâm điều vận LongTech, Hà Nội',
            'req_change'=> 1
        ],
        [
            'role_id'   => 4, // order_manager
            'username'  => 'nvdonhang2',
            'email'     => 'donhang2@longtech.vn',
            'password'  => 'Staff@12345',
            'full_name' => 'Đỗ Minh Vận (Đơn Hàng 2)',
            'phone'     => '0969876542',
            'address'   => 'Chi nhánh TP. Hồ Chí Minh',
            'req_change'=> 1
        ],
        [
            'role_id'   => 5, // customer
            'username'  => 'khach1',
            'email'     => 'khach1@gmail.com',
            'password'  => 'Customer@12345',
            'full_name' => 'Nguyễn Anh Tuấn',
            'phone'     => '0901234001',
            'address'   => 'Số 12 Kim Mã, Ba Đình, Hà Nội',
            'req_change'=> 1
        ],
        [
            'role_id'   => 5,
            'username'  => 'khach2',
            'email'     => 'khach2@gmail.com',
            'password'  => 'Customer@12345',
            'full_name' => 'Trần Thị Mai',
            'phone'     => '0901234002',
            'address'   => 'Số 88 Lê Lợi, Quận 1, TP. Hồ Chí Minh',
            'req_change'=> 1
        ],
        [
            'role_id'   => 5,
            'username'  => 'khach3',
            'email'     => 'khach3@gmail.com',
            'password'  => 'Customer@12345',
            'full_name' => 'Vũ Đình Trọng',
            'phone'     => '0901234003',
            'address'   => 'Số 25 Nguyễn Văn Linh, Hải Châu, Đà Nẵng',
            'req_change'=> 1
        ],
        [
            'role_id'   => 5,
            'username'  => 'khach4',
            'email'     => 'khach4@gmail.com',
            'password'  => 'Customer@12345',
            'full_name' => 'Hoàng Bích Phương',
            'phone'     => '0901234004',
            'address'   => 'Số 5 Lê Hồng Phong, Ngô Quyền, Hải Phòng',
            'req_change'=> 1
        ],
        [
            'role_id'   => 5,
            'username'  => 'khach5',
            'email'     => 'khach5@gmail.com',
            'password'  => 'Customer@12345',
            'full_name' => 'Đặng Quốc Huy',
            'phone'     => '0901234005',
            'address'   => 'Số 99 Hùng Vương, Ninh Kiều, Cần Thơ',
            'req_change'=> 1
        ],
    ];

    $checkStmt = $db->prepare("SELECT id FROM `users` WHERE `username` = :username OR `email` = :email LIMIT 1");
    $insertStmt = $db->prepare(
        "INSERT INTO `users` (`role_id`, `username`, `email`, `password`, `full_name`, `phone`, `address`, `status`, `require_password_change`, `created_at`)
         VALUES (:role_id, :username, :email, :password, :full_name, :phone, :address, 'active', :req_change, NOW())"
    );
    $updateStmt = $db->prepare(
        "UPDATE `users` SET `role_id` = :role_id, `password` = :password, `full_name` = :full_name, 
         `phone` = :phone, `address` = :address, `status` = 'active', `require_password_change` = :req_change
         WHERE `id` = :id"
    );

    foreach ($accounts as $acc) {
        $checkStmt->execute([':username' => $acc['username'], ':email' => $acc['email']]);
        $existing = $checkStmt->fetch(PDO::FETCH_ASSOC);
        $hashed = password_hash($acc['password'], PASSWORD_BCRYPT);

        if ($existing) {
            $updateStmt->execute([
                ':role_id'    => $acc['role_id'],
                ':password'   => $hashed,
                ':full_name'  => $acc['full_name'],
                ':phone'      => $acc['phone'],
                ':address'    => $acc['address'],
                ':req_change' => $acc['req_change'],
                ':id'         => $existing['id'],
            ]);
            echo "[Cập nhật] Tài khoản: {$acc['username']} ({$acc['email']}) - Role ID: {$acc['role_id']}\n";
        } else {
            $insertStmt->execute([
                ':role_id'    => $acc['role_id'],
                ':username'   => $acc['username'],
                ':email'      => $acc['email'],
                ':password'   => $hashed,
                ':full_name'  => $acc['full_name'],
                ':phone'      => $acc['phone'],
                ':address'    => $acc['address'],
                ':req_change' => $acc['req_change'],
            ]);
            echo "[Tạo mới]  Tài khoản: {$acc['username']} ({$acc['email']}) - Role ID: {$acc['role_id']}\n";
        }
    }

    // 3. Thêm đơn hàng mẫu thực tế cho khách hàng khach1 -> khach5
    echo "\n=== BẮT ĐẦU SEED ĐƠN HÀNG MẪU ===\n";
    $customerUsers = $db->query("SELECT id, full_name, phone, address FROM `users` WHERE `username` LIKE 'khach%'")->fetchAll(PDO::FETCH_ASSOC);
    $products = $db->query("SELECT id, name, price FROM `products` LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($customerUsers) && !empty($products)) {
        $statuses = ['pending', 'confirmed', 'processing', 'shipping', 'completed', 'cancelled'];
        $orderCheck = $db->prepare("SELECT id FROM `orders` WHERE `order_code` = :code LIMIT 1");
        $orderInsert = $db->prepare(
            "INSERT INTO `orders` (`user_id`, `order_code`, `total_amount`, `shipping_name`, `shipping_phone`, 
             `shipping_address`, `payment_method`, `payment_status`, `status`, `created_at`) 
             VALUES (:user_id, :order_code, :total_amount, :shipping_name, :shipping_phone, 
             :shipping_address, :payment_method, :payment_status, :status, :created_at)"
        );
        $itemInsert = $db->prepare(
            "INSERT INTO `order_items` (`order_id`, `product_id`, `product_name`, `price`, `quantity`, `subtotal`) 
             VALUES (:order_id, :product_id, :product_name, :price, :quantity, :subtotal)"
        );

        $sampleOrders = [
            ['code' => 'ORD-2026-001', 'user_idx' => 0, 'prod_idx' => 0, 'qty' => 1, 'status' => 'completed', 'days_ago' => 5],
            ['code' => 'ORD-2026-002', 'user_idx' => 1, 'prod_idx' => 1, 'qty' => 1, 'status' => 'shipping',  'days_ago' => 2],
            ['code' => 'ORD-2026-003', 'user_idx' => 2, 'prod_idx' => 2, 'qty' => 2, 'status' => 'processing','days_ago' => 1],
            ['code' => 'ORD-2026-004', 'user_idx' => 3, 'prod_idx' => 3, 'qty' => 1, 'status' => 'confirmed', 'days_ago' => 0],
            ['code' => 'ORD-2026-005', 'user_idx' => 4, 'prod_idx' => 0, 'qty' => 1, 'status' => 'pending',   'days_ago' => 0],
        ];

        foreach ($sampleOrders as $sOrd) {
            $orderCheck->execute([':code' => $sOrd['code']]);
            if ($orderCheck->fetch()) {
                echo "[Bỏ qua] Đơn hàng {$sOrd['code']} đã tồn tại.\n";
                continue;
            }

            $u = $customerUsers[$sOrd['user_idx'] % count($customerUsers)];
            $p = $products[$sOrd['prod_idx'] % count($products)];
            $total = (float)$p['price'] * $sOrd['qty'];
            $createdAt = date('Y-m-d H:i:s', strtotime("-{$sOrd['days_ago']} days"));

            $orderInsert->execute([
                ':user_id'          => $u['id'],
                ':order_code'       => $sOrd['code'],
                ':total_amount'     => $total,
                ':shipping_name'    => $u['full_name'],
                ':shipping_phone'   => $u['phone'],
                ':shipping_address' => $u['address'],
                ':payment_method'   => 'COD',
                ':payment_status'   => ($sOrd['status'] === 'completed') ? 'paid' : 'unpaid',
                ':status'           => $sOrd['status'],
                ':created_at'       => $createdAt
            ]);
            $orderId = (int)$db->lastInsertId();

            $itemInsert->execute([
                ':order_id'     => $orderId,
                ':product_id'   => $p['id'],
                ':product_name' => $p['name'],
                ':price'        => $p['price'],
                ':quantity'     => $sOrd['qty'],
                ':subtotal'     => $total
            ]);
            echo "[Tạo mới] Đơn hàng {$sOrd['code']} cho {$u['full_name']} ({$sOrd['status']})\n";
        }
    }

    echo "\n>>> HOÀN TẤT SEED DỮ LIỆU THÀNH CÔNG 100%! <<<\n";
} catch (Exception $e) {
    echo "\n[!] LỖI TRONG QUÁ TRÌNH SEED: " . $e->getMessage() . "\n";
}

