<?php
/**
 * ========================================================
 * LONGTECH - FILE KHỞI TẠO VÀ CẤU HÌNH HỆ THỐNG (config.php)
 * ========================================================
 * - Đọc và nạp các biến môi trường từ file .env
 * - Thiết lập múi giờ Việt Nam, mã hóa UTF-8
 * - Cấu hình bảo mật Session (HttpOnly, SameSite)
 * - Định nghĩa hằng số đường dẫn và thông số hệ thống
 */

// 1. Thiết lập múi giờ chuẩn Việt Nam
date_default_timezone_set('Asia/Ho_Chi_Minh');

// 2. Thiết lập cấu hình Session an toàn
if (session_status() === PHP_SESSION_NONE) {
    // Ngăn chặn JavaScript đọc session cookie (Chống tấn công XSS đánh cắp session)
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    
    // Thiết lập cookie params an toàn
    session_set_cookie_params([
        'lifetime' => 86400 * 7, // 7 ngày
        'path'     => '/',
        'domain'   => '',
        'secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    
    session_start();
}

// 3. Hàm phân tích và đọc file .env thủ công bằng PHP thuần
function loadEnv($envPath) {
    if (!file_exists($envPath)) {
        return;
    }

    $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        // Bỏ qua dòng ghi chú hoặc dòng rỗng
        if (empty($line) || strpos($line, '#') === 0) {
            continue;
        }

        // Tách khóa và giá trị qua dấu =
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);

            // Loại bỏ dấu ngoặc kép hoặc đơn nếu có
            if ((str_starts_with($value, '"') && str_ends_with($value, '"')) ||
                (str_starts_with($value, "'") && str_ends_with($value, "'"))) {
                $value = substr($value, 1, -1);
            }

            // Gán vào $_ENV và biến môi trường
            if (!array_key_exists($key, $_ENV)) {
                $_ENV[$key] = $value;
                putenv("$key=$value");
            }
        }
    }
}

// Nạp file .env
loadEnv(__DIR__ . '/.env');

// Hàm lấy giá trị biến môi trường có giá trị mặc định fallback
function env($key, $default = null) {
    return $_ENV[$key] ?? getenv($key) ?: $default;
}

// 4. Định nghĩa các hằng số ứng dụng
define('APP_NAME', env('APP_NAME', 'LongTech'));
define('APP_ENV', env('APP_ENV', 'local'));
define('APP_DEBUG', filter_var(env('APP_DEBUG', true), FILTER_VALIDATE_BOOLEAN));
define('APP_URL', rtrim(env('APP_URL', 'http://localhost/LongTech'), '/'));

// Cấu hình hiển thị lỗi PHP theo chế độ debug
if (APP_DEBUG) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(0);
}

// 5. Cấu hình kết nối Cơ sở dữ liệu
define('DB_HOST', env('DB_HOST', '127.0.0.1'));
define('DB_PORT', env('DB_PORT', '3306'));
define('DB_NAME', env('DB_NAME', 'longtech'));
define('DB_USER', env('DB_USER', 'root'));
define('DB_PASS', env('DB_PASS', ''));
define('DB_CHARSET', env('DB_CHARSET', 'utf8mb4'));

// 6. Cấu hình vận chuyển và kinh doanh
define('SHIPPING_FEE', (int) env('SHIPPING_FEE', 30000)); // 30.000 VNĐ
define('FREE_SHIPPING_MIN', (int) env('FREE_SHIPPING_MIN', 2000000)); // Đơn từ 2.000.000 VNĐ miễn ship
define('HOTLINE', env('HOTLINE', '1900 6868'));
define('CONTACT_EMAIL', env('CONTACT_EMAIL', 'support@longtech.vn'));
define('STORE_ADDRESS', env('STORE_ADDRESS', 'Số 123 Đường Công Nghệ, Quận Cầu Giấy, Hà Nội'));

// 7. Định nghĩa đường dẫn tuyệt đối cho hệ thống thư mục
define('ROOT_PATH', __DIR__);
define('VIEW_PATH', ROOT_PATH . '/views');
define('CONTROLLER_PATH', ROOT_PATH . '/controllers');
define('MODEL_PATH', ROOT_PATH . '/models');
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('UPLOAD_PATH', ROOT_PATH . '/assets/uploads');
define('UPLOAD_URL', APP_URL . '/assets/uploads');
define('ASSET_URL', APP_URL . '/assets');

// Tự động tạo thư mục uploads nếu chưa tồn tại
if (!is_dir(UPLOAD_PATH)) {
    @mkdir(UPLOAD_PATH, 0755, true);
}

