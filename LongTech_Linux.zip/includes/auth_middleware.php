<?php
/**
 * ========================================================
 * LONGTECH - MIDDLEWARE XÁC THỰC VÀ PHÂN QUYỀN (auth_middleware.php)
 * ========================================================
 * Quản lý và kiểm tra quyền truy cập 5 vai trò hệ thống:
 * 1. Super Admin   (super_admin)     : Toàn quyền cao nhất
 * 2. Admin         (admin)           : Quản trị nội dung, sản phẩm, đơn hàng, user
 * 3. NV Sản phẩm   (product_manager) : Quản lý kho, thêm/sửa sản phẩm
 * 4. NV Đơn hàng   (order_manager)   : Xử lý và cập nhật đơn hàng
 * 5. Khách hàng    (customer)        : Mua hàng, xem đơn cá nhân, đổi thông tin
 * 
 * BẢO MẬT: Mọi trang admin kiểm tra quyền ở phía server,
 * Customer TUYỆT ĐỐI không được truy cập vào khu vực quản trị.
 */

if (!defined('ROOT_PATH')) {
    require_once __DIR__ . '/../config.php';
}
if (!function_exists('is_logged_in')) {
    require_once __DIR__ . '/functions.php';
}

/**
 * 1. Bắt buộc người dùng phải đăng nhập mới được tiếp tục
 * Nếu chưa đăng nhập, lưu lại URL dự định truy cập và chuyển hướng về trang Đăng nhập
 */
function require_login() {
    if (!is_logged_in()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        set_flash('error', 'Vui lòng đăng nhập để tiếp tục thao tác.');
        redirect('/dang-nhap');
    }
}

/**
 * 2. Bắt buộc là khách vãng lai (Guest) - Dùng cho trang Đăng nhập / Đăng ký
 * Nếu đã đăng nhập rồi mà cố vào /dang-nhap hoặc /dang-ky thì chuyển về Trang chủ
 */
function require_guest() {
    if (is_logged_in()) {
        $user = current_user();
        if (in_array($user['role_name'] ?? '', ['super_admin', 'admin', 'product_manager', 'order_manager'])) {
            redirect('/admin.php');
        } else {
            redirect('/tai-khoan');
        }
    }
}

/**
 * 3. Bắt buộc có quyền vào khu vực Quản trị Admin
 * Chặn TUYỆT ĐỐI vai trò customer (khách hàng)
 */
function require_admin() {
    require_login();

    $allowedRoles = ['super_admin', 'admin', 'product_manager', 'order_manager'];
    $currentRole = current_role();

    if (!in_array($currentRole, $allowedRoles, true)) {
        // Chặn khách hàng và ghi nhận phản hồi 403 Forbidden
        http_response_code(403);
        ?>
        <!DOCTYPE html>
        <html lang="vi">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>403 - Quyền Truy Cập Bị Từ Chối | LongTech</title>
            <link rel="stylesheet" href="<?= ASSET_URL ?>/css/main.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
        </head>
        <body style="display:flex;align-items:center;justify-content:center;min-height:100vh;background:#f1f5f9;font-family:'Inter',sans-serif;">
            <div style="background:#fff;border-radius:16px;padding:40px;max-width:520px;text-align:center;box-shadow:0 10px 25px rgba(0,0,0,0.1);border-top:6px solid #D70018;">
                <div style="width:64px;height:64px;background:#fee2e2;color:#D70018;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:30px;margin-bottom:16px;">
                    <i class="fa-solid fa-ban"></i>
                </div>
                <h2 style="color:#0A2540;font-size:22px;margin-bottom:8px;">Quyền Truy Cập Bị Từ Chối (403)</h2>
                <p style="color:#64748b;font-size:14px;line-height:1.6;margin-bottom:24px;">
                    Tài khoản của bạn là <strong>Khách hàng (Customer)</strong>. Bạn tuyệt đối không có quyền truy cập vào bảng điều khiển quản trị LongTech.
                </p>
                <div style="display:flex;gap:12px;justify-content:center;">
                    <a href="<?= APP_URL ?>" style="display:inline-block;padding:10px 20px;background:#0A2540;color:#fff;border-radius:8px;font-weight:600;text-decoration:none;">Về Trang Chủ</a>
                    <a href="<?= APP_URL ?>/dang-xuat" style="display:inline-block;padding:10px 20px;background:#e2e8f0;color:#334155;border-radius:8px;font-weight:600;text-decoration:none;">Đăng Xuất</a>
                </div>
            </div>
        </body>
        </html>
        <?php
        exit();
    }
}

/**
 * 4. Kiểm tra nhóm quyền cụ thể theo từng phân hệ quản trị
 * @param array|string $roles Danh sách các quyền được phép
 */
function require_roles($roles) {
    require_admin();

    $roles = is_array($roles) ? $roles : [$roles];
    $currentRole = current_role();

    // Super Admin có toàn quyền ở mọi phân hệ
    if ($currentRole === 'super_admin') {
        return true;
    }

    if (!in_array($currentRole, $roles, true)) {
        set_flash('error', 'Bạn không có đặc quyền để thực hiện hành động này.');
        redirect('/admin.php');
    }

    return true;
}

/**
 * 5. Bắt buộc quyền Super Admin cao nhất
 */
function require_super_admin() {
    require_roles(['super_admin']);
}

