<?php
/**
 * ========================================================
 * LONGTECH - DANH SÁCH BỘ PHẬN VÀ PHÂN QUYỀN CHỨC NĂNG (includes/site_content.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

/**
 * 12 Bộ phận chuyên trách tương ứng 12 vai trò quản lý trong hệ thống
 */
function get_departments(): array
{
    return [
        'dept_dieu_hanh' => [
            'key'         => 'dept_dieu_hanh',
            'perm_key'    => 'perm_dieu_hanh',
            'group'       => 'core',
            'name'        => 'Bộ phận Quản lý & Điều hành',
            'short'       => 'Điều hành & Chiến lược',
            'lead'        => 'Ban Giám đốc (CEO)',
            'icon'        => 'fa-chess-king',
            'color'       => '#0A2540',
            'bg'          => '#e2e8f0',
            'email'       => 'ceo@longtech.vn',
            'summary'     => 'Xây dựng chiến lược, kế hoạch kinh doanh, quản lý ngân sách và quyết định định hướng sản phẩm, thị trường.',
            'tasks'       => [
                'Xây dựng <strong>chiến lược, kế hoạch kinh doanh</strong> và định hướng phát triển website.',
                'Quản lý <strong>ngân sách</strong>, phân bổ nguồn lực và giám sát vận hành tổng thể.',
                'Đưa ra <strong>quyết định quan trọng</strong> về sản phẩm, ngành hàng và mở rộng thị trường.',
                'Duyệt các đề xuất cấp cao và phê duyệt thao tác quản trị toàn hệ thống.'
            ],
            'kpis'        => ['Tăng trưởng doanh thu', 'Hiệu quả ngân sách', 'Chỉ số ROI']
        ],
        'dept_cong_nghe' => [
            'key'         => 'dept_cong_nghe',
            'perm_key'    => 'perm_cong_nghe',
            'group'       => 'core',
            'name'        => 'Bộ phận Công nghệ (IT & Phát triển Web)',
            'short'       => 'IT & Phát triển Web',
            'lead'        => 'Giám đốc Công nghệ (CTO)',
            'icon'        => 'fa-laptop-code',
            'color'       => '#2563eb',
            'bg'          => '#eff6ff',
            'email'       => 'it@longtech.vn',
            'summary'     => 'Thiết kế UI/UX, quản trị máy chủ, cơ sở dữ liệu, bảo mật HTTPS, xác thực an toàn, phát hiện gian lận và tối ưu website.',
            'tasks'       => [
                'Thiết kế và phát triển giao diện người dùng <strong>(UI/UX)</strong> và Live Editor.',
                'Quản lý <strong>hệ thống máy chủ, cơ sở dữ liệu</strong>, sao lưu định kỳ.',
                'Đảm bảo <strong>bảo mật (mã hóa HTTPS, CSRF token, phát hiện gian lận)</strong>.',
                'Đảm bảo website <strong>ổn định, tải nhanh và responsive</strong> trên mọi thiết bị.',
                'Tích hợp <strong>thanh toán trực tuyến</strong> và đồng bộ dữ liệu kỹ thuật.'
            ],
            'kpis'        => ['Uptime ≥ 99.9%', 'Tốc độ tải < 2s', 'An toàn bảo mật 100%']
        ],
        'dept_kinh_doanh' => [
            'key'         => 'dept_kinh_doanh',
            'perm_key'    => 'perm_kinh_doanh',
            'group'       => 'core',
            'name'        => 'Bộ phận Kinh doanh & Tiếp thị (Sales & Marketing)',
            'short'       => 'Kinh doanh & Marketing',
            'lead'        => 'Trưởng phòng Marketing (CMO)',
            'icon'        => 'fa-bullhorn',
            'color'       => '#db2777',
            'bg'          => '#fdf2f8',
            'email'       => 'marketing@longtech.vn',
            'summary'     => 'Triển khai chiến dịch tiếp thị số (SEO, SEM, mạng xã hội, email marketing), nghiên cứu thị trường, chạy khuyến mãi.',
            'tasks'       => [
                'Triển khai tiếp thị số: <strong>SEO, SEM, quảng cáo mạng xã hội, email marketing</strong>.',
                '<strong>Nghiên cứu thị trường</strong>, đối thủ cạnh tranh, xây dựng thương hiệu LongTech.',
                'Thiết lập và quản lý <strong>chương trình khuyến mãi, Flash Sale, mã giảm giá (Coupons)</strong>.',
                'Theo dõi tỷ lệ chuyển đổi và tăng trưởng doanh số bán lẻ.'
            ],
            'kpis'        => ['Lượt tiếp cận chiến dịch', 'Tỷ lệ chuyển đổi đơn', 'Doanh thu chiến dịch']
        ],
        'dept_cskh' => [
            'key'         => 'dept_cskh',
            'perm_key'    => 'perm_cskh',
            'group'       => 'core',
            'name'        => 'Bộ phận Chăm sóc khách hàng (CSKH)',
            'short'       => 'CSKH & Hỗ trợ',
            'lead'        => 'Trưởng bộ phận CSKH',
            'icon'        => 'fa-headset',
            'color'       => '#D70018',
            'bg'          => '#fef2f2',
            'email'       => 'cskh@longtech.vn',
            'summary'     => 'Giải đáp thắc mắc đa kênh, xử lý khiếu nại, đổi trả, vận hành trung tâm FAQ giải đáp tự động cho khách.',
            'tasks'       => [
                'Giải đáp thắc mắc qua <strong>email, chat trực tuyến, hotline 1800.2097</strong>.',
                'Hỗ trợ khách hàng <strong>trước, trong và sau khi mua hàng</strong>.',
                '<strong>Xử lý khiếu nại, đổi trả sản phẩm</strong> và cung cấp thông tin chi tiết.',
                'Vận hành <strong>trang FAQ và mục Hỏi & Đáp</strong> giúp khách tự giải đáp nhanh chóng.'
            ],
            'kpis'        => ['Phản hồi < 5 phút', 'Độ hài lòng CSAT ≥ 96%', 'Giải quyết khiếu nại < 24h']
        ],
        'dept_kho_van' => [
            'key'         => 'dept_kho_van',
            'perm_key'    => 'perm_kho_van',
            'group'       => 'ops',
            'name'        => 'Bộ phận Kho vận & Giao nhận (Logistics)',
            'short'       => 'Kho vận & Giao nhận',
            'lead'        => 'Trưởng phòng Kho vận',
            'icon'        => 'fa-warehouse',
            'color'       => '#0891b2',
            'bg'          => '#ecfeff',
            'email'       => 'logistics@longtech.vn',
            'summary'     => 'Quản lý kho hàng, nhập xuất, đóng gói, theo dõi đơn vận chuyển và điều phối giao hàng nhanh 2H.',
            'tasks'       => [
                'Kiểm đếm nhập xuất hàng hoá, quản lý <strong>hàng tồn kho thực tế</strong>.',
                'Đóng gói tiêu chuẩn chống va đập, <strong>điều phối giao hàng hỏa tốc 2H</strong>.',
                'Cập nhật <strong>trạng thái vận chuyển đơn hàng</strong> (Đang giao, Đã giao, Trả hàng).',
                'Phối hợp các đối tác vận chuyển liên tỉnh (GHTK, ViettelPost, GHN).'
            ],
            'kpis'        => ['Giao đúng hẹn ≥ 98%', 'Tỷ lệ hàng hoàn < 2%', 'Chính xác tồn kho 99.8%']
        ],
        'dept_mua_hang' => [
            'key'         => 'dept_mua_hang',
            'perm_key'    => 'perm_mua_hang',
            'group'       => 'ops',
            'name'        => 'Bộ phận Mua hàng & Quản lý ngành hàng',
            'short'       => 'Mua hàng & Sản phẩm',
            'lead'        => 'Trưởng phòng Mua hàng (Category Manager)',
            'icon'        => 'fa-boxes-stacked',
            'color'       => '#ea580c',
            'bg'          => '#fff7ed',
            'email'       => 'purchasing@longtech.vn',
            'summary'     => 'Đàm phán giá nhập từ hãng chính hãng (Apple, Samsung, Sony...), định giá bán và quản lý danh mục sản phẩm.',
            'tasks'       => [
                'Tìm kiếm và làm việc với các nhà phân phối chính hãng uy tín.',
                'Đàm phán chính sách giá nhập tốt nhất, cân đối <strong>giá bán lẻ & giá khuyến mãi</strong>.',
                'Thêm mới, cập nhật <strong>danh mục và thông số sản phẩm</strong> trên website.',
                'Dự báo xu hướng công nghệ để nhập các sản phẩm HOT kịp thời.'
            ],
            'kpis'        => ['Biên lợi nhuận gộp', 'Vòng quay tồn kho', 'Đa dạng 8 ngành hàng']
        ],
        'dept_ky_thuat' => [
            'key'         => 'dept_ky_thuat',
            'perm_key'    => 'perm_ky_thuat',
            'group'       => 'ops',
            'name'        => 'Bộ phận Kỹ thuật & Bảo hành (LongCare)',
            'short'       => 'Kỹ thuật & Bảo hành',
            'lead'        => 'Trưởng trung tâm LongCare',
            'icon'        => 'fa-screwdriver-wrench',
            'color'       => '#7c3aed',
            'bg'          => '#f5f3ff',
            'email'       => 'longcare@longtech.vn',
            'summary'     => 'Tiếp nhận bảo hành, thẩm định kỹ thuật 1 đổi 1 trong 30 ngày, sửa chữa và định giá máy thu cũ đổi mới.',
            'tasks'       => [
                'Tiếp nhận thiết bị bảo hành chính hãng từ khách hàng.',
                'Kiểm định lỗi phần cứng từ nhà sản xuất để <strong>đổi máy mới 1-1 trong 30 ngày</strong>.',
                'Vận hành tiện ích <strong>Định giá máy chuyên sâu (Thu cũ đổi mới 2 phút)</strong>.',
                'Cung cấp máy dùng tạm cho khách trong thời gian gửi hãng bảo dưỡng.'
            ],
            'kpis'        => ['Thời gian thẩm định < 30 phút', 'Tỷ lệ hài lòng kỹ thuật ≥ 98%']
        ],
        'dept_noi_dung' => [
            'key'         => 'dept_noi_dung',
            'perm_key'    => 'perm_noi_dung',
            'group'       => 'ops',
            'name'        => 'Bộ phận Nội dung & Truyền thông (LongStudio)',
            'short'       => 'Review & Truyền thông',
            'lead'        => 'Trưởng ban Biên tập LongStudio',
            'icon'        => 'fa-video',
            'color'       => '#e11d48',
            'bg'          => '#fff1f2',
            'email'       => 'studio@longtech.vn',
            'summary'     => 'Sản xuất bài viết review, video mở hộp, chụp ảnh sản phẩm HD và quản lý chuyên trang công nghệ LongStudio.',
            'tasks'       => [
                'Viết bài <strong>đánh giá, so sánh, mẹo công nghệ</strong> trên chuyên trang LongStudio.',
                'Chụp ảnh sản phẩm HD chân thực, làm đồ họa banner bắt mắt.',
                'Quản trị hệ sinh thái kênh truyền thông: YouTube, TikTok, Fanpage LongTech.',
                'Biên tập mô tả sản phẩm chi tiết, trung thực và chuẩn SEO.'
            ],
            'kpis'        => ['Lượt đọc bài review', 'Lượt xem video unbox', 'Traffic tự nhiên']
        ],
        'dept_ke_toan' => [
            'key'         => 'dept_ke_toan',
            'perm_key'    => 'perm_ke_toan',
            'group'       => 'support',
            'name'        => 'Bộ phận Tài chính – Kế toán',
            'short'       => 'Tài chính & Kế toán',
            'lead'        => 'Kế toán trưởng (CFO)',
            'icon'        => 'fa-file-invoice-dollar',
            'color'       => '#16a34a',
            'bg'          => '#f0fdf4',
            'email'       => 'ketoan@longtech.vn',
            'summary'     => 'Đối soát thanh toán online, hóa đơn điện tử VAT, theo dõi dòng tiền và xử lý hoàn tiền trả hàng.',
            'tasks'       => [
                '<strong>Đối soát thanh toán online</strong> với cổng VNPAY, MoMo, ZaloPay, OnePay.',
                'Xuất <strong>hóa đơn điện tử VAT</strong> theo yêu cầu của khách hàng cá nhân và doanh nghiệp.',
                'Xử lý thủ tục <strong>hoàn tiền nhanh</strong> cho các đơn đổi trả hoặc huỷ đơn hợp lệ.',
                'Theo dõi thu chi, công nợ nhà cung cấp và lập báo cáo tài chính.'
            ],
            'kpis'        => ['Khớp số đối soát 100%', 'Xuất hóa đơn trong ngày', 'Hoàn tiền < 48h']
        ],
        'dept_nhan_su' => [
            'key'         => 'dept_nhan_su',
            'perm_key'    => 'perm_nhan_su',
            'group'       => 'support',
            'name'        => 'Bộ phận Nhân sự & Đào tạo (HR)',
            'short'       => 'Nhân sự & Đào tạo',
            'lead'        => 'Trưởng phòng Nhân sự',
            'icon'        => 'fa-users-gear',
            'color'       => '#9333ea',
            'bg'          => '#faf5ff',
            'email'       => 'tuyendung@longtech.vn',
            'summary'     => 'Tuyển dụng nhân sự công nghệ, đào tạo kỹ năng tư vấn bán hàng, quản lý hồ sơ nhân sự các bộ phận.',
            'tasks'       => [
                'Đăng tin tuyển dụng và phỏng vấn nhân sự cho các bộ phận.',
                'Tổ chức <strong>đào tạo kiến thức sản phẩm mới</strong> và kỹ năng dịch vụ khách hàng.',
                'Quản lý hồ sơ, KPI và chế độ đãi ngộ cho đội ngũ nhân sự LongTech.',
                'Xây dựng văn hóa làm việc chuyên nghiệp, tận tâm vì khách hàng.'
            ],
            'kpis'        => ['Đúng hạn tuyển dụng', 'Tỷ lệ hoàn thành đào tạo 100%']
        ],
        'dept_du_lieu' => [
            'key'         => 'dept_du_lieu',
            'perm_key'    => 'perm_du_lieu',
            'group'       => 'support',
            'name'        => 'Bộ phận Phân tích dữ liệu (Data & BI)',
            'short'       => 'Dữ liệu & Báo cáo',
            'lead'        => 'Trưởng nhóm Dữ liệu & BI',
            'icon'        => 'fa-chart-pie',
            'color'       => '#0d9488',
            'bg'          => '#f0fdfa',
            'email'       => 'data@longtech.vn',
            'summary'     => 'Xây dựng báo cáo doanh thu, phân tích xu hướng mua sắm của khách, tối ưu trải nghiệm và đưa ra dự báo kinh doanh.',
            'tasks'       => [
                'Xây dựng <strong>báo cáo doanh thu, đơn hàng, khách hàng</strong> theo thời gian thực.',
                'Phân tích hành vi duyệt web để tối ưu trải nghiệm mua sắm.',
                'Đề xuất <strong>sản phẩm gợi ý liên quan</strong> dựa trên dữ liệu người dùng.',
                'Dự báo sản phẩm bán chạy để tối ưu kế hoạch tồn kho.'
            ],
            'kpis'        => ['Báo cáo chính xác 100%', 'Khuyến nghị tăng trưởng chuyển đổi']
        ],
        'dept_phap_che' => [
            'key'         => 'dept_phap_che',
            'perm_key'    => 'perm_phap_che',
            'group'       => 'support',
            'name'        => 'Bộ phận Pháp chế & Kiểm soát chất lượng',
            'short'       => 'Pháp chế & Chất lượng',
            'lead'        => 'Trưởng ban Pháp chế',
            'icon'        => 'fa-scale-balanced',
            'color'       => '#475569',
            'bg'          => '#f8fafc',
            'email'       => 'phapche@longtech.vn',
            'summary'     => 'Đảm bảo website tuân thủ quy định thương mại điện tử Bộ Công Thương, bảo vệ dữ liệu cá nhân khách hàng.',
            'tasks'       => [
                'Soạn thảo và giám sát <strong>Chính sách bảo mật, Quy chế sàn TMĐT, Điều khoản sử dụng</strong>.',
                'Làm việc với cơ quan quản lý (Đăng ký Website với Bộ Công Thương, chứng nhận DMCA).',
                'Kiểm soát tính pháp lý hợp đồng đối tác, nhãn mác hóa đơn sản phẩm.',
                'Bảo đảm tuân thủ Nghị định bảo vệ dữ liệu cá nhân người dùng.'
            ],
            'kpis'        => ['100% tuân thủ pháp luật', '0 sự cố tranh chấp pháp lý']
        ]
    ];
}

/**
 * Trả về danh sách câu hỏi thường gặp (FAQ)
 */
function get_faq_items(): array
{
    $hotline = HOTLINE;
    $freeShip = format_money(FREE_SHIPPING_MIN);

    return [
        'dat-hang' => [
            'label' => 'Đặt hàng & Thanh toán',
            'icon'  => 'fa-cart-shopping',
            'items' => [
                ['q' => 'Làm thế nào để đặt hàng trên LongTech?', 'a' => 'Chọn sản phẩm → bấm <strong>Mua ngay</strong> hoặc <strong>Thêm vào giỏ</strong> → vào Giỏ hàng → <strong>Thanh toán</strong>, điền thông tin nhận hàng và chọn phương thức thanh toán. Bạn có thể đặt hàng không cần tài khoản, nhưng đăng nhập sẽ giúp theo dõi đơn dễ hơn.'],
                ['q' => 'LongTech hỗ trợ những phương thức thanh toán nào?', 'a' => 'Thanh toán khi nhận hàng (COD), chuyển khoản ngân hàng, ví điện tử <strong>MoMo, ZaloPay, VNPAY-QR</strong>, thẻ ATM nội địa, thẻ Visa/Master/JCB và Apple Pay.'],
                ['q' => 'Thanh toán online có an toàn không?', 'a' => 'Có. Website sử dụng <strong>mã hóa HTTPS</strong>, LongTech không lưu thông tin thẻ của bạn — mọi giao dịch được xử lý trực tiếp qua cổng thanh toán đạt chuẩn bảo mật PCI DSS.'],
                ['q' => 'Tôi có thể huỷ hoặc thay đổi đơn hàng đã đặt không?', 'a' => 'Bạn có thể huỷ/thay đổi miễn phí khi đơn còn ở trạng thái <strong>Chờ xác nhận</strong> trong mục <a href="' . APP_URL . '/tai-khoan/don-hang">Đơn hàng của tôi</a>, hoặc gọi hotline ' . $hotline . '.'],
                ['q' => 'Làm sao để áp dụng mã giảm giá?', 'a' => 'Tại trang Giỏ hàng, nhập mã vào ô <strong>Mã giảm giá</strong> và bấm Áp dụng. Mỗi đơn hàng áp dụng 1 mã; mã có điều kiện về giá trị đơn và thời hạn sử dụng.']
            ]
        ],
        'giao-hang' => [
            'label' => 'Giao hàng & Vận chuyển',
            'icon'  => 'fa-truck-fast',
            'items' => [
                ['q' => 'Phí giao hàng được tính như thế nào?', 'a' => 'Miễn phí giao hàng toàn quốc cho đơn từ <strong>' . $freeShip . '</strong>. Đơn dưới mức này phí sẽ hiển thị tự động ở bước thanh toán.'],
                ['q' => 'Bao lâu tôi nhận được hàng?', 'a' => 'Nội thành Hà Nội &amp; TP.HCM: <strong>giao hỏa tốc 2H</strong>. Các tỉnh thành khác: 1–3 ngày làm việc tuỳ khu vực.'],
                ['q' => 'Tôi có được kiểm tra hàng trước khi thanh toán?', 'a' => 'Có. Bạn được <strong>đồng kiểm</strong> ngoại quan sản phẩm (tem, seal, phụ kiện) trước khi thanh toán cho nhân viên giao hàng.'],
                ['q' => 'Làm sao để theo dõi tình trạng đơn hàng?', 'a' => 'Đăng nhập và vào <a href="' . APP_URL . '/tai-khoan/don-hang">Đơn hàng của tôi</a>, hoặc liên hệ hotline ' . $hotline . ' kèm mã đơn hàng.']
            ]
        ],
        'doi-tra' => [
            'label' => 'Đổi trả & Bảo hành',
            'icon'  => 'fa-arrows-rotate',
            'items' => [
                ['q' => 'Chính sách đổi trả của LongTech như thế nào?', 'a' => '<strong>Lỗi 1 đổi 1 trong 30 ngày</strong> nếu sản phẩm có lỗi phần cứng từ nhà sản xuất. Xem chi tiết tại <a href="' . APP_URL . '/chinh-sach-doi-tra">Chính sách đổi trả</a>.'],
                ['q' => 'Sản phẩm được bảo hành bao lâu?', 'a' => 'Bảo hành chính hãng <strong>12–24 tháng</strong> tuỳ sản phẩm tại trung tâm LongCare và trung tâm ủy quyền của hãng trên toàn quốc.'],
                ['q' => 'Khi bảo hành tôi có được hỗ trợ máy dùng tạm?', 'a' => 'Có. LongCare cung cấp <strong>máy dùng tạm miễn phí</strong> trong thời gian chờ bảo hành (áp dụng điện thoại & máy tính bảng).'],
                ['q' => 'Hoàn tiền mất bao lâu khi trả hàng?', 'a' => 'Bộ phận Kế toán hoàn tiền trong <strong>1–3 ngày làm việc</strong> với chuyển khoản/ví điện tử, 7–15 ngày với thẻ tín dụng tuỳ ngân hàng.'],
                ['q' => 'LongTech có thu cũ đổi mới không?', 'a' => 'Có. Bấm <strong>Định giá ngay</strong> ở chân trang để nhận báo giá thu mua dự kiến trong 2 phút, kèm trợ giá lên đời tới 3.000.000đ.']
            ]
        ],
        'tra-gop' => [
            'label' => 'Trả góp 0%',
            'icon'  => 'fa-credit-card',
            'items' => [
                ['q' => 'Điều kiện mua trả góp 0% là gì?', 'a' => 'Trả góp qua <strong>thẻ tín dụng</strong> của 25+ ngân hàng, hoặc qua công ty tài chính chỉ cần <strong>CCCD gắn chip</strong>, duyệt hồ sơ trong 15 phút.'],
                ['q' => 'Kỳ hạn trả góp linh hoạt thế nào?', 'a' => 'Kỳ hạn 3, 6, 9 hoặc 12 tháng. Xem chi tiết tại <a href="' . APP_URL . '/huong-dan-tra-gop">Hướng dẫn trả góp</a>.']
            ]
        ]
    ];
}
