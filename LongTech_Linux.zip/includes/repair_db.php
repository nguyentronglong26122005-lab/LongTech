<?php
/**
 * ========================================================
 * LONGTECH - TỰ ĐỘNG CHUẨN HÓA DỮ LIỆU UTF-8 & ẢNH GỐC CHO DATABASE
 * ========================================================
 */

function repair_database_utf8(?PDO $pdo = null): bool {
    if (!$pdo) {
        require_once __DIR__ . '/../models/Database.php';
        $pdo = Database::connect();
    }

    $sqlPath = dirname(__DIR__) . '/longtech.sql';
    if (!file_exists($sqlPath)) {
        return false;
    }

    $sql = file_get_contents($sqlPath);
    if (empty($sql)) {
        return false;
    }

    // Xóa toàn bộ các dòng comment SQL (-- ...) trước khi tách câu lệnh
    $sql = preg_replace('/^\s*--.*$/m', '', $sql);

    // Bỏ qua lệnh tạo Database và USE để dùng đúng database đang kết nối (freedb hoặc longtech)
    $sql = preg_replace('/CREATE DATABASE IF NOT EXISTS `[^`]+`[^;]*;/i', '', $sql);
    $sql = preg_replace('/USE `[^`]+`;/i', '', $sql);

    try {
        $pdo->exec("SET NAMES utf8mb4;");
        $pdo->exec("SET CHARACTER SET utf8mb4;");
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");

        // Sao lưu các tài khoản thành viên do người dùng đã tạo (id > 2) để không bị mất khi làm mới DB
        $savedUsers = [];
        try {
            $stmtUsers = $pdo->query("SELECT * FROM users WHERE id > 2");
            if ($stmtUsers) {
                $savedUsers = $stmtUsers->fetchAll(PDO::FETCH_ASSOC);
            }
        } catch (Throwable $e) {
            // Bảng chưa tồn tại
        }
        
        // Tách câu lệnh theo dấu ; ở cuối dòng để execute từng block an toàn
        $queries = preg_split('/;\s*[\r\n]+/', $sql);
        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                $pdo->exec($query);
            }
        }

        // Khôi phục các tài khoản thành viên đã tạo trước đó
        if (!empty($savedUsers)) {
            $ins = $pdo->prepare("
                INSERT IGNORE INTO users (id, role_id, permissions, username, email, password, full_name, phone, address, avatar, status, require_password_change, created_at)
                VALUES (:id, :role_id, :permissions, :username, :email, :password, :full_name, :phone, :address, :avatar, :status, :req_pw, :created_at)
            ");
            foreach ($savedUsers as $u) {
                $ins->execute([
                    ':id'          => $u['id'],
                    ':role_id'     => $u['role_id'] ?? 5,
                    ':permissions' => $u['permissions'] ?? null,
                    ':username'    => $u['username'],
                    ':email'       => $u['email'],
                    ':password'    => $u['password'],
                    ':full_name'   => $u['full_name'],
                    ':phone'       => $u['phone'] ?? null,
                    ':address'     => $u['address'] ?? null,
                    ':avatar'      => $u['avatar'] ?? null,
                    ':status'      => $u['status'] ?? 'active',
                    ':req_pw'      => $u['require_password_change'] ?? 0,
                    ':created_at'  => $u['created_at'] ?? date('Y-m-d H:i:s')
                ]);
            }
        }
        
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");
        return true;
    } catch (Throwable $e) {
        error_log("DB Repair Error: " . $e->getMessage());
        return false;
    }
}
