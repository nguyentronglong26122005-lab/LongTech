<?php
/**
 * ========================================================
 * LONGTECH - TỰ ĐỘNG CHUẨN HÓA DỮ LIỆU UTF-8 CHO CƠ SỞ DỮ LIỆU
 * ========================================================
 */

function repair_database_utf8(?PDO $pdo = null): bool {
    if (!$pdo) {
        require_once __DIR__ . '/../models/Database.php';
        $pdo = Database::connect();
    }

    $sqlPath = dirname(__DIR__) . '/longtech.sql';
    if (!file_exists($sqlPath)) {
        return false;
    }

    $sql = file_get_contents($sqlPath);
    if (empty($sql)) {
        return false;
    }

    // Bỏ qua lệnh tạo Database và USE để dùng đúng database đang kết nối (freedb hoặc longtech)
    $sql = preg_replace('/CREATE DATABASE IF NOT EXISTS `[^`]+`[^;]*;/i', '', $sql);
    $sql = preg_replace('/USE `[^`]+`;/i', '', $sql);

    try {
        $pdo->exec("SET NAMES utf8mb4;");
        $pdo->exec("SET CHARACTER SET utf8mb4;");
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");
        
        // Tách câu lệnh theo dấu ; ở cuối dòng để execute từng block an toàn
        $queries = preg_split('/;\s*[\r\n]+/', $sql);
        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query) && !str_starts_with($query, '--')) {
                $pdo->exec($query);
            }
        }
        
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");
        return true;
    } catch (Throwable $e) {
        error_log("DB Repair Error: " . $e->getMessage());
        return false;
    }
}
