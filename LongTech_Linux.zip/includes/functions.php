<?php
/**
 * ========================================================
 * LONGTECH - CÁC HÀM TIỆN ÍCH DÙNG CHUNG (functions.php)
 * ========================================================
 */

// Ngăn chặn truy cập nếu chưa có config
if (!defined('ROOT_PATH')) {
    require_once __DIR__ . '/../config.php';
}

/**
 * 1. Định dạng tiền tệ VNĐ (Chuẩn yêu cầu: 1.000.000đ)
 * Dấu chấm phân cách hàng nghìn, không số lẻ thập phân
 */
function format_money($amount) {
    $num = (float) $amount;
    return number_format($num, 0, ',', '.') . 'đ';
}

/**
 * 2. Làm sạch chuỗi chống tấn công XSS
 */
function sanitize($string) {
    if ($string === null) return '';
    return htmlspecialchars(trim((string)$string), ENT_QUOTES, 'UTF-8');
}

/**
 * Viết tắt hàm sanitize để xuất an toàn ra HTML: <?= e($var) ?>
 */
function e($string) {
    return sanitize($string);
}

/**
 * 3. Tạo và lấy Token chống tấn công CSRF
 */
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Tạo thẻ input ẩn chứa CSRF token chèn vào form HTML
 */
function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}

/**
 * Xác thực CSRF Token khi nhận POST request
 */
function verify_csrf_token($token = null) {
    $token = $token ?? ($_POST['csrf_token'] ?? '');
    if (empty($token) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        die('<div style="font-family:sans-serif;padding:30px;text-align:center;">
                <h2 style="color:#d70018;">Lỗi bảo mật (403 Forbidden)</h2>
                <p>CSRF Token không hợp lệ hoặc phiên làm việc đã hết hạn. Vui lòng thử lại!</p>
                <a href="' . APP_URL . '" style="display:inline-block;padding:10px 20px;background:#0a2540;color:#fff;text-decoration:none;border-radius:6px;">Về trang chủ</a>
             </div>');
    }
    return true;
}

/**
 * 4. Chuyển hướng trang (Redirect)
 */
function redirect($url) {
    if (!str_starts_with($url, 'http://') && !str_starts_with($url, 'https://')) {
        $url = APP_URL . '/' . ltrim($url, '/');
    }
    header("Location: $url");
    exit();
}

/**
 * 5. Quản lý thông báo tạm (Flash Message: success, error, warning, info)
 */
function set_flash($type, $message) {
    $_SESSION['flash'][$type] = $message;
}

function get_flash($type) {
    if (isset($_SESSION['flash'][$type])) {
        $message = $_SESSION['flash'][$type];
        unset($_SESSION['flash'][$type]);
        return $message;
    }
    return null;
}

function has_flash($type) {
    return isset($_SESSION['flash'][$type]);
}

/**
 * 6. Quản lý thông tin đăng nhập người dùng hiện tại
 */
function current_user() {
    return $_SESSION['user'] ?? null;
}

function is_logged_in() {
    return isset($_SESSION['user']) && !empty($_SESSION['user']['id']);
}

function current_user_id() {
    return $_SESSION['user']['id'] ?? null;
}

function current_role() {
    return $_SESSION['user']['role_name'] ?? null;
}

/**
 * Kiểm tra người dùng có quyền cụ thể hay không
 */
function has_role($roles) {
    if (!is_logged_in()) return false;
    $userRole = current_role();
    if (is_array($roles)) {
        return in_array($userRole, $roles, true);
    }
    return $userRole === $roles;
}

/**
 * 7. Hàm nạp View linh hoạt kèm truyền dữ liệu
 */
function render_view($viewPath, $data = [], $layout = true) {
    // Trích xuất biến từ mảng dữ liệu
    extract($data);
    $fullPath = VIEW_PATH . '/' . ltrim($viewPath, '/') . '.php';

    if (!file_exists($fullPath)) {
        die("View không tồn tại: " . htmlspecialchars($fullPath));
    }

    if ($layout) {
        // Nạp layout mặc định client
        require_once VIEW_PATH . '/client/layouts/header.php';
        require $fullPath;
        require_once VIEW_PATH . '/client/layouts/footer.php';
    } else {
        require $fullPath;
    }
}

/**
 * Nạp giao diện Quản trị viên (Admin View Layout)
 */
function render_admin_view($viewPath, $data = []) {
    extract($data);
    $fullPath = VIEW_PATH . '/' . ltrim($viewPath, '/') . '.php';

    if (!file_exists($fullPath)) {
        die("Admin View không tồn tại: " . htmlspecialchars($fullPath));
    }

    require_once VIEW_PATH . '/admin/layouts/header.php';
    require_once VIEW_PATH . '/admin/layouts/sidebar.php';
    require $fullPath;
    require_once VIEW_PATH . '/admin/layouts/footer.php';
}

/**
 * 8. Tạo chuỗi URL thân thiện (Slug) tiếng Việt
 */
function slugify($str) {
    $str = mb_strtolower($str, 'UTF-8');
    $str = preg_replace('/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/', 'a', $str);
    $str = preg_replace('/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/', 'e', $str);
    $str = preg_replace('/(ì|í|ị|ỉ|ĩ)/', 'i', $str);
    $str = preg_replace('/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/', 'o', $str);
    $str = preg_replace('/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/', 'u', $str);
    $str = preg_replace('/(ỳ|ý|ỵ|ỷ|ỹ)/', 'y', $str);
    $str = preg_replace('/(đ)/', 'd', $str);
    $str = preg_replace('/[^a-z0-9-\s]/', '', $str);
    $str = preg_replace('/([\s]+)/', '-', $str);
    $str = trim($str, '-');
    return $str;
}

/**
 * 9. Xử lý tải file hình ảnh an toàn
 */
function upload_image($fileInputName, $subFolder = '') {
    if (!isset($_FILES[$fileInputName]) || $_FILES[$fileInputName]['error'] !== UPLOAD_ERR_OK) {
        return ['status' => false, 'message' => 'Không có file nào được tải lên hoặc lỗi upload.'];
    }

    $file = $_FILES[$fileInputName];
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    $allowedMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $maxSize = 5 * 1024 * 1024; // 5MB

    if ($file['size'] > $maxSize) {
        return ['status' => false, 'message' => 'Kích thước file không được vượt quá 5MB.'];
    }

    $fileInfo = pathinfo($file['name']);
    $extension = strtolower($fileInfo['extension'] ?? '');

    if (!in_array($extension, $allowedExtensions, true)) {
        return ['status' => false, 'message' => 'Định dạng file không được hỗ trợ. Chỉ chấp nhận jpg, png, webp, gif.'];
    }

    // Kiểm tra MIME type thực tế bằng mime_content_type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mimeType, $allowedMimes, true)) {
        return ['status' => false, 'message' => 'File không phải là ảnh hợp lệ!'];
    }

    // Tạo tên file ngẫu nhiên an toàn
    $newFileName = time() . '_' . bin2hex(random_bytes(6)) . '.' . $extension;
    $targetDir = UPLOAD_PATH . ($subFolder ? '/' . trim($subFolder, '/') : '');

    if (!is_dir($targetDir)) {
        @mkdir($targetDir, 0755, true);
    }

    $destination = $targetDir . '/' . $newFileName;

    if (move_uploaded_file($file['tmp_name'], $destination)) {
        $relativePath = ($subFolder ? trim($subFolder, '/') . '/' : '') . $newFileName;
        return [
            'status' => true,
            'file_name' => $newFileName,
            'relative_path' => $relativePath,
            'full_url' => UPLOAD_URL . '/' . $relativePath
        ];
    }

    return ['status' => false, 'message' => 'Không thể lưu file vào máy chủ.'];
}

/**
 * 10. Rút gọn văn bản mô tả
 */
function truncate_words($text, $limit = 20) {
    $text = strip_tags($text);
    $words = explode(' ', $text);
    if (count($words) > $limit) {
        return implode(' ', array_slice($words, 0, $limit)) . '...';
    }
    return $text;
}

/**
 * 11. Hiển thị thông báo Flash dạng Alert có màu sắc (dùng cho cả client và admin)
 * - success: Xanh lá
 * - error: Đỏ
 * - warning: Vàng
 * - info: Xanh dương
 */
function render_flash_messages() {
    $types = ['success', 'error', 'warning', 'info'];
    $icons = [
        'success' => 'fa-circle-check',
        'error'   => 'fa-circle-xmark',
        'warning' => 'fa-triangle-exclamation',
        'info'    => 'fa-circle-info'
    ];
    $output = '';
    foreach ($types as $type) {
        $msg = get_flash($type);
        if ($msg) {
            $icon = $icons[$type] ?? 'fa-circle-info';
            $output .= '<div class="flash-alert flash-' . $type . '" role="alert">';
            $output .= '<i class="fa-solid ' . $icon . '"></i> ';
            $output .= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8');
            $output .= '<button class="flash-close" onclick="this.parentElement.remove()" aria-label="Đóng">&times;</button>';
            $output .= '</div>';
        }
    }
    return $output;
}

/**
 * 12. Lấy nhãn tiếng Việt cho trạng thái đơn hàng
 */
function get_order_status_label(string $status): string {
    return match ($status) {
        'pending'    => 'Chờ xử lý',
        'confirmed'  => 'Đã xác nhận',
        'processing' => 'Đang đóng gói',
        'shipping'   => 'Đang giao hàng',
        'completed'  => 'Hoàn thành',
        'cancelled'  => 'Đã hủy',
        'refunded'   => 'Đã hoàn tiền',
        default      => ucfirst($status)
    };
}

/**
 * 13. Xuất CSV an toàn
 * @param array $headers  - Mảng tiêu đề cột
 * @param array $rows     - Mảng dữ liệu dòng (mỗi dòng là mảng)
 * @param string $filename - Tên file tải về
 */
function export_csv(array $headers, array $rows, string $filename = 'export.csv') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    // BOM UTF-8 để Excel đọc đúng tiếng Việt
    echo "\xEF\xBB\xBF";
    $fp = fopen('php://output', 'wb');
    // Ghi tiêu đề
    fputcsv($fp, $headers);
    // Ghi dữ liệu
    foreach ($rows as $row) {
        fputcsv($fp, $row);
    }
    fclose($fp);
    exit();
}

/**
 * 14. Phân trang đơn giản - Trả về HTML pagination
 */
function render_pagination(int $currentPage, int $totalPages, string $baseUrl): string {
    if ($totalPages <= 1) return '';
    $html = '<div class="admin-pagination">';
    // Nút Trước
    if ($currentPage > 1) {
        $html .= '<a href="' . $baseUrl . '&page=' . ($currentPage - 1) . '" class="page-btn">&laquo; Trước</a>';
    }
    // Các nút số trang
    $start = max(1, $currentPage - 2);
    $end   = min($totalPages, $currentPage + 2);
    for ($i = $start; $i <= $end; $i++) {
        $active = ($i === $currentPage) ? 'active' : '';
        $html .= '<a href="' . $baseUrl . '&page=' . $i . '" class="page-btn ' . $active . '">' . $i . '</a>';
    }
    // Nút Sau
    if ($currentPage < $totalPages) {
        $html .= '<a href="' . $baseUrl . '&page=' . ($currentPage + 1) . '" class="page-btn">Sau &raquo;</a>';
    }
    $html .= '</div>';
    return $html;
}

/**
 * 15. Ghi nhật ký hoạt động quản trị (Audit / Activity Logs)
 */
function log_activity(string $action, string $description, ?int $targetId = null): void {
    try {
        $db = Database::connect();
        // Tự tạo bảng nếu chưa có
        $db->exec("
            CREATE TABLE IF NOT EXISTS `activity_logs` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT NULL,
                `username` VARCHAR(50) NULL,
                `action` VARCHAR(100) NOT NULL,
                `description` TEXT NOT NULL,
                `target_id` INT NULL,
                `ip_address` VARCHAR(50) NULL,
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

        $userId = current_user_id();
        $username = current_user()['username'] ?? 'Khách/Hệ thống';
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

        $stmt = $db->prepare(
            "INSERT INTO `activity_logs` (`user_id`, `username`, `action`, `description`, `target_id`, `ip_address`, `created_at`) 
             VALUES (:uid, :uname, :act, :desc, :tid, :ip, NOW())"
        );
        $stmt->execute([
            ':uid'   => $userId,
            ':uname' => $username,
            ':act'   => $action,
            ':desc'  => $description,
            ':tid'   => $targetId,
            ':ip'    => $ip
        ]);
    } catch (Exception $e) {
        // Tránh làm gián đoạn luồng chính nếu lỗi log
    }
}


