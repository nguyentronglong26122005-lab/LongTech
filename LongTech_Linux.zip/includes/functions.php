<?php
/**
 * ========================================================
 * LONGTECH - CÁC HÀM TIỆN ÍCH DÙNG CHUNG (functions.php)
 * ========================================================
 */

// Ngăn chặn truy cập nếu chưa có config
if (!defined('ROOT_PATH')) {
    require_once __DIR__ . '/../config.php';
}

/**
 * 1. Định dạng tiền tệ VNĐ (Chuẩn yêu cầu: 1.000.000đ)
 * Dấu chấm phân cách hàng nghìn, không số lẻ thập phân
 */
function format_money($amount) {
    $num = (float) $amount;
    return number_format($num, 0, ',', '.') . 'đ';
}

/**
 * 2. Làm sạch chuỗi chống tấn công XSS
 */
function sanitize($string) {
    if ($string === null) return '';
    return htmlspecialchars(trim((string)$string), ENT_QUOTES, 'UTF-8');
}

/**
 * Viết tắt hàm sanitize để xuất an toàn ra HTML: <?= e($var) ?>
 */
function e($string) {
    return sanitize($string);
}

/**
 * 3. Tạo và lấy Token chống tấn công CSRF
 */
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Tạo thẻ input ẩn chứa CSRF token chèn vào form HTML
 */
function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}

/**
 * Xác thực CSRF Token khi nhận POST request
 */
function verify_csrf_token($token = null) {
    $token = $token ?? ($_POST['csrf_token'] ?? '');
    if (empty($token) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        die('<div style="font-family:sans-serif;padding:30px;text-align:center;">
                <h2 style="color:#d70018;">Lỗi bảo mật (403 Forbidden)</h2>
                <p>CSRF Token không hợp lệ hoặc phiên làm việc đã hết hạn. Vui lòng thử lại!</p>
                <a href="' . APP_URL . '" style="display:inline-block;padding:10px 20px;background:#0a2540;color:#fff;text-decoration:none;border-radius:6px;">Về trang chủ</a>
             </div>');
    }
    return true;
}

/**
 * 4. Chuyển hướng trang (Redirect)
 */
function redirect($url) {
    if (!empty($GLOBALS['IS_EXECUTING_APPROVED_ACTION'])) {
        if (!empty($_SESSION['flash']['success'])) {
            $_SESSION['flash']['success'] = '✅ Đã duyệt yêu cầu & áp dụng lập tức lên web: ' . $_SESSION['flash']['success'];
        } else {
            $_SESSION['flash']['success'] = '✅ Đã duyệt yêu cầu và thực hiện thay đổi ngay lập tức trên website!';
        }
        $url = APP_URL . '/admin.php?act=approvals';
        header("Location: $url");
        exit();
    }
    if (!str_starts_with($url, 'http://') && !str_starts_with($url, 'https://')) {
        $url = APP_URL . '/' . ltrim($url, '/');
    }
    header("Location: $url");
    exit();
}

/**
 * 5. Quản lý thông báo tạm (Flash Message: success, error, warning, info)
 */
function set_flash($type, $message) {
    $_SESSION['flash'][$type] = $message;
}

function get_flash($type) {
    if (isset($_SESSION['flash'][$type])) {
        $message = $_SESSION['flash'][$type];
        unset($_SESSION['flash'][$type]);
        return $message;
    }
    return null;
}

function has_flash($type) {
    return isset($_SESSION['flash'][$type]);
}

/**
 * 6. Quản lý thông tin đăng nhập người dùng hiện tại
 */
function current_user() {
    return $_SESSION['user'] ?? null;
}

function is_logged_in() {
    return isset($_SESSION['user']) && !empty($_SESSION['user']['id']);
}

function current_user_id() {
    return $_SESSION['user']['id'] ?? null;
}

function current_role() {
    return $_SESSION['user']['role_name'] ?? null;
}

/**
 * Kiểm tra người dùng có quyền cụ thể hay không
 */
function has_role($roles) {
    if (!is_logged_in()) return false;
    $userRole = current_role();
    if (is_array($roles)) {
        return in_array($userRole, $roles, true);
    }
    return $userRole === $roles;
}

/**
 * Danh sách 5 nhóm chức năng phân quyền chi tiết (Multi-Permission RBAC)
 */
function get_all_permissions_list(): array {
    return [
        'manage_products' => [
            'name'  => 'Quản lý Sản phẩm & Kho hàng',
            'label' => 'Quản lý Sản phẩm & Kho hàng',
            'short' => 'Sản phẩm & Kho',
            'icon'  => 'fa-boxes-stacked',
            'color' => '#0284c7',
            'bg'    => '#e0f2fe',
            'desc'  => 'Thêm, sửa, xóa sản phẩm, danh mục, kiểm kê tồn kho và quản lý đánh giá'
        ],
        'manage_orders' => [
            'name'  => 'Quản lý Đơn hàng & Vận chuyển',
            'label' => 'Quản lý Đơn hàng & Vận chuyển',
            'short' => 'Đơn hàng',
            'icon'  => 'fa-cart-shopping',
            'color' => '#d97706',
            'bg'    => '#fef3c7',
            'desc'  => 'Xem đơn, duyệt đơn, cập nhật trạng thái giao hàng và xuất hóa đơn/CSV'
        ],
        'manage_users' => [
            'name'  => 'Quản lý Tài khoản & Phân quyền',
            'label' => 'Quản lý Tài khoản & Phân quyền',
            'short' => 'Tài khoản & User',
            'icon'  => 'fa-users-gear',
            'color' => '#7c3aed',
            'bg'    => '#ede9fe',
            'desc'  => 'Thêm thành viên mới, khóa/mở tài khoản, cấp quyền đa năng và xem nhật ký'
        ],
        'manage_marketing' => [
            'name'  => 'Quản lý Marketing & Tin tức',
            'label' => 'Quản lý Marketing & Tin tức',
            'short' => 'Marketing & Tin tức',
            'icon'  => 'fa-bullhorn',
            'color' => '#16a34a',
            'bg'    => '#dcfce7',
            'desc'  => 'Quản lý mã giảm giá (Coupons), đăng bài tin tức và phản hồi hộp thư khách'
        ],
        'manage_appearance' => [
            'name'  => 'Quản lý Giao diện & Banner',
            'label' => 'Quản lý Giao diện & Banner',
            'short' => 'Giao diện & Banner',
            'icon'  => 'fa-wand-magic-sparkles',
            'color' => '#dc2626',
            'bg'    => '#fee2e2',
            'desc'  => 'Tùy chỉnh bố cục trang chủ Live Editor và quản lý Banner quảng cáo'
        ]
    ];
}

/**
 * Lấy danh sách quyền mặc định theo tên vai trò
 */
function get_default_permissions_by_role(string $roleName): array {
    return match ($roleName) {
        'super_admin', 'admin' => ['manage_products', 'manage_orders', 'manage_users', 'manage_marketing', 'manage_appearance'],
        'product_manager'      => ['manage_products'],
        'order_manager'        => ['manage_orders'],
        default                => []
    };
}

/**
 * Lấy mảng các quyền chức năng thực tế của 1 user (hỗ trợ 1 người nhiều chức năng)
 */
function get_user_permissions(?array $user = null): array {
    if ($user === null) {
        $user = current_user();
    }
    if (!$user) return [];

    $roleName = $user['role_name'] ?? '';
    if ($roleName === 'super_admin') {
        return array_keys(get_all_permissions_list());
    }

    if (isset($user['permissions']) && $user['permissions'] !== null && trim((string)$user['permissions']) !== '') {
        if (is_array($user['permissions'])) {
            return $user['permissions'];
        }
        $raw = trim((string)$user['permissions']);
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            return $decoded;
        }
        return array_values(array_filter(array_map('trim', explode(',', $raw))));
    }

    return get_default_permissions_by_role($roleName);
}

/**
 * Kiểm tra người dùng có quyền thực hiện chức năng cụ thể hay không
 */
function has_permission($perms, ?array $user = null): bool {
    if ($user === null && !is_logged_in()) return false;
    $userPerms = get_user_permissions($user);
    if (empty($userPerms)) return false;

    $perms = is_array($perms) ? $perms : [$perms];
    foreach ($perms as $p) {
        if (in_array($p, $userPerms, true)) {
            return true;
        }
    }
    return false;
}

/**
 * Chuẩn hóa đường dẫn hình ảnh sản phẩm (Đảm bảo 100% hiển thị đúng ảnh gốc sắc nét của từng sản phẩm)
 */
function product_thumb_url(?string $path, int $productId = 0): string {
    $originalMap = [
        1  => 'assets/uploads/products/1793809755_2716485aa03a.png', // iPhone 15 Pro Max
        2  => 'assets/uploads/products/1793809745_c0e380be3c3f.png', // Samsung Galaxy S24 Ultra
        3  => 'assets/uploads/products/1793809734_f929dc8b6176.png', // Xiaomi 14 5G
        4  => 'assets/uploads/products/1793809722_2ac73279ab32.png', // OPPO Reno11 5G
        5  => 'assets/uploads/products/1793809710_f9e65b394bef.png', // iPad Pro 11 inch M2
        6  => 'assets/uploads/products/1793809699_f7488efc68e4.png', // Samsung Galaxy Tab S9
        7  => 'assets/uploads/products/1793809689_d08e00dd79ba.png', // Laptop ASUS ROG Strix G16
        8  => 'assets/uploads/products/1793809671_7784e5f8f562.png', // Laptop Dell XPS 13
        9  => 'assets/uploads/products/1793809657_346c0d86e1e4.png', // Laptop Lenovo Legion Slim 5
        10 => 'assets/uploads/products/1793809647_9e2615259e18.png', // Tai nghe Apple AirPods Pro 2
        11 => 'assets/uploads/products/1793809636_f60965de2420.png', // Củ sạc nhanh Anker GaNPrime 65W
        12 => 'assets/uploads/products/1793809625_6bf85845d382.png', // Chuột không dây Logitech MX Master 3S
        13 => 'assets/uploads/products/prod_13.png', // iPhone 16 Pro Max Titan Sa Mạc
        14 => 'assets/uploads/products/prod_14.png', // Samsung Galaxy Z Fold6 5G
        15 => 'assets/uploads/products/prod_15.png', // iPad Pro M4 13 inch WiFi
        16 => 'assets/uploads/products/prod_16.png', // MacBook Pro 14 M3 Pro Space Black
        17 => 'assets/uploads/products/prod_17.png', // Apple Watch Ultra 2 49mm Titan Đen
        18 => 'assets/uploads/products/prod_18.png', // Samsung Galaxy Watch Ultra 47mm
        19 => 'assets/uploads/products/prod_19.png', // Tai nghe Sony WH-1000XM5
        20 => 'assets/uploads/products/prod_20.png', // Loa Marshall Stanmore III
        21 => 'assets/uploads/products/prod_21.png', // Máy chơi game Sony PS5 Slim
        22 => 'assets/uploads/products/prod_22.png', // Bàn phím cơ ASUS ROG Azoth
        23 => 'assets/uploads/products/prod_23.png', // Màn hình LG UltraGear OLED 27"
        24 => 'assets/uploads/products/prod_24.png', // Apple Mac Studio M2 Max
    ];

    $path = trim((string)$path);
    if ($productId >= 1 && $productId <= 24 && isset($originalMap[$productId])) {
        if (empty($path) || str_contains($path, 'cellphones.com.vn') || str_contains($path, '1793809') || str_contains($path, 'prod_')) {
            return APP_URL . '/' . $originalMap[$productId];
        }
    }
    if (empty($path)) {
        return APP_URL . '/assets/uploads/products/1793809755_2716485aa03a.png';
    }
    if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
        return $path;
    }
    $clean = ltrim(str_replace('\\', '/', $path), '/');
    if (str_starts_with($clean, 'assets/')) {
        return APP_URL . '/' . $clean;
    }
    if (str_starts_with($clean, 'uploads/')) {
        return APP_URL . '/assets/' . $clean;
    }
    return UPLOAD_URL . '/products/' . $clean;
}

/**
 * 7. Hàm nạp View linh hoạt kèm truyền dữ liệu
 */
function render_view($viewPath, $data = [], $layout = true) {
    // Trích xuất biến từ mảng dữ liệu
    extract($data);
    $fullPath = VIEW_PATH . '/' . ltrim($viewPath, '/') . '.php';

    if (!file_exists($fullPath)) {
        die("View không tồn tại: " . htmlspecialchars($fullPath));
    }

    if ($layout) {
        // Nạp layout mặc định client
        require_once VIEW_PATH . '/client/layouts/header.php';
        require $fullPath;
        require_once VIEW_PATH . '/client/layouts/footer.php';
    } else {
        require $fullPath;
    }
}

/**
 * Nạp giao diện Quản trị viên (Admin View Layout)
 */
function render_admin_view($viewPath, $data = []) {
    extract($data);
    $fullPath = VIEW_PATH . '/' . ltrim($viewPath, '/') . '.php';

    if (!file_exists($fullPath)) {
        die("Admin View không tồn tại: " . htmlspecialchars($fullPath));
    }

    require_once VIEW_PATH . '/admin/layouts/header.php';
    require_once VIEW_PATH . '/admin/layouts/sidebar.php';
    require $fullPath;
    require_once VIEW_PATH . '/admin/layouts/footer.php';
}

/**
 * 8. Tạo chuỗi URL thân thiện (Slug) tiếng Việt
 */
function slugify($str) {
    $str = mb_strtolower($str, 'UTF-8');
    $str = preg_replace('/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/', 'a', $str);
    $str = preg_replace('/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/', 'e', $str);
    $str = preg_replace('/(ì|í|ị|ỉ|ĩ)/', 'i', $str);
    $str = preg_replace('/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/', 'o', $str);
    $str = preg_replace('/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/', 'u', $str);
    $str = preg_replace('/(ỳ|ý|ỵ|ỷ|ỹ)/', 'y', $str);
    $str = preg_replace('/(đ)/', 'd', $str);
    $str = preg_replace('/[^a-z0-9-\s]/', '', $str);
    $str = preg_replace('/([\s]+)/', '-', $str);
    $str = trim($str, '-');
    return $str;
}

/**
 * 9. Xử lý tải file hình ảnh an toàn
 */
function upload_image($fileInputName, $subFolder = '') {
    if (is_array($fileInputName)) {
        $file = $fileInputName;
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            return ['status' => false, 'message' => 'Không có file nào được tải lên hoặc lỗi upload.'];
        }
    } else {
        if (!isset($_FILES[$fileInputName]) || $_FILES[$fileInputName]['error'] !== UPLOAD_ERR_OK) {
            return ['status' => false, 'message' => 'Không có file nào được tải lên hoặc lỗi upload.'];
        }
        $file = $_FILES[$fileInputName];
    }
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    $allowedMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $maxSize = 5 * 1024 * 1024; // 5MB

    if ($file['size'] > $maxSize) {
        return ['status' => false, 'message' => 'Kích thước file không được vượt quá 5MB.'];
    }

    $fileInfo = pathinfo($file['name']);
    $extension = strtolower($fileInfo['extension'] ?? '');

    if (!in_array($extension, $allowedExtensions, true)) {
        return ['status' => false, 'message' => 'Định dạng file không được hỗ trợ. Chỉ chấp nhận jpg, png, webp, gif.'];
    }

    // Kiểm tra MIME type thực tế bằng mime_content_type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mimeType, $allowedMimes, true)) {
        return ['status' => false, 'message' => 'File không phải là ảnh hợp lệ!'];
    }

    // Tạo tên file ngẫu nhiên an toàn
    $newFileName = time() . '_' . bin2hex(random_bytes(6)) . '.' . $extension;
    $targetDir = UPLOAD_PATH . ($subFolder ? '/' . trim($subFolder, '/') : '');

    if (!is_dir($targetDir)) {
        @mkdir($targetDir, 0755, true);
    }

    $destination = $targetDir . '/' . $newFileName;

    if (move_uploaded_file($file['tmp_name'], $destination)) {
        $relativePath = ($subFolder ? trim($subFolder, '/') . '/' : '') . $newFileName;
        return [
            'status' => true,
            'file_name' => $newFileName,
            'relative_path' => $relativePath,
            'full_url' => UPLOAD_URL . '/' . $relativePath
        ];
    }

    return ['status' => false, 'message' => 'Không thể lưu file vào máy chủ.'];
}

/**
 * 10. Rút gọn văn bản mô tả
 */
function truncate_words($text, $limit = 20) {
    $text = strip_tags($text);
    $words = explode(' ', $text);
    if (count($words) > $limit) {
        return implode(' ', array_slice($words, 0, $limit)) . '...';
    }
    return $text;
}

/**
 * 11. Hiển thị thông báo Flash dạng Alert có màu sắc (dùng cho cả client và admin)
 * - success: Xanh lá
 * - error: Đỏ
 * - warning: Vàng
 * - info: Xanh dương
 */
function render_flash_messages() {
    $types = ['success', 'error', 'warning', 'info'];
    $icons = [
        'success' => 'fa-circle-check',
        'error'   => 'fa-circle-xmark',
        'warning' => 'fa-triangle-exclamation',
        'info'    => 'fa-circle-info'
    ];
    $output = '';
    foreach ($types as $type) {
        $msg = get_flash($type);
        if ($msg) {
            $icon = $icons[$type] ?? 'fa-circle-info';
            $output .= '<div class="flash-alert flash-' . $type . '" role="alert">';
            $output .= '<i class="fa-solid ' . $icon . '"></i> ';
            $output .= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8');
            $output .= '<button class="flash-close" onclick="this.parentElement.remove()" aria-label="Đóng">&times;</button>';
            $output .= '</div>';
        }
    }
    return $output;
}

/**
 * 12. Lấy nhãn tiếng Việt cho trạng thái đơn hàng
 */
function get_order_status_label(string $status): string {
    return match ($status) {
        'pending'    => 'Chờ xử lý',
        'confirmed'  => 'Đã xác nhận',
        'processing' => 'Đang đóng gói',
        'shipping'   => 'Đang giao hàng',
        'completed'  => 'Hoàn thành',
        'cancelled'  => 'Đã hủy',
        'refunded'   => 'Đã hoàn tiền',
        default      => ucfirst($status)
    };
}

/**
 * 13. Xuất CSV an toàn
 * @param array $headers  - Mảng tiêu đề cột
 * @param array $rows     - Mảng dữ liệu dòng (mỗi dòng là mảng)
 * @param string $filename - Tên file tải về
 */
function export_csv(array $headers, array $rows, string $filename = 'export.csv') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    // BOM UTF-8 để Excel đọc đúng tiếng Việt
    echo "\xEF\xBB\xBF";
    $fp = fopen('php://output', 'wb');
    // Ghi tiêu đề
    fputcsv($fp, $headers);
    // Ghi dữ liệu
    foreach ($rows as $row) {
        fputcsv($fp, $row);
    }
    fclose($fp);
    exit();
}

/**
 * 14. Phân trang đơn giản - Trả về HTML pagination
 */
function render_pagination(int $currentPage, int $totalPages, string $baseUrl): string {
    if ($totalPages <= 1) return '';
    $html = '<div class="admin-pagination">';
    // Nút Trước
    if ($currentPage > 1) {
        $html .= '<a href="' . $baseUrl . '&page=' . ($currentPage - 1) . '" class="page-btn">&laquo; Trước</a>';
    }
    // Các nút số trang
    $start = max(1, $currentPage - 2);
    $end   = min($totalPages, $currentPage + 2);
    for ($i = $start; $i <= $end; $i++) {
        $active = ($i === $currentPage) ? 'active' : '';
        $html .= '<a href="' . $baseUrl . '&page=' . $i . '" class="page-btn ' . $active . '">' . $i . '</a>';
    }
    // Nút Sau
    if ($currentPage < $totalPages) {
        $html .= '<a href="' . $baseUrl . '&page=' . ($currentPage + 1) . '" class="page-btn">Sau &raquo;</a>';
    }
    $html .= '</div>';
    return $html;
}

/**
 * 15. Ghi nhật ký hoạt động quản trị (Audit / Activity Logs)
 */
function log_activity(string $action, string $description, ?int $targetId = null): void {
    try {
        $db = Database::connect();
        // Tự tạo bảng nếu chưa có
        $db->exec("
            CREATE TABLE IF NOT EXISTS `activity_logs` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT NULL,
                `username` VARCHAR(50) NULL,
                `action` VARCHAR(100) NOT NULL,
                `description` TEXT NOT NULL,
                `target_id` INT NULL,
                `ip_address` VARCHAR(50) NULL,
                `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        ");

        $userId = current_user_id();
        $username = current_user()['username'] ?? 'Khách/Hệ thống';
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

        $stmt = $db->prepare(
            "INSERT INTO `activity_logs` (`user_id`, `username`, `action`, `description`, `target_id`, `ip_address`, `created_at`) 
             VALUES (:uid, :uname, :act, :desc, :tid, :ip, NOW())"
        );
        $stmt->execute([
            ':uid'   => $userId,
            ':uname' => $username,
            ':act'   => $action,
            ':desc'  => $description,
            ':tid'   => $targetId,
            ':ip'    => $ip
        ]);
    } catch (Exception $e) {
        // Tránh làm gián đoạn luồng chính nếu lỗi log
    }
}


