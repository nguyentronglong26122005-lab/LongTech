<?php
$host = 'sql.freedb.tech';
$port = 3306;
$dbname = 'freedb_t6xxjW8d';
$user = 'u_OXKmST';
$pass = 'QBaZKymkCcAT';

try {
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);
    echo "Connected successfully to FreeDB!\n";
    
    // Read longtech.sql as UTF-8
    $sql = file_get_contents('E:/LongTech/longtech.sql');
    
    // Remove database create/use statements that don't apply to freedb
    $sql = preg_replace('/CREATE DATABASE .*?;/i', '', $sql);
    $sql = preg_replace('/USE `longtech`;/i', '', $sql);
    
    // Execute SQL
    $pdo->exec($sql);
    echo "Re-imported longtech.sql into FreeDB with pure UTF-8!\n";
    
    // Check one category
    $stmt = $pdo->query("SELECT id, name FROM categories LIMIT 5");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "Category: " . $row['name'] . "\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
