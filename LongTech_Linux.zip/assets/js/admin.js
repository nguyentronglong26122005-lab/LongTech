/**
 * ========================================================
 * LONGTECH - JAVASCRIPT BẢNG ĐIỀU KHIỂN QUẢN TRỊ (admin.js)
 * Sidebar Accordion có nhớ trạng thái, Thu gọn icon,
 * Phím tắt Ctrl+K tìm kiếm nhanh, Toast Notification, Dark Mode
 * ========================================================
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. QUẢN LÝ ACCORDION MENU SIDEBAR & GHI NHỚ LOCALSTORAGE
    const navGroups = document.querySelectorAll('.nav-group');
    navGroups.forEach(group => {
        const header = group.querySelector('.nav-group-header');
        const groupKey = group.getAttribute('data-group');

        // Khôi phục trạng thái mở từ localStorage nếu trước đó người dùng đã mở
        const savedState = localStorage.getItem('longtech_nav_' + groupKey);
        if (savedState === 'open') {
            group.classList.add('open');
        } else if (savedState === 'closed') {
            group.classList.remove('open');
        }

        if (header) {
            header.addEventListener('click', function () {
                const isOpen = group.classList.toggle('open');
                localStorage.setItem('longtech_nav_' + groupKey, isOpen ? 'open' : 'closed');
            });
        }
    });

    // 2. THU GỌN SIDEBAR THÀNH THANH ICON (COLLAPSE MODE)
    const sidebar = document.getElementById('adminSidebar');
    const collapseBtn = document.getElementById('sidebarCollapseBtn');
    if (sidebar && collapseBtn) {
        if (localStorage.getItem('longtech_sidebar_collapsed') === 'true') {
            sidebar.classList.add('collapsed');
            document.body.classList.add('sidebar-is-collapsed');
        }

        collapseBtn.addEventListener('click', function () {
            const isCollapsed = sidebar.classList.toggle('collapsed');
            document.body.classList.toggle('sidebar-is-collapsed', isCollapsed);
            localStorage.setItem('longtech_sidebar_collapsed', isCollapsed ? 'true' : 'false');
        });
    }

    // 3. DARK MODE TOGGLE VỚI LOCALSTORAGE
    const darkToggleBtn = document.getElementById('btnToggleDark');
    function applyDarkMode(isDark) {
        if (isDark) {
            document.documentElement.classList.add('dark');
            if (darkToggleBtn) {
                darkToggleBtn.innerHTML = '<i class="fa-solid fa-sun" style="color:#f59e0b;"></i> <span class="dark-label">Chế độ Sáng</span>';
            }
        } else {
            document.documentElement.classList.remove('dark');
            if (darkToggleBtn) {
                darkToggleBtn.innerHTML = '<i class="fa-solid fa-moon"></i> <span class="dark-label">Chế độ Tối</span>';
            }
        }
    }

    const savedTheme = localStorage.getItem('longtech_admin_theme');
    applyDarkMode(savedTheme === 'dark');

    if (darkToggleBtn) {
        darkToggleBtn.addEventListener('click', function () {
            const currentlyDark = document.documentElement.classList.contains('dark');
            const newMode = !currentlyDark;
            applyDarkMode(newMode);
            localStorage.setItem('longtech_admin_theme', newMode ? 'dark' : 'light');
            if (window.showToast) {
                window.showToast(newMode ? 'Đã bật chế độ giao diện ban đêm' : 'Đã chuyển về giao diện ban ngày', 'info');
            }
        });
    }

    // 4. PHÍM TẮT CTRL + K / CMD + K MỞ Ô TÌM KIẾM NHANH
    document.addEventListener('keydown', function (e) {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
            e.preventDefault();
            window.openQuickSearch();
        }
        if (e.key === 'Escape') {
            window.closeQuickSearch();
        }
    });

    // Tự động ẩn flash alert sau 5s
    setTimeout(function () {
        document.querySelectorAll('.flash-alert').forEach(function (el) {
            el.style.transition = 'opacity 0.4s ease';
            el.style.opacity = '0';
            setTimeout(() => el.remove(), 400);
        });
    }, 5000);
});

// 5. TOAST NOTIFICATION HỆ THỐNG
window.showToast = function (message, type = 'info', duration = 3500) {
    let container = document.getElementById('adminToastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'adminToastContainer';
        container.className = 'admin-toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `admin-toast toast-${type}`;
    const icon = type === 'success' ? 'fa-circle-check' :
                 type === 'error'   ? 'fa-circle-xmark' :
                 type === 'warning' ? 'fa-triangle-exclamation' : 'fa-circle-info';

    toast.innerHTML = `
        <i class="fa-solid ${icon}"></i>
        <div class="toast-text">${message}</div>
        <button type="button" class="toast-close" onclick="this.parentElement.remove()">&times;</button>
    `;

    container.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 300);
    }, duration);
};

// 6. XÁC NHẬN XÓA DỮ LIỆU AN TOÀN
window.confirmAdminDelete = function (formOrUrl, itemName = 'mục này') {
    if (confirm(`Bạn có chắc chắn muốn xóa "${itemName}" không?\nHành động này không thể hoàn tác!`)) {
        if (typeof formOrUrl === 'string') {
            window.location.href = formOrUrl;
        } else if (formOrUrl && formOrUrl.submit) {
            formOrUrl.submit();
        }
    }
};

// 7. XỬ LÝ QUICK SEARCH MODAL (CTRL + K)
const QUICK_PAGES = [
    { title: 'Tổng Quan (Dashboard)', act: 'dashboard', icon: 'fa-chart-pie', category: 'Chính' },
    { title: 'Danh sách Sản phẩm', act: 'products', icon: 'fa-boxes-stacked', category: 'Sản phẩm' },
    { title: 'Thêm Sản phẩm mới', act: 'products/add', icon: 'fa-plus-circle', category: 'Sản phẩm' },
    { title: 'Danh mục Sản phẩm', act: 'categories', icon: 'fa-layer-group', category: 'Sản phẩm' },
    { title: 'Đánh giá & Nhận xét', act: 'reviews', icon: 'fa-star-half-stroke', category: 'Sản phẩm' },
    { title: 'Tất cả Đơn hàng', act: 'orders', icon: 'fa-receipt', category: 'Đơn hàng' },
    { title: 'Đơn hàng chờ xử lý', act: 'orders&status=pending', icon: 'fa-clock-rotate-left', category: 'Đơn hàng' },
    { title: 'Trình Live Editor Bố Cục', act: 'appearance/editor', icon: 'fa-wand-magic-sparkles', category: 'Giao diện' },
    { title: 'Quản lý Banner Slider', act: 'banners', icon: 'fa-images', category: 'Giao diện' },
    { title: 'Mã Giảm Giá (Coupons)', act: 'coupons', icon: 'fa-ticket', category: 'Marketing' },
    { title: 'Bài viết & Tin tức', act: 'posts', icon: 'fa-newspaper', category: 'Marketing' },
    { title: 'Hộp thư Liên hệ', act: 'contacts', icon: 'fa-envelope-open-text', category: 'Khách hàng' },
    { title: 'Quản lý Thành viên & Phân quyền', act: 'users', icon: 'fa-users-gear', category: 'Hệ thống' },
];

window.openQuickSearch = function () {
    const modal = document.getElementById('quickSearchModal');
    const input = document.getElementById('quickSearchInput');
    if (modal && input) {
        modal.style.display = 'flex';
        input.value = '';
        input.focus();
        window.filterQuickLinks();
    }
};

window.closeQuickSearch = function () {
    const modal = document.getElementById('quickSearchModal');
    if (modal) modal.style.display = 'none';
};

window.filterQuickLinks = function () {
    const input = document.getElementById('quickSearchInput');
    const results = document.getElementById('quickSearchResults');
    if (!input || !results) return;

    const query = input.value.trim().toLowerCase();
    const filtered = QUICK_PAGES.filter(p => p.title.toLowerCase().includes(query) || p.category.toLowerCase().includes(query));

    if (filtered.length === 0) {
        results.innerHTML = '<div style="padding:20px; text-align:center; color:#9ca3af;">Không tìm thấy trang nào phù hợp.</div>';
        return;
    }

    results.innerHTML = filtered.map(p => `
        <a href="admin.php?act=${p.act}" class="quick-link-item">
            <div style="display:flex; align-items:center; gap:12px;">
                <i class="fa-solid ${p.icon}" style="color:var(--primary-color, #D70018); width:20px;"></i>
                <strong>${p.title}</strong>
            </div>
            <span class="quick-category-badge">${p.category}</span>
        </a>
    `).join('');
};
