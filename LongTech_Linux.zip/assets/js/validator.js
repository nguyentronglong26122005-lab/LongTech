/**
 * ========================================================
 * LONGTECH - VALIDATOR FORM PHÍA CLIENT (validator.js)
 * ========================================================
 */

function validateForm(formSelector, rules = {}) {
    const formElement = document.querySelector(formSelector);
    if (!formElement) return true;

    let isValid = true;

    for (const [fieldName, rule] of Object.entries(rules)) {
        const input = formElement.querySelector(`[name="${fieldName}"]`);
        if (!input) continue;

        const value = input.value.trim();
        let errorMsg = '';

        if (rule.required && !value) {
            errorMsg = rule.message || 'Trường này không được để trống!';
        } else if (rule.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
            errorMsg = 'Địa chỉ email không đúng định dạng!';
        } else if (rule.phone && !/(0[3|5|7|8|9])+([0-9]{8})\b/.test(value)) {
            errorMsg = 'Số điện thoại không hợp lệ (10 chữ số)!';
        } else if (rule.minLength && value.length < rule.minLength) {
            errorMsg = `Tối thiểu ${rule.minLength} ký tự!`;
        } else if (rule.match) {
            const matchInput = formElement.querySelector(`[name="${rule.match}"]`);
            if (matchInput && matchInput.value !== value) {
                errorMsg = 'Mật khẩu xác nhận không khớp!';
            }
        }

        // Hiển thị hoặc xóa lỗi
        let errorElement = input.parentElement.querySelector('.form-error-msg');
        if (errorMsg) {
            isValid = false;
            input.classList.add('is-invalid');
            if (!errorElement) {
                errorElement = document.createElement('span');
                errorElement.className = 'form-error-msg';
                errorElement.style.color = '#d70018';
                errorElement.style.fontSize = '12px';
                errorElement.style.display = 'block';
                errorElement.style.marginTop = '4px';
                input.parentElement.appendChild(errorElement);
            }
            errorElement.textContent = errorMsg;
        } else {
            input.classList.remove('is-invalid');
            if (errorElement) errorElement.remove();
        }
    }

    return isValid;
}

