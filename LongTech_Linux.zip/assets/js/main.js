/**
 * ========================================================
 * LONGTECH - JAVASCRIPT XỬ LÝ SỰ KIỆN PHÍA CLIENT (main.js)
 * Tích hợp Banner Slider mượt mà, Swipe cảm ứng điện thoại,
 * Countdown Flash Sale thời gian thực, Scroll Reveal và Counter
 * ========================================================
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. XỬ LÝ MENU MOBILE DRAWER
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mobileDrawer = document.getElementById('mobileDrawer');
    const mobileDrawerOverlay = document.getElementById('mobileDrawerOverlay');
    const drawerCloseBtn = document.getElementById('drawerCloseBtn');

    function openMobileDrawer() {
        if (mobileDrawer && mobileDrawerOverlay) {
            mobileDrawer.classList.add('active');
            mobileDrawerOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    function closeMobileDrawer() {
        if (mobileDrawer && mobileDrawerOverlay) {
            mobileDrawer.classList.remove('active');
            mobileDrawerOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    if (mobileMenuBtn) mobileMenuBtn.addEventListener('click', openMobileDrawer);
    if (drawerCloseBtn) drawerCloseBtn.addEventListener('click', closeMobileDrawer);
    if (mobileDrawerOverlay) mobileDrawerOverlay.addEventListener('click', closeMobileDrawer);

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeMobileDrawer();
            cleanAllOverlays();
        }
    });

    // 2. CƠ CHẾ DỌN SẠCH OVERLAY CHỐNG KẸT MÀN HÌNH ĐEN/XÁM
    window.cleanAllOverlays = function () {
        document.body.style.overflow = '';
        const overlays = document.querySelectorAll('.modal-backdrop, .overlay, .mobile-drawer-overlay.active');
        overlays.forEach(function (overlay) {
            overlay.classList.remove('active');
            if (overlay.classList.contains('modal-backdrop')) {
                overlay.remove();
            }
        });
    };

    // 3. XỬ LÝ HERO BANNER SLIDER NÂNG CAO (Autoplay 5s, Swipe, Pause on Hover, Dots)
    const sliderContainer = document.querySelector('.hero-slider');
    const slides = document.querySelectorAll('.hero-slide');
    const prevBtn = document.querySelector('.slider-btn.prev');
    const nextBtn = document.querySelector('.slider-btn.next');
    const dotsContainer = document.querySelector('.slider-dots');

    if (slides.length > 0) {
        let currentSlide = 0;
        let slideInterval = null;
        const totalSlides = slides.length;

        // Tạo dots điều hướng nếu có container
        if (dotsContainer) {
            dotsContainer.innerHTML = '';
            for (let i = 0; i < totalSlides; i++) {
                const dot = document.createElement('button');
                dot.type = 'button';
                dot.className = 'slider-dot' + (i === 0 ? ' active' : '');
                dot.setAttribute('aria-label', 'Chuyển tới slide ' + (i + 1));
                dot.addEventListener('click', function () {
                    goToSlide(i);
                    resetAutoplay();
                });
                dotsContainer.appendChild(dot);
            }
        }

        const dots = document.querySelectorAll('.slider-dot');

        function updateSliderUI() {
            slides.forEach((slide, idx) => {
                slide.classList.toggle('active', idx === currentSlide);
            });
            dots.forEach((dot, idx) => {
                dot.classList.toggle('active', idx === currentSlide);
            });
        }

        function goToSlide(n) {
            currentSlide = (n + totalSlides) % totalSlides;
            updateSliderUI();
        }

        function nextSlide() {
            goToSlide(currentSlide + 1);
        }

        function prevSlide() {
            goToSlide(currentSlide - 1);
        }

        if (nextBtn) {
            nextBtn.addEventListener('click', function () {
                nextSlide();
                resetAutoplay();
            });
        }
        if (prevBtn) {
            prevBtn.addEventListener('click', function () {
                prevSlide();
                resetAutoplay();
            });
        }

        // Tự động chạy sau mỗi 5 giây
        function startAutoplay() {
            if (!slideInterval) {
                slideInterval = setInterval(nextSlide, 5000);
            }
        }

        function stopAutoplay() {
            if (slideInterval) {
                clearInterval(slideInterval);
                slideInterval = null;
            }
        }

        function resetAutoplay() {
            stopAutoplay();
            startAutoplay();
        }

        // Dừng khi rê chuột (Pause on hover)
        if (sliderContainer) {
            sliderContainer.addEventListener('mouseenter', stopAutoplay);
            sliderContainer.addEventListener('mouseleave', startAutoplay);

            // Vuốt chạm cảm ứng trên điện thoại (Touch Swipe)
            let touchStartX = 0;
            let touchEndX = 0;

            sliderContainer.addEventListener('touchstart', function (e) {
                touchStartX = e.changedTouches[0].screenX;
                stopAutoplay();
            }, { passive: true });

            sliderContainer.addEventListener('touchend', function (e) {
                touchEndX = e.changedTouches[0].screenX;
                handleSwipe();
                startAutoplay();
            }, { passive: true });

            function handleSwipe() {
                const diff = touchStartX - touchEndX;
                if (Math.abs(diff) > 40) {
                    if (diff > 0) {
                        nextSlide(); // Vuốt sang trái -> xem slide tiếp
                    } else {
                        prevSlide(); // Vuốt sang phải -> xem slide trước
                    }
                }
            }
        }

        startAutoplay();
    }

    // 4. ĐỒNG HỒ ĐẾM NGƯỢC FLASH SALE (COUNTDOWN TIMER)
    const countdownEl = document.querySelector('.flash-sale-countdown');
    if (countdownEl) {
        // Hạn chót đếm ngược: Cuối ngày hôm nay
        const now = new Date();
        const endOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59).getTime();

        function updateCountdown() {
            const currentTime = new Date().getTime();
            const distance = endOfDay - currentTime;

            if (distance > 0) {
                const hours = Math.floor((distance / (1000 * 60 * 60)) % 24);
                const minutes = Math.floor((distance / (1000 * 60)) % 60);
                const seconds = Math.floor((distance / 1000) % 60);

                const hEl = countdownEl.querySelector('.timer-hours');
                const mEl = countdownEl.querySelector('.timer-minutes');
                const sEl = countdownEl.querySelector('.timer-seconds');

                if (hEl) hEl.textContent = String(hours).padStart(2, '0');
                if (mEl) mEl.textContent = String(minutes).padStart(2, '0');
                if (sEl) sEl.textContent = String(seconds).padStart(2, '0');
            }
        }
        setInterval(updateCountdown, 1000);
        updateCountdown();
    }

    // 5. HIỆU ỨNG CUỘN HIỆN DẦN (SCROLL REVEAL ANIMATION)
    const revealElements = document.querySelectorAll('.product-card, .category-card, .news-card, .feature-box');
    if ('IntersectionObserver' in window && revealElements.length > 0) {
        const revealObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

        revealElements.forEach(el => {
            el.classList.add('reveal-item');
            revealObserver.observe(el);
        });
    }

    // 6. THỐNG KÊ ĐẾM SỐ TĂNG DẦN (NUMBER COUNTER)
    const counterElements = document.querySelectorAll('.stat-number[data-target]');
    if ('IntersectionObserver' in window && counterElements.length > 0) {
        const counterObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const el = entry.target;
                    const target = parseInt(el.getAttribute('data-target'), 10) || 0;
                    let count = 0;
                    const duration = 1500;
                    const stepTime = Math.max(20, Math.floor(duration / target));

                    const timer = setInterval(() => {
                        count += Math.ceil(target / (duration / stepTime));
                        if (count >= target) {
                            el.textContent = target.toLocaleString('vi-VN');
                            clearInterval(timer);
                        } else {
                            el.textContent = count.toLocaleString('vi-VN');
                        }
                    }, stepTime);

                    observer.unobserve(el);
                }
            });
        }, { threshold: 0.5 });

        counterElements.forEach(el => counterObserver.observe(el));
    }
});
