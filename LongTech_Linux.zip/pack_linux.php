<?php
$zipFile = 'E:/LongTech/LongTech_Linux.zip';
if (file_exists($zipFile)) {
    unlink($zipFile);
}

$zip = new ZipArchive();
if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
    $dir = realpath('E:/LongTech');
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );

    foreach ($files as $name => $file) {
        if (!$file->isDir()) {
            $filePath = $file->getRealPath();
            $relativePath = substr($filePath, strlen($dir) + 1);
            // Chuẩn hóa dấu gạch chéo thành forward-slash / cho Linux
            $linuxPath = str_replace('\\', '/', $relativePath);
            
            if (str_contains($linuxPath, '.zip') || str_contains($linuxPath, 'create_zip') || str_contains($linuxPath, 'scratch')) {
                continue;
            }
            $zip->addFile($filePath, $linuxPath);
        }
    }
    $zip->close();
    echo "ZIP LINUX CREATED: " . filesize($zipFile) . " bytes\n";
} else {
    echo "FAILED\n";
}
