<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER XÁC THỰC TÀI KHOẢN (AuthController.php)
 * ========================================================
 * Xử lý luồng Đăng nhập, Đăng ký, Đăng xuất, Phân luồng quyền
 * và tái tạo Session ID bảo mật (session_regenerate_id).
 */

require_once __DIR__ . '/../models/UserModel.php';
require_once __DIR__ . '/../includes/auth_middleware.php';

class AuthController {
    private UserModel $userModel;

    public function __construct() {
        $this->userModel = new UserModel();
    }

    /**
     * 1. Xử lý Đăng nhập
     */
    public function login() {
        // Nếu đã đăng nhập thì chuyển hướng ngay
        require_guest();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Xác thực CSRF Token
            verify_csrf_token();

            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';

            if (empty($username) || empty($password)) {
                set_flash('error', 'Vui lòng nhập đầy đủ tên tài khoản/email và mật khẩu.');
                redirect('/dang-nhap');
            }

            // Gọi model xác thực
            $result = $this->userModel->authenticate($username, $password);

            if (!$result['status']) {
                set_flash('error', $result['message']);
                redirect('/dang-nhap');
            }

            // Đăng nhập thành công -> Tái tạo session ID chống Session Fixation
            session_regenerate_id(true);

            $user = $result['user'];
            $_SESSION['user'] = [
                'id'                      => $user['id'],
                'role_id'                 => $user['role_id'],
                'role_name'               => $user['role_name'],
                'role_display'            => $user['role_display'],
                'permissions'             => $user['permissions'] ?? null,
                'username'                => $user['username'],
                'email'                   => $user['email'],
                'full_name'               => $user['full_name'],
                'phone'                   => $user['phone'],
                'address'                 => $user['address'],
                'avatar'                  => $user['avatar'],
                'require_password_change' => (int)($user['require_password_change'] ?? 0)
            ];

            // Nếu tài khoản được đánh dấu cần đổi mật khẩu ở lần đăng nhập đầu
            if (!empty($user['require_password_change'])) {
                set_flash('warning', 'Đây là lần đầu đăng nhập với mật khẩu tạm. Vui lòng đổi mật khẩu mới để bảo mật tài khoản!');
                redirect('/tai-khoan/cai-dat');
            }

            set_flash('success', 'Chào mừng ' . htmlspecialchars($user['full_name']) . ' đã quay trở lại LongTech!');

            // Kiểm tra có trang chờ trước đó không (redirect_after_login)
            if (!empty($_SESSION['redirect_after_login'])) {
                $target = $_SESSION['redirect_after_login'];
                unset($_SESSION['redirect_after_login']);
                redirect($target);
            }

            // Phân luồng quyền: Nếu là Quản trị/Nhân viên hoặc có quyền chức năng -> chuyển hướng trang quản trị
            $userPerms = get_user_permissions($_SESSION['user']);
            if (in_array($user['role_name'], ['super_admin', 'admin', 'product_manager', 'order_manager']) || !empty($userPerms)) {
                redirect('/admin.php');
            }

            // Nếu là Khách hàng -> Về trang cá nhân
            redirect('/tai-khoan');
        }

        // Phương thức GET: Hiển thị form đăng nhập
        $pageTitle = "Đăng Nhập Tài Khoản | LongTech";
        render_view('client/pages/login', [
            'pageTitle' => $pageTitle
        ]);
    }

    /**
     * 2. Xử lý Đăng ký tài khoản mới
     */
    public function register() {
        require_guest();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();

            $fullName        = trim($_POST['full_name'] ?? '');
            $username        = trim($_POST['username'] ?? '');
            $email           = trim($_POST['email'] ?? '');
            $phone           = trim($_POST['phone'] ?? '');
            $password        = $_POST['password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            $agreeTerms      = isset($_POST['agree_terms']);

            // Kiểm tra điều khoản
            if (!$agreeTerms) {
                set_flash('error', 'Bạn cần đồng ý với Điều khoản dịch vụ và Chính sách của LongTech để tiếp tục.');
                redirect('/dang-ky');
            }

            // Kiểm tra rỗng
            if (empty($fullName) || empty($username) || empty($email) || empty($password)) {
                set_flash('error', 'Vui lòng điền đầy đủ các trường thông tin bắt buộc.');
                redirect('/dang-ky');
            }

            // Kiểm tra định dạng username
            if (!preg_match('/^[a-zA-Z0-9_]{3,30}$/', $username)) {
                set_flash('error', 'Tên đăng nhập từ 3 - 30 ký tự, chỉ gồm chữ cái, số và dấu gạch dưới.');
                redirect('/dang-ky');
            }

            // Kiểm tra định dạng email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                set_flash('error', 'Địa chỉ email không đúng định dạng.');
                redirect('/dang-ky');
            }

            // Kiểm tra độ dài mật khẩu
            if (strlen($password) < 6) {
                set_flash('error', 'Mật khẩu phải chứa ít nhất 6 ký tự để đảm bảo an toàn.');
                redirect('/dang-ky');
            }

            // Kiểm tra khớp mật khẩu
            if ($password !== $confirmPassword) {
                set_flash('error', 'Mật khẩu xác nhận không khớp. Vui lòng nhập lại.');
                redirect('/dang-ky');
            }

            // Thực hiện đăng ký
            $registerResult = $this->userModel->register([
                'full_name' => $fullName,
                'username'  => $username,
                'email'     => $email,
                'phone'     => $phone,
                'password'  => $password
            ]);

            if (!$registerResult['status']) {
                set_flash('error', $registerResult['message']);
                redirect('/dang-ky');
            }

            // Đăng ký thành công -> Tự động đăng nhập cho khách hàng
            $newUser = $this->userModel->findById($registerResult['user_id']);
            session_regenerate_id(true);

            $_SESSION['user'] = [
                'id'           => $newUser['id'],
                'role_id'      => $newUser['role_id'],
                'role_name'    => $newUser['role_name'] ?? 'customer',
                'role_display' => $newUser['role_display'] ?? 'Khách hàng',
                'username'     => $newUser['username'],
                'email'        => $newUser['email'],
                'full_name'    => $newUser['full_name'],
                'phone'        => $newUser['phone'],
                'address'      => $newUser['address'],
                'avatar'       => null
            ];

            set_flash('success', 'Đăng ký tài khoản thành công! Chào mừng bạn gia nhập cộng đồng LongTech.');
            redirect('/tai-khoan');
        }

        // GET: Hiển thị giao diện đăng ký
        $pageTitle = "Đăng Ký Tài Khoản Mới | LongTech";
        render_view('client/pages/register', [
            'pageTitle' => $pageTitle
        ]);
    }

    /**
     * 3. Xử lý Đăng xuất
     */
    public function logout() {
        if (isset($_SESSION['user'])) {
            unset($_SESSION['user']);
        }
        session_regenerate_id(true);
        set_flash('info', 'Bạn đã đăng xuất tài khoản an toàn.');
        redirect('/');
    }
}

