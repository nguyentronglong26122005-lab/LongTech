<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN TRỊ HỆ THỐNG & NHẬT KÝ (SystemManageController.php)
 * ========================================================
 */

require_once __DIR__ . '/../../models/Database.php';
require_once __DIR__ . '/../../models/SiteSettingModel.php';
require_once __DIR__ . '/../../includes/auth_middleware.php';

class SystemManageController {
    private PDO $db;
    private SiteSettingModel $settingModel;

    public function __construct() {
        require_permission('manage_users');
        $this->db = Database::connect();
        $this->settingModel = new SiteSettingModel();
    }

    /**
     * Xem nhật ký hoạt động (Audit Logs)
     */
    public function logs(): void {
        $perPage = 25;
        $page    = max(1, (int)($_GET['page'] ?? 1));
        $search  = trim($_GET['search'] ?? '');

        // Đảm bảo bảng tồn tại
        log_activity('view_logs', 'Xem danh sách nhật ký hoạt động hệ thống');

        $where = ['1=1'];
        $params = [];
        if ($search !== '') {
            $where[] = '(username LIKE :s OR action LIKE :s OR description LIKE :s)';
            $params[':s'] = "%$search%";
        }
        $whereSQL = implode(' AND ', $where);

        $totalItems = (int)$this->db->query("SELECT COUNT(*) FROM `activity_logs` WHERE $whereSQL")->fetchColumn();
        $totalPages = max(1, (int)ceil($totalItems / $perPage));
        $offset = ($page - 1) * $perPage;

        $stmt = $this->db->prepare("SELECT * FROM `activity_logs` WHERE $whereSQL ORDER BY `created_at` DESC LIMIT :limit OFFSET :offset");
        foreach ($params as $k => $v) $stmt->bindValue($k, $v);
        $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $baseUrl = APP_URL . '/admin.php?act=system/logs&search=' . urlencode($search);
        $pagination = render_pagination($page, $totalPages, $baseUrl);

        $pageTitle = "Nhật Ký Hoạt Động Hệ Thống | LongTech Admin";
        render_admin_view('admin/pages/system/logs', compact('logs', 'search', 'page', 'totalPages', 'totalItems', 'pagination', 'pageTitle'));
    }

    /**
     * Bật / Tắt chế độ bảo trì website
     */
    public function toggleMaintenance(): void {
        verify_csrf_token();
        $current = $this->settingModel->getSetting('maintenance_mode', '0');
        $newMode = ($current === '1') ? '0' : '1';

        $this->settingModel->saveSettings(['maintenance_mode' => $newMode], current_user_id());
        log_activity('toggle_maintenance', ($newMode === '1' ? 'Bật' : 'Tắt') . ' chế độ bảo trì website');

        set_flash('success', $newMode === '1' ? 'Đã BẬT chế độ bảo trì website!' : 'Đã TẮT chế độ bảo trì, website hoạt động bình thường.');
        redirect('/admin.php?act=appearance/editor');
    }

    /**
     * Sao lưu cơ sở dữ liệu (Export SQL Backup)
     */
    public function backupDatabase(): void {
        require_super_admin(); // Chỉ Super Admin mới được tải backup CSDL

        log_activity('backup_database', 'Tải bản sao lưu cơ sở dữ liệu hệ thống');

        header('Content-Type: application/sql; charset=UTF-8');
        header('Content-Disposition: attachment; filename="longtech_backup_' . date('Ymd_His') . '.sql"');

        echo "-- LONGTECH DATABASE BACKUP\n";
        echo "-- Exported on: " . date('Y-m-d H:i:s') . "\n";
        echo "SET FOREIGN_KEY_CHECKS = 0;\n\n";

        $tables = $this->db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($tables as $t) {
            $createTable = $this->db->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_ASSOC)['Create Table'] ?? '';
            echo "-- Table structure for `$t`\n";
            echo "DROP TABLE IF EXISTS `$t`;\n";
            echo $createTable . ";\n\n";

            $rows = $this->db->query("SELECT * FROM `$t`")->fetchAll(PDO::FETCH_ASSOC);
            if (!empty($rows)) {
                echo "-- Dumping data for `$t`\n";
                foreach ($rows as $row) {
                    $keys = array_map(fn($k) => "`$k`", array_keys($row));
                    $values = array_map(function($v) {
                        return ($v === null) ? "NULL" : $this->db->quote($v);
                    }, array_values($row));
                    echo "INSERT INTO `$t` (" . implode(', ', $keys) . ") VALUES (" . implode(', ', $values) . ");\n";
                }
                echo "\n";
            }
        }
        echo "SET FOREIGN_KEY_CHECKS = 1;\n";
        exit();
    }
}

