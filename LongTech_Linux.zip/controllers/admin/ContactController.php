<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN LÝ LIÊN HỆ / GÓP Ý (ContactController.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

require_once ROOT_PATH . '/models/Database.php';

class ContactController {

    private PDO $db;

    public function __construct() {
        require_roles(['super_admin', 'admin']);
        $this->db = Database::connect();
    }

    // --------------------------------------------------------
    // Danh sách liên hệ + lọc
    // --------------------------------------------------------
    public function index(): void {
        $perPage = 20;
        $page    = max(1, (int)($_GET['page'] ?? 1));
        $status  = trim($_GET['status'] ?? '');
        $search  = trim($_GET['search'] ?? '');

        $where  = ['1=1'];
        $params = [];

        if (in_array($status, ['unread', 'read', 'replied'], true)) {
            $where[]          = 'c.status = :status';
            $params[':status'] = $status;
        }
        if ($search !== '') {
            $where[]  = '(c.full_name LIKE :s OR c.email LIKE :s2 OR c.subject LIKE :s3)';
            $params[':s']  = "%$search%";
            $params[':s2'] = "%$search%";
            $params[':s3'] = "%$search%";
        }

        $whereSQL = implode(' AND ', $where);

        $stmtCount = $this->db->prepare("SELECT COUNT(*) FROM contacts c WHERE $whereSQL");
        $stmtCount->execute($params);
        $totalItems = (int)$stmtCount->fetchColumn();
        $totalPages = max(1, (int)ceil($totalItems / $perPage));
        $page       = min($page, $totalPages);
        $offset     = ($page - 1) * $perPage;

        $stmt = $this->db->prepare(
            "SELECT c.* FROM contacts c
             WHERE $whereSQL
             ORDER BY FIELD(c.status, 'unread', 'read', 'replied'), c.created_at DESC
             LIMIT :limit OFFSET :offset"
        );
        foreach ($params as $k => $v) {
            $stmt->bindValue($k, $v);
        }
        $stmt->bindValue(':limit',  $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset,  PDO::PARAM_INT);
        $stmt->execute();
        $contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Đếm theo trạng thái (badge sidebar)
        $counts = $this->db->query(
            "SELECT status, COUNT(*) as cnt FROM contacts GROUP BY status"
        )->fetchAll(PDO::FETCH_KEY_PAIR);

        $unreadCount = (int)($counts['unread'] ?? 0);

        $baseUrl    = APP_URL . '/admin.php?act=contacts&status=' . urlencode($status) . '&search=' . urlencode($search);
        $pagination = render_pagination($page, $totalPages, $baseUrl);

        render_admin_view('admin/pages/contacts/list', compact(
            'contacts', 'status', 'search', 'page', 'totalPages', 'totalItems',
            'pagination', 'counts', 'unreadCount'
        ));
    }

    // --------------------------------------------------------
    // Đánh dấu đã đọc / đã trả lời
    // --------------------------------------------------------
    public function markRead(): void {
        verify_csrf_token();

        $id        = (int)($_POST['id'] ?? 0);
        $newStatus = in_array($_POST['new_status'] ?? '', ['read', 'replied'], true)
            ? $_POST['new_status'] : 'read';

        if ($id <= 0) {
            set_flash('error', 'ID liên hệ không hợp lệ!');
            redirect(APP_URL . '/admin.php?act=contacts');
        }

        $this->db->prepare("UPDATE contacts SET status = :status WHERE id = :id")
            ->execute([':status' => $newStatus, ':id' => $id]);

        $label = $newStatus === 'replied' ? 'Đánh dấu đã trả lời' : 'Đánh dấu đã đọc';
        set_flash('success', "$label liên hệ #$id thành công!");
        redirect(APP_URL . '/admin.php?act=contacts');
    }

    // --------------------------------------------------------
    // Xóa liên hệ
    // --------------------------------------------------------
    public function delete(): void {
        verify_csrf_token();

        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            set_flash('error', 'ID không hợp lệ!');
            redirect(APP_URL . '/admin.php?act=contacts');
        }

        $this->db->prepare("DELETE FROM contacts WHERE id = :id")->execute([':id' => $id]);
        set_flash('success', "Đã xóa liên hệ #$id thành công!");
        redirect(APP_URL . '/admin.php?act=contacts');
    }

    // --------------------------------------------------------
    // Export CSV liên hệ
    // --------------------------------------------------------
    public function exportCsv(): void {
        require_roles(['super_admin', 'admin']);

        $rows = $this->db->query(
            "SELECT id, full_name, email, phone, subject, message, status, created_at
             FROM contacts ORDER BY created_at DESC"
        )->fetchAll(PDO::FETCH_ASSOC);

        $csvRows = [];
        foreach ($rows as $r) {
            $csvRows[] = [
                $r['id'], $r['full_name'], $r['email'], $r['phone'] ?? '',
                $r['subject'], $r['message'], $r['status'], $r['created_at'],
            ];
        }

        export_csv(
            ['ID', 'Họ tên', 'Email', 'Điện thoại', 'Chủ đề', 'Nội dung', 'Trạng thái', 'Ngày gửi'],
            $csvRows,
            'contacts_' . date('Ymd') . '.csv'
        );
    }
}

