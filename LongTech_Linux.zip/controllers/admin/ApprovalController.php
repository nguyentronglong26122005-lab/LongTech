<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER DUYỆT YÊU CẦU THAO TÁC NHÂN VIÊN (ApprovalController.php)
 * ========================================================
 * - Super Admin: Xem toàn bộ yêu cầu, bấm Duyệt để thực thi lập tức trên web hoặc Từ chối
 * - Nhân viên các vai trò: Xem danh sách các yêu cầu mình đã gửi và trạng thái duyệt
 */

require_once __DIR__ . '/../../models/ApprovalModel.php';
require_once __DIR__ . '/../../includes/auth_middleware.php';

class ApprovalController {
    private ApprovalModel $approvalModel;

    public function __construct() {
        require_admin();
        $this->approvalModel = new ApprovalModel();
    }

    /**
     * 1. Danh sách các yêu cầu chờ duyệt / đã xử lý
     */
    public function index(): void {
        $statusFilter = trim($_GET['status'] ?? '');
        $isSuperAdmin = (current_role() === 'super_admin');
        $onlyUserId   = $isSuperAdmin ? null : (int)current_user_id();

        $requests     = $this->approvalModel->getRequests($statusFilter, $onlyUserId);
        $pendingCount = $this->approvalModel->countPending($onlyUserId);

        render_admin_view('admin/pages/approvals/list', [
            'pageTitle'    => 'Phê Duyệt Yêu Cầu Thao Tác | LongTech Admin',
            'requests'     => $requests,
            'statusFilter' => $statusFilter,
            'pendingCount' => $pendingCount,
            'isSuperAdmin' => $isSuperAdmin
        ]);
    }

    /**
     * 2. Admin bấm Duyệt -> Thực thi lập tức hành động của nhân viên lên website
     */
    public function approve(): void {
        if (current_role() !== 'super_admin') {
            set_flash('error', 'Chỉ Admin cấp cao (Super Admin) mới có quyền phê duyệt yêu cầu.');
            redirect('/admin.php?act=approvals');
        }

        $id  = (int)($_GET['id'] ?? ($_POST['id'] ?? 0));
        $req = $this->approvalModel->getById($id);

        if (!$req) {
            set_flash('error', 'Yêu cầu phê duyệt không tồn tại.');
            redirect('/admin.php?act=approvals');
        }

        if ($req['status'] !== 'pending') {
            set_flash('warning', 'Yêu cầu này đã được xử lý trước đó.');
            redirect('/admin.php?act=approvals');
        }

        $adminUser = current_user()['username'] ?? 'admin';
        $this->approvalModel->updateStatus($id, 'approved', $adminUser, 'Admin đã duyệt và thực thi trên web');
        log_activity('approve_action', "Duyệt yêu cầu #{$id} của @{$req['username']}: {$req['action_title']}", $id);

        // Khôi phục môi trường request của nhân viên để thực thi ngay lập tức
        $savedGet  = json_decode($req['get_data'] ?? '{}', true);
        $savedPost = json_decode($req['post_data'] ?? '{}', true);

        $_GET  = is_array($savedGet) ? $savedGet : [];
        $_POST = is_array($savedPost) ? $savedPost : [];
        $_FILES = []; // File ảnh (nếu có) đã được lưu thành đường dẫn trong $_POST khi gửi yêu cầu

        if (!empty($_POST)) {
            $_POST['csrf_token'] = csrf_token();
            $_SERVER['REQUEST_METHOD'] = 'POST';
        } else {
            $_SERVER['REQUEST_METHOD'] = 'GET';
        }

        $GLOBALS['IS_EXECUTING_APPROVED_ACTION'] = true;

        // Gọi bộ điều phối thực thi trực tiếp hành động
        dispatch_admin_action($req['action_key']);

        // Nếu controller không gọi redirect(), tự động quay về trang phê duyệt
        $GLOBALS['IS_EXECUTING_APPROVED_ACTION'] = false;
        set_flash('success', '✅ Đã duyệt và thực hiện lập tức trên web: ' . $req['action_title']);
        redirect('/admin.php?act=approvals');
    }

    /**
     * 3. Admin bấm Từ chối yêu cầu
     */
    public function reject(): void {
        if (current_role() !== 'super_admin') {
            set_flash('error', 'Chỉ Admin cấp cao (Super Admin) mới có quyền từ chối yêu cầu.');
            redirect('/admin.php?act=approvals');
        }

        $id   = (int)($_GET['id'] ?? ($_POST['id'] ?? 0));
        $note = trim($_POST['admin_note'] ?? ($_GET['note'] ?? 'Admin từ chối yêu cầu'));
        $req  = $this->approvalModel->getById($id);

        if (!$req || $req['status'] !== 'pending') {
            set_flash('error', 'Yêu cầu không hợp lệ hoặc đã được xử lý.');
            redirect('/admin.php?act=approvals');
        }

        $adminUser = current_user()['username'] ?? 'admin';
        $this->approvalModel->updateStatus($id, 'rejected', $adminUser, $note);
        log_activity('reject_action', "Từ chối yêu cầu #{$id} của @{$req['username']}: {$req['action_title']}", $id);

        set_flash('info', "Đã từ chối yêu cầu #{$id} ({$req['action_title']}) của @{$req['username']}.");
        redirect('/admin.php?act=approvals');
    }
}

