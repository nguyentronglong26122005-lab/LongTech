<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER BẢNG ĐIỀU KHIỂN QUẢN TRỊ (AdminController.php)
 * ========================================================
 * - Tính toán các chỉ số kinh doanh cốt lõi (KPIs)
 * - Cảnh báo kho hàng sắp hết (ngưỡng tồn kho <= 5)
 * - Thống kê đơn hàng mới nhất và dữ liệu biểu đồ doanh thu theo 12 tháng
 */

require_once __DIR__ . '/../../models/Database.php';

class AdminController {
    private PDO $db;

    public function __construct() {
        $this->db = Database::connect();
    }

    /**
     * Hiển thị trang Dashboard tổng quan
     */
    public function index() {
        // 1. Tổng doanh thu thực tế (Từ các đơn hàng thành công, đang giao hoặc đã thanh toán)
        $stmtRev = $this->db->query("SELECT SUM(total_amount) FROM `orders` WHERE `status` IN ('completed', 'processing', 'shipping') OR `payment_status` = 'paid'");
        $totalRevenue = (float)$stmtRev->fetchColumn();

        // 2. Tổng số đơn hàng trong hệ thống
        $stmtOrders = $this->db->query("SELECT COUNT(*) FROM `orders`");
        $totalOrders = (int)$stmtOrders->fetchColumn();

        // 3. Tổng số sản phẩm đang kinh doanh
        $stmtProds = $this->db->query("SELECT COUNT(*) FROM `products` WHERE `status` = 'active'");
        $totalProducts = (int)$stmtProds->fetchColumn();

        // 4. Tổng số khách hàng thành viên (Role customer)
        $stmtUsers = $this->db->query("SELECT COUNT(*) FROM `users` WHERE `role_id` = 5");
        $totalCustomers = (int)$stmtUsers->fetchColumn();

        // 5. Cảnh báo kho: Sản phẩm sắp hết hàng (Tồn kho <= 5)
        $stmtLowStock = $this->db->query("SELECT id, name, slug, thumbnail, stock_quantity, price 
                                         FROM `products` 
                                         WHERE `status` = 'active' AND `stock_quantity` <= 5 
                                         ORDER BY `stock_quantity` ASC 
                                         LIMIT 6");
        $lowStockProducts = $stmtLowStock->fetchAll();

        // 6. Danh sách 6 đơn hàng mới nhất gửi lên
        $stmtRecent = $this->db->query("SELECT id, order_code, customer_name, customer_phone, total_amount, payment_method, status, created_at 
                                       FROM `orders` 
                                       ORDER BY `id` DESC 
                                       LIMIT 6");
        $recentOrders = $stmtRecent->fetchAll();

        // 7. Thống kê biểu đồ doanh thu 12 tháng của năm hiện tại
        $currentYear = date('Y');
        $monthlyRevenue = array_fill(1, 12, 0);

        $sqlMonthly = "SELECT MONTH(created_at) AS order_month, SUM(total_amount) AS month_total 
                       FROM `orders` 
                       WHERE YEAR(created_at) = :year AND `status` != 'cancelled'
                       GROUP BY MONTH(created_at)";
        $stmtMonthly = $this->db->prepare($sqlMonthly);
        $stmtMonthly->execute([':year' => $currentYear]);
        $rowsMonthly = $stmtMonthly->fetchAll();

        foreach ($rowsMonthly as $row) {
            $month = (int)$row['order_month'];
            $monthlyRevenue[$month] = (float)$row['month_total'];
        }

        // Đảm bảo có dữ liệu mẫu trực quan cho biểu đồ nếu là database mới khởi tạo
        if ($totalRevenue <= 0) {
            $monthlyRevenue = [1 => 15000000, 2 => 22000000, 3 => 35000000, 4 => 42000000, 5 => 38000000, 6 => 55000000, 7 => 62000000, 8 => 71000000, 9 => 68000000, 10 => 82000000, 11 => 94000000, 12 => 105000000];
        }

        $chartLabels = [];
        $chartData = [];
        for ($m = 1; $m <= 12; $m++) {
            $chartLabels[] = "Tháng " . $m;
            $chartData[] = $monthlyRevenue[$m];
        }

        $pageTitle = "Bảng Điều Khiển Tổng Quan (Dashboard) | LongTech Admin";

        render_admin_view('admin/pages/dashboard', [
            'pageTitle'        => $pageTitle,
            'totalRevenue'     => $totalRevenue,
            'totalOrders'      => $totalOrders,
            'totalProducts'    => $totalProducts,
            'totalCustomers'   => $totalCustomers,
            'lowStockProducts' => $lowStockProducts,
            'recentOrders'     => $recentOrders,
            'chartLabels'      => $chartLabels,
            'chartData'        => $chartData
        ]);
    }
}

