<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN LÝ BÀI VIẾT / TIN TỨC (PostController.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

require_once ROOT_PATH . '/models/Database.php';

class PostController {

    private PDO $db;

    public function __construct() {
        // Chỉ super_admin và admin mới được quản lý bài viết
        require_roles(['super_admin', 'admin']);
        $this->db = Database::connect();
    }

    // --------------------------------------------------------
    // Danh sách bài viết + tìm kiếm + phân trang
    // --------------------------------------------------------
    public function index(): void {
        $perPage = 15;
        $page    = max(1, (int)($_GET['page'] ?? 1));
        $search  = trim($_GET['search'] ?? '');
        $status  = trim($_GET['status'] ?? '');

        $where  = ['1=1'];
        $params = [];

        if ($search !== '') {
            $where[]  = '(p.title LIKE :search OR p.summary LIKE :search2)';
            $params[':search']  = "%$search%";
            $params[':search2'] = "%$search%";
        }
        if (in_array($status, ['published', 'draft'], true)) {
            $where[]          = 'p.status = :status';
            $params[':status'] = $status;
        }

        $whereSQL = implode(' AND ', $where);

        // Đếm tổng bài viết
        $stmtCount = $this->db->prepare(
            "SELECT COUNT(*) FROM posts p WHERE $whereSQL"
        );
        $stmtCount->execute($params);
        $totalItems = (int)$stmtCount->fetchColumn();
        $totalPages = max(1, (int)ceil($totalItems / $perPage));
        $page       = min($page, $totalPages);
        $offset     = ($page - 1) * $perPage;

        // Lấy danh sách bài viết
        $stmt = $this->db->prepare(
            "SELECT p.*, u.full_name AS author_name
             FROM posts p
             LEFT JOIN users u ON p.author_id = u.id
             WHERE $whereSQL
             ORDER BY p.created_at DESC
             LIMIT :limit OFFSET :offset"
        );
        foreach ($params as $k => $v) {
            $stmt->bindValue($k, $v);
        }
        $stmt->bindValue(':limit',  $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset,  PDO::PARAM_INT);
        $stmt->execute();
        $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $baseUrl    = APP_URL . '/admin.php?act=posts&search=' . urlencode($search) . '&status=' . urlencode($status);
        $pagination = render_pagination($page, $totalPages, $baseUrl);

        render_admin_view('admin/pages/posts/list', compact(
            'posts', 'search', 'status', 'page', 'totalPages', 'totalItems', 'pagination'
        ));
    }

    // --------------------------------------------------------
    // Thêm / Sửa bài viết
    // --------------------------------------------------------
    public function addEdit(): void {
        $id   = (int)($_GET['id'] ?? 0);
        $post = null;

        if ($id > 0) {
            $stmt = $this->db->prepare("SELECT * FROM posts WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $post = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$post) {
                set_flash('error', 'Bài viết không tồn tại!');
                redirect(APP_URL . '/admin.php?act=posts');
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();

            $title     = trim($_POST['title']   ?? '');
            $slug      = trim($_POST['slug']    ?? '');
            $summary   = trim($_POST['summary'] ?? '');
            $content   = $_POST['content']      ?? '';
            $thumbnail = trim($_POST['thumbnail'] ?? ($post['thumbnail'] ?? ''));
            $status    = in_array($_POST['status'] ?? '', ['published', 'draft']) ? $_POST['status'] : 'draft';
            $authorId  = current_user_id();

            // Validate
            if ($title === '') {
                set_flash('error', 'Tiêu đề bài viết không được để trống!');
                render_admin_view('admin/pages/posts/add-edit', compact('post', 'id'));
                return;
            }

            // Tự động tạo slug nếu rỗng
            if ($slug === '') {
                $slug = slugify($title);
            }

            // Upload ảnh đại diện nếu có
            if (!empty($_FILES['thumbnail_file']['name'])) {
                $upload = upload_image($_FILES['thumbnail_file'], 'posts');
                if ($upload['status']) {
                    $thumbnail = $upload['full_url'];
                } else {
                    set_flash('warning', 'Upload ảnh thất bại: ' . $upload['message']);
                }
            }

            if ($id > 0) {
                // Cập nhật bài viết
                $stmt = $this->db->prepare(
                    "UPDATE posts SET title=:title, slug=:slug, summary=:summary, content=:content,
                     thumbnail=:thumbnail, status=:status, author_id=:author_id WHERE id=:id"
                );
                $stmt->execute([
                    ':title'     => $title,
                    ':slug'      => $slug,
                    ':summary'   => $summary,
                    ':content'   => $content,
                    ':thumbnail' => $thumbnail,
                    ':status'    => $status,
                    ':author_id' => $authorId,
                    ':id'        => $id,
                ]);
                set_flash('success', "Đã cập nhật bài viết \"$title\" thành công!");
            } else {
                // Thêm bài viết mới
                $stmt = $this->db->prepare(
                    "INSERT INTO posts (title, slug, summary, content, thumbnail, status, author_id, created_at)
                     VALUES (:title, :slug, :summary, :content, :thumbnail, :status, :author_id, NOW())"
                );
                $stmt->execute([
                    ':title'     => $title,
                    ':slug'      => $slug,
                    ':summary'   => $summary,
                    ':content'   => $content,
                    ':thumbnail' => $thumbnail,
                    ':status'    => $status,
                    ':author_id' => $authorId,
                ]);
                set_flash('success', "Đã thêm bài viết \"$title\" thành công!");
            }

            redirect(APP_URL . '/admin.php?act=posts');
        }

        render_admin_view('admin/pages/posts/add-edit', compact('post', 'id'));
    }

    // --------------------------------------------------------
    // Xóa bài viết
    // --------------------------------------------------------
    public function delete(): void {
        verify_csrf_token();

        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            set_flash('error', 'ID bài viết không hợp lệ!');
            redirect(APP_URL . '/admin.php?act=posts');
        }

        // Lấy thông tin để xác nhận
        $stmt = $this->db->prepare("SELECT title FROM posts WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $post = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$post) {
            set_flash('error', 'Bài viết không tồn tại!');
            redirect(APP_URL . '/admin.php?act=posts');
        }

        $this->db->prepare("DELETE FROM posts WHERE id = :id")->execute([':id' => $id]);
        set_flash('success', "Đã xóa bài viết \"" . $post['title'] . "\" thành công!");
        redirect(APP_URL . '/admin.php?act=posts');
    }
}

