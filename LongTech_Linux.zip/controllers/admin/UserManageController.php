<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN LÝ THÀNH VIÊN & PHÂN QUYỀN (UserManageController.php)
 * ========================================================
 * - Phân quyền Server-Side: Super Admin, Admin
 * - Quản lý 5 Vai trò:
 *   1. super_admin (Super Admin - Toàn quyền)
 *   2. admin (Quản trị viên)
 *   3. product_manager (Nhân viên sản phẩm & kho)
 *   4. order_manager (Nhân viên xử lý đơn hàng)
 *   5. customer (Khách hàng)
 * - Khóa / Mở khóa tài khoản người dùng
 * - Đổi vai trò tài khoản với các chốt bảo mật ngăn chặn tự hạ quyền hoặc can thiệp Super Admin trái phép
 */

require_once __DIR__ . '/../../models/UserModel.php';
require_once __DIR__ . '/../../includes/auth_middleware.php';

class UserManageController {
    private UserModel $userModel;

    public function __construct() {
        // Cho phép Super Admin, Admin hoặc bất kỳ nhân viên nào được cấp chức năng Quản lý Tài khoản (manage_users)
        require_permission('manage_users');
        $this->userModel = new UserModel();
    }

    /**
     * 1. Danh sách người dùng hệ thống (Tìm kiếm, Lọc vai trò, Lọc trạng thái)
     */
    public function index() {
        $keyword      = trim($_GET['keyword'] ?? '');
        $roleFilter   = trim($_GET['role'] ?? '');
        $statusFilter = trim($_GET['status'] ?? '');

        $users = $this->userModel->getAllUsers($keyword, $roleFilter, $statusFilter);
        $roles = $this->userModel->getAllRoles();

        $pageTitle = "Quản Lý Thành Viên & Phân Quyền | LongTech Admin";

        render_admin_view('admin/pages/users/list', [
            'pageTitle'    => $pageTitle,
            'users'        => $users,
            'roles'        => $roles,
            'keyword'      => $keyword,
            'roleFilter'   => $roleFilter,
            'statusFilter' => $statusFilter
        ]);
    }

    /**
     * 1.1 Thêm tài khoản thành viên mới (Tinh gọn: Tài khoản + Mật khẩu + Tích chọn vai trò)
     */
    public function add() {
        $roles = $this->userModel->getAllRoles();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();

            $username  = trim($_POST['username'] ?? '');
            $password  = $_POST['password'] ?? '';
            $fullName  = trim($_POST['full_name'] ?? '');
            $email     = trim($_POST['email'] ?? '');
            $phone     = trim($_POST['phone'] ?? '');
            $address   = trim($_POST['address'] ?? '');
            $reqChange = !empty($_POST['require_password_change']) ? 1 : 0;

            // Xử lý danh sách các vai trò/chức năng được tích chọn
            $validKeys = array_keys(get_all_permissions_list());
            $rawPerms  = isset($_POST['permissions']) && is_array($_POST['permissions']) ? $_POST['permissions'] : [];
            $selectedPerms = array_values(array_intersect($rawPerms, $validKeys));

            if (empty($username) || empty($password)) {
                set_flash('error', 'Vui lòng nhập đầy đủ Tài khoản và Mật khẩu.');
                render_admin_view('admin/pages/users/add', [
                    'pageTitle' => "Thêm Thành Viên Mới | LongTech Admin",
                    'roles'     => $roles
                ]);
                return;
            }

            if (empty($selectedPerms)) {
                set_flash('error', 'Vui lòng tích chọn ít nhất 1 vai trò chức năng cho thành viên.');
                render_admin_view('admin/pages/users/add', [
                    'pageTitle' => "Thêm Thành Viên Mới | LongTech Admin",
                    'roles'     => $roles
                ]);
                return;
            }

            // Tự động gán role_id = 3 (Nhân viên quản lý) để mọi thao tác của thành viên gửi yêu cầu lên Admin duyệt
            $roleId = 3;
            if (in_array('manage_orders', $selectedPerms, true) && !in_array('manage_products', $selectedPerms, true)) {
                $roleId = 4;
            }
            $permString = implode(',', $selectedPerms);

            // Tự động khởi tạo Họ tên và Email nội bộ nếu form tinh gọn không nhập
            if ($fullName === '') {
                $fullName = $username;
            }
            $cleanUser = strtolower(preg_replace('/[^a-zA-Z0-9_.-]/', '', $username)) ?: 'member';
            if ($email === '') {
                $email = $cleanUser . '_' . substr(uniqid(), -4) . '@longtech.vn';
            }

            $db = Database::connect();

            // Kiểm tra username trùng lặp
            $checkUser = $db->prepare("SELECT id FROM `users` WHERE `username` = :u LIMIT 1");
            $checkUser->execute([':u' => $username]);
            if ($checkUser->fetch()) {
                set_flash('error', "Tài khoản '$username' đã tồn tại. Vui lòng chọn tên tài khoản khác!");
                render_admin_view('admin/pages/users/add', [
                    'pageTitle' => "Thêm Thành Viên Mới | LongTech Admin",
                    'roles'     => $roles
                ]);
                return;
            }

            // Băm mật khẩu an toàn
            $passwordHash = password_hash($password, PASSWORD_BCRYPT);

            $stmt = $db->prepare(
                "INSERT INTO `users` (`role_id`, `permissions`, `username`, `email`, `password`, `full_name`, `phone`, `address`, `status`, `require_password_change`, `created_at`)
                 VALUES (:rid, :perms, :u, :e, :p, :fn, :ph, :addr, 'active', :req, NOW())"
            );
            $stmt->execute([
                ':rid'   => $roleId,
                ':perms' => $permString,
                ':u'     => $username,
                ':e'     => $email,
                ':p'     => $passwordHash,
                ':fn'    => $fullName,
                ':ph'    => $phone ?: null,
                ':addr'  => $address ?: null,
                ':req'   => $reqChange
            ]);

            log_activity('create_user', "Tạo tài khoản mới: $username với các vai trò: " . $permString);
            set_flash('success', "Đã tạo tài khoản \"$username\" và phân quyền vai trò thành công! Khi thành viên này thao tác, yêu cầu sẽ được gửi lên Admin duyệt.");
            redirect('/admin.php?act=users');
        }

        render_admin_view('admin/pages/users/add', [
            'pageTitle' => "Thêm Thành Viên Mới | LongTech Admin",
            'roles'     => $roles
        ]);
    }

    /**
     * 2. Khóa / Mở khóa tài khoản
     */
    public function toggleStatus() {
        $id = (int)($_GET['id'] ?? 0);
        $currentLoggedInId = (int)($_SESSION['user']['id'] ?? 0);

        if ($id <= 0) {
            set_flash('error', 'Tài khoản không hợp lệ.');
            redirect('/admin.php?act=users');
        }

        // Không cho phép tự khóa tài khoản chính mình
        if ($id === $currentLoggedInId) {
            set_flash('error', 'Bạn không thể tự khóa tài khoản đang đăng nhập của chính mình!');
            redirect('/admin.php?act=users');
        }

        $targetUser = $this->userModel->findById($id);
        if (!$targetUser) {
            set_flash('error', 'Người dùng không tồn tại.');
            redirect('/admin.php?act=users');
        }

        // Người có vai trò admin thường không được phép khóa tài khoản super_admin
        if ($targetUser['role_name'] === 'super_admin' && current_role() !== 'super_admin') {
            set_flash('error', 'Chỉ Super Admin mới có quyền thao tác với tài khoản Super Admin khác.');
            redirect('/admin.php?act=users');
        }

        $this->userModel->toggleUserStatus($id);
        $newStatusText = ($targetUser['status'] === 'active') ? 'đã bị khóa' : 'đã được mở khóa';
        set_flash('success', 'Tài khoản "' . htmlspecialchars($targetUser['username']) . '" ' . $newStatusText . ' thành công.');

        redirect('/admin.php?act=users');
    }

    /**
     * 3. Thay đổi vai trò (Phân quyền 5 vai trò)
     */
    public function changeRole() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/admin.php?act=users');
        }

        verify_csrf_token();

        $userId = (int)($_POST['user_id'] ?? 0);
        $roleId = (int)($_POST['role_id'] ?? 0);
        $currentLoggedInId = (int)($_SESSION['user']['id'] ?? 0);

        if ($userId <= 0 || $roleId <= 0) {
            set_flash('error', 'Dữ liệu phân quyền không hợp lệ.');
            redirect('/admin.php?act=users');
        }

        // Không cho phép tự hạ quyền của chính mình
        if ($userId === $currentLoggedInId && current_role() === 'super_admin' && $roleId !== 1) {
            set_flash('error', 'Bạn không thể tự tước quyền Super Admin của chính mình.');
            redirect('/admin.php?act=users');
        }

        $targetUser = $this->userModel->findById($userId);
        if (!$targetUser) {
            set_flash('error', 'Người dùng không tồn tại.');
            redirect('/admin.php?act=users');
        }

        // Chỉ Super Admin mới có quyền gán hoặc gỡ vai trò Super Admin
        if (($roleId === 1 || $targetUser['role_name'] === 'super_admin') && current_role() !== 'super_admin') {
            set_flash('error', 'Chỉ Super Admin mới có quyền thăng cấp hoặc giáng chức vai trò Super Admin.');
            redirect('/admin.php?act=users');
        }

        // Kiểm tra xem có phải lưu từ bảng cấu hình đa chức năng (Multi-Permission) không
        $permissions = null;
        if (isset($_POST['is_multi_perm'])) {
            $validKeys = array_keys(get_all_permissions_list());
            $rawPerms  = isset($_POST['permissions']) && is_array($_POST['permissions']) ? $_POST['permissions'] : [];
            $permissions = array_values(array_intersect($rawPerms, $validKeys));

            // Nếu gán chức năng quản trị nhưng để vai trò Khách hàng (5), tự chuyển lên Nhân viên (3) hoặc Admin (2)
            if ($roleId === 5 && !empty($permissions)) {
                $roleId = (count($permissions) >= 3 || in_array('manage_users', $permissions, true)) ? 2 : 3;
            }
            if ($roleId === 1) {
                $permissions = $validKeys;
            }
        }

        $this->userModel->updateUserRole($userId, $roleId, $permissions);
        log_activity('update_permissions', 'Cập nhật phân quyền tài khoản @' . $targetUser['username'], $userId);
        set_flash('success', 'Đã cập nhật vai trò và chức năng phân quyền cho tài khoản "' . htmlspecialchars($targetUser['username']) . '" thành công!');

        redirect('/admin.php?act=users');
    }

    /**
     * Xuất danh sách người dùng ra file CSV
     */
    public function exportCsv(): void {
        $users = $this->userModel->getAllUsers();
        $rows = [];
        foreach ($users as $u) {
            $rows[] = [
                $u['id'],
                $u['username'],
                $u['full_name'],
                $u['email'],
                $u['phone'] ?? '',
                $u['role_name'] ?? 'customer',
                ($u['status'] ?? 1) == 1 ? 'Hoạt động' : 'Bị khóa',
                $u['created_at'] ?? ''
            ];
        }

        export_csv(
            ['ID', 'Tên Đăng Nhập', 'Họ Tên', 'Email', 'Điện Thoại', 'Vai Trò', 'Trạng Thái', 'Ngày Tạo'],
            $rows,
            'users_' . date('Ymd_His') . '.csv'
        );
    }
}

