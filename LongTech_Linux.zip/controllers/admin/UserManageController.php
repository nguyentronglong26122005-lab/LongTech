<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN LÝ THÀNH VIÊN & PHÂN QUYỀN (UserManageController.php)
 * ========================================================
 * - Phân quyền Server-Side: Super Admin, Admin
 * - Quản lý 5 Vai trò:
 *   1. super_admin (Super Admin - Toàn quyền)
 *   2. admin (Quản trị viên)
 *   3. product_manager (Nhân viên sản phẩm & kho)
 *   4. order_manager (Nhân viên xử lý đơn hàng)
 *   5. customer (Khách hàng)
 * - Khóa / Mở khóa tài khoản người dùng
 * - Đổi vai trò tài khoản với các chốt bảo mật ngăn chặn tự hạ quyền hoặc can thiệp Super Admin trái phép
 */

require_once __DIR__ . '/../../models/UserModel.php';
require_once __DIR__ . '/../../includes/auth_middleware.php';

class UserManageController {
    private UserModel $userModel;

    public function __construct() {
        // Chỉ Super Admin và Admin mới được quản lý thành viên
        require_roles(['super_admin', 'admin']);
        $this->userModel = new UserModel();
    }

    /**
     * 1. Danh sách người dùng hệ thống (Tìm kiếm, Lọc vai trò, Lọc trạng thái)
     */
    public function index() {
        $keyword      = trim($_GET['keyword'] ?? '');
        $roleFilter   = trim($_GET['role'] ?? '');
        $statusFilter = trim($_GET['status'] ?? '');

        $users = $this->userModel->getAllUsers($keyword, $roleFilter, $statusFilter);
        $roles = $this->userModel->getAllRoles();

        $pageTitle = "Quản Lý Thành Viên & Phân Quyền | LongTech Admin";

        render_admin_view('admin/pages/users/list', [
            'pageTitle'    => $pageTitle,
            'users'        => $users,
            'roles'        => $roles,
            'keyword'      => $keyword,
            'roleFilter'   => $roleFilter,
            'statusFilter' => $statusFilter
        ]);
    }

    /**
     * 1.1 Thêm tài khoản thành viên mới
     */
    public function add() {
        $roles = $this->userModel->getAllRoles();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();

            $username  = trim($_POST['username'] ?? '');
            $email     = trim($_POST['email'] ?? '');
            $password  = $_POST['password'] ?? '';
            $fullName  = trim($_POST['full_name'] ?? '');
            $phone     = trim($_POST['phone'] ?? '');
            $address   = trim($_POST['address'] ?? '');
            $roleId    = (int)($_POST['role_id'] ?? 5);
            $reqChange = !empty($_POST['require_password_change']) ? 1 : 0;

            if (empty($username) || empty($email) || empty($password) || empty($fullName)) {
                set_flash('error', 'Vui lòng điền đầy đủ các thông tin bắt buộc (*).');
                render_admin_view('admin/pages/users/add', [
                    'pageTitle' => "Thêm Thành Viên Mới | LongTech Admin",
                    'roles'     => $roles
                ]);
                return;
            }

            // Bảo mật: Nếu không phải Super Admin thì không được tạo tài khoản có quyền Super Admin
            if ($roleId === 1 && current_role() !== 'super_admin') {
                set_flash('error', 'Chỉ Super Admin mới có quyền tạo thêm tài khoản Super Admin.');
                render_admin_view('admin/pages/users/add', [
                    'pageTitle' => "Thêm Thành Viên Mới | LongTech Admin",
                    'roles'     => $roles
                ]);
                return;
            }

            $db = Database::connect();

            // Kiểm tra username trùng lặp
            $checkUser = $db->prepare("SELECT id FROM `users` WHERE `username` = :u LIMIT 1");
            $checkUser->execute([':u' => $username]);
            if ($checkUser->fetch()) {
                set_flash('error', "Tên đăng nhập '$username' đã tồn tại. Vui lòng chọn tên khác!");
                render_admin_view('admin/pages/users/add', [
                    'pageTitle' => "Thêm Thành Viên Mới | LongTech Admin",
                    'roles'     => $roles
                ]);
                return;
            }

            // Kiểm tra email trùng lặp
            $checkEmail = $db->prepare("SELECT id FROM `users` WHERE `email` = :e LIMIT 1");
            $checkEmail->execute([':e' => $email]);
            if ($checkEmail->fetch()) {
                set_flash('error', "Địa chỉ email '$email' đã được sử dụng. Vui lòng chọn email khác!");
                render_admin_view('admin/pages/users/add', [
                    'pageTitle' => "Thêm Thành Viên Mới | LongTech Admin",
                    'roles'     => $roles
                ]);
                return;
            }

            // Băm mật khẩu an toàn
            $passwordHash = password_hash($password, PASSWORD_BCRYPT);

            $stmt = $db->prepare(
                "INSERT INTO `users` (`role_id`, `username`, `email`, `password`, `full_name`, `phone`, `address`, `status`, `require_password_change`, `created_at`)
                 VALUES (:rid, :u, :e, :p, :fn, :ph, :addr, 'active', :req, NOW())"
            );
            $stmt->execute([
                ':rid'  => $roleId,
                ':u'    => $username,
                ':e'    => $email,
                ':p'    => $passwordHash,
                ':fn'   => $fullName,
                ':ph'   => $phone ?: null,
                ':addr' => $address ?: null,
                ':req'  => $reqChange
            ]);

            log_activity('create_user', "Tạo tài khoản mới: $username ($email) với vai trò ID $roleId");
            set_flash('success', "Đã tạo tài khoản cho thành viên \"$fullName\" ($username) thành công!");
            redirect('/admin.php?act=users');
        }

        render_admin_view('admin/pages/users/add', [
            'pageTitle' => "Thêm Thành Viên Mới | LongTech Admin",
            'roles'     => $roles
        ]);
    }

    /**
     * 2. Khóa / Mở khóa tài khoản
     */
    public function toggleStatus() {
        $id = (int)($_GET['id'] ?? 0);
        $currentLoggedInId = (int)($_SESSION['user']['id'] ?? 0);

        if ($id <= 0) {
            set_flash('error', 'Tài khoản không hợp lệ.');
            redirect('/admin.php?act=users');
        }

        // Không cho phép tự khóa tài khoản chính mình
        if ($id === $currentLoggedInId) {
            set_flash('error', 'Bạn không thể tự khóa tài khoản đang đăng nhập của chính mình!');
            redirect('/admin.php?act=users');
        }

        $targetUser = $this->userModel->findById($id);
        if (!$targetUser) {
            set_flash('error', 'Người dùng không tồn tại.');
            redirect('/admin.php?act=users');
        }

        // Người có vai trò admin thường không được phép khóa tài khoản super_admin
        if ($targetUser['role_name'] === 'super_admin' && current_role() !== 'super_admin') {
            set_flash('error', 'Chỉ Super Admin mới có quyền thao tác với tài khoản Super Admin khác.');
            redirect('/admin.php?act=users');
        }

        $this->userModel->toggleUserStatus($id);
        $newStatusText = ($targetUser['status'] === 'active') ? 'đã bị khóa' : 'đã được mở khóa';
        set_flash('success', 'Tài khoản "' . htmlspecialchars($targetUser['username']) . '" ' . $newStatusText . ' thành công.');

        redirect('/admin.php?act=users');
    }

    /**
     * 3. Thay đổi vai trò (Phân quyền 5 vai trò)
     */
    public function changeRole() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/admin.php?act=users');
        }

        verify_csrf_token();

        $userId = (int)($_POST['user_id'] ?? 0);
        $roleId = (int)($_POST['role_id'] ?? 0);
        $currentLoggedInId = (int)($_SESSION['user']['id'] ?? 0);

        if ($userId <= 0 || $roleId <= 0) {
            set_flash('error', 'Dữ liệu phân quyền không hợp lệ.');
            redirect('/admin.php?act=users');
        }

        // Không cho phép tự hạ quyền của chính mình
        if ($userId === $currentLoggedInId && current_role() === 'super_admin' && $roleId !== 1) {
            set_flash('error', 'Bạn không thể tự tước quyền Super Admin của chính mình.');
            redirect('/admin.php?act=users');
        }

        $targetUser = $this->userModel->findById($userId);
        if (!$targetUser) {
            set_flash('error', 'Người dùng không tồn tại.');
            redirect('/admin.php?act=users');
        }

        // Chỉ Super Admin mới có quyền gán hoặc gỡ vai trò Super Admin
        if (($roleId === 1 || $targetUser['role_name'] === 'super_admin') && current_role() !== 'super_admin') {
            set_flash('error', 'Chỉ Super Admin mới có quyền thăng cấp hoặc giáng chức vai trò Super Admin.');
            redirect('/admin.php?act=users');
        }

        $this->userModel->updateUserRole($userId, $roleId);
        set_flash('success', 'Đã cập nhật vai trò phân quyền cho tài khoản "' . htmlspecialchars($targetUser['username']) . '" thành công.');

        redirect('/admin.php?act=users');
    }

    /**
     * Xuất danh sách người dùng ra file CSV
     */
    public function exportCsv(): void {
        $users = $this->userModel->getAllUsers('', null, 1, 10000)['items'] ?? [];
        $rows = [];
        foreach ($users as $u) {
            $rows[] = [
                $u['id'],
                $u['username'],
                $u['full_name'],
                $u['email'],
                $u['phone'] ?? '',
                $u['role_name'] ?? 'customer',
                ($u['status'] ?? 1) == 1 ? 'Hoạt động' : 'Bị khóa',
                $u['created_at'] ?? ''
            ];
        }

        export_csv(
            ['ID', 'Tên Đăng Nhập', 'Họ Tên', 'Email', 'Điện Thoại', 'Vai Trò', 'Trạng Thái', 'Ngày Tạo'],
            $rows,
            'users_' . date('Ymd_His') . '.csv'
        );
    }
}

