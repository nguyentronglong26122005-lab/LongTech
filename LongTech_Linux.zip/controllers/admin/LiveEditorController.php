<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN LÝ GIAO DIỆN & LIVE EDITOR (LiveEditorController.php)
 * ========================================================
 */

require_once __DIR__ . '/../../models/SiteSettingModel.php';
require_once __DIR__ . '/../../includes/auth_middleware.php';

class LiveEditorController {
    private SiteSettingModel $settingModel;

    public function __construct() {
        require_permission(['manage_appearance', 'manage_products']);
        $this->settingModel = new SiteSettingModel();
    }

    /**
     * Trang cấu hình giao diện & Live Editor chính
     */
    public function index(): void {
        $settings = $this->settingModel->getAllSettings();
        $sections = $this->settingModel->getHomepageSections();
        $versions = $this->settingModel->getVersionList();

        $pageTitle = "Trình Chỉnh Sửa Giao Diện & Live Editor | LongTech Admin";
        render_admin_view('admin/pages/appearance/editor', compact('settings', 'sections', 'versions', 'pageTitle'));
    }

    /**
     * AJAX: Lưu một hoặc nhiều cài đặt
     */
    public function saveSettings(): void {
        header('Content-Type: application/json; charset=UTF-8');
        verify_csrf_token();

        $data = $_POST['settings'] ?? [];
        if (!is_array($data) || empty($data)) {
            echo json_encode(['status' => false, 'message' => 'Dữ liệu cài đặt không hợp lệ.']);
            exit();
        }

        $userId = current_user_id();
        $success = $this->settingModel->saveSettings($data, $userId);

        echo json_encode([
            'status'  => $success,
            'message' => $success ? 'Đã lưu cấu hình giao diện thành công!' : 'Lỗi khi lưu cài đặt.'
        ]);
        exit();
    }

    /**
     * AJAX: Lưu chỉnh sửa trực tiếp ngay trên trang (Sản phẩm, Danh mục, hoặc Nội dung giao diện)
     */
    public function liveInlineSave(): void {
        header('Content-Type: application/json; charset=UTF-8');
        verify_csrf_token();

        $targetType = trim($_POST['target_type'] ?? 'setting');
        $field      = trim($_POST['field'] ?? '');
        $newValue   = trim($_POST['new_value'] ?? '');
        $entityId   = (int)($_POST['entity_id'] ?? 0);
        $entitySlug = trim($_POST['entity_slug'] ?? '');
        $settingKey = trim($_POST['setting_key'] ?? '');
        $userId     = current_user_id();

        if ($newValue === '') {
            echo json_encode(['status' => false, 'message' => 'Nội dung chỉnh sửa không được để trống!']);
            exit();
        }

        $db = Database::connect();

        try {
            if ($targetType === 'product') {
                // Tìm sản phẩm theo ID hoặc Slug
                if ($entityId > 0) {
                    $stmt = $db->prepare("SELECT * FROM `products` WHERE `id` = :id LIMIT 1");
                    $stmt->execute([':id' => $entityId]);
                } else {
                    $stmt = $db->prepare("SELECT * FROM `products` WHERE `slug` = :slug LIMIT 1");
                    $stmt->execute([':slug' => $entitySlug]);
                }
                $product = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$product) {
                    echo json_encode(['status' => false, 'message' => 'Không tìm thấy sản phẩm cần cập nhật!']);
                    exit();
                }

                $pid = (int)$product['id'];
                if ($field === 'name') {
                    $up = $db->prepare("UPDATE `products` SET `name` = :val WHERE `id` = :id");
                    $up->execute([':val' => $newValue, ':id' => $pid]);
                    if (!empty($GLOBALS['IS_EXECUTING_APPROVED_ACTION'])) {
                        set_flash('success', "Đã cập nhật tên sản phẩm #$pid thành \"$newValue\"!");
                        redirect('/admin.php?act=approvals');
                    }
                    echo json_encode([
                        'status'          => true,
                        'formatted_value' => $newValue,
                        'message'         => "Đã cập nhật tên sản phẩm #$pid thành công!"
                    ]);
                    exit();
                } elseif ($field === 'price') {
                    $numericPrice = (float)preg_replace('/[^0-9]/', '', $newValue);
                    if ($numericPrice <= 0) {
                        echo json_encode(['status' => false, 'message' => 'Giá sản phẩm không hợp lệ!']);
                        exit();
                    }
                    // Nếu sản phẩm đang có sale_price thì cập nhật sale_price, đồng thời nếu giá mới > price gốc thì nâng price gốc
                    if (!empty($product['sale_price']) && $product['sale_price'] > 0) {
                        $origPrice = max((float)$product['price'], $numericPrice);
                        $up = $db->prepare("UPDATE `products` SET `sale_price` = :sale, `price` = :orig WHERE `id` = :id");
                        $up->execute([':sale' => $numericPrice, ':orig' => $origPrice, ':id' => $pid]);
                    } else {
                        $up = $db->prepare("UPDATE `products` SET `price` = :orig WHERE `id` = :id");
                        $up->execute([':orig' => $numericPrice, ':id' => $pid]);
                    }
                    if (!empty($GLOBALS['IS_EXECUTING_APPROVED_ACTION'])) {
                        set_flash('success', "Đã cập nhật giá sản phẩm #$pid thành " . format_money($numericPrice) . "!");
                        redirect('/admin.php?act=approvals');
                    }
                    echo json_encode([
                        'status'          => true,
                        'formatted_value' => format_money($numericPrice),
                        'message'         => "Đã cập nhật giá sản phẩm #$pid thành " . format_money($numericPrice) . "!"
                    ]);
                    exit();
                } elseif ($field === 'short_description') {
                    $up = $db->prepare("UPDATE `products` SET `short_description` = :val WHERE `id` = :id");
                    $up->execute([':val' => $newValue, ':id' => $pid]);
                    if (!empty($GLOBALS['IS_EXECUTING_APPROVED_ACTION'])) {
                        set_flash('success', "Đã cập nhật mô tả sản phẩm #$pid!");
                        redirect('/admin.php?act=approvals');
                    }
                    echo json_encode([
                        'status'          => true,
                        'formatted_value' => $newValue,
                        'message'         => "Đã cập nhật mô tả sản phẩm #$pid thành công!"
                    ]);
                    exit();
                }
            } elseif ($targetType === 'category' && $entitySlug !== '') {
                $up = $db->prepare("UPDATE `categories` SET `name` = :val WHERE `slug` = :slug");
                $up->execute([':val' => $newValue, ':slug' => $entitySlug]);
                if (!empty($GLOBALS['IS_EXECUTING_APPROVED_ACTION'])) {
                    set_flash('success', "Đã cập nhật tên danh mục thành \"$newValue\"!");
                    redirect('/admin.php?act=approvals');
                }
                echo json_encode([
                    'status'          => true,
                    'formatted_value' => $newValue,
                    'message'         => "Đã cập nhật tên danh mục thành công!"
                ]);
                exit();
            }

            // Mặc định: Lưu vào bảng site_settings theo setting_key
            if ($settingKey === '') {
                echo json_encode(['status' => false, 'message' => 'Thiếu khóa định danh nội dung (setting_key).']);
                exit();
            }
            $this->settingModel->saveSettings([$settingKey => $newValue], $userId);
            if (!empty($GLOBALS['IS_EXECUTING_APPROVED_ACTION'])) {
                set_flash('success', "Đã lưu thay đổi nội dung [$settingKey] trực tiếp trên trang!");
                redirect('/admin.php?act=approvals');
            }
            echo json_encode([
                'status'          => true,
                'formatted_value' => $newValue,
                'message'         => 'Đã lưu thay đổi nội dung trực tiếp trên trang!'
            ]);
            exit();
        } catch (Throwable $e) {
            echo json_encode(['status' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()]);
            exit();
        }
    }

    /**
     * AJAX: Cập nhật sắp xếp thứ tự và ẩn/hiện khối trang chủ
     */
    public function saveSections(): void {
        header('Content-Type: application/json; charset=UTF-8');
        verify_csrf_token();

        $rawSections = $_POST['sections'] ?? '[]';
        $sections = is_array($rawSections) ? $rawSections : json_decode($rawSections, true);

        if (!is_array($sections)) {
            echo json_encode(['status' => false, 'message' => 'Dữ liệu các khối trang chủ không đúng định dạng.']);
            exit();
        }

        $success = $this->settingModel->updateHomepageSections($sections);
        echo json_encode([
            'status'  => $success,
            'message' => $success ? 'Đã cập nhật bố cục trang chủ thành công!' : 'Lỗi khi cập nhật bố cục.'
        ]);
        exit();
    }

    /**
     * Tạo bản lưu lịch sử phiên bản (Snapshot Version)
     */
    public function createVersion(): void {
        header('Content-Type: application/json; charset=UTF-8');
        verify_csrf_token();

        $name = trim($_POST['version_name'] ?? ('Phiên bản ngày ' . date('d/m/Y H:i')));
        $userId = current_user_id();

        $versionId = $this->settingModel->createVersion($name, $userId);
        echo json_encode([
            'status'     => ($versionId > 0),
            'version_id' => $versionId,
            'message'    => 'Đã tạo bản sao lưu phiên bản thành công!'
        ]);
        exit();
    }

    /**
     * Khôi phục phiên bản lịch sử
     */
    public function restoreVersion(): void {
        header('Content-Type: application/json; charset=UTF-8');
        verify_csrf_token();

        $id = (int)($_POST['version_id'] ?? 0);
        if ($id <= 0) {
            echo json_encode(['status' => false, 'message' => 'Mã phiên bản không hợp lệ.']);
            exit();
        }

        $userId = current_user_id();
        $success = $this->settingModel->restoreVersion($id, $userId);

        echo json_encode([
            'status'  => $success,
            'message' => $success ? 'Đã khôi phục cài đặt từ phiên bản đã chọn!' : 'Khôi phục phiên bản thất bại.'
        ]);
        exit();
    }
}

