<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN LÝ GIAO DIỆN & LIVE EDITOR (LiveEditorController.php)
 * ========================================================
 */

require_once __DIR__ . '/../../models/SiteSettingModel.php';
require_once __DIR__ . '/../../includes/auth_middleware.php';

class LiveEditorController {
    private SiteSettingModel $settingModel;

    public function __construct() {
        require_permission('manage_appearance');
        $this->settingModel = new SiteSettingModel();
    }

    /**
     * Trang cấu hình giao diện & Live Editor chính
     */
    public function index(): void {
        $settings = $this->settingModel->getAllSettings();
        $sections = $this->settingModel->getHomepageSections();
        $versions = $this->settingModel->getVersionList();

        $pageTitle = "Trình Chỉnh Sửa Giao Diện & Live Editor | LongTech Admin";
        render_admin_view('admin/pages/appearance/editor', compact('settings', 'sections', 'versions', 'pageTitle'));
    }

    /**
     * AJAX: Lưu một hoặc nhiều cài đặt
     */
    public function saveSettings(): void {
        header('Content-Type: application/json; charset=UTF-8');
        verify_csrf_token();

        $data = $_POST['settings'] ?? [];
        if (!is_array($data) || empty($data)) {
            echo json_encode(['status' => false, 'message' => 'Dữ liệu cài đặt không hợp lệ.']);
            exit();
        }

        $userId = current_user_id();
        $success = $this->settingModel->saveSettings($data, $userId);

        echo json_encode([
            'status'  => $success,
            'message' => $success ? 'Đã lưu cấu hình giao diện thành công!' : 'Lỗi khi lưu cài đặt.'
        ]);
        exit();
    }

    /**
     * AJAX: Cập nhật sắp xếp thứ tự và ẩn/hiện khối trang chủ
     */
    public function saveSections(): void {
        header('Content-Type: application/json; charset=UTF-8');
        verify_csrf_token();

        $rawSections = $_POST['sections'] ?? '[]';
        $sections = is_array($rawSections) ? $rawSections : json_decode($rawSections, true);

        if (!is_array($sections)) {
            echo json_encode(['status' => false, 'message' => 'Dữ liệu các khối trang chủ không đúng định dạng.']);
            exit();
        }

        $success = $this->settingModel->updateHomepageSections($sections);
        echo json_encode([
            'status'  => $success,
            'message' => $success ? 'Đã cập nhật bố cục trang chủ thành công!' : 'Lỗi khi cập nhật bố cục.'
        ]);
        exit();
    }

    /**
     * Tạo bản lưu lịch sử phiên bản (Snapshot Version)
     */
    public function createVersion(): void {
        header('Content-Type: application/json; charset=UTF-8');
        verify_csrf_token();

        $name = trim($_POST['version_name'] ?? ('Phiên bản ngày ' . date('d/m/Y H:i')));
        $userId = current_user_id();

        $versionId = $this->settingModel->createVersion($name, $userId);
        echo json_encode([
            'status'     => ($versionId > 0),
            'version_id' => $versionId,
            'message'    => 'Đã tạo bản sao lưu phiên bản thành công!'
        ]);
        exit();
    }

    /**
     * Khôi phục phiên bản lịch sử
     */
    public function restoreVersion(): void {
        header('Content-Type: application/json; charset=UTF-8');
        verify_csrf_token();

        $id = (int)($_POST['version_id'] ?? 0);
        if ($id <= 0) {
            echo json_encode(['status' => false, 'message' => 'Mã phiên bản không hợp lệ.']);
            exit();
        }

        $userId = current_user_id();
        $success = $this->settingModel->restoreVersion($id, $userId);

        echo json_encode([
            'status'  => $success,
            'message' => $success ? 'Đã khôi phục cài đặt từ phiên bản đã chọn!' : 'Khôi phục phiên bản thất bại.'
        ]);
        exit();
    }
}

