<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN LÝ MÃ GIẢM GIÁ (CouponController.php)
 * ========================================================
 */
require_once __DIR__ . '/../../models/Database.php';
require_once __DIR__ . '/../../includes/auth_middleware.php';

class CouponController {
    private PDO $db;

    public function __construct() {
        require_permission('manage_marketing');
        $this->db = Database::connect();
    }

    /** Danh sách mã giảm giá */
    public function index() {
        $coupons = $this->db->query("SELECT * FROM `coupons` ORDER BY `id` DESC")->fetchAll();
        render_admin_view('admin/pages/coupons/list', [
            'pageTitle' => 'Quản Lý Mã Giảm Giá | LongTech Admin',
            'coupons'   => $coupons
        ]);
    }

    /** Thêm / Sửa coupon */
    public function addEdit() {
        $id     = (int)($_GET['id'] ?? 0);
        $coupon = $id > 0 ? $this->db->query("SELECT * FROM `coupons` WHERE `id` = $id LIMIT 1")->fetch() : null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();

            $code          = strtoupper(trim($_POST['code'] ?? ''));
            $type          = $_POST['type'] ?? 'percentage';
            $value         = (float)($_POST['value'] ?? 0);
            $minOrder      = (float)($_POST['min_order_value'] ?? 0);
            $maxDiscount   = !empty($_POST['max_discount']) ? (float)$_POST['max_discount'] : null;
            $usageLimit    = (int)($_POST['usage_limit'] ?? 100);
            $startDate     = $_POST['start_date'] ?? date('Y-m-d');
            $endDate       = $_POST['end_date'] ?? date('Y-12-31');
            $status        = $_POST['status'] ?? 'active';

            if (empty($code) || $value <= 0) {
                set_flash('error', 'Mã coupon và giá trị giảm không được để trống / bằng 0.');
                redirect('/admin.php?act=coupons/add-edit' . ($id > 0 ? '&id=' . $id : ''));
            }

            if ($id > 0) {
                $stmt = $this->db->prepare("UPDATE `coupons` SET `code`=:c,`type`=:t,`value`=:v,`min_order_value`=:mo,`max_discount`=:md,`usage_limit`=:ul,`start_date`=:sd,`end_date`=:ed,`status`=:s WHERE `id`=:id");
                $stmt->execute([':c'=>$code,':t'=>$type,':v'=>$value,':mo'=>$minOrder,':md'=>$maxDiscount,':ul'=>$usageLimit,':sd'=>$startDate,':ed'=>$endDate,':s'=>$status,':id'=>$id]);
                set_flash('success', 'Cập nhật mã coupon ' . htmlspecialchars($code) . ' thành công!');
            } else {
                // Kiểm tra trùng mã
                $check = $this->db->prepare("SELECT id FROM `coupons` WHERE `code` = :c LIMIT 1");
                $check->execute([':c' => $code]);
                if ($check->fetch()) {
                    set_flash('error', 'Mã coupon "' . htmlspecialchars($code) . '" đã tồn tại trong hệ thống!');
                    redirect('/admin.php?act=coupons/add-edit');
                }
                $stmt = $this->db->prepare("INSERT INTO `coupons`(`code`,`type`,`value`,`min_order_value`,`max_discount`,`usage_limit`,`start_date`,`end_date`,`status`) VALUES(:c,:t,:v,:mo,:md,:ul,:sd,:ed,:s)");
                $stmt->execute([':c'=>$code,':t'=>$type,':v'=>$value,':mo'=>$minOrder,':md'=>$maxDiscount,':ul'=>$usageLimit,':sd'=>$startDate,':ed'=>$endDate,':s'=>$status]);
                set_flash('success', 'Thêm mã coupon ' . htmlspecialchars($code) . ' thành công!');
            }
            redirect('/admin.php?act=coupons');
        }

        render_admin_view('admin/pages/coupons/add-edit', [
            'pageTitle' => ($id > 0 ? 'Chỉnh Sửa Coupon' : 'Tạo Mã Giảm Giá Mới') . ' | LongTech Admin',
            'coupon'    => $coupon
        ]);
    }

    /** Bật / Tắt trạng thái coupon */
    public function toggle() {
        $id = (int)($_GET['id'] ?? 0);
        if ($id > 0) {
            $cur = $this->db->query("SELECT `status` FROM `coupons` WHERE `id` = $id LIMIT 1")->fetchColumn();
            $new = ($cur === 'active') ? 'inactive' : 'active';
            $this->db->prepare("UPDATE `coupons` SET `status`=:s WHERE `id`=:id")->execute([':s'=>$new,':id'=>$id]);
            set_flash('success', 'Đã ' . ($new === 'active' ? 'kích hoạt' : 'tạm dừng') . ' mã coupon #' . $id . '.');
        }
        redirect('/admin.php?act=coupons');
    }

    /** Xóa coupon */
    public function delete() {
        $id = (int)($_GET['id'] ?? 0);
        if ($id > 0) {
            $this->db->prepare("DELETE FROM `coupons` WHERE `id`=:id")->execute([':id'=>$id]);
            set_flash('success', 'Đã xóa mã giảm giá #' . $id . '.');
        }
        redirect('/admin.php?act=coupons');
    }
}

