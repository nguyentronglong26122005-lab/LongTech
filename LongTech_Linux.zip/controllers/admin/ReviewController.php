<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN LÝ ĐÁNH GIÁ SẢN PHẨM (ReviewController.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

require_once ROOT_PATH . '/models/Database.php';

class ReviewController {

    private PDO $db;

    public function __construct() {
        require_roles(['super_admin', 'admin', 'product_manager']);
        $this->db = Database::connect();
    }

    // --------------------------------------------------------
    // Danh sách đánh giá + lọc theo trạng thái
    // --------------------------------------------------------
    public function index(): void {
        $perPage = 20;
        $page    = max(1, (int)($_GET['page'] ?? 1));
        $status  = trim($_GET['status'] ?? '');
        $search  = trim($_GET['search'] ?? '');

        $where  = ['1=1'];
        $params = [];

        if (in_array($status, ['pending', 'approved', 'rejected'], true)) {
            $where[]          = 'r.status = :status';
            $params[':status'] = $status;
        }
        if ($search !== '') {
            $where[]  = '(u.full_name LIKE :s OR pr.name LIKE :s2)';
            $params[':s']  = "%$search%";
            $params[':s2'] = "%$search%";
        }

        $whereSQL = implode(' AND ', $where);

        $stmtCount = $this->db->prepare(
            "SELECT COUNT(*) FROM reviews r
             LEFT JOIN users u ON r.user_id = u.id
             LEFT JOIN products pr ON r.product_id = pr.id
             WHERE $whereSQL"
        );
        $stmtCount->execute($params);
        $totalItems = (int)$stmtCount->fetchColumn();
        $totalPages = max(1, (int)ceil($totalItems / $perPage));
        $page       = min($page, $totalPages);
        $offset     = ($page - 1) * $perPage;

        $stmt = $this->db->prepare(
            "SELECT r.*, u.full_name AS user_name, pr.name AS product_name, pr.id AS product_id
             FROM reviews r
             LEFT JOIN users u ON r.user_id = u.id
             LEFT JOIN products pr ON r.product_id = pr.id
             WHERE $whereSQL
             ORDER BY r.created_at DESC
             LIMIT :limit OFFSET :offset"
        );
        foreach ($params as $k => $v) {
            $stmt->bindValue($k, $v);
        }
        $stmt->bindValue(':limit',  $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset,  PDO::PARAM_INT);
        $stmt->execute();
        $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Đếm theo trạng thái
        $counts = $this->db->query(
            "SELECT status, COUNT(*) as cnt FROM reviews GROUP BY status"
        )->fetchAll(PDO::FETCH_KEY_PAIR);

        $baseUrl    = APP_URL . '/admin.php?act=reviews&status=' . urlencode($status) . '&search=' . urlencode($search);
        $pagination = render_pagination($page, $totalPages, $baseUrl);

        render_admin_view('admin/pages/reviews/list', compact(
            'reviews', 'status', 'search', 'page', 'totalPages', 'totalItems', 'pagination', 'counts'
        ));
    }

    // --------------------------------------------------------
    // Duyệt / Từ chối đánh giá
    // --------------------------------------------------------
    public function approve(): void {
        verify_csrf_token();

        $id        = (int)($_POST['id'] ?? 0);
        $newStatus = in_array($_POST['new_status'] ?? '', ['approved', 'rejected', 'pending'], true)
            ? $_POST['new_status'] : 'approved';

        if ($id <= 0) {
            set_flash('error', 'ID đánh giá không hợp lệ!');
            redirect(APP_URL . '/admin.php?act=reviews');
        }

        $this->db->prepare("UPDATE reviews SET status = :status WHERE id = :id")
            ->execute([':status' => $newStatus, ':id' => $id]);

        $label = match ($newStatus) {
            'approved' => 'Đã duyệt',
            'rejected' => 'Đã từ chối',
            default    => 'Đặt lại chờ duyệt',
        };
        set_flash('success', "$label đánh giá #$id thành công!");
        redirect(APP_URL . '/admin.php?act=reviews');
    }

    // --------------------------------------------------------
    // Xóa đánh giá
    // --------------------------------------------------------
    public function delete(): void {
        verify_csrf_token();

        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            set_flash('error', 'ID không hợp lệ!');
            redirect(APP_URL . '/admin.php?act=reviews');
        }

        $this->db->prepare("DELETE FROM reviews WHERE id = :id")->execute([':id' => $id]);
        set_flash('success', "Đã xóa đánh giá #$id thành công!");
        redirect(APP_URL . '/admin.php?act=reviews');
    }
}

