<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN LÝ SẢN PHẨM & KHO HÀNG (ProductManageController.php)
 * ========================================================
 * - Phân quyền Server-Side: Super Admin, Admin, Nhân viên sản phẩm (product_manager)
 * - Xử lý CRUD Sản phẩm, Quản lý kho, Upload hình ảnh an toàn
 * - Xử lý CRUD Danh mục sản phẩm
 */

require_once __DIR__ . '/../../models/ProductModel.php';
require_once __DIR__ . '/../../models/CategoryModel.php';
require_once __DIR__ . '/../../includes/auth_middleware.php';

class ProductManageController {
    private ProductModel $productModel;
    private CategoryModel $categoryModel;

    public function __construct() {
        // Kiểm tra quyền chức năng: Quản lý Sản phẩm & Kho hàng
        require_permission('manage_products');
        $this->productModel = new ProductModel();
        $this->categoryModel = new CategoryModel();
    }

    /**
     * 1. Danh sách sản phẩm (Bảng quản lý, tìm kiếm, lọc kho)
     */
    public function index() {
        $keyword     = trim($_GET['keyword'] ?? '');
        $categoryId  = (int)($_GET['category_id'] ?? 0);
        $brandId     = (int)($_GET['brand_id'] ?? 0);
        $stockFilter = trim($_GET['stock'] ?? '');

        $products = $this->productModel->getAllAdminProducts($keyword, $categoryId, $brandId, $stockFilter);
        $categories = $this->categoryModel->getAllCategories();
        $brands = $this->productModel->getAllBrands();

        $pageTitle = "Quản Lý Sản Phẩm & Tồn Kho | LongTech Admin";

        render_admin_view('admin/pages/products/list', [
            'pageTitle'    => $pageTitle,
            'products'     => $products,
            'categories'   => $categories,
            'brands'       => $brands,
            'keyword'      => $keyword,
            'categoryId'   => $categoryId,
            'brandId'      => $brandId,
            'stockFilter'  => $stockFilter
        ]);
    }

    /**
     * 2. Thêm sản phẩm mới
     */
    public function add() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();

            $name        = trim($_POST['name'] ?? '');
            $productCode = strtoupper(trim($_POST['product_code'] ?? ''));
            $categoryId  = (int)($_POST['category_id'] ?? 0);
            $brandId     = (int)($_POST['brand_id'] ?? 0);
            $price       = (float)($_POST['price'] ?? 0);
            $salePrice   = !empty($_POST['sale_price']) ? (float)$_POST['sale_price'] : null;
            $stock       = max(0, (int)($_POST['stock_quantity'] ?? 0));
            $thumbnail   = trim($_POST['thumbnail_url'] ?? '');

            if (empty($name) || empty($productCode) || $categoryId <= 0 || $price <= 0) {
                set_flash('error', 'Vui lòng điền đầy đủ các thông tin bắt buộc (Tên, Mã SP, Danh mục, Giá).');
                redirect('/admin.php?act=products/add');
            }

            // Xử lý upload ảnh chính (nếu có file tải lên)
            if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] === UPLOAD_ERR_OK) {
                $uploadRes = upload_image('thumbnail', 'products');
                if ($uploadRes['status']) {
                    $thumbnail = $uploadRes['full_url'];
                }
            }

            if (empty($thumbnail)) {
                $thumbnail = 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=600&auto=format&fit=crop';
            }

            // Tạo slug duy nhất
            $slug = slugify($name);
            $checkProduct = $this->productModel->getBySlug($slug);
            if ($checkProduct) {
                $slug .= '-' . strtolower(bin2hex(random_bytes(2)));
            }

            $productData = [
                'category_id'       => $categoryId,
                'brand_id'          => $brandId,
                'product_code'      => $productCode,
                'name'              => $name,
                'slug'              => $slug,
                'price'             => $price,
                'sale_price'        => $salePrice,
                'stock_quantity'    => $stock,
                'thumbnail'         => $thumbnail,
                'short_description' => trim($_POST['short_description'] ?? ''),
                'description'       => trim($_POST['description'] ?? ''),
                'colors'            => trim($_POST['colors'] ?? ''),
                'storage_options'   => trim($_POST['storage_options'] ?? ''),
                'ram_options'       => trim($_POST['ram_options'] ?? ''),
                'screen'            => trim($_POST['screen'] ?? ''),
                'camera'            => trim($_POST['camera'] ?? ''),
                'battery'           => trim($_POST['battery'] ?? ''),
                'warranty_months'   => (int)($_POST['warranty_months'] ?? 12),
                'is_featured'       => isset($_POST['is_featured']),
                'is_hot_deal'       => isset($_POST['is_hot_deal']),
                'is_new'            => isset($_POST['is_new']),
                'status'            => $_POST['status'] ?? 'active'
            ];

            $newId = $this->productModel->createProduct($productData);

            // Xử lý thêm album ảnh phụ nếu có
            if (!empty($_POST['extra_images'])) {
                $extraUrls = explode("\n", $_POST['extra_images']);
                foreach ($extraUrls as $url) {
                    $url = trim($url);
                    if (!empty($url)) {
                        $this->productModel->addProductImage($newId, $url);
                    }
                }
            }

            set_flash('success', 'Thêm sản phẩm mới "' . htmlspecialchars($name) . '" thành công!');
            redirect('/admin.php?act=products');
        }

        $categories = $this->categoryModel->getActiveCategories();
        $brands = $this->productModel->getAllBrands();
        $pageTitle = "Thêm Sản Phẩm Mới | LongTech Admin";

        render_admin_view('admin/pages/products/add', [
            'pageTitle'  => $pageTitle,
            'categories' => $categories,
            'brands'     => $brands
        ]);
    }

    /**
     * 3. Chỉnh sửa sản phẩm
     */
    public function edit() {
        $id = (int)($_GET['id'] ?? ($_POST['id'] ?? 0));
        $product = $this->productModel->getById($id);

        if (!$product) {
            set_flash('error', 'Sản phẩm không tồn tại.');
            redirect('/admin.php?act=products');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();

            $name        = trim($_POST['name'] ?? '');
            $productCode = strtoupper(trim($_POST['product_code'] ?? ''));
            $categoryId  = (int)($_POST['category_id'] ?? 0);
            $brandId     = (int)($_POST['brand_id'] ?? 0);
            $price       = (float)($_POST['price'] ?? 0);
            $salePrice   = !empty($_POST['sale_price']) ? (float)$_POST['sale_price'] : null;
            $stock       = max(0, (int)($_POST['stock_quantity'] ?? 0));
            $thumbnail   = trim($_POST['thumbnail_url'] ?? $product['thumbnail']);

            // Nếu upload ảnh mới
            if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] === UPLOAD_ERR_OK) {
                $uploadRes = upload_image('thumbnail', 'products');
                if ($uploadRes['status']) {
                    $thumbnail = $uploadRes['full_url'];
                }
            }

            // Slug giữ nguyên hoặc cập nhật nếu đổi tên
            $slug = !empty($_POST['slug']) ? slugify($_POST['slug']) : $product['slug'];

            $productData = [
                'category_id'       => $categoryId,
                'brand_id'          => $brandId,
                'product_code'      => $productCode,
                'name'              => $name,
                'slug'              => $slug,
                'price'             => $price,
                'sale_price'        => $salePrice,
                'stock_quantity'    => $stock,
                'thumbnail'         => $thumbnail,
                'short_description' => trim($_POST['short_description'] ?? ''),
                'description'       => trim($_POST['description'] ?? ''),
                'colors'            => trim($_POST['colors'] ?? ''),
                'storage_options'   => trim($_POST['storage_options'] ?? ''),
                'ram_options'       => trim($_POST['ram_options'] ?? ''),
                'screen'            => trim($_POST['screen'] ?? ''),
                'camera'            => trim($_POST['camera'] ?? ''),
                'battery'           => trim($_POST['battery'] ?? ''),
                'warranty_months'   => (int)($_POST['warranty_months'] ?? 12),
                'is_featured'       => isset($_POST['is_featured']),
                'is_hot_deal'       => isset($_POST['is_hot_deal']),
                'is_new'            => isset($_POST['is_new']),
                'status'            => $_POST['status'] ?? 'active'
            ];

            $this->productModel->updateProduct($id, $productData);

            // Thêm ảnh phụ mới
            if (!empty($_POST['extra_images'])) {
                $extraUrls = explode("\n", $_POST['extra_images']);
                foreach ($extraUrls as $url) {
                    $url = trim($url);
                    if (!empty($url)) {
                        $this->productModel->addProductImage($id, $url);
                    }
                }
            }

            // Xóa ảnh phụ nếu có yêu cầu
            if (!empty($_GET['del_img'])) {
                $this->productModel->deleteProductImage((int)$_GET['del_img']);
            }

            set_flash('success', 'Cập nhật sản phẩm #' . $id . ' thành công!');
            redirect('/admin.php?act=products');
        }

        $categories = $this->categoryModel->getActiveCategories();
        $brands = $this->productModel->getAllBrands();
        $productImages = $this->productModel->getProductImages($id);
        $pageTitle = "Chỉnh Sửa Sản Phẩm: " . $product['name'] . " | LongTech Admin";

        render_admin_view('admin/pages/products/edit', [
            'pageTitle'     => $pageTitle,
            'product'       => $product,
            'categories'    => $categories,
            'brands'        => $brands,
            'productImages' => $productImages
        ]);
    }

    /**
     * 4. Xóa sản phẩm
     */
    public function delete() {
        $id = (int)($_GET['id'] ?? 0);
        if ($id > 0) {
            $this->productModel->deleteProduct($id);
            set_flash('success', 'Đã xóa sản phẩm #' . $id . ' khỏi hệ thống.');
        }
        redirect('/admin.php?act=products');
    }

    /**
     * 5. Quản lý Danh mục (List)
     */
    public function categories() {
        $categories = $this->categoryModel->getAllCategories();
        $pageTitle = "Quản Lý Danh Mục Sản Phẩm | LongTech Admin";

        render_admin_view('admin/pages/categories/list', [
            'pageTitle'  => $pageTitle,
            'categories' => $categories
        ]);
    }

    /**
     * 6. Thêm / Sửa Danh mục
     */
    public function categoryAddEdit() {
        $id = (int)($_GET['id'] ?? 0);
        $category = ($id > 0) ? $this->categoryModel->getById($id) : null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();

            $name      = trim($_POST['name'] ?? '');
            $icon      = trim($_POST['icon'] ?? 'fa-cube');
            $sortOrder = (int)($_POST['sort_order'] ?? 0);
            $status    = $_POST['status'] ?? 'active';

            if (empty($name)) {
                set_flash('error', 'Tên danh mục không được để trống.');
                redirect('/admin.php?act=categories/add-edit' . ($id > 0 ? '&id=' . $id : ''));
            }

            $slug = !empty($_POST['slug']) ? slugify($_POST['slug']) : slugify($name);

            $data = [
                'name'       => $name,
                'slug'       => $slug,
                'icon'       => $icon,
                'status'     => $status,
                'sort_order' => $sortOrder
            ];

            if ($id > 0) {
                $this->categoryModel->updateCategory($id, $data);
                set_flash('success', 'Cập nhật danh mục thành công!');
            } else {
                $this->categoryModel->createCategory($data);
                set_flash('success', 'Thêm danh mục mới thành công!');
            }

            redirect('/admin.php?act=categories');
        }

        $pageTitle = ($id > 0) ? "Chỉnh Sửa Danh Mục" : "Thêm Danh Mục Mới";
        render_admin_view('admin/pages/categories/add-edit', [
            'pageTitle' => $pageTitle . " | LongTech Admin",
            'category'  => $category
        ]);
    }

    /**
     * 7. Xóa Danh mục
     */
    public function categoryDelete() {
        $id = (int)($_GET['id'] ?? 0);
        if ($id > 0) {
            $this->categoryModel->deleteCategory($id);
            set_flash('success', 'Đã xóa danh mục.');
        }
        redirect('/admin.php?act=categories');
    }

    /**
     * 8. Xuất danh sách sản phẩm dạng CSV
     */
    public function exportCsv(): void {
        $products = $this->productModel->getAllForAdmin('', null, 1, 10000)['items'] ?? [];
        $rows = [];
        foreach ($products as $p) {
            $rows[] = [
                $p['id'],
                $p['sku'] ?? ('SP-' . $p['id']),
                $p['name'],
                $p['category_name'] ?? '',
                $p['brand_name'] ?? '',
                (float)$p['price'],
                (float)($p['sale_price'] ?? 0),
                (int)$p['stock'],
                ($p['status'] ?? 1) == 1 ? 'Đang bán' : 'Ngừng bán',
                $p['created_at'] ?? ''
            ];
        }

        export_csv(
            ['ID', 'Mã SKU', 'Tên sản phẩm', 'Danh mục', 'Thương hiệu', 'Giá gốc', 'Giá KM', 'Tồn kho', 'Trạng thái', 'Ngày tạo'],
            $rows,
            'products_' . date('Ymd_His') . '.csv'
        );
    }
}

