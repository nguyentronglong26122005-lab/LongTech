<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN LÝ ĐƠN HÀNG (OrderManageController.php)
 * ========================================================
 * - Phân quyền Server-Side: Super Admin, Admin, Nhân viên đơn hàng (order_manager)
 * - Xử lý Vòng đời 7 bước đơn hàng:
 *   1. Chờ xử lý (pending)
 *   2. Đã xác nhận (confirmed)
 *   3. Đang đóng gói (processing)
 *   4. Đang giao hàng (shipping)
 *   5. Giao thành công (completed)
 *   6. Đã hủy đơn (cancelled - tự động hoàn kho)
 *   7. Hoàn tiền (refunded)
 */

require_once __DIR__ . '/../../models/OrderModel.php';
require_once __DIR__ . '/../../models/UserModel.php';
require_once __DIR__ . '/../../includes/auth_middleware.php';

class OrderManageController {
    private OrderModel $orderModel;
    private UserModel $userModel;

    public function __construct() {
        // Kiểm tra quyền hạn: Chỉ Super Admin, Admin, Nhân viên đơn hàng được phép
        require_roles(['super_admin', 'admin', 'order_manager']);
        $this->orderModel = new OrderModel();
        $this->userModel = new UserModel();
    }

    /**
     * 1. Danh sách đơn hàng (Lọc trạng thái, tìm kiếm mã đơn / khách hàng)
     */
    public function index() {
        $statusFilter = trim($_GET['status'] ?? '');
        $keyword      = trim($_GET['keyword'] ?? '');

        $orders = $this->orderModel->getAllOrders($statusFilter, $keyword);

        // Lấy số lượng đơn theo từng trạng thái để làm tab đếm
        $allOrders = $this->orderModel->getAllOrders('', '');
        $statusCounts = [
            'all'        => count($allOrders),
            'pending'    => 0,
            'confirmed'  => 0,
            'processing' => 0,
            'shipping'   => 0,
            'completed'  => 0,
            'cancelled'  => 0
        ];
        foreach ($allOrders as $o) {
            $st = $o['status'];
            if (isset($statusCounts[$st])) {
                $statusCounts[$st]++;
            }
        }

        $pageTitle = "Quản Lý Đơn Hàng & Vận Chuyển | LongTech Admin";

        render_admin_view('admin/pages/orders/list', [
            'pageTitle'    => $pageTitle,
            'orders'       => $orders,
            'statusFilter' => $statusFilter,
            'keyword'      => $keyword,
            'statusCounts' => $statusCounts
        ]);
    }

    /**
     * 2. Xem chi tiết đơn hàng & Lịch sử xử lý
     */
    public function detail() {
        $id = (int)($_GET['id'] ?? 0);
        $order = $this->orderModel->getOrderById($id);

        if (!$order) {
            set_flash('error', 'Đơn hàng #' . $id . ' không tồn tại trên hệ thống.');
            redirect('/admin.php?act=orders');
        }

        $items = $this->orderModel->getOrderItems($id);
        $customerUser = $order['user_id'] ? $this->userModel->findById($order['user_id']) : null;

        $pageTitle = "Chi Tiết Đơn Hàng " . $order['order_code'] . " | LongTech Admin";

        render_admin_view('admin/pages/orders/detail', [
            'pageTitle'    => $pageTitle,
            'order'        => $order,
            'items'        => $items,
            'customerUser' => $customerUser
        ]);
    }

    /**
     * 3. Cập nhật trạng thái đơn hàng & Thanh toán
     */
    public function updateStatus() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect('/admin.php?act=orders');
        }

        verify_csrf_token();

        $id = (int)($_POST['id'] ?? 0);
        $status = trim($_POST['status'] ?? '');
        $paymentStatus = trim($_POST['payment_status'] ?? '');

        $order = $this->orderModel->getOrderById($id);
        if (!$order) {
            set_flash('error', 'Đơn hàng không tồn tại.');
            redirect('/admin.php?act=orders');
        }

        $allowedStatuses = ['pending', 'confirmed', 'processing', 'shipping', 'completed', 'cancelled', 'refunded'];
        $allowedPayment  = ['unpaid', 'paid', 'refunded'];

        if (!in_array($status, $allowedStatuses)) {
            set_flash('error', 'Trạng thái đơn hàng không hợp lệ.');
            redirect('/admin.php?act=orders/detail&id=' . $id);
        }

        if (!empty($paymentStatus) && !in_array($paymentStatus, $allowedPayment)) {
            set_flash('error', 'Trạng thái thanh toán không hợp lệ.');
            redirect('/admin.php?act=orders/detail&id=' . $id);
        }

        $success = $this->orderModel->updateOrderStatus($id, $status, $paymentStatus);

        if ($success) {
            $msg = 'Đã cập nhật đơn hàng ' . $order['order_code'] . ' sang trạng thái "' . self::getStatusLabel($status) . '".';
            if ($status === 'cancelled') {
                $msg .= ' Số lượng sản phẩm đã tự động được hoàn lại kho hàng.';
            }
            set_flash('success', $msg);
        } else {
            set_flash('error', 'Có lỗi khi cập nhật đơn hàng, vui lòng thử lại.');
        }

        redirect('/admin.php?act=orders/detail&id=' . $id);
    }

    /**
     * Xuất danh sách đơn hàng ra file CSV
     */
    public function exportCsv(): void {
        $orders = $this->orderModel->getAll(1, 10000)['items'] ?? [];
        $rows = [];
        foreach ($orders as $o) {
            $rows[] = [
                $o['id'],
                $o['order_code'] ?? ('#' . $o['id']),
                $o['customer_name'] ?? ($o['shipping_name'] ?? 'Khách lẻ'),
                $o['shipping_phone'] ?? '',
                (float)$o['total_amount'],
                self::getStatusLabel($o['status'] ?? 'pending'),
                $o['payment_method'] ?? 'COD',
                $o['payment_status'] ?? 'unpaid',
                $o['created_at'] ?? ''
            ];
        }

        export_csv(
            ['ID', 'Mã Đơn', 'Khách Hàng', 'Số Điện Thoại', 'Tổng Tiền (VNĐ)', 'Trạng Thái', 'Phương Thức TT', 'Tình Trạng TT', 'Ngày Đặt'],
            $rows,
            'orders_' . date('Ymd_His') . '.csv'
        );
    }

    /**
     * Nhãn hiển thị tiếng Việt của trạng thái đơn hàng
     */
    public static function getStatusLabel(string $status): string {
        return match ($status) {
            'pending'    => 'Chờ xử lý',
            'confirmed'  => 'Đã xác nhận',
            'processing' => 'Đang đóng gói',
            'shipping'   => 'Đang giao hàng',
            'completed'  => 'Hoàn thành',
            'cancelled'  => 'Đã hủy',
            'refunded'   => 'Đã hoàn tiền',
            default      => ucfirst($status)
        };
    }
}

