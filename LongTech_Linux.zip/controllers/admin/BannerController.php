<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN LÝ BANNER & SLIDESHOW (BannerController.php)
 * ========================================================
 */
require_once __DIR__ . '/../../models/Database.php';
require_once __DIR__ . '/../../includes/auth_middleware.php';

class BannerController {
    private PDO $db;

    public function __construct() {
        require_roles(['super_admin', 'admin', 'product_manager']);
        $this->db = Database::connect();
    }

    /** Danh sách banner */
    public function index() {
        $banners = $this->db->query("SELECT * FROM `banners` ORDER BY `position`, `sort_order` ASC")->fetchAll();
        render_admin_view('admin/pages/banners/list', [
            'pageTitle' => 'Quản Lý Banner & Slideshow | LongTech Admin',
            'banners'   => $banners
        ]);
    }

    /** Thêm / Sửa banner */
    public function addEdit() {
        $id     = (int)($_GET['id'] ?? 0);
        $banner = $id > 0 ? $this->db->query("SELECT * FROM `banners` WHERE `id` = $id LIMIT 1")->fetch() : null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();

            $title    = trim($_POST['title'] ?? '');
            $subtitle = trim($_POST['subtitle'] ?? '');
            $imageUrl = trim($_POST['image_url'] ?? '');
            $link     = trim($_POST['link'] ?? '#');
            $position = $_POST['position'] ?? 'home_slider';
            $sortOrder = (int)($_POST['sort_order'] ?? 0);
            $status   = $_POST['status'] ?? 'active';

            if (empty($title) || empty($imageUrl)) {
                set_flash('error', 'Tiêu đề và URL hình ảnh không được để trống.');
                redirect('/admin.php?act=banners/add-edit' . ($id > 0 ? '&id=' . $id : ''));
            }

            // Xử lý upload ảnh nếu có file
            if (isset($_FILES['image_file']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
                $upload = upload_image('image_file', 'banners');
                if ($upload['status']) $imageUrl = $upload['full_url'];
            }

            if ($id > 0) {
                $stmt = $this->db->prepare("UPDATE `banners` SET `title`=:t,`subtitle`=:st,`image_url`=:img,`link`=:lk,`position`=:pos,`sort_order`=:so,`status`=:s WHERE `id`=:id");
                $stmt->execute([':t'=>$title,':st'=>$subtitle,':img'=>$imageUrl,':lk'=>$link,':pos'=>$position,':so'=>$sortOrder,':s'=>$status,':id'=>$id]);
                set_flash('success', 'Cập nhật banner "' . htmlspecialchars($title) . '" thành công!');
            } else {
                $stmt = $this->db->prepare("INSERT INTO `banners`(`title`,`subtitle`,`image_url`,`link`,`position`,`sort_order`,`status`) VALUES(:t,:st,:img,:lk,:pos,:so,:s)");
                $stmt->execute([':t'=>$title,':st'=>$subtitle,':img'=>$imageUrl,':lk'=>$link,':pos'=>$position,':so'=>$sortOrder,':s'=>$status]);
                set_flash('success', 'Thêm banner "' . htmlspecialchars($title) . '" thành công!');
            }
            redirect('/admin.php?act=banners');
        }

        render_admin_view('admin/pages/banners/add-edit', [
            'pageTitle' => ($id > 0 ? 'Chỉnh Sửa Banner' : 'Thêm Banner Mới') . ' | LongTech Admin',
            'banner'    => $banner
        ]);
    }

    /** Xóa banner */
    public function delete() {
        $id = (int)($_GET['id'] ?? 0);
        if ($id > 0) {
            $this->db->prepare("DELETE FROM `banners` WHERE `id` = :id")->execute([':id' => $id]);
            set_flash('success', 'Đã xóa banner #' . $id . ' khỏi hệ thống.');
        }
        redirect('/admin.php?act=banners');
    }
}

