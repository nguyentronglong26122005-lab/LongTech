<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER GIỎ HÀNG & THANH TOÁN (CartController.php)
 * ========================================================
 * Xử lý:
 * - Thêm vào giỏ (AJAX hoặc chuyển trang), Cập nhật số lượng, Xóa sản phẩm
 * - Áp dụng và xóa mã giảm giá (Coupon)
 * - Tính toán phí vận chuyển tự động (30.000đ, miễn ship đơn từ 2.000.000đ)
 * - Quy trình Đặt hàng & Thanh toán (COD / Chuyển khoản ngân hàng)
 * - Xử lý gửi biểu mẫu Liên hệ & Góp ý
 */

require_once __DIR__ . '/../models/ProductModel.php';
require_once __DIR__ . '/../models/OrderModel.php';

class CartController {
    private ProductModel $productModel;
    private OrderModel $orderModel;

    public function __construct() {
        $this->productModel = new ProductModel();
        $this->orderModel = new OrderModel();

        if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
    }

    /**
     * 1. Hiển thị trang giỏ hàng
     */
    public function index() {
        $cartTotals = $this->calculateTotals();

        $pageTitle = "Giỏ Hàng Công Nghệ Của Bạn (" . $cartTotals['total_items'] . ") | LongTech";
        render_view('client/pages/cart', [
            'pageTitle'  => $pageTitle,
            'cart'       => $_SESSION['cart'],
            'cartTotals' => $cartTotals
        ]);
    }

    /**
     * 2. Thêm sản phẩm vào giỏ hàng
     */
    public function add() {
        $productId = (int)($_POST['product_id'] ?? ($_GET['id'] ?? 0));
        $quantity  = max(1, (int)($_POST['quantity'] ?? ($_GET['qty'] ?? 1)));
        $color     = trim($_POST['color'] ?? ($_GET['color'] ?? ''));
        $storage   = trim($_POST['storage'] ?? ($_GET['storage'] ?? ''));
        $buyNow    = isset($_POST['buynow']) || isset($_GET['buynow']);

        $product = $this->productModel->getById($productId);
        if (!$product || $product['status'] !== 'active') {
            if ($this->isAjax()) {
                echo json_encode(['status' => 'error', 'message' => 'Sản phẩm không tồn tại hoặc đã ngừng bán.']);
                exit();
            }
            set_flash('error', 'Sản phẩm không tồn tại.');
            redirect('/san-pham');
        }

        // Kiểm tra số lượng tồn kho
        if ($product['stock_quantity'] <= 0) {
            if ($this->isAjax()) {
                echo json_encode(['status' => 'error', 'message' => 'Sản phẩm này tạm thời đã hết hàng.']);
                exit();
            }
            set_flash('error', 'Sản phẩm này hiện đã hết hàng.');
            redirect('/san-pham/' . $product['slug']);
        }

        // Tạo khóa định danh phân biệt phiên bản sản phẩm
        $itemKey = $productId . '_' . md5($color . '_' . $storage);
        $price = !empty($product['sale_price']) && $product['sale_price'] < $product['price']
            ? (float)$product['sale_price'] 
            : (float)$product['price'];

        if (isset($_SESSION['cart'][$itemKey])) {
            $newQty = $_SESSION['cart'][$itemKey]['quantity'] + $quantity;
            if ($newQty > $product['stock_quantity']) {
                $newQty = $product['stock_quantity'];
            }
            $_SESSION['cart'][$itemKey]['quantity'] = $newQty;
        } else {
            $_SESSION['cart'][$itemKey] = [
                'id'         => $product['id'],
                'name'       => $product['name'],
                'slug'       => $product['slug'],
                'thumbnail'  => $product['thumbnail'],
                'price'      => $price,
                'quantity'   => min($quantity, $product['stock_quantity']),
                'color'      => $color,
                'storage'    => $storage,
                'stock'      => $product['stock_quantity']
            ];
        }

        $totalItems = $this->getTotalItemCount();

        if ($this->isAjax()) {
            echo json_encode([
                'status'      => 'success',
                'message'     => 'Đã thêm "' . $product['name'] . '" vào giỏ hàng!',
                'total_items' => $totalItems
            ]);
            exit();
        }

        if ($buyNow) {
            redirect('/thanh-toan');
        }

        set_flash('success', 'Đã thêm sản phẩm vào giỏ hàng thành công!');
        redirect('/gio-hang');
    }

    /**
     * 3. Cập nhật số lượng sản phẩm trong giỏ
     */
    public function update() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $key    = trim($_POST['item_key'] ?? '');
            $action = trim($_POST['action'] ?? '');
            $newQty = (int)($_POST['quantity'] ?? 0);

            if (isset($_SESSION['cart'][$key])) {
                $stock = $_SESSION['cart'][$key]['stock'] ?? 999;

                if ($action === 'increase') {
                    if ($_SESSION['cart'][$key]['quantity'] < $stock) {
                        $_SESSION['cart'][$key]['quantity']++;
                    } else {
                        set_flash('error', 'Đã đạt giới hạn số lượng còn trong kho.');
                    }
                } elseif ($action === 'decrease') {
                    if ($_SESSION['cart'][$key]['quantity'] > 1) {
                        $_SESSION['cart'][$key]['quantity']--;
                    } else {
                        unset($_SESSION['cart'][$key]);
                    }
                } elseif ($newQty > 0) {
                    $_SESSION['cart'][$key]['quantity'] = min($newQty, $stock);
                } else {
                    unset($_SESSION['cart'][$key]);
                }
            }
        }
        redirect('/gio-hang');
    }

    /**
     * 4. Xóa sản phẩm khỏi giỏ hàng
     */
    public function delete() {
        $key = trim($_GET['key'] ?? ($_POST['item_key'] ?? ''));
        if (isset($_SESSION['cart'][$key])) {
            unset($_SESSION['cart'][$key]);
            set_flash('success', 'Đã xóa sản phẩm khỏi giỏ hàng.');
        }

        if (empty($_SESSION['cart'])) {
            unset($_SESSION['coupon']);
        }

        redirect('/gio-hang');
    }

    /**
     * 5. Áp dụng mã giảm giá (Coupon)
     */
    public function applyCoupon() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();
            $code = trim($_POST['coupon_code'] ?? '');

            if (empty($code)) {
                set_flash('error', 'Vui lòng nhập mã giảm giá.');
                redirect('/gio-hang');
            }

            $totals = $this->calculateTotals();
            if ($totals['subtotal'] <= 0) {
                set_flash('error', 'Giỏ hàng của bạn đang trống.');
                redirect('/gio-hang');
            }

            $result = $this->orderModel->applyCoupon($code, $totals['subtotal']);
            if ($result['status']) {
                $_SESSION['coupon'] = [
                    'code'     => $result['coupon']['code'],
                    'discount' => $result['discount']
                ];
                set_flash('success', $result['message']);
            } else {
                unset($_SESSION['coupon']);
                set_flash('error', $result['message']);
            }
        }
        redirect('/gio-hang');
    }

    /**
     * 6. Hủy bỏ mã giảm giá đang dùng
     */
    public function removeCoupon() {
        unset($_SESSION['coupon']);
        set_flash('info', 'Đã hủy bỏ mã giảm giá.');
        redirect('/gio-hang');
    }

    /**
     * 7. Quy trình Thanh toán & Đặt hàng
     */
    public function checkout() {
        if (empty($_SESSION['cart'])) {
            set_flash('error', 'Giỏ hàng của bạn đang trống. Vui lòng chọn sản phẩm để thanh toán.');
            redirect('/gio-hang');
        }

        $cartTotals = $this->calculateTotals();
        $currentUser = current_user();

        // Xử lý gửi Form Đặt hàng (POST)
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();

            $customerName    = trim($_POST['customer_name'] ?? '');
            $customerPhone   = trim($_POST['customer_phone'] ?? '');
            $customerEmail   = trim($_POST['customer_email'] ?? '');
            $city            = trim($_POST['city'] ?? '');
            $district        = trim($_POST['district'] ?? '');
            $ward            = trim($_POST['ward'] ?? '');
            $customerAddress = trim($_POST['customer_address'] ?? '');
            $note            = trim($_POST['note'] ?? '');
            $paymentMethod   = in_array($_POST['payment_method'] ?? '', ['cod', 'bank_transfer']) 
                                ? $_POST['payment_method'] 
                                : 'cod';

            // Kiểm tra tính hợp lệ dữ liệu
            if (empty($customerName) || empty($customerPhone) || empty($customerAddress) || empty($city) || empty($district)) {
                set_flash('error', 'Vui lòng điền đầy đủ các thông tin nhận hàng bắt buộc.');
                redirect('/thanh-toan');
            }

            if (!preg_match('/(0[3|5|7|8|9])+([0-9]{8})\b/', $customerPhone)) {
                set_flash('error', 'Số điện thoại nhận hàng không hợp lệ (gồm 10 chữ số).');
                redirect('/thanh-toan');
            }

            // Chuẩn bị dữ liệu lưu đơn hàng
            $orderData = [
                'user_id'          => current_user_id(),
                'customer_name'    => $customerName,
                'customer_phone'   => $customerPhone,
                'customer_email'   => $customerEmail ?: ($currentUser['email'] ?? 'guest@longtech.vn'),
                'customer_address' => $customerAddress,
                'city'             => $city,
                'district'         => $district,
                'ward'             => $ward,
                'note'             => $note,
                'payment_method'   => $paymentMethod,
                'shipping_fee'     => $cartTotals['shipping_fee'],
                'discount_amount'  => $cartTotals['discount'],
                'subtotal'         => $cartTotals['subtotal'],
                'total_amount'     => $cartTotals['total_amount'],
                'coupon_code'      => $_SESSION['coupon']['code'] ?? null
            ];

            // Tạo đơn hàng & tự động trừ kho
            $result = $this->orderModel->createOrder($orderData, $_SESSION['cart']);

            if ($result['status']) {
                // Xóa giỏ hàng và coupon sau khi đặt thành công
                $_SESSION['last_order'] = [
                    'order_id'       => $result['order_id'],
                    'order_code'     => $result['order_code'],
                    'total_amount'   => $cartTotals['total_amount'],
                    'payment_method' => $paymentMethod
                ];

                unset($_SESSION['cart']);
                unset($_SESSION['coupon']);

                set_flash('success', 'Đặt hàng thành công! Mã đơn của bạn là: ' . $result['order_code']);

                if (is_logged_in()) {
                    redirect('/tai-khoan/don-hang');
                } else {
                    redirect('/thanh-toan?success=' . $result['order_code']);
                }
            } else {
                set_flash('error', $result['message']);
                redirect('/thanh-toan');
            }
        }

        // Hiển thị giao diện thanh toán (GET)
        $pageTitle = "Thanh Toán Đơn Hàng | LongTech";
        render_view('client/pages/checkout', [
            'pageTitle'    => $pageTitle,
            'cart'         => $_SESSION['cart'],
            'cartTotals'   => $cartTotals,
            'currentUser'  => $currentUser,
            'successOrder' => $_GET['success'] ?? null
        ]);
    }

    /**
     * 8. Xử lý Form Liên hệ & Góp ý
     */
    public function contact() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();

            $fullName = trim($_POST['full_name'] ?? '');
            $email    = trim($_POST['email'] ?? '');
            $phone    = trim($_POST['phone'] ?? '');
            $subject  = trim($_POST['subject'] ?? 'Hỗ trợ chung');
            $message  = trim($_POST['message'] ?? '');

            if (empty($fullName) || empty($email) || empty($message)) {
                set_flash('error', 'Vui lòng điền đầy đủ họ tên, email và nội dung tin nhắn.');
                redirect('/lien-he');
            }

            $success = $this->orderModel->saveContact([
                'full_name' => $fullName,
                'email'     => $email,
                'phone'     => $phone,
                'subject'   => $subject,
                'message'   => $message
            ]);

            if ($success) {
                set_flash('success', 'Cảm ơn bạn! Tin nhắn góp ý của bạn đã được gửi tới bộ phận CSKH LongTech.');
            } else {
                set_flash('error', 'Không thể gửi tin nhắn lúc này, vui lòng thử lại.');
            }
            redirect('/lien-he');
        }

        render_view('client/pages/contact', [
            'pageTitle' => 'Liên Hệ & Hỗ Trợ Khách Hàng | LongTech'
        ]);
    }

    /**
     * Tính toán tổng giá trị giỏ hàng, giảm giá và phí ship
     */
    private function calculateTotals(): array {
        $subtotal = 0;
        $totalItems = 0;

        foreach ($_SESSION['cart'] as $item) {
            $subtotal += (float)$item['price'] * (int)$item['quantity'];
            $totalItems += (int)$item['quantity'];
        }

        // Tính giảm giá coupon
        $discount = (float)($_SESSION['coupon']['discount'] ?? 0);
        $discount = min($discount, $subtotal);

        // Quy ước G: Phí vận chuyển cố định 30.000đ; miễn phí khi đơn từ 2.000.000đ
        $shippingFee = 0;
        if ($subtotal > 0) {
            $shippingFee = ($subtotal >= FREE_SHIPPING_MIN) ? 0 : SHIPPING_FEE;
        }

        $totalAmount = max(0, $subtotal - $discount + $shippingFee);

        return [
            'subtotal'          => $subtotal,
            'total_items'       => $totalItems,
            'discount'          => $discount,
            'coupon_code'       => $_SESSION['coupon']['code'] ?? null,
            'shipping_fee'      => $shippingFee,
            'is_freeship'       => ($shippingFee === 0 && $subtotal > 0),
            'amount_to_freeship'=> max(0, FREE_SHIPPING_MIN - $subtotal),
            'total_amount'      => $totalAmount
        ];
    }

    private function getTotalItemCount(): int {
        $count = 0;
        foreach ($_SESSION['cart'] as $item) {
            $count += (int)$item['quantity'];
        }
        return $count;
    }

    private function isAjax(): bool {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
}

