<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER TRANG CHỦ (HomeController.php)
 * ========================================================
 * Xử lý dữ liệu nạp cho trang chủ: Banner, Danh mục,
 * Sản phẩm Flash Sale, Sản phẩm nổi bật, Hàng mới về,
 * Thương hiệu đối tác và Tin tức công nghệ.
 */

require_once __DIR__ . '/../models/ProductModel.php';
require_once __DIR__ . '/../models/CategoryModel.php';

class HomeController {
    private ProductModel $productModel;
    private CategoryModel $categoryModel;

    public function __construct() {
        $this->productModel = new ProductModel();
        $this->categoryModel = new CategoryModel();
    }

    /**
     * Hiển thị trang chủ website
     */
    public function index() {
        // 1. Lấy danh mục sản phẩm đang kích hoạt
        $categories = $this->categoryModel->getActiveCategories();

        // 2. Lấy danh sách banner slider
        $banners = $this->productModel->getBanners('home_slider');

        // 3. Lấy sản phẩm Flash Sale / Giá sốc
        $hotDeals = $this->productModel->getHotDeals(8);

        // 4. Lấy sản phẩm nổi bật
        $featuredProducts = $this->productModel->getFeatured(12);

        // 5. Lấy sản phẩm mới nhất
        $newProducts = $this->productModel->getNewProducts(8);

        // 6. Lấy danh sách thương hiệu đối tác
        $brands = $this->productModel->getAllBrands();

        // 7. Lấy tin tức công nghệ mới nhất
        $latestPosts = $this->productModel->getLatestPosts(3);

        // Tiêu đề trang
        $pageTitle = "LongTech - Hệ Thống Bán Lẻ Điện Thoại, Laptop, Tablet & Phụ Kiện Chính Hãng";

        // Nạp view
        render_view('client/pages/home', [
            'pageTitle'        => $pageTitle,
            'categories'       => $categories,
            'banners'          => $banners,
            'hotDeals'         => $hotDeals,
            'featuredProducts' => $featuredProducts,
            'newProducts'      => $newProducts,
            'brands'           => $brands,
            'latestPosts'      => $latestPosts
        ]);
    }
}

