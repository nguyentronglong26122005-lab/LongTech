<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN LÝ TÀI KHOẢN KHÁCH HÀNG (UserController.php)
 * ========================================================
 * Xử lý khu vực cá nhân của User:
 * - Tổng quan tài khoản (Dashboard)
 * - Lịch sử đơn hàng đã mua (Orders)
 * - Cập nhật thông tin cá nhân và Đổi mật khẩu (Settings)
 * BẢO MẬT: Customer chỉ xem và chỉnh sửa dữ liệu của chính mình.
 */

require_once __DIR__ . '/../models/UserModel.php';
require_once __DIR__ . '/../includes/auth_middleware.php';

class UserController {
    private UserModel $userModel;

    public function __construct() {
        // Mọi hành động của UserController bắt buộc phải đăng nhập
        require_login();
        $this->userModel = new UserModel();
    }

    /**
     * 1. Trang tổng quan tài khoản
     */
    public function dashboard() {
        $userId = current_user_id();
        $user = $this->userModel->findById($userId);
        $orders = $this->userModel->getUserOrders($userId);

        // Tính toán thống kê cơ bản của cá nhân
        $totalOrders = count($orders);
        $totalSpent = 0;
        foreach ($orders as $order) {
            if ($order['status'] === 'completed' || $order['status'] === 'processing' || $order['status'] === 'shipping') {
                $totalSpent += (float)$order['total_amount'];
            }
        }

        $pageTitle = "Tổng Quan Tài Khoản | LongTech";
        render_view('client/profile/dashboard', [
            'pageTitle'    => $pageTitle,
            'user'         => $user,
            'orders'       => array_slice($orders, 0, 5), // 5 đơn hàng mới nhất
            'totalOrders'  => $totalOrders,
            'totalSpent'   => $totalSpent,
            'activeTab'    => 'dashboard'
        ]);
    }

    /**
     * 2. Lịch sử đơn hàng đã mua
     */
    public function orders() {
        $userId = current_user_id();
        $user = $this->userModel->findById($userId);
        $orders = $this->userModel->getUserOrders($userId);

        $pageTitle = "Lịch Sử Đơn Hàng Của Tôi | LongTech";
        render_view('client/profile/orders', [
            'pageTitle' => $pageTitle,
            'user'      => $user,
            'orders'    => $orders,
            'activeTab' => 'orders'
        ]);
    }

    /**
     * 3. Đổi mật khẩu và cài đặt thông tin cá nhân
     */
    public function settings() {
        $userId = current_user_id();
        $user = $this->userModel->findById($userId);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();
            $action = $_POST['action'] ?? '';

            // A. Cập nhật thông tin cá nhân
            if ($action === 'update_profile') {
                $fullName = trim($_POST['full_name'] ?? '');
                $phone    = trim($_POST['phone'] ?? '');
                $address  = trim($_POST['address'] ?? '');

                if (empty($fullName)) {
                    set_flash('error', 'Họ và tên không được để trống.');
                    redirect('/tai-khoan/cai-dat');
                }

                $updated = $this->userModel->updateProfile($userId, [
                    'full_name' => $fullName,
                    'phone'     => $phone,
                    'address'   => $address
                ]);

                if ($updated) {
                    // Cập nhật lại session
                    $_SESSION['user']['full_name'] = $fullName;
                    $_SESSION['user']['phone']     = $phone;
                    $_SESSION['user']['address']   = $address;

                    set_flash('success', 'Cập nhật thông tin cá nhân thành công!');
                } else {
                    set_flash('error', 'Không thể cập nhật thông tin lúc này.');
                }
                redirect('/tai-khoan/cai-dat');
            }

            // B. Đổi mật khẩu tài khoản
            if ($action === 'change_password') {
                $oldPassword     = $_POST['old_password'] ?? '';
                $newPassword     = $_POST['new_password'] ?? '';
                $confirmPassword = $_POST['confirm_password'] ?? '';

                if (empty($oldPassword) || empty($newPassword)) {
                    set_flash('error', 'Vui lòng điền đầy đủ mật khẩu cũ và mật khẩu mới.');
                    redirect('/tai-khoan/cai-dat');
                }

                if (strlen($newPassword) < 6) {
                    set_flash('error', 'Mật khẩu mới phải có ít nhất 6 ký tự.');
                    redirect('/tai-khoan/cai-dat');
                }

                if ($newPassword !== $confirmPassword) {
                    set_flash('error', 'Mật khẩu xác nhận không khớp với mật khẩu mới.');
                    redirect('/tai-khoan/cai-dat');
                }

                $res = $this->userModel->changePassword($userId, $oldPassword, $newPassword);
                if ($res['status']) {
                    set_flash('success', 'Đổi mật khẩu thành công!');
                } else {
                    set_flash('error', $res['message']);
                }
                redirect('/tai-khoan/cai-dat');
            }
        }

        $pageTitle = "Cài Đặt Tài Khoản & Mật Khẩu | LongTech";
        render_view('client/profile/settings', [
            'pageTitle' => $pageTitle,
            'user'      => $user,
            'activeTab' => 'settings'
        ]);
    }
}

