<?php
/**
 * ========================================================
 * LONGTECH - CONTROLLER QUẢN LÝ SẢN PHẨM & TÌM KIẾM (ProductController.php)
 * ========================================================
 * Xử lý:
 * - Danh sách sản phẩm theo danh mục (Điện thoại, Tablet, Laptop, Phụ kiện)
 * - Lọc đa tiêu chí (Thương hiệu, Giá, RAM, Bộ nhớ, Flash Sale)
 * - Sắp xếp (Giá tăng/giảm, Mới nhất, Đánh giá cao, Bán chạy)
 * - Tìm kiếm từ khóa
 * - Chi tiết sản phẩm, Gallery ảnh, Thông số kỹ thuật, Sản phẩm liên quan
 * - Gửi đánh giá nhận xét sản phẩm
 */

require_once __DIR__ . '/../models/ProductModel.php';
require_once __DIR__ . '/../models/CategoryModel.php';
require_once __DIR__ . '/../includes/auth_middleware.php';

class ProductController {
    private ProductModel $productModel;
    private CategoryModel $categoryModel;

    public function __construct() {
        $this->productModel = new ProductModel();
        $this->categoryModel = new CategoryModel();
    }

    /**
     * 1. Hiển thị danh sách sản phẩm theo Danh mục, Tìm kiếm hoặc Bộ lọc
     */
    public function index(string $route = '') {
        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $limit = 12;

        // Chuẩn bị mảng điều kiện lọc
        $filters = [];

        // Xác định danh mục dựa trên Route hoặc tham số GET
        $currentCategory = null;
        if (!empty($route) && $route !== 'san-pham' && $route !== 'tim-kiem' && $route !== 'khuyen-mai') {
            $currentCategory = $this->categoryModel->getBySlug($route);
            if ($currentCategory) {
                $filters['category_id'] = $currentCategory['id'];
            }
        }

        // Nếu là trang Flash Sale / Khuyến mãi
        if ($route === 'khuyen-mai' || isset($_GET['hot_deal'])) {
            $filters['is_hot_deal'] = 1;
        }

        // Lấy từ khóa tìm kiếm
        $keyword = trim($_GET['keyword'] ?? '');
        if (!empty($keyword)) {
            $filters['keyword'] = $keyword;
        }

        // Lấy thương hiệu lọc (có thể chọn 1 hoặc nhiều thương hiệu)
        if (!empty($_GET['brand'])) {
            $filters['brand_slugs'] = $_GET['brand'];
        }

        // Lọc khoảng giá
        if (!empty($_GET['price_range'])) {
            $range = explode('-', $_GET['price_range']);
            if (count($range) === 2) {
                $filters['min_price'] = (float)$range[0];
                $filters['max_price'] = (float)$range[1];
            } elseif (count($range) === 1 && str_ends_with($_GET['price_range'], '+')) {
                $filters['min_price'] = (float)rtrim($_GET['price_range'], '+');
            }
        } elseif (isset($_GET['min_price']) || isset($_GET['max_price'])) {
            if (!empty($_GET['min_price'])) $filters['min_price'] = (float)$_GET['min_price'];
            if (!empty($_GET['max_price'])) $filters['max_price'] = (float)$_GET['max_price'];
        }

        // Lọc thông số RAM & Bộ nhớ
        if (!empty($_GET['ram'])) $filters['ram'] = $_GET['ram'];
        if (!empty($_GET['storage'])) $filters['storage'] = $_GET['storage'];

        // Sắp xếp
        $filters['sort'] = $_GET['sort'] ?? 'newest';

        // Lấy danh sách sản phẩm và tổng số kết quả
        $products = $this->productModel->getFilteredProducts($filters, $page, $limit);
        $totalProducts = $this->productModel->countFilteredProducts($filters);
        $totalPages = ceil($totalProducts / $limit);

        // Lấy dữ liệu hỗ trợ bộ lọc sidebar
        $categories = $this->categoryModel->getActiveCategories();
        $brands = $this->productModel->getAllBrands();

        // Tiêu đề trang động
        $pageTitle = "Tất Cả Sản Phẩm Công Nghệ | LongTech";
        if ($currentCategory) {
            $pageTitle = $currentCategory['name'] . " Chính Hãng | LongTech";
        } elseif ($route === 'khuyen-mai') {
            $pageTitle = "Săn Sale Giá Sốc - Khuyến Mãi Độc Quyền | LongTech";
        } elseif (!empty($keyword)) {
            $pageTitle = "Kết quả tìm kiếm cho: \"" . htmlspecialchars($keyword) . "\" | LongTech";
        }

        render_view('client/pages/products', [
            'pageTitle'       => $pageTitle,
            'products'        => $products,
            'totalProducts'   => $totalProducts,
            'currentPage'     => $page,
            'totalPages'      => $totalPages,
            'currentCategory' => $currentCategory,
            'categories'      => $categories,
            'brands'          => $brands,
            'filters'         => $filters,
            'route'           => $route
        ]);
    }

    /**
     * 2. Hiển thị chi tiết một sản phẩm
     */
    public function detail(string $slug) {
        $product = $this->productModel->getBySlug($slug);

        if (!$product) {
            set_flash('error', 'Sản phẩm bạn đang tìm kiếm không tồn tại hoặc đã ngừng kinh doanh.');
            redirect('/san-pham');
        }

        // Tăng lượt xem sản phẩm
        $this->productModel->incrementViewCount($product['id']);

        // Lấy album ảnh phụ của sản phẩm
        $productImages = $this->productModel->getProductImages($product['id']);

        // Lấy danh sách sản phẩm liên quan
        $relatedProducts = $this->productModel->getRelatedProducts($product['category_id'], $product['id'], 4);

        // Lấy đánh giá của khách hàng
        $reviews = $this->productModel->getProductReviews($product['id']);

        // Phân tách màu sắc, RAM, dung lượng từ chuỗi lưu trong CSDL
        $colorOptions = !empty($product['colors']) ? array_map('trim', explode(',', $product['colors'])) : [];
        $storageOptions = !empty($product['storage_options']) ? array_map('trim', explode(',', $product['storage_options'])) : [];
        $ramOptions = !empty($product['ram_options']) ? array_map('trim', explode(',', $product['ram_options'])) : [];

        $pageTitle = $product['name'] . " - Giá Tốt, Trả Góp 0% | LongTech";

        render_view('client/pages/product-detail', [
            'pageTitle'       => $pageTitle,
            'product'         => $product,
            'productImages'   => $productImages,
            'relatedProducts' => $relatedProducts,
            'reviews'         => $reviews,
            'colorOptions'    => $colorOptions,
            'storageOptions'  => $storageOptions,
            'ramOptions'      => $ramOptions
        ]);
    }

    /**
     * 3. Gửi đánh giá cho sản phẩm (Chỉ người dùng đã đăng nhập)
     */
    public function review() {
        require_login();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();

            $productId = (int)($_POST['product_id'] ?? 0);
            $slug      = trim($_POST['slug'] ?? '');
            $rating    = (int)($_POST['rating'] ?? 5);
            $comment   = trim($_POST['comment'] ?? '');

            if ($productId <= 0 || empty($comment)) {
                set_flash('error', 'Vui lòng nhập nội dung đánh giá và chọn số sao.');
                redirect('/san-pham/' . $slug . '#reviewsTab');
            }

            $userId = current_user_id();
            $success = $this->productModel->addReview($productId, $userId, $rating, $comment);

            if ($success) {
                set_flash('success', 'Cảm ơn bạn! Đánh giá sản phẩm của bạn đã được đăng thành công.');
            } else {
                set_flash('error', 'Không thể gửi đánh giá lúc này, vui lòng thử lại.');
            }

            redirect('/san-pham/' . $slug . '#reviewsTab');
        }
    }
}

