<?php
/**
 * ========================================================
 * LONGTECH - TRANG QUẢN LÝ CÂU HỎI & ĐÁP FAQ ADMIN (admin/pages/faq/index.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
require_once ROOT_PATH . '/models/FaqModel.php';
$faqModel = new FaqModel();
$questions = $faqModel->getAllForAdmin();
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-circle-question text-primary"></i> Quản Lý Hỏi &amp; Đáp (FAQ / Q&amp;A)</h1>
        <p class="page-subtitle">Xem câu hỏi khách gửi từ Trung tâm FAQ hoặc trang chi tiết sản phẩm và phản hồi nhanh</p>
    </div>
    <div style="display:flex; gap:10px;">
        <a href="<?= APP_URL ?>/hoi-dap" target="_blank" class="btn btn-outline-primary">
            <i class="fa-solid fa-arrow-up-right-from-square"></i> Mở Trung Tâm FAQ Khách
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<div class="admin-card">
    <div class="admin-card-header" style="display:flex; justify-content:space-between; align-items:center; padding:16px 20px;">
        <h3 style="font-size:16px; font-weight:700; margin:0;"><i class="fa-solid fa-comments text-danger"></i> Danh Sách Câu Hỏi Từ Khách Hàng (<?= count($questions) ?>)</h3>
    </div>
    <div class="admin-card-body" style="padding:0;">
        <div class="table-responsive">
            <table class="table table-hover" style="width:100%; margin:0;">
                <thead style="background:#f8fafc;">
                    <tr>
                        <th style="width:60px;">ID</th>
                        <th style="width:160px;">Khách Hàng</th>
                        <th style="width:180px;">Sản Phẩm / Nguồn</th>
                        <th>Nội Dung Câu Hỏi</th>
                        <th style="width:140px;">Thời Gian</th>
                        <th style="width:130px; text-align:right;">Thao Tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($questions)): ?>
                        <tr>
                            <td colspan="6" style="text-align:center; padding:36px; color:#64748b;">
                                <i class="fa-solid fa-inbox" style="font-size:32px; color:#cbd5e1; display:block; margin-bottom:8px;"></i>
                                Chưa có câu hỏi nào từ khách hàng.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($questions as $q): ?>
                            <tr>
                                <td><strong>#<?= (int)$q['id'] ?></strong></td>
                                <td>
                                    <strong><?= e($q['author_name']) ?></strong>
                                    <?php if (!empty($q['author_phone'])): ?>
                                        <small style="display:block; color:#64748b;"><i class="fa-solid fa-phone"></i> <?= e($q['author_phone']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($q['product_name'])): ?>
                                        <span class="badge badge-info" style="font-size:11.5px;"><?= e($q['product_name']) ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary" style="font-size:11.5px;">Trung tâm FAQ chung</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div style="font-size:13.5px; color:#0f172a; font-weight:600; margin-bottom:4px;">
                                        <?= nl2br(e($q['question_text'])) ?>
                                    </div>
                                </td>
                                <td>
                                    <small style="color:#64748b;"><?= date('H:i d/m/Y', strtotime($q['created_at'])) ?></small>
                                </td>
                                <td style="text-align:right;">
                                    <button type="button" class="btn btn-sm btn-primary" onclick="openReplyModal(<?= (int)$q['id'] ?>, '<?= htmlspecialchars(addslashes($q['question_text']), ENT_QUOTES) ?>')">
                                        <i class="fa-solid fa-reply"></i> Trả lời
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Trả lời câu hỏi -->
<div id="replyModal" style="display:none; position:fixed; inset:0; background:rgba(15,23,42,0.65); z-index:99999; align-items:center; justify-content:center; padding:16px;">
    <div style="background:#fff; border-radius:14px; max-width:520px; width:100%; box-shadow:0 20px 45px rgba(0,0,0,0.25); overflow:hidden;">
        <div style="background:linear-gradient(135deg,#0A2540,#1e3a8a); color:#fff; padding:16px 20px; display:flex; justify-content:space-between; align-items:center;">
            <h4 style="margin:0; font-size:15px; font-weight:700;"><i class="fa-solid fa-reply"></i> Phản Hồi Câu Hỏi Khách Hàng</h4>
            <button type="button" onclick="closeReplyModal()" style="background:none; border:none; color:#fff; font-size:20px; cursor:pointer;">&times;</button>
        </div>
        <form onsubmit="submitReply(event)" style="padding:20px;">
            <input type="hidden" id="replyQid" name="question_id">
            <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:12px; margin-bottom:14px; font-size:13px; color:#334155;">
                <strong style="color:#0f172a; display:block; margin-bottom:4px;">Câu hỏi của khách:</strong>
                <p id="modalQuestionText" style="margin:0; font-style:italic;"></p>
            </div>
            <div class="form-group mb-3">
                <label class="form-label" style="font-weight:700;">Nội dung phản hồi (danh nghĩa QTV / CSKH) *</label>
                <textarea id="replyText" required rows="4" class="form-control" placeholder="Nhập câu trả lời chi tiết và lịch sự gửi đến khách hàng..."></textarea>
            </div>
            <div style="display:flex; justify-content:flex-end; gap:10px;">
                <button type="button" class="btn btn-secondary" onclick="closeReplyModal()">Hủy</button>
                <button type="submit" class="btn btn-primary" id="btnSubmitReply"><i class="fa-solid fa-paper-plane"></i> Gửi Phản Hồi</button>
            </div>
        </form>
    </div>
</div>

<script>
    function openReplyModal(qid, text) {
        document.getElementById('replyQid').value = qid;
        document.getElementById('modalQuestionText').textContent = text;
        document.getElementById('replyText').value = '';
        document.getElementById('replyModal').style.display = 'flex';
    }

    function closeReplyModal() {
        document.getElementById('replyModal').style.display = 'none';
    }

    function submitReply(e) {
        e.preventDefault();
        const qid = document.getElementById('replyQid').value;
        const text = document.getElementById('replyText').value.trim();
        if (!qid || !text) return;

        const btn = document.getElementById('btnSubmitReply');
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Đang gửi...';

        const fd = new FormData();
        fd.append('csrf_token', '<?= csrf_token() ?>');
        fd.append('question_id', qid);
        fd.append('reply_text', text);

        fetch('<?= APP_URL ?>/index.php?route=api/faq/reply', {
            method: 'POST',
            body: fd
        })
        .then(r => r.json())
        .then(res => {
            if (res.status) {
                alert('✔ Đã gửi câu trả lời thành công!');
                location.reload();
            } else {
                alert('Lỗi: ' + (res.message || 'Không thể gửi phản hồi'));
            }
        })
        .catch(err => {
            alert('Lỗi kết nối máy chủ!');
        })
        .finally(() => {
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Gửi Phản Hồi';
        });
    }
</script>

