<?php
/**
 * ========================================================
 * LONGTECH - TRANG TỔNG QUAN CÁC BỘ PHẬN VÀ PHÂN QUYỀN QUẢN LÝ (admin/pages/departments/index.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
require_once ROOT_PATH . '/includes/site_content.php';
$departments = get_departments();
$allPerms = get_all_permissions_list();

// Lấy danh sách nhân sự hiện có trong hệ thống và phân loại theo quyền
$db = Database::connect();
$stmt = $db->query("SELECT u.id, u.username, u.full_name, u.role_id, u.permissions, r.display_name AS role_display FROM `users` u JOIN `roles` r ON u.role_id = r.id WHERE u.role_id != 5 ORDER BY u.id ASC");
$staffMembers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-sitemap text-primary"></i> Quản Lý Bộ Phận &amp; Phân Quyền Nhân Sự</h1>
        <p class="page-subtitle">Sơ đồ 12 bộ phận quản trị chuyên trách - Phân quyền nhiệm vụ trực tiếp cho từng nhân viên</p>
    </div>
    <div style="display:flex; gap:10px;">
        <a href="<?= APP_URL ?>/admin.php?act=users" class="btn btn-secondary">
            <i class="fa-solid fa-user-shield"></i> Danh Sách Thành Viên
        </a>
        <a href="<?= APP_URL ?>/admin.php?act=users/add" class="btn btn-primary">
            <i class="fa-solid fa-user-plus"></i> Thêm &amp; Cấp Quyền Nhân Viên
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<!-- BẢNG TỔNG QUAN PHÂN BỔ NHÂN SỰ VÀO CÁC BỘ PHẬN -->
<div class="admin-card mb-4" style="border-top: 4px solid #2563eb;">
    <div class="admin-card-header" style="display:flex; justify-content:space-between; align-items:center; padding:16px 20px;">
        <div>
            <h3 style="font-size:16px; font-weight:700; margin:0;"><i class="fa-solid fa-users-gear text-primary"></i> Nhân Sự &amp; Vai Trò Đang Phụ Trách Bộ Phận</h3>
            <small style="color:#64748b;">Mỗi nhân viên có thể đảm nhiệm 1 hoặc nhiều chức năng quản lý khác nhau</small>
        </div>
        <a href="<?= APP_URL ?>/admin.php?act=users/add" class="btn btn-sm btn-primary">
            <i class="fa-solid fa-plus"></i> Phân Quyền Người Mới
        </a>
    </div>
    <div class="admin-card-body" style="padding:0;">
        <div class="table-responsive">
            <table class="table table-hover" style="width:100%; margin:0;">
                <thead style="background:#f8fafc;">
                    <tr>
                        <th style="width:60px;">ID</th>
                        <th style="width:180px;">Tài Khoản / Nhân Viên</th>
                        <th style="width:140px;">Cấp Bậc</th>
                        <th>Các Bộ Phận / Quyền Chức Năng Đảm Nhiệm</th>
                        <th style="width:120px; text-align:right;">Thao Tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($staffMembers as $st): ?>
                        <?php 
                            $stPerms = get_user_permissions($st);
                            $isSuper = ((int)$st['role_id'] === 1);
                        ?>
                        <tr>
                            <td><strong>#<?= (int)$st['id'] ?></strong></td>
                            <td>
                                <strong><?= e($st['full_name'] ?: $st['username']) ?></strong>
                                <small style="display:block; color:#64748b;">@<?= e($st['username']) ?></small>
                            </td>
                            <td>
                                <span class="badge <?= $isSuper ? 'badge-danger' : 'badge-primary' ?>">
                                    <?= e($st['role_display']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($isSuper): ?>
                                    <span style="color:#dc2626; font-weight:700; font-size:12px;">
                                        <i class="fa-solid fa-crown"></i> Toàn quyền điều hành tất cả 12 bộ phận
                                    </span>
                                <?php elseif (!empty($stPerms)): ?>
                                    <div style="display:flex; flex-wrap:wrap; gap:5px;">
                                        <?php foreach ($stPerms as $pk): ?>
                                            <?php if (isset($allPerms[$pk])): ?>
                                                <span style="display:inline-flex; align-items:center; gap:5px; font-size:11.5px; padding:3px 9px; border-radius:12px; background:<?= $allPerms[$pk]['bg'] ?>; color:<?= $allPerms[$pk]['color'] ?>; font-weight:700; border:1px solid <?= $allPerms[$pk]['color'] ?>40;">
                                                    <i class="fa-solid <?= e($allPerms[$pk]['icon']) ?>"></i>
                                                    <?= e($allPerms[$pk]['short']) ?>
                                                </span>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <span style="color:#94a3b8; font-style:italic;">Chưa gán bộ phận phụ trách</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:right;">
                                <?php if (!$isSuper): ?>
                                    <a href="<?= APP_URL ?>/admin.php?act=users" class="btn btn-sm btn-outline-primary" style="padding:4px 10px; font-size:11.5px;">
                                        <i class="fa-solid fa-sliders"></i> Đổi Quyền
                                    </a>
                                <?php else: ?>
                                    <span style="font-size:11.5px; color:#94a3b8; font-style:italic;">Cố định</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- LƯỚI 12 BỘ PHẬN VÀ QUYỀN CHỨC NĂNG TƯƠNG ỨNG -->
<div class="admin-card">
    <div class="admin-card-header" style="display:flex; justify-content:space-between; align-items:center; padding:16px 20px;">
        <h3 style="font-size:16px; font-weight:700; margin:0;"><i class="fa-solid fa-sitemap text-warning"></i> Chi Tiết 12 Bộ Phận Quản Lý Của LongTech</h3>
        <span class="badge badge-info" style="font-size:12px;">Đã sẵn sàng phân quyền</span>
    </div>
    <div class="admin-card-body" style="padding:20px;">
        <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(360px, 1fr)); gap:18px;">
            <?php foreach ($departments as $d): ?>
                <div style="background:#f8fafc; border:1.5px solid #e2e8f0; border-radius:14px; padding:20px; display:flex; flex-direction:column; justify-content:space-between; transition:all 0.25s;" onmouseover="this.style.borderColor='<?= e($d['color']) ?>'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 10px 25px rgba(0,0,0,0.06)'" onmouseout="this.style.borderColor='#e2e8f0'; this.style.transform='none'; this.style.boxShadow='none'">
                    <div>
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px;">
                            <div style="display:flex; align-items:center; gap:12px;">
                                <div style="width:44px; height:44px; border-radius:12px; background:<?= e($d['bg']) ?>; color:<?= e($d['color']) ?>; display:flex; align-items:center; justify-content:center; font-size:20px; flex-shrink:0;">
                                    <i class="fa-solid <?= e($d['icon']) ?>"></i>
                                </div>
                                <div>
                                    <h4 style="font-size:15.5px; font-weight:800; color:#0f172a; margin:0 0 2px;"><?= e($d['name']) ?></h4>
                                    <small style="color:#64748b; font-size:12px;"><i class="fa-solid fa-user-tie"></i> Phụ trách: <strong><?= e($d['lead']) ?></strong></small>
                                </div>
                            </div>
                        </div>

                        <p style="font-size:13px; color:#475569; line-height:1.5; margin-bottom:14px;">
                            <?= e($d['summary']) ?>
                        </p>

                        <div style="background:#fff; border:1px solid #e2e8f0; border-radius:10px; padding:12px 14px; margin-bottom:14px;">
                            <strong style="color:#0f172a; font-size:12.5px; display:block; margin-bottom:6px;"><i class="fa-solid fa-list-check text-primary"></i> Trách nhiệm &amp; quyền hạn:</strong>
                            <ul style="padding-left:18px; margin:0; font-size:12px; color:#334155; line-height:1.6;">
                                <?php foreach ($d['tasks'] as $t): ?>
                                    <li style="margin-bottom:3px;"><?= $t ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>

                    <div style="border-top:1px dashed #cbd5e1; padding-top:12px; display:flex; justify-content:space-between; align-items:center; font-size:12px;">
                        <span style="color:#64748b;"><i class="fa-regular fa-envelope"></i> <?= e($d['email']) ?></span>
                        <a href="<?= APP_URL ?>/admin.php?act=users/add" class="btn btn-sm btn-primary" style="padding:4px 10px; font-size:11.5px;">
                            <i class="fa-solid fa-user-plus"></i> Cấp Quyền NV
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
