<?php
/**
 * ========================================================
 * LONGTECH - VIEW DANH SÁCH PHÊ DUYỆT YÊU CẦU THAO TÁC (admin/pages/approvals/list.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
$allPermissions = get_all_permissions_list();
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title">
            <i class="fa-solid fa-clipboard-check text-primary"></i>
            <?= $isSuperAdmin ? 'Phê Duyệt Yêu Cầu Từ Nhân Viên' : 'Yêu Cầu Phê Duyệt Của Tôi' ?>
        </h1>
        <p class="page-subtitle">
            <?= $isSuperAdmin 
                ? 'Kiểm tra và phê duyệt các thao tác từ thành viên các vai trò. Khi bấm Duyệt, thay đổi sẽ được thực hiện lập tức trên web.' 
                : 'Danh sách các thao tác bạn đã thực hiện và gửi lên Admin chờ phê duyệt.' ?>
        </p>
    </div>
    <div style="display:flex; gap:8px; flex-wrap:wrap;">
        <a href="<?= APP_URL ?>/admin.php?act=approvals" class="btn <?= $statusFilter === '' ? 'btn-primary' : 'btn-secondary' ?>">
            Tất cả
        </a>
        <a href="<?= APP_URL ?>/admin.php?act=approvals&status=pending" class="btn <?= $statusFilter === 'pending' ? 'btn-primary' : 'btn-secondary' ?>">
            ⏳ Chờ duyệt (<?= (int)$pendingCount ?>)
        </a>
        <a href="<?= APP_URL ?>/admin.php?act=approvals&status=approved" class="btn <?= $statusFilter === 'approved' ? 'btn-primary' : 'btn-secondary' ?>">
            ✅ Đã duyệt
        </a>
        <a href="<?= APP_URL ?>/admin.php?act=approvals&status=rejected" class="btn <?= $statusFilter === 'rejected' ? 'btn-primary' : 'btn-secondary' ?>">
            ❌ Đã từ chối
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<div class="admin-card">
    <div class="admin-card-header">
        <div class="card-title">
            <span>Danh Sách Yêu Cầu Thao Tác</span>
            <span class="badge badge-info" style="margin-left: 8px;"><?= count($requests) ?> yêu cầu</span>
        </div>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width: 65px;">Mã YC</th>
                        <th style="width: 190px;">Thành Viên Gửi</th>
                        <th style="width: 160px;">Phân Hệ / Vai Trò</th>
                        <th>Nội Dung Thao Tác Yêu Cầu</th>
                        <th style="width: 145px;">Thời Gian</th>
                        <th style="text-align: center; width: 140px;">Trạng Thái</th>
                        <?php if ($isSuperAdmin): ?>
                            <th style="text-align: right; width: 220px;">Thao Tác Duyệt (Admin)</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($requests)): ?>
                        <tr>
                            <td colspan="<?= $isSuperAdmin ? 7 : 6 ?>" class="text-center" style="padding: 45px; color: #64748b;">
                                <i class="fa-solid fa-circle-check" style="font-size: 34px; color: #16a34a; margin-bottom: 10px; display: block;"></i>
                                Không có yêu cầu nào trong danh sách này.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($requests as $r): ?>
                            <tr style="<?= $r['status'] === 'pending' ? 'background: #fffbeb;' : '' ?>">
                                <td><strong>#<?= (int)$r['id'] ?></strong></td>
                                <td>
                                    <div style="font-weight: 700; color: #0f172a;">@<?= e($r['username']) ?></div>
                                    <small style="color: #64748b;"><?= e($r['full_name'] ?: $r['username']) ?></small>
                                </td>
                                <td>
                                    <span class="badge badge-primary" style="font-size: 11.5px;">
                                        <?= e($r['module_name']) ?>
                                    </span>
                                </td>
                                <td>
                                    <div style="font-weight: 700; color: #0f172a; font-size: 14px; margin-bottom: 3px;">
                                        <?= e($r['action_title']) ?>
                                    </div>
                                    <?php if (!empty($r['action_summary'])): ?>
                                        <div style="font-size: 12.5px; color: #475569; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 6px 10px; margin-top: 4px;">
                                            <?= e($r['action_summary']) ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div style="font-size: 12.5px; color: #334155;">
                                        <?= date('H:i - d/m/Y', strtotime($r['created_at'])) ?>
                                    </div>
                                    <?php if (!empty($r['reviewed_at'])): ?>
                                        <small style="color: #64748b; display: block; margin-top: 2px;">
                                            Xử lý: <?= date('H:i d/m', strtotime($r['reviewed_at'])) ?>
                                        </small>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: center;">
                                    <?php if ($r['status'] === 'pending'): ?>
                                        <span class="badge badge-warning" style="font-size: 12px;">
                                            <i class="fa-solid fa-hourglass-half"></i> Chờ Admin duyệt
                                        </span>
                                    <?php elseif ($r['status'] === 'approved'): ?>
                                        <span class="badge badge-success" style="font-size: 12px;">
                                            <i class="fa-solid fa-check-double"></i> Đã duyệt & Thực thi
                                        </span>
                                    <?php else: ?>
                                        <span class="badge badge-danger" style="font-size: 12px;">
                                            <i class="fa-solid fa-xmark"></i> Đã từ chối
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <?php if ($isSuperAdmin): ?>
                                    <td style="text-align: right;">
                                        <?php if ($r['status'] === 'pending'): ?>
                                            <div style="display: flex; gap: 6px; justify-content: flex-end; flex-wrap: wrap;">
                                                <a href="<?= APP_URL ?>/admin.php?act=approvals/approve&id=<?= (int)$r['id'] ?>"
                                                   class="btn btn-sm btn-success"
                                                   style="padding: 6px 12px; font-size: 12px; font-weight: 700;"
                                                   onclick="return confirm('Xác nhận DUYỆT yêu cầu #<?= (int)$r['id'] ?> và thực hiện ngay lập tức trên web?');">
                                                    <i class="fa-solid fa-check"></i> Duyệt & Thực thi
                                                </a>
                                                <a href="<?= APP_URL ?>/admin.php?act=approvals/reject&id=<?= (int)$r['id'] ?>"
                                                   class="btn btn-sm btn-danger"
                                                   style="padding: 6px 10px; font-size: 12px;"
                                                   onclick="return confirm('Bạn muốn TỪ CHỐI yêu cầu #<?= (int)$r['id'] ?> này?');">
                                                    <i class="fa-solid fa-xmark"></i> Từ chối
                                                </a>
                                            </div>
                                        <?php else: ?>
                                            <span style="font-size: 12px; color: #94a3b8; font-style: italic;">
                                                Bởi @<?= e($r['reviewed_by'] ?? 'admin') ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

