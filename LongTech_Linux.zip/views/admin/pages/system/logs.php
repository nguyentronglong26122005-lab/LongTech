<?php
/**
 * ========================================================
 * LONGTECH - VIEW NHẬT KÝ HOẠT ĐỘNG (admin/pages/system/logs.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-clock-rotate-left text-primary"></i> Nhật Ký Hoạt Động Hệ Thống (Audit Logs)</h1>
        <p class="page-subtitle">Theo dõi lịch sử thao tác của các thành viên quản trị, thay đổi dữ liệu và phân quyền</p>
    </div>
    <?php if (current_role() === 'super_admin'): ?>
    <div>
        <a href="<?= APP_URL ?>/admin.php?act=system/backup" class="btn btn-secondary">
            <i class="fa-solid fa-database"></i> Sao Lưu Cơ Sở Dữ Liệu
        </a>
    </div>
    <?php endif; ?>
</div>

<?= render_flash_messages() ?>

<!-- BỘ LỌC TÌM KIẾM -->
<div class="admin-card mb-4">
    <div class="admin-card-body" style="padding:16px 20px;">
        <form method="GET" action="<?= APP_URL ?>/admin.php" style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;">
            <input type="hidden" name="act" value="system/logs">
            <div style="flex:2;min-width:220px;">
                <input type="text" name="search" class="form-control" placeholder="🔍 Tìm theo username, hành động, mô tả..."
                       value="<?= e($search ?? '') ?>">
            </div>
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-filter"></i> Lọc</button>
            <a href="<?= APP_URL ?>/admin.php?act=system/logs" class="btn btn-secondary">Đặt lại</a>
        </form>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <h3 class="admin-card-title">
            <i class="fa-solid fa-list-check"></i> Danh Sách Bản Ghi Nhật Ký
            <span class="badge badge-primary"><?= $totalItems ?? count($logs) ?></span>
        </h3>
    </div>
    <div class="admin-card-body">
        <?php if (empty($logs)): ?>
            <div style="text-align:center;padding:40px;color:#9ca3af;">
                <i class="fa-solid fa-clipboard-check" style="font-size:3rem;margin-bottom:12px;display:block;"></i>
                <p>Chưa có bản ghi hoạt động nào.</p>
            </div>
        <?php else: ?>
        <div style="overflow-x:auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width:60px;">ID</th>
                        <th style="width:140px;">Người Thao Tác</th>
                        <th style="width:160px;">Hành Động</th>
                        <th>Chi Tiết Nội Dung</th>
                        <th style="width:120px;">Địa Chỉ IP</th>
                        <th style="width:140px;">Thời Gian</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><strong>#<?= $log['id'] ?></strong></td>
                        <td>
                            <strong style="color:var(--admin-secondary);"><i class="fa-solid fa-user"></i> <?= e($log['username']) ?></strong>
                            <?php if (!empty($log['user_id'])): ?>
                                <br><small class="text-muted">UID: <?= $log['user_id'] ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge badge-secondary" style="font-family:monospace;"><?= e($log['action']) ?></span>
                        </td>
                        <td><?= e($log['description']) ?></td>
                        <td><small style="font-family:monospace;"><?= e($log['ip_address'] ?? '127.0.0.1') ?></small></td>
                        <td><small><?= date('d/m/Y H:i:s', strtotime($log['created_at'])) ?></small></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <?= $pagination ?? '' ?>
    </div>
</div>

