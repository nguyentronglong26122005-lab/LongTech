<?php
/**
 * ========================================================
 * LONGTECH - VIEW QUẢN LÝ DANH MỤC (admin/pages/categories/list.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-layer-group text-primary"></i> Quản Lý Danh Mục</h1>
        <p class="page-subtitle">Phân nhóm thiết bị công nghệ: Điện thoại, Máy tính bảng, Laptop, Phụ kiện</p>
    </div>
    <div class="header-actions">
        <a href="<?= APP_URL ?>/admin.php?act=categories/add-edit" class="btn btn-primary">
            <i class="fa-solid fa-plus"></i> Thêm Danh Mục
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<!-- BẢNG DANH MỤC -->
<div class="admin-card">
    <div class="admin-card-header">
        <div class="card-title">
            <span>Danh Sách Danh Mục Thiết Bị</span>
            <span class="badge badge-info" style="margin-left: 8px;"><?= count($categories) ?> danh mục</span>
        </div>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width: 70px;">ID</th>
                        <th>Biểu Tượng & Tên Danh Mục</th>
                        <th>Đường Dẫn (Slug)</th>
                        <th style="text-align: center;">Số Lượng SP</th>
                        <th style="text-align: center;">Thứ Tự</th>
                        <th style="text-align: center;">Trạng Thái</th>
                        <th style="text-align: right; width: 140px;">Hành Động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($categories)): ?>
                        <tr>
                            <td colspan="7" class="text-center" style="padding: 40px; color: #64748b;">
                                <i class="fa-solid fa-folder-open" style="font-size: 32px; margin-bottom: 10px; display: block;"></i>
                                Chưa có danh mục nào trong hệ thống.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($categories as $cat): ?>
                            <tr>
                                <td><strong>#<?= $cat['id'] ?></strong></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 12px;">
                                        <div style="width: 40px; height: 40px; border-radius: 8px; background: rgba(10,37,64,0.06); display: flex; align-items: center; justify-content: center; font-size: 18px; color: var(--primary);">
                                            <i class="fa-solid <?= e($cat['icon'] ?: 'fa-cube') ?>"></i>
                                        </div>
                                        <div>
                                            <div style="font-weight: 600; color: #0f172a; font-size: 14px;">
                                                <?= e($cat['name']) ?>
                                            </div>
                                            <small style="color: #64748b;">Mã FA: <code><?= e($cat['icon'] ?: 'fa-cube') ?></code></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <code style="background: #f1f5f9; padding: 3px 8px; border-radius: 4px; font-size: 13px; color: #475569;">
                                        /san-pham?danh-muc=<?= e($cat['slug']) ?>
                                    </code>
                                </td>
                                <td style="text-align: center;">
                                    <span class="badge badge-primary" style="font-size: 13px;">
                                        <?= (int)($cat['total_products'] ?? 0) ?> sản phẩm
                                    </span>
                                </td>
                                <td style="text-align: center; font-weight: 600; color: #334155;">
                                    <?= (int)$cat['sort_order'] ?>
                                </td>
                                <td style="text-align: center;">
                                    <?php if ($cat['status'] === 'active'): ?>
                                        <span class="badge badge-success"><i class="fa-solid fa-check"></i> Hiển thị</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary"><i class="fa-solid fa-eye-slash"></i> Tạm ẩn</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: right;">
                                    <div style="display: flex; gap: 6px; justify-content: flex-end;">
                                        <a href="<?= APP_URL ?>/admin.php?act=categories/add-edit&id=<?= $cat['id'] ?>" class="btn-action edit" title="Chỉnh sửa danh mục">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </a>
                                        <a href="<?= APP_URL ?>/admin.php?act=categories/delete&id=<?= $cat['id'] ?>" 
                                           class="btn-action delete" 
                                           title="Xóa danh mục"
                                           onclick="return confirm('Bạn có chắc chắn muốn xóa danh mục &quot;<?= addslashes($cat['name']) ?>&quot;?\nLưu ý: Các sản phẩm thuộc danh mục này sẽ cần được phân loại lại.');">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

