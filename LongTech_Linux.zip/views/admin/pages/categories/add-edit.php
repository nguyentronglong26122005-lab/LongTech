<?php
/**
 * ========================================================
 * LONGTECH - VIEW THÊM / SỬA DANH MỤC (admin/pages/categories/add-edit.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

$isEdit = !empty($category);
$catId = $category['id'] ?? 0;
$currentIcon = $category['icon'] ?? 'fa-cube';
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title">
            <i class="fa-solid <?= $isEdit ? 'fa-pen-to-square' : 'fa-plus-circle' ?> text-primary"></i> 
            <?= $isEdit ? 'Chỉnh Sửa Danh Mục: ' . e($category['name']) : 'Thêm Danh Mục Mới' ?>
        </h1>
        <p class="page-subtitle"><?= $isEdit ? 'Cập nhật thông tin phân loại sản phẩm #' . $catId : 'Tạo mới nhóm thiết bị công nghệ vào hệ thống LongTech' ?></p>
    </div>
    <div class="header-actions">
        <a href="<?= APP_URL ?>/admin.php?act=categories" class="btn btn-secondary">
            <i class="fa-solid fa-arrow-left"></i> Quay Lại Danh Sách
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<div class="admin-grid" style="grid-template-columns: 2fr 1fr; align-items: flex-start;">
    <!-- FORM NHẬP THÔNG TIN -->
    <div class="admin-card">
        <div class="admin-card-header">
            <div class="card-title">
                <span>Thông Tin Danh Mục</span>
            </div>
        </div>
        <div class="admin-card-body">
            <form action="<?= APP_URL ?>/admin.php?act=categories/add-edit<?= $isEdit ? '&id=' . $catId : '' ?>" method="POST" id="categoryForm">
                <?= csrf_field() ?>
                <?php if ($isEdit): ?>
                    <input type="hidden" name="id" value="<?= $catId ?>">
                <?php endif; ?>

                <div class="form-group mb-3">
                    <label class="form-label required">Tên Danh Mục</label>
                    <input type="text" name="name" id="catName" class="form-control" 
                           placeholder="Ví dụ: Điện thoại, Laptop, Máy tính bảng, Phụ kiện..." 
                           value="<?= e($category['name'] ?? '') ?>" required autofocus>
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Đường Dẫn Thân Thiện (Slug URL)</label>
                    <input type="text" name="slug" id="catSlug" class="form-control" 
                           placeholder="dien-thoai (để trống hệ thống sẽ tự sinh tự động)" 
                           value="<?= e($category['slug'] ?? '') ?>">
                    <small class="form-text text-muted">Sử dụng trong liên kết danh mục: <code>/san-pham?danh-muc=slug</code></small>
                </div>

                <div class="row" style="display: flex; gap: 15px; margin-bottom: 15px;">
                    <div style="flex: 1;">
                        <label class="form-label required">Biểu Tượng FontAwesome</label>
                        <div style="display: flex; gap: 8px;">
                            <input type="text" name="icon" id="catIcon" class="form-control" 
                                   placeholder="fa-mobile-screen" 
                                   value="<?= e($currentIcon) ?>" required>
                            <div id="iconPreview" style="width: 44px; height: 44px; border-radius: 8px; background: #0A2540; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0;">
                                <i class="fa-solid <?= e($currentIcon) ?>"></i>
                            </div>
                        </div>
                    </div>
                    <div style="flex: 1;">
                        <label class="form-label">Thứ Tự Sắp Xếp</label>
                        <input type="number" name="sort_order" class="form-control" 
                               value="<?= (int)($category['sort_order'] ?? 0) ?>" min="0">
                        <small class="form-text text-muted">Số càng nhỏ ưu tiên hiển thị trước</small>
                    </div>
                </div>

                <div class="form-group mb-4">
                    <label class="form-label">Trạng Thái Hiển Thị</label>
                    <select name="status" class="form-control">
                        <option value="active" <?= ($category['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>
                            Hiển thị công khai (Active)
                        </option>
                        <option value="inactive" <?= ($category['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>
                            Tạm ẩn trên website (Inactive)
                        </option>
                    </select>
                </div>

                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="btn btn-primary" style="padding: 10px 24px;">
                        <i class="fa-solid <?= $isEdit ? 'fa-check' : 'fa-plus' ?>"></i> 
                        <?= $isEdit ? 'Lưu Thay Đổi' : 'Thêm Danh Mục' ?>
                    </button>
                    <a href="<?= APP_URL ?>/admin.php?act=categories" class="btn btn-secondary" style="padding: 10px 20px;">
                        Hủy Bỏ
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- GỢI Ý BIỂU TƯỢNG (ICONS) PHỔ BIẾN CHO THIẾT BỊ ĐIỆN TỬ -->
    <div class="admin-card">
        <div class="admin-card-header">
            <div class="card-title">
                <i class="fa-solid fa-icons text-primary"></i>
                <span>Gợi Ý Biểu Tượng Công Nghệ</span>
            </div>
        </div>
        <div class="admin-card-body">
            <p style="font-size: 13px; color: #64748b; margin-bottom: 12px;">Nhấp vào biểu tượng bên dưới để áp dụng nhanh cho danh mục:</p>
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px;">
                <button type="button" class="btn-icon-sample" data-icon="fa-mobile-screen">
                    <i class="fa-solid fa-mobile-screen"></i> <span>Điện thoại</span>
                </button>
                <button type="button" class="btn-icon-sample" data-icon="fa-tablet-screen-button">
                    <i class="fa-solid fa-tablet-screen-button"></i> <span>Tablet</span>
                </button>
                <button type="button" class="btn-icon-sample" data-icon="fa-laptop">
                    <i class="fa-solid fa-laptop"></i> <span>Laptop</span>
                </button>
                <button type="button" class="btn-icon-sample" data-icon="fa-headphones">
                    <i class="fa-solid fa-headphones"></i> <span>Tai nghe</span>
                </button>
                <button type="button" class="btn-icon-sample" data-icon="fa-charging-station">
                    <i class="fa-solid fa-charging-station"></i> <span>Củ sạc</span>
                </button>
                <button type="button" class="btn-icon-sample" data-icon="fa-battery-full">
                    <i class="fa-solid fa-battery-full"></i> <span>Sạc dự phòng</span>
                </button>
                <button type="button" class="btn-icon-sample" data-icon="fa-shield-halved">
                    <i class="fa-solid fa-shield-halved"></i> <span>Ốp lưng & Kính</span>
                </button>
                <button type="button" class="btn-icon-sample" data-icon="fa-computer-mouse">
                    <i class="fa-solid fa-computer-mouse"></i> <span>Chuột & Phím</span>
                </button>
                <button type="button" class="btn-icon-sample" data-icon="fa-clock">
                    <i class="fa-solid fa-clock"></i> <span>Đồng hồ</span>
                </button>
                <button type="button" class="btn-icon-sample" data-icon="fa-plug">
                    <i class="fa-solid fa-plug"></i> <span>Cáp & Hub</span>
                </button>
            </div>
        </div>
    </div>
</div>

<style>
.btn-icon-sample {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 10px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    cursor: pointer;
    font-size: 13px;
    color: #334155;
    transition: all 0.2s ease;
    text-align: left;
}
.btn-icon-sample:hover {
    background: #e2e8f0;
    border-color: #cbd5e1;
    color: var(--primary);
}
.btn-icon-sample i {
    width: 20px;
    text-align: center;
    color: var(--primary);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const iconInput = document.getElementById('catIcon');
    const iconPreview = document.getElementById('iconPreview');

    // Cập nhật preview icon khi gõ
    if (iconInput && iconPreview) {
        iconInput.addEventListener('input', function() {
            const iconVal = this.value.trim() || 'fa-cube';
            iconPreview.innerHTML = '<i class="fa-solid ' + iconVal + '"></i>';
        });
    }

    // Chọn nhanh biểu tượng từ danh sách gợi ý
    document.querySelectorAll('.btn-icon-sample').forEach(btn => {
        btn.addEventListener('click', function() {
            const icon = this.dataset.icon;
            if (iconInput && iconPreview) {
                iconInput.value = icon;
                iconPreview.innerHTML = '<i class="fa-solid ' + icon + '"></i>';
            }
        });
    });
});
</script>

