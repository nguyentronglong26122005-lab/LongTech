<?php
/**
 * ========================================================
 * LONGTECH - VIEW DUYỆT ĐÁNH GIÁ (admin/pages/reviews/list.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-star-half-stroke text-primary"></i> Quản Lý Đánh Giá & Nhận Xét</h1>
        <p class="page-subtitle">Kiểm duyệt đánh giá của khách hàng đối với các sản phẩm trên hệ thống</p>
    </div>
</div>

<?= render_flash_messages() ?>

<!-- BỘ LỌC TÌM KIẾM & TRẠNG THÁI -->
<div class="admin-card mb-4">
    <div class="admin-card-body" style="padding:16px 20px;">
        <form method="GET" action="<?= APP_URL ?>/admin.php" style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;">
            <input type="hidden" name="act" value="reviews">
            <div style="flex:2;min-width:200px;">
                <input type="text" name="search" class="form-control" placeholder="🔍 Tìm theo tên khách hoặc sản phẩm..."
                       value="<?= e($search ?? '') ?>">
            </div>
            <div style="min-width:160px;">
                <select name="status" class="form-control">
                    <option value="">-- Tất cả trạng thái --</option>
                    <option value="pending" <?= ($status??'')==='pending' ? 'selected' : '' ?>>Chờ duyệt (<?= (int)($counts['pending'] ?? 0) ?>)</option>
                    <option value="approved" <?= ($status??'')==='approved' ? 'selected' : '' ?>>Đã duyệt (<?= (int)($counts['approved'] ?? 0) ?>)</option>
                    <option value="rejected" <?= ($status??'')==='rejected' ? 'selected' : '' ?>>Bị từ chối (<?= (int)($counts['rejected'] ?? 0) ?>)</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-filter"></i> Lọc</button>
            <a href="<?= APP_URL ?>/admin.php?act=reviews" class="btn btn-secondary">Đặt lại</a>
        </form>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <h3 class="admin-card-title">
            <i class="fa-solid fa-comments"></i> Danh Sách Đánh Giá
            <span class="badge badge-primary"><?= $totalItems ?? count($reviews) ?></span>
        </h3>
    </div>
    <div class="admin-card-body">
        <?php if (empty($reviews)): ?>
            <div style="text-align:center;padding:40px;color:#9ca3af;">
                <i class="fa-regular fa-star" style="font-size:3rem;margin-bottom:12px;display:block;"></i>
                <p>Không tìm thấy nhận xét/đánh giá nào phù hợp.</p>
            </div>
        <?php else: ?>
        <div style="overflow-x:auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width:60px;">ID</th>
                        <th>Sản Phẩm</th>
                        <th>Khách Hàng</th>
                        <th style="width:110px;">Điểm Sao</th>
                        <th>Nội Dung</th>
                        <th style="width:110px;">Trạng Thái</th>
                        <th style="width:120px;">Ngày Gửi</th>
                        <th style="width:140px;">Thao Tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reviews as $review): ?>
                    <tr>
                        <td><strong>#<?= e($review['id']) ?></strong></td>
                        <td>
                            <strong><?= e($review['product_name'] ?? 'Sản phẩm #' . $review['product_id']) ?></strong>
                        </td>
                        <td><?= e($review['user_name'] ?? 'Khách vãng lai') ?></td>
                        <td>
                            <div style="color: #f59e0b; white-space: nowrap;">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fa-<?= $i <= (int)$review['rating'] ? 'solid' : 'regular' ?> fa-star"></i>
                                <?php endfor; ?>
                            </div>
                        </td>
                        <td>
                            <div style="max-width: 300px; word-break: break-word;">
                                <?= nl2br(e($review['comment'] ?? '')) ?>
                            </div>
                        </td>
                        <td>
                            <?php if ($review['status'] === 'approved'): ?>
                                <span class="badge badge-success">Đã duyệt</span>
                            <?php elseif ($review['status'] === 'rejected'): ?>
                                <span class="badge badge-danger">Từ chối</span>
                            <?php else: ?>
                                <span class="badge badge-warning">Chờ duyệt</span>
                            <?php endif; ?>
                        </td>
                        <td><small><?= date('d/m/Y H:i', strtotime($review['created_at'])) ?></small></td>
                        <td>
                            <div style="display: flex; gap: 5px;">
                                <?php if ($review['status'] !== 'approved'): ?>
                                <form method="POST" action="<?= APP_URL ?>/admin.php?act=reviews/approve" style="display:inline;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= $review['id'] ?>">
                                    <input type="hidden" name="new_status" value="approved">
                                    <button type="submit" class="btn btn-sm btn-success" title="Duyệt bài">
                                        <i class="fa-solid fa-check"></i>
                                    </button>
                                </form>
                                <?php endif; ?>

                                <?php if ($review['status'] !== 'rejected'): ?>
                                <form method="POST" action="<?= APP_URL ?>/admin.php?act=reviews/approve" style="display:inline;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= $review['id'] ?>">
                                    <input type="hidden" name="new_status" value="rejected">
                                    <button type="submit" class="btn btn-sm btn-warning" title="Từ chối">
                                        <i class="fa-solid fa-ban"></i>
                                    </button>
                                </form>
                                <?php endif; ?>

                                <form method="POST" action="<?= APP_URL ?>/admin.php?act=reviews/delete" style="display:inline;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= $review['id'] ?>">
                                    <button type="button" class="btn btn-sm btn-danger" title="Xóa"
                                            onclick="confirmAdminDelete(this.closest('form'), 'Đánh giá #<?= $review['id'] ?>')">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <?= $pagination ?? '' ?>
    </div>
</div>

