<?php
/**
 * ========================================================
 * LONGTECH - VIEW QUẢN LÝ ĐƠN HÀNG (admin/pages/orders/list.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-cart-flatbed-suitcase text-primary"></i> Quản Lý Đơn Hàng</h1>
        <p class="page-subtitle">Theo dõi quy trình tiếp nhận, xác nhận, đóng gói và giao hàng 7 bước</p>
    </div>
</div>

<?= render_flash_messages() ?>

<!-- THANH LỌC TRẠNG THÁI (STATUS TABS) -->
<div class="status-tab-bar" style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 20px;">
    <?php
    $tabs = [
        ''           => ['label' => 'Tất Cả', 'count' => $statusCounts['all'] ?? 0, 'icon' => 'fa-list'],
        'pending'    => ['label' => 'Chờ xử lý', 'count' => $statusCounts['pending'] ?? 0, 'icon' => 'fa-clock'],
        'confirmed'  => ['label' => 'Đã xác nhận', 'count' => $statusCounts['confirmed'] ?? 0, 'icon' => 'fa-check'],
        'processing' => ['label' => 'Đang đóng gói', 'count' => $statusCounts['processing'] ?? 0, 'icon' => 'fa-box-open'],
        'shipping'   => ['label' => 'Đang giao', 'count' => $statusCounts['shipping'] ?? 0, 'icon' => 'fa-truck-fast'],
        'completed'  => ['label' => 'Hoàn thành', 'count' => $statusCounts['completed'] ?? 0, 'icon' => 'fa-circle-check'],
        'cancelled'  => ['label' => 'Đã hủy', 'count' => $statusCounts['cancelled'] ?? 0, 'icon' => 'fa-ban']
    ];
    ?>
    <?php foreach ($tabs as $stKey => $tab): ?>
        <?php $isActive = ($statusFilter === $stKey); ?>
        <a href="<?= APP_URL ?>/admin.php?act=orders<?= !empty($stKey) ? '&status=' . $stKey : '' ?><?= !empty($keyword) ? '&keyword=' . urlencode($keyword) : '' ?>" 
           class="status-pill <?= $isActive ? 'active' : '' ?>">
            <i class="fa-solid <?= $tab['icon'] ?>"></i>
            <span><?= $tab['label'] ?></span>
            <span class="count-badge"><?= $tab['count'] ?></span>
        </a>
    <?php endforeach; ?>
</div>

<!-- KHUNG TÌM KIẾM ĐƠN HÀNG -->
<div class="admin-card mb-4">
    <div class="admin-card-body" style="padding: 16px 20px;">
        <form action="<?= APP_URL ?>/admin.php" method="GET" style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
            <input type="hidden" name="act" value="orders">
            <?php if (!empty($statusFilter)): ?>
                <input type="hidden" name="status" value="<?= e($statusFilter) ?>">
            <?php endif; ?>

            <div style="flex: 1; min-width: 260px;">
                <input type="text" name="keyword" class="form-control" 
                       placeholder="Nhập mã đơn (LT-...), tên người nhận hoặc số điện thoại..." 
                       value="<?= e($keyword) ?>">
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-magnifying-glass"></i> Tìm Kiếm
            </button>

            <?php if (!empty($keyword) || !empty($statusFilter)): ?>
                <a href="<?= APP_URL ?>/admin.php?act=orders" class="btn btn-secondary">
                    <i class="fa-solid fa-rotate-left"></i> Xóa Lọc
                </a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- BẢNG DANH SÁCH ĐƠN HÀNG -->
<div class="admin-card">
    <div class="admin-card-header">
        <div class="card-title">
            <span>Danh Sách Đơn Hàng</span>
            <span class="badge badge-info" style="margin-left: 8px;"><?= count($orders) ?> đơn</span>
        </div>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Mã Đơn Hàng</th>
                        <th>Ngày Đặt</th>
                        <th>Khách Hàng & Liên Hệ</th>
                        <th>Thanh Toán</th>
                        <th style="text-align: right;">Tổng Tiền</th>
                        <th style="text-align: center;">Trạng Thái Đơn</th>
                        <th style="text-align: right; width: 130px;">Hành Động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($orders)): ?>
                        <tr>
                            <td colspan="7" class="text-center" style="padding: 40px; color: #64748b;">
                                <i class="fa-solid fa-receipt" style="font-size: 32px; margin-bottom: 10px; display: block;"></i>
                                Không tìm thấy đơn hàng nào phù hợp với bộ lọc.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td>
                                    <a href="<?= APP_URL ?>/admin.php?act=orders/detail&id=<?= $order['id'] ?>" style="font-weight: 700; color: var(--primary);">
                                        <?= e($order['order_code']) ?>
                                    </a>
                                </td>
                                <td>
                                    <div style="font-size: 13px; color: #334155;">
                                        <?= date('d/m/Y', strtotime($order['created_at'])) ?>
                                    </div>
                                    <small style="color: #64748b;"><?= date('H:i', strtotime($order['created_at'])) ?></small>
                                </td>
                                <td>
                                    <div style="font-weight: 600; color: #0f172a;">
                                        <?= e($order['customer_name']) ?>
                                    </div>
                                    <div style="font-size: 13px; color: #64748b;">
                                        <i class="fa-solid fa-phone" style="font-size: 11px;"></i> <?= e($order['customer_phone']) ?>
                                    </div>
                                </td>
                                <td>
                                    <div style="font-size: 13px; margin-bottom: 4px;">
                                        <?= ($order['payment_method'] === 'bank_transfer') ? '<i class="fa-solid fa-qrcode text-primary"></i> Chuyển khoản' : '<i class="fa-solid fa-money-bill-wave text-success"></i> COD (Tiền mặt)' ?>
                                    </div>
                                    <?php if ($order['payment_status'] === 'paid'): ?>
                                        <span class="badge badge-success"><i class="fa-solid fa-check"></i> Đã thanh toán</span>
                                    <?php elseif ($order['payment_status'] === 'refunded'): ?>
                                        <span class="badge badge-secondary"><i class="fa-solid fa-rotate-left"></i> Hoàn tiền</span>
                                    <?php else: ?>
                                        <span class="badge badge-warning"><i class="fa-solid fa-clock"></i> Chưa thu tiền</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: right; font-weight: 700; color: var(--accent); font-size: 15px;">
                                    <?= format_money($order['total_amount']) ?>
                                </td>
                                <td style="text-align: center;">
                                    <?php
                                    $st = $order['status'];
                                    $stClass = match($st) {
                                        'pending'    => 'badge-warning',
                                        'confirmed'  => 'badge-info',
                                        'processing' => 'badge-secondary',
                                        'shipping'   => 'badge-primary',
                                        'completed'  => 'badge-success',
                                        'cancelled'  => 'badge-danger',
                                        'refunded'   => 'badge-secondary',
                                        default      => 'badge-secondary'
                                    };
                                    ?>
                                    <span class="badge <?= $stClass ?>">
                                        <?= e(OrderManageController::getStatusLabel($st)) ?>
                                    </span>
                                </td>
                                <td style="text-align: right;">
                                    <a href="<?= APP_URL ?>/admin.php?act=orders/detail&id=<?= $order['id'] ?>" class="btn btn-sm btn-primary" style="padding: 6px 12px; font-size: 12px;">
                                        <i class="fa-solid fa-eye"></i> Xem & Duyệt
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.status-pill {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 14px;
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 500;
    color: #475569;
    text-decoration: none;
    transition: all 0.2s ease;
}
.status-pill:hover {
    border-color: var(--primary);
    color: var(--primary);
}
.status-pill.active {
    background: var(--primary);
    border-color: var(--primary);
    color: #fff;
}
.status-pill .count-badge {
    background: rgba(0,0,0,0.06);
    padding: 2px 8px;
    border-radius: 10px;
    font-size: 11px;
    font-weight: 700;
}
.status-pill.active .count-badge {
    background: rgba(255,255,255,0.25);
    color: #fff;
}
</style>

