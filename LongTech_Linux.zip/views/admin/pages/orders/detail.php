<?php
/**
 * ========================================================
 * LONGTECH - VIEW CHI TIẾT & DUYỆT ĐƠN HÀNG (admin/pages/orders/detail.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

$currentStatus = $order['status'];
$paymentStatus = $order['payment_status'];
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title">
            <i class="fa-solid fa-file-invoice text-primary"></i> 
            Đơn Hàng #<?= e($order['order_code']) ?>
        </h1>
        <p class="page-subtitle">Ngày đặt hàng: <?= date('d/m/Y - H:i:s', strtotime($order['created_at'])) ?></p>
    </div>
    <div class="header-actions">
        <a href="<?= APP_URL ?>/admin.php?act=orders" class="btn btn-secondary">
            <i class="fa-solid fa-arrow-left"></i> Quay Lại Danh Sách
        </a>
        <button onclick="window.print()" class="btn btn-secondary" style="margin-left: 8px;">
            <i class="fa-solid fa-print"></i> In Đơn
        </button>
    </div>
</div>

<?= render_flash_messages() ?>

<!-- TIẾN TRÌNH VÒNG ĐỜI ĐƠN HÀNG (STATUS PROGRESS) -->
<div class="admin-card mb-4">
    <div class="admin-card-body">
        <?php if ($currentStatus === 'cancelled'): ?>
            <div style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 16px; display: flex; align-items: center; gap: 14px; color: #991b1b;">
                <i class="fa-solid fa-ban" style="font-size: 28px;"></i>
                <div>
                    <h3 style="margin: 0; font-size: 16px; font-weight: 700;">Đơn Hàng Này Đã Bị Hủy</h3>
                    <p style="margin: 4px 0 0; font-size: 13px;">Số lượng linh kiện / thiết bị trong đơn đã được tự động hoàn lại vào kho hàng.</p>
                </div>
            </div>
        <?php else: ?>
            <div class="order-stepper">
                <?php
                $steps = [
                    'pending'    => ['title' => 'Chờ xử lý', 'icon' => 'fa-clock'],
                    'confirmed'  => ['title' => 'Đã xác nhận', 'icon' => 'fa-clipboard-check'],
                    'processing' => ['title' => 'Đóng gói', 'icon' => 'fa-box'],
                    'shipping'   => ['title' => 'Đang giao', 'icon' => 'fa-truck-fast'],
                    'completed'  => ['title' => 'Hoàn thành', 'icon' => 'fa-circle-check']
                ];
                $stepKeys = array_keys($steps);
                $currentIndex = array_search($currentStatus, $stepKeys);
                if ($currentIndex === false) $currentIndex = 0;
                ?>
                <?php foreach ($steps as $key => $s): ?>
                    <?php 
                    $idx = array_search($key, $stepKeys);
                    $isPassed = ($idx <= $currentIndex);
                    $isCurrent = ($idx === $currentIndex);
                    ?>
                    <div class="stepper-item <?= $isPassed ? 'completed' : '' ?> <?= $isCurrent ? 'active' : '' ?>">
                        <div class="stepper-circle">
                            <i class="fa-solid <?= $s['icon'] ?>"></i>
                        </div>
                        <div class="stepper-label"><?= $s['title'] ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="admin-grid" style="grid-template-columns: 2fr 1fr; align-items: flex-start; gap: 24px;">
    <!-- CỘT TRÁI: DANH SÁCH SẢN PHẨM & TỔNG TIỀN -->
    <div>
        <!-- DANH SÁCH MẶT HÀNG -->
        <div class="admin-card mb-4">
            <div class="admin-card-header">
                <div class="card-title">
                    <i class="fa-solid fa-box text-primary"></i>
                    <span>Sản Phẩm Trong Đơn Hàng (<?= count($items) ?> mặt hàng)</span>
                </div>
            </div>
            <div class="admin-card-body p-0">
                <div class="table-responsive">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Sản Phẩm</th>
                                <th style="text-align: right;">Đơn Giá</th>
                                <th style="text-align: center;">SL</th>
                                <th style="text-align: right;">Thành Tiền</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                                <tr>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 12px;">
                                            <img src="<?= e($item['thumbnail'] ?: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=200') ?>" 
                                                 alt="<?= e($item['product_name']) ?>"
                                                 style="width: 50px; height: 50px; object-fit: cover; border-radius: 6px; border: 1px solid #e2e8f0;">
                                            <div>
                                                <a href="<?= APP_URL ?>/san-pham/<?= e($item['slug'] ?? '') ?>" target="_blank" style="font-weight: 600; color: #0f172a; text-decoration: none;">
                                                    <?= e($item['product_name']) ?>
                                                </a>
                                                <div style="display: flex; gap: 6px; margin-top: 4px; font-size: 12px;">
                                                    <?php if (!empty($item['color'])): ?>
                                                        <span class="badge badge-secondary"><?= e($item['color']) ?></span>
                                                    <?php endif; ?>
                                                    <?php if (!empty($item['storage'])): ?>
                                                        <span class="badge badge-info"><?= e($item['storage']) ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td style="text-align: right; color: #334155; font-weight: 500;">
                                        <?= format_money($item['product_price']) ?>
                                    </td>
                                    <td style="text-align: center; font-weight: 700;">
                                        <?= (int)$item['quantity'] ?>
                                    </td>
                                    <td style="text-align: right; font-weight: 700; color: var(--primary);">
                                        <?= format_money($item['total_price']) ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- BẢNG TỔNG KẾT TÀI CHÍNH -->
            <div style="padding: 20px; background: #f8fafc; border-top: 1px solid #e2e8f0;">
                <div style="max-width: 360px; margin-left: auto;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px; color: #475569;">
                        <span>Tạm tính hàng hóa:</span>
                        <strong><?= format_money($order['subtotal']) ?></strong>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px; color: #475569;">
                        <span>Phí vận chuyển:</span>
                        <span><?= ((float)$order['shipping_fee'] == 0) ? '<strong class="text-success">Miễn phí (Freeship)</strong>' : format_money($order['shipping_fee']) ?></span>
                    </div>
                    <?php if ((float)$order['discount_amount'] > 0): ?>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px; color: #16a34a;">
                            <span>Mã giảm giá (Coupon):</span>
                            <strong>- <?= format_money($order['discount_amount']) ?></strong>
                        </div>
                    <?php endif; ?>
                    <div style="display: flex; justify-content: space-between; padding-top: 10px; border-top: 2px dashed #cbd5e1; font-size: 17px;">
                        <span style="font-weight: 700; color: #0f172a;">Tổng thanh toán:</span>
                        <strong style="color: var(--accent); font-size: 20px;"><?= format_money($order['total_amount']) ?></strong>
                    </div>
                </div>
            </div>
        </div>

        <!-- GHI CHÚ TỪ KHÁCH HÀNG -->
        <?php if (!empty($order['note'])): ?>
            <div class="admin-card">
                <div class="admin-card-header">
                    <div class="card-title">
                        <i class="fa-solid fa-comment-dots text-primary"></i>
                        <span>Lời Nhắn Của Khách Hàng</span>
                    </div>
                </div>
                <div class="admin-card-body">
                    <p style="background: #fffbeb; border-left: 4px solid #f59e0b; padding: 12px 16px; border-radius: 4px; margin: 0; color: #92400e; font-style: italic;">
                        "<?= nl2br(e($order['note'])) ?>"
                    </p>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- CỘT PHẢI: XỬ LÝ TRẠNG THÁI & THÔNG TIN KHÁCH HÀNG -->
    <div>
        <!-- FORM DUYỆT TRẠNG THÁI ĐƠN HÀNG -->
        <div class="admin-card mb-4" style="border-top: 4px solid var(--primary);">
            <div class="admin-card-header">
                <div class="card-title">
                    <i class="fa-solid fa-sliders text-primary"></i>
                    <span>Cập Nhật Đơn Hàng</span>
                </div>
            </div>
            <div class="admin-card-body">
                <form action="<?= APP_URL ?>/admin.php?act=orders/update-status" method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= $order['id'] ?>">

                    <div class="form-group mb-3">
                        <label class="form-label required">Trạng Thái Đơn Hàng</label>
                        <select name="status" class="form-control" style="font-weight: 600;">
                            <option value="pending" <?= $currentStatus === 'pending' ? 'selected' : '' ?>>⏳ 1. Chờ xử lý (Mới)</option>
                            <option value="confirmed" <?= $currentStatus === 'confirmed' ? 'selected' : '' ?>>✅ 2. Đã xác nhận đơn</option>
                            <option value="processing" <?= $currentStatus === 'processing' ? 'selected' : '' ?>>📦 3. Đang đóng gói sản phẩm</option>
                            <option value="shipping" <?= $currentStatus === 'shipping' ? 'selected' : '' ?>>🚚 4. Đang giao hàng</option>
                            <option value="completed" <?= $currentStatus === 'completed' ? 'selected' : '' ?>>🎉 5. Hoàn thành đơn hàng</option>
                            <option value="cancelled" <?= $currentStatus === 'cancelled' ? 'selected' : '' ?>>❌ 6. Đã hủy đơn (Hoàn kho)</option>
                            <option value="refunded" <?= $currentStatus === 'refunded' ? 'selected' : '' ?>>🔄 7. Hoàn tiền cho khách</option>
                        </select>
                    </div>

                    <div class="form-group mb-3">
                        <label class="form-label required">Trạng Thái Thu Tiền</label>
                        <select name="payment_status" class="form-control">
                            <option value="unpaid" <?= $paymentStatus === 'unpaid' ? 'selected' : '' ?>>Chưa thu tiền (Unpaid)</option>
                            <option value="paid" <?= $paymentStatus === 'paid' ? 'selected' : '' ?>>Đã thu tiền (Paid)</option>
                            <option value="refunded" <?= $paymentStatus === 'refunded' ? 'selected' : '' ?>>Đã hoàn lại tiền (Refunded)</option>
                        </select>
                    </div>

                    <div style="background: #f8fafc; border-radius: 6px; padding: 10px 12px; margin-bottom: 16px; font-size: 12px; color: #64748b;">
                        <i class="fa-solid fa-shield-halved text-primary"></i> 
                        Nếu chọn <strong>"Đã hủy đơn"</strong>, số lượng của <?= count($items) ?> sản phẩm sẽ được tự động cộng hoàn lại kho.
                    </div>

                    <button type="submit" class="btn btn-primary" style="width: 100%; padding: 10px;">
                        <i class="fa-solid fa-floppy-disk"></i> Lưu Trạng Thái
                    </button>
                </form>
            </div>
        </div>

        <!-- THÔNG TIN NGƯỜI NHẬN HÀNG -->
        <div class="admin-card mb-4">
            <div class="admin-card-header">
                <div class="card-title">
                    <i class="fa-solid fa-user text-primary"></i>
                    <span>Thông Tin Nhận Hàng</span>
                </div>
            </div>
            <div class="admin-card-body" style="font-size: 14px; line-height: 1.6;">
                <div style="margin-bottom: 10px;">
                    <strong style="color: #0f172a; font-size: 15px;"><?= e($order['customer_name']) ?></strong>
                    <?php if ($customerUser): ?>
                        <span class="badge badge-info" style="margin-left: 6px;">Thành viên (@<?= e($customerUser['username']) ?>)</span>
                    <?php else: ?>
                        <span class="badge badge-secondary" style="margin-left: 6px;">Khách vãng lai</span>
                    <?php endif; ?>
                </div>

                <div style="color: #475569; margin-bottom: 6px;">
                    <i class="fa-solid fa-phone" style="width: 20px; color: var(--primary);"></i>
                    <a href="tel:<?= e($order['customer_phone']) ?>" style="color: #0284c7; text-decoration: none; font-weight: 600;">
                        <?= e($order['customer_phone']) ?>
                    </a>
                </div>

                <div style="color: #475569; margin-bottom: 10px;">
                    <i class="fa-solid fa-envelope" style="width: 20px; color: var(--primary);"></i>
                    <a href="mailto:<?= e($order['customer_email']) ?>" style="color: #475569; text-decoration: none;">
                        <?= e($order['customer_email']) ?>
                    </a>
                </div>

                <div style="padding-top: 10px; border-top: 1px solid #e2e8f0;">
                    <div style="font-weight: 600; color: #334155; margin-bottom: 4px;">
                        <i class="fa-solid fa-location-dot" style="color: var(--accent);"></i> Địa chỉ giao hàng:
                    </div>
                    <div style="color: #1e293b;">
                        <?= e($order['customer_address']) ?><br>
                        <?= e($order['ward'] ? $order['ward'] . ', ' : '') ?><?= e($order['district'] ? $order['district'] . ', ' : '') ?><?= e($order['city']) ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- HÌNH THỨC THANH TOÁN -->
        <div class="admin-card">
            <div class="admin-card-header">
                <div class="card-title">
                    <i class="fa-solid fa-credit-card text-primary"></i>
                    <span>Hình Thức Thanh Toán</span>
                </div>
            </div>
            <div class="admin-card-body">
                <?php if ($order['payment_method'] === 'bank_transfer'): ?>
                    <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 12px; font-size: 13px; color: #1e40af;">
                        <strong style="display: block; margin-bottom: 4px;"><i class="fa-solid fa-qrcode"></i> Chuyển khoản Ngân hàng (VietQR)</strong>
                        Cú pháp chuyển khoản: <code><?= e($order['order_code']) ?></code><br>
                        Vui lòng kiểm tra sao kê ngân hàng trước khi xác nhận đã thanh toán.
                    </div>
                <?php else: ?>
                    <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 12px; font-size: 13px; color: #166534;">
                        <strong><i class="fa-solid fa-money-bill-wave"></i> Thu tiền khi nhận hàng (COD)</strong><br>
                        Shipper sẽ thu tiền mặt trực tiếp khi giao gói hàng.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.order-stepper {
    display: flex;
    justify-content: space-between;
    position: relative;
    margin: 10px 0;
}
.order-stepper::before {
    content: '';
    position: absolute;
    top: 20px;
    left: 40px;
    right: 40px;
    height: 3px;
    background: #e2e8f0;
    z-index: 1;
}
.stepper-item {
    position: relative;
    z-index: 2;
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 1;
}
.stepper-circle {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    background: #fff;
    border: 3px solid #cbd5e1;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    color: #94a3b8;
    transition: all 0.2s ease;
}
.stepper-label {
    margin-top: 8px;
    font-size: 13px;
    font-weight: 600;
    color: #64748b;
    text-align: center;
}
.stepper-item.completed .stepper-circle {
    background: #10b981;
    border-color: #10b981;
    color: #fff;
}
.stepper-item.completed .stepper-label {
    color: #0f172a;
}
.stepper-item.active .stepper-circle {
    background: var(--primary);
    border-color: var(--primary);
    color: #fff;
    box-shadow: 0 0 0 4px rgba(10,37,64,0.15);
}
.stepper-item.active .stepper-label {
    color: var(--primary);
}
</style>

