<?php
/**
 * ========================================================
 * LONGTECH - QUẢN LÝ DANH SÁCH SẢN PHẨM (admin/pages/products/list.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="admin-products-page">
    <!-- Header: Tiêu đề & Nút Thêm mới -->
    <div class="card-header-flex" style="margin-bottom: 20px;">
        <div>
            <h2 style="font-size: 20px; font-weight: 800; color: var(--admin-primary);">
                <i class="fa-solid fa-boxes-stacked"></i> Danh Sách Sản Phẩm & Quản Lý Kho
            </h2>
            <span style="font-size: 13px; color: #64748b;">Tổng cộng: <strong><?= count($products) ?></strong> sản phẩm</span>
        </div>
        <a href="<?= APP_URL ?>/admin.php?act=products/add" class="btn-primary-tech" style="padding: 10px 18px; border-radius: 6px;">
            <i class="fa-solid fa-plus"></i> Thêm Sản Phẩm Mới
        </a>
    </div>

    <!-- Thanh Tìm Kiếm & Lọc Nhanh -->
    <div class="admin-table-card" style="padding: 16px 20px; margin-bottom: 20px;">
        <form action="<?= APP_URL ?>/admin.php" method="GET" class="admin-filter-form" style="display:flex; gap:12px; flex-wrap:wrap; align-items:center;">
            <input type="hidden" name="act" value="products">

            <!-- Từ khóa -->
            <div style="flex: 1; min-width: 220px;">
                <input type="text" name="keyword" class="form-control" placeholder="Tìm tên, mã SP..." value="<?= e($keyword) ?>">
            </div>

            <!-- Danh mục -->
            <div style="min-width: 160px;">
                <select name="category_id" class="form-control" style="cursor: pointer;">
                    <option value="0">Tất cả danh mục</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= $categoryId == $cat['id'] ? 'selected' : '' ?>><?= e($cat['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Thương hiệu -->
            <div style="min-width: 150px;">
                <select name="brand_id" class="form-control" style="cursor: pointer;">
                    <option value="0">Tất cả thương hiệu</option>
                    <?php foreach ($brands as $b): ?>
                        <option value="<?= $b['id'] ?>" <?= $brandId == $b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Lọc Tồn kho -->
            <div style="min-width: 170px;">
                <select name="stock" class="form-control" style="cursor: pointer;">
                    <option value="">Tất cả tồn kho</option>
                    <option value="low" <?= $stockFilter === 'low' ? 'selected' : '' ?>>⚠️ Sắp hết hàng (&le; 5)</option>
                    <option value="out" <?= $stockFilter === 'out' ? 'selected' : '' ?>>❌ Hết hàng (0)</option>
                    <option value="in" <?= $stockFilter === 'in' ? 'selected' : '' ?>>✅ Còn hàng (&gt; 5)</option>
                </select>
            </div>

            <button type="submit" class="btn-primary-tech" style="padding: 10px 18px; border-radius: 6px;">
                <i class="fa-solid fa-filter"></i> Lọc
            </button>
            <a href="<?= APP_URL ?>/admin.php?act=products" class="btn-action-view" style="padding: 9px 14px; border-radius: 6px;">
                <i class="fa-solid fa-rotate-left"></i> Đặt lại
            </a>
        </form>
    </div>

    <!-- Bảng Danh Sách Sản Phẩm -->
    <div class="admin-table-card">
        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">ID</th>
                        <th style="width: 70px;">Ảnh</th>
                        <th>Tên Sản Phẩm / Mã SP</th>
                        <th>Danh Mục / Hãng</th>
                        <th>Giá Bán</th>
                        <th>Giá Khuyến Mãi</th>
                        <th>Tồn Kho</th>
                        <th>Trạng Thái</th>
                        <th style="text-align: right;">Thao Tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($products)): ?>
                        <?php foreach ($products as $p): ?>
                            <tr>
                                <td>#<?= $p['id'] ?></td>
                                <td>
                                    <img src="<?= e($p['thumbnail']) ?>" alt="<?= e($p['name']) ?>" style="width: 50px; height: 50px; object-fit: contain; border: 1px solid #e2e8f0; border-radius: 6px; padding: 2px;">
                                </td>
                                <td>
                                    <strong style="color: var(--admin-primary); display:block; font-size:14px;"><?= e($p['name']) ?></strong>
                                    <small style="color: #64748b; font-family: monospace;">Mã: <?= e($p['product_code']) ?></small>
                                </td>
                                <td>
                                    <span style="font-size:12px; font-weight:600; display:block;"><?= e($p['category_name']) ?></span>
                                    <small style="color: #64748b;"><?= e($p['brand_name'] ?? 'N/A') ?></small>
                                </td>
                                <td>
                                    <span style="font-weight: 600;"><?= format_money($p['price']) ?></span>
                                </td>
                                <td>
                                    <?php if (!empty($p['sale_price']) && $p['sale_price'] < $p['price']): ?>
                                        <strong class="text-danger"><?= format_money($p['sale_price']) ?></strong>
                                    <?php else: ?>
                                        <span style="color: #94a3b8;">Không</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($p['stock_quantity'] <= 0): ?>
                                        <span class="badge-status status-cancelled">Hết hàng</span>
                                    <?php elseif ($p['stock_quantity'] <= 5): ?>
                                        <span class="badge-status status-processing" title="Cảnh báo: Sắp hết!">
                                            Còn <?= $p['stock_quantity'] ?> (Cảnh báo)
                                        </span>
                                    <?php else: ?>
                                        <span class="badge-status status-completed">Còn <?= $p['stock_quantity'] ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge-status <?= $p['status'] === 'active' ? 'status-completed' : 'status-refunded' ?>">
                                        <?= $p['status'] === 'active' ? 'Hoạt động' : 'Tạm ẩn' ?>
                                    </span>
                                </td>
                                <td style="text-align: right; white-space: nowrap;">
                                    <a href="<?= APP_URL ?>/san-pham/<?= e($p['slug']) ?>" target="_blank" class="btn-action-view" title="Xem trên web">
                                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                    </a>
                                    <a href="<?= APP_URL ?>/admin.php?act=products/edit&id=<?= $p['id'] ?>" class="btn-action-view" style="background:#fef3c7; color:#b45309;" title="Chỉnh sửa">
                                        <i class="fa-solid fa-pen-to-square"></i> Sửa
                                    </a>
                                    <a href="<?= APP_URL ?>/admin.php?act=products/delete&id=<?= $p['id'] ?>" class="btn-action-view" style="background:#fee2e2; color:#b91c1c;" onclick="return confirmAdminDelete(this.href, 'sản phẩm này')" title="Xóa">
                                        <i class="fa-solid fa-trash-can"></i> Xóa
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" style="text-align:center; padding: 40px; color: #64748b;">
                                <i class="fa-solid fa-magnifying-glass" style="font-size: 28px; display:block; margin-bottom: 8px;"></i>
                                Không tìm thấy sản phẩm nào phù hợp với điều kiện tìm kiếm.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

