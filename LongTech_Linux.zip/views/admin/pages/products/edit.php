<?php
/**
 * ========================================================
 * LONGTECH - CHỈNH SỬA SẢN PHẨM (admin/pages/products/edit.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="admin-product-form-page">
    <div class="card-header-flex" style="margin-bottom: 20px;">
        <div>
            <h2 style="font-size: 20px; font-weight: 800; color: var(--admin-primary);">
                <i class="fa-solid fa-pen-to-square text-secondary"></i> Chỉnh Sửa Sản Phẩm: <?= e($product['name']) ?>
            </h2>
            <span style="font-size: 13px; color: #64748b;">Mã định danh: #<?= $product['id'] ?> | SKU: <?= e($product['product_code']) ?></span>
        </div>
        <div style="display:flex; gap:10px;">
            <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" target="_blank" class="btn-action-view" style="padding: 9px 14px;">
                <i class="fa-solid fa-arrow-up-right-from-square"></i> Xem trên Web
            </a>
            <a href="<?= APP_URL ?>/admin.php?act=products" class="btn-action-view" style="padding: 9px 14px;">
                <i class="fa-solid fa-arrow-left"></i> Quay lại
            </a>
        </div>
    </div>

    <form action="<?= APP_URL ?>/admin.php?act=products/edit&id=<?= $product['id'] ?>" method="POST" enctype="multipart/form-data" class="admin-form">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= $product['id'] ?>">

        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px; align-items: flex-start;">
            <!-- CỘT TRÁI: THÔNG TIN CHÍNH & MÔ TẢ -->
            <div style="display: flex; flex-direction: column; gap: 20px;">
                <!-- Hộp 1: Thông tin cơ bản -->
                <div class="admin-table-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 800; color: var(--admin-primary); margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--admin-border);">
                        1. Thông Tin Định Danh & Giá Bán
                    </h3>

                    <div class="form-group">
                        <label class="form-label">Tên sản phẩm <span class="required">*</span></label>
                        <input type="text" name="name" class="form-control" value="<?= e($product['name']) ?>" required>
                    </div>

                    <div class="form-row-2">
                        <div class="form-group">
                            <label class="form-label">Mã sản phẩm (SKU) <span class="required">*</span></label>
                            <input type="text" name="product_code" class="form-control" value="<?= e($product['product_code']) ?>" required style="text-transform: uppercase;">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Số lượng tồn kho (Chiếc) <span class="required">*</span></label>
                            <input type="number" name="stock_quantity" class="form-control" value="<?= $product['stock_quantity'] ?>" min="0" required>
                        </div>
                    </div>

                    <div class="form-row-2">
                        <div class="form-group">
                            <label class="form-label">Danh mục sản phẩm <span class="required">*</span></label>
                            <select name="category_id" class="form-control" required style="cursor: pointer;">
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>" <?= $product['category_id'] == $cat['id'] ? 'selected' : '' ?>>
                                        <?= e($cat['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Thương hiệu / Hãng <span class="required">*</span></label>
                            <select name="brand_id" class="form-control" required style="cursor: pointer;">
                                <?php foreach ($brands as $b): ?>
                                    <option value="<?= $b['id'] ?>" <?= $product['brand_id'] == $b['id'] ? 'selected' : '' ?>>
                                        <?= e($b['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row-2">
                        <div class="form-group">
                            <label class="form-label">Giá niêm yết (VNĐ) <span class="required">*</span></label>
                            <input type="number" name="price" class="form-control" value="<?= (int)$product['price'] ?>" step="1000" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Giá khuyến mãi / Flash Sale (VNĐ)</label>
                            <input type="number" name="sale_price" class="form-control" value="<?= !empty($product['sale_price']) ? (int)$product['sale_price'] : '' ?>" step="1000">
                        </div>
                    </div>
                </div>

                <!-- Hộp 2: Mô tả bài viết -->
                <div class="admin-table-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 800; color: var(--admin-primary); margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--admin-border);">
                        2. Nội Dung Mô Tả Sản Phẩm
                    </h3>

                    <div class="form-group">
                        <label class="form-label">Mô tả ngắn gọn</label>
                        <textarea name="short_description" rows="3" class="form-control"><?= e($product['short_description'] ?? '') ?></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Mô tả chi tiết sản phẩm (Hỗ trợ định dạng HTML)</label>
                        <textarea name="description" rows="8" class="form-control"><?= htmlspecialchars($product['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
                    </div>
                </div>
            </div>

            <!-- CỘT PHẢI: HÌNH ẢNH, THÔNG SỐ & TRẠNG THÁI -->
            <div style="display: flex; flex-direction: column; gap: 20px;">
                <!-- Hộp 3: Hình ảnh -->
                <div class="admin-table-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 800; color: var(--admin-primary); margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--admin-border);">
                        3. Hình Ảnh Sản Phẩm
                    </h3>

                    <!-- Ảnh hiện tại -->
                    <div style="text-align: center; margin-bottom: 16px;">
                        <img src="<?= e($product['thumbnail']) ?>" alt="Ảnh hiện tại" style="max-height: 120px; max-width: 100%; border: 1px solid var(--admin-border); border-radius: 8px; padding: 4px;">
                        <span style="font-size: 11px; color: #64748b; display: block; margin-top: 4px;">Ảnh đại diện hiện tại</span>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Tải ảnh mới thay thế</label>
                        <input type="file" name="thumbnail" accept="image/*" class="form-control">
                    </div>

                    <div class="form-group">
                        <label class="form-label">HOẶC đổi link URL ảnh</label>
                        <input type="url" name="thumbnail_url" class="form-control" value="<?= e($product['thumbnail']) ?>">
                    </div>

                    <!-- Album ảnh phụ hiện có -->
                    <?php if (!empty($productImages)): ?>
                        <div class="form-group">
                            <label class="form-label">Album ảnh phụ hiện có (Bấm để xóa):</label>
                            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                                <?php foreach ($productImages as $pImg): ?>
                                    <div style="position:relative; display:inline-block;">
                                        <img src="<?= e($pImg['image_url']) ?>" style="width:50px; height:50px; object-fit:contain; border:1px solid #e2e8f0; border-radius:4px; padding:2px;">
                                        <a href="<?= APP_URL ?>/admin.php?act=products/edit&id=<?= $product['id'] ?>&del_img=<?= $pImg['id'] ?>" onclick="return confirm('Xóa ảnh này?')" style="position:absolute; top:-6px; right:-6px; background:#ef4444; color:#fff; width:18px; height:18px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:10px; text-decoration:none;">&times;</a>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label class="form-label">Thêm ảnh phụ mới (Mỗi URL một dòng)</label>
                        <textarea name="extra_images" rows="2" class="form-control" placeholder="https://.../anh-1.webp&#10;https://.../anh-2.webp"></textarea>
                    </div>
                </div>

                <!-- Hộp 4: Thông số kỹ thuật -->
                <div class="admin-table-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 800; color: var(--admin-primary); margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--admin-border);">
                        4. Cấu Hình & Thông Số Kỹ Thuật
                    </h3>

                    <div class="form-group">
                        <label class="form-label">RAM</label>
                        <input type="text" name="ram_options" class="form-control" value="<?= e($product['ram_options'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Bộ nhớ trong</label>
                        <input type="text" name="storage_options" class="form-control" value="<?= e($product['storage_options'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Màu sắc</label>
                        <input type="text" name="colors" class="form-control" value="<?= e($product['colors'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Màn hình</label>
                        <input type="text" name="screen" class="form-control" value="<?= e($product['screen'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Camera</label>
                        <input type="text" name="camera" class="form-control" value="<?= e($product['camera'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Pin & Sạc</label>
                        <input type="text" name="battery" class="form-control" value="<?= e($product['battery'] ?? '') ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Thời hạn bảo hành (Tháng)</label>
                        <input type="number" name="warranty_months" class="form-control" value="<?= $product['warranty_months'] ?? 12 ?>">
                    </div>
                </div>

                <!-- Hộp 5: Cài đặt hiển thị -->
                <div class="admin-table-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 800; color: var(--admin-primary); margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--admin-border);">
                        5. Cài Đặt Hiển Thị
                    </h3>

                    <div style="display:flex; flex-direction:column; gap:10px; margin-bottom: 18px;">
                        <label class="custom-checkbox-label">
                            <input type="checkbox" name="is_featured" value="1" <?= $product['is_featured'] ? 'checked' : '' ?>>
                            <span>Sản phẩm Nổi Bật (Trang chủ)</span>
                        </label>
                        <label class="custom-checkbox-label">
                            <input type="checkbox" name="is_hot_deal" value="1" <?= $product['is_hot_deal'] ? 'checked' : '' ?>>
                            <span>Sản phẩm Flash Sale / Giá Sốc</span>
                        </label>
                        <label class="custom-checkbox-label">
                            <input type="checkbox" name="is_new" value="1" <?= $product['is_new'] ? 'checked' : '' ?>>
                            <span>Gắn nhãn Hàng Mới Về</span>
                        </label>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Trạng thái phát hành</label>
                        <select name="status" class="form-control">
                            <option value="active" <?= $product['status'] === 'active' ? 'selected' : '' ?>>Hoạt động (Hiển thị bán)</option>
                            <option value="inactive" <?= $product['status'] === 'inactive' ? 'selected' : '' ?>>Tạm ẩn (Không hiển thị)</option>
                        </select>
                    </div>

                    <button type="submit" class="btn-primary-tech" style="width: 100%; justify-content: center; padding: 12px; margin-top: 10px;">
                        <i class="fa-solid fa-floppy-disk"></i> Lưu Thay Đổi
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

