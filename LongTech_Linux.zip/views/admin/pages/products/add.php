<?php
/**
 * ========================================================
 * LONGTECH - THÊM SẢN PHẨM MỚI (admin/pages/products/add.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="admin-product-form-page">
    <div class="card-header-flex" style="margin-bottom: 20px;">
        <div>
            <h2 style="font-size: 20px; font-weight: 800; color: var(--admin-primary);">
                <i class="fa-solid fa-plus-circle text-secondary"></i> Thêm Sản Phẩm Mới Vào Hệ Thống
            </h2>
            <span style="font-size: 13px; color: #64748b;">Điền đầy đủ thông số kỹ thuật, giá bán và hình ảnh sản phẩm</span>
        </div>
        <a href="<?= APP_URL ?>/admin.php?act=products" class="btn-action-view" style="padding: 9px 16px;">
            <i class="fa-solid fa-arrow-left"></i> Quay lại danh sách
        </a>
    </div>

    <form action="<?= APP_URL ?>/admin.php?act=products/add" method="POST" enctype="multipart/form-data" class="admin-form">
        <?= csrf_field() ?>

        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px; align-items: flex-start;">
            <!-- CỘT TRÁI: THÔNG TIN CHÍNH & MÔ TẢ -->
            <div style="display: flex; flex-direction: column; gap: 20px;">
                <!-- Hộp 1: Thông tin cơ bản -->
                <div class="admin-table-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 800; color: var(--admin-primary); margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--admin-border);">
                        1. Thông Tin Định Danh & Giá Bán
                    </h3>

                    <div class="form-group">
                        <label class="form-label">Tên sản phẩm <span class="required">*</span></label>
                        <input type="text" name="name" class="form-control" placeholder="Ví dụ: iPhone 15 Pro Max 256GB" required autofocus>
                    </div>

                    <div class="form-row-2">
                        <div class="form-group">
                            <label class="form-label">Mã sản phẩm (SKU) <span class="required">*</span></label>
                            <input type="text" name="product_code" class="form-control" placeholder="IP15PM-256" required style="text-transform: uppercase;">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Số lượng tồn kho ban đầu <span class="required">*</span></label>
                            <input type="number" name="stock_quantity" class="form-control" value="20" min="0" required>
                        </div>
                    </div>

                    <div class="form-row-2">
                        <div class="form-group">
                            <label class="form-label">Danh mục sản phẩm <span class="required">*</span></label>
                            <select name="category_id" class="form-control" required style="cursor: pointer;">
                                <option value="">-- Chọn danh mục --</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>"><?= e($cat['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Thương hiệu / Hãng <span class="required">*</span></label>
                            <select name="brand_id" class="form-control" required style="cursor: pointer;">
                                <option value="">-- Chọn thương hiệu --</option>
                                <?php foreach ($brands as $b): ?>
                                    <option value="<?= $b['id'] ?>"><?= e($b['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row-2">
                        <div class="form-group">
                            <label class="form-label">Giá niêm yết (VNĐ) <span class="required">*</span></label>
                            <input type="number" name="price" class="form-control" placeholder="Ví dụ: 34990000" step="1000" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Giá khuyến mãi / Flash Sale (VNĐ)</label>
                            <input type="number" name="sale_price" class="form-control" placeholder="Ví dụ: 29890000 (Để trống nếu không sale)" step="1000">
                        </div>
                    </div>
                </div>

                <!-- Hộp 2: Mô tả bài viết -->
                <div class="admin-table-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 800; color: var(--admin-primary); margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--admin-border);">
                        2. Nội Dung Mô Tả Sản Phẩm
                    </h3>

                    <div class="form-group">
                        <label class="form-label">Mô tả ngắn gọn (Hiển thị đầu trang chi tiết & thẻ sản phẩm)</label>
                        <textarea name="short_description" rows="3" class="form-control" placeholder="Tóm tắt điểm nhấn nổi bật nhất trong 2 - 3 câu..."></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Mô tả chi tiết sản phẩm (Hỗ trợ định dạng HTML)</label>
                        <textarea name="description" rows="8" class="form-control" placeholder="<p>Bài viết đánh giá chuyên sâu về thiết kế, hiệu năng, màn hình và camera của máy...</p>"></textarea>
                    </div>
                </div>
            </div>

            <!-- CỘT PHẢI: HÌNH ẢNH, THÔNG SỐ & TRẠNG THÁI -->
            <div style="display: flex; flex-direction: column; gap: 20px;">
                <!-- Hộp 3: Hình ảnh -->
                <div class="admin-table-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 800; color: var(--admin-primary); margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--admin-border);">
                        3. Hình Ảnh Sản Phẩm
                    </h3>

                    <div class="form-group">
                        <label class="form-label">Tải ảnh đại diện từ máy tính</label>
                        <input type="file" name="thumbnail" accept="image/*" class="form-control">
                        <small style="font-size: 11px; color: #64748b; display:block; margin-top: 4px;">Chấp nhận jpg, png, webp (Tối đa 5MB).</small>
                    </div>

                    <div class="form-group">
                        <label class="form-label">HOẶC nhập đường dẫn URL ảnh chính</label>
                        <input type="url" name="thumbnail_url" class="form-control" placeholder="https://cdn.../anh-san-pham.webp">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Album ảnh phụ (Mỗi URL một dòng)</label>
                        <textarea name="extra_images" rows="3" class="form-control" placeholder="https://.../anh-1.webp&#10;https://.../anh-2.webp"></textarea>
                    </div>
                </div>

                <!-- Hộp 4: Thông số kỹ thuật chi tiết -->
                <div class="admin-table-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 800; color: var(--admin-primary); margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--admin-border);">
                        4. Cấu Hình & Thông Số Kỹ Thuật
                    </h3>

                    <div class="form-group">
                        <label class="form-label">Tùy chọn RAM</label>
                        <input type="text" name="ram_options" class="form-control" placeholder="8GB, 12GB...">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Tùy chọn Bộ nhớ trong</label>
                        <input type="text" name="storage_options" class="form-control" placeholder="128GB, 256GB, 512GB...">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Các phiên bản Màu sắc</label>
                        <input type="text" name="colors" class="form-control" placeholder="Titan Tự Nhiên, Titan Xanh, Đen...">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Màn hình</label>
                        <input type="text" name="screen" class="form-control" placeholder="6.7 inch OLED 120Hz...">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Hệ thống Camera</label>
                        <input type="text" name="camera" class="form-control" placeholder="48MP + 12MP + 12MP...">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Dung lượng Pin & Sạc</label>
                        <input type="text" name="battery" class="form-control" placeholder="4.422 mAh, Sạc nhanh 20W...">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Thời hạn bảo hành (Tháng)</label>
                        <input type="number" name="warranty_months" class="form-control" value="12" min="1">
                    </div>
                </div>

                <!-- Hộp 5: Trạng thái & Nhãn -->
                <div class="admin-table-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 800; color: var(--admin-primary); margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--admin-border);">
                        5. Cài Đặt Hiển Thị
                    </h3>

                    <div style="display:flex; flex-direction:column; gap:10px; margin-bottom: 18px;">
                        <label class="custom-checkbox-label">
                            <input type="checkbox" name="is_featured" value="1" checked>
                            <span>Sản phẩm Nổi Bật (Trang chủ)</span>
                        </label>
                        <label class="custom-checkbox-label">
                            <input type="checkbox" name="is_hot_deal" value="1">
                            <span>Sản phẩm Flash Sale / Giá Sốc</span>
                        </label>
                        <label class="custom-checkbox-label">
                            <input type="checkbox" name="is_new" value="1" checked>
                            <span>Gắn nhãn Hàng Mới Về</span>
                        </label>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Trạng thái phát hành</label>
                        <select name="status" class="form-control">
                            <option value="active">Hoạt động (Hiển thị bán)</option>
                            <option value="inactive">Tạm ẩn (Không hiển thị)</option>
                        </select>
                    </div>

                    <button type="submit" class="btn-primary-tech" style="width: 100%; justify-content: center; padding: 12px; margin-top: 10px;">
                        <i class="fa-solid fa-floppy-disk"></i> Lưu & Đăng Sản Phẩm
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

