<?php
/**
 * ========================================================
 * LONGTECH - VIEW CẤU HÌNH GIAO DIỆN & LIVE EDITOR (admin/pages/appearance/editor.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-wand-magic-sparkles text-primary"></i> Trình Quản Lý Giao Diện & Live Editor</h1>
        <p class="page-subtitle">Tùy biến thương hiệu, bố cục trang chủ dạng kéo thả và quản lý phiên bản giao diện</p>
    </div>
    <div style="display:flex; gap:10px; flex-wrap:wrap;">
        <a href="<?= APP_URL ?>" target="_blank" class="btn btn-secondary">
            <i class="fa-solid fa-arrow-up-right-from-square"></i> Xem Website Ngoài
        </a>
        <button type="button" class="btn btn-primary" onclick="createVersionSnapshot()">
            <i class="fa-solid fa-clock-rotate-left"></i> Tạo Bản Sao Lưu Phiên Bản
        </button>
    </div>
</div>

<?= render_flash_messages() ?>

<!-- THANH ĐIỀU HƯỚNG TABS -->
<div class="admin-card mb-4">
    <div style="display:flex; border-bottom:1px solid #e5e7eb; overflow-x:auto;" id="editorTabs">
        <button class="editor-tab-btn active" onclick="switchTab('tab-general')">
            <i class="fa-solid fa-palette"></i> Thương Hiệu & Màu Sắc
        </button>
        <button class="editor-tab-btn" onclick="switchTab('tab-sections')">
            <i class="fa-solid fa-layer-group"></i> Bố Cục Trang Chủ (Kéo Thả)
        </button>
        <button class="editor-tab-btn" onclick="switchTab('tab-contact')">
            <i class="fa-solid fa-address-book"></i> Thông Tin Liên Hệ & Footer
        </button>
        <button class="editor-tab-btn" onclick="switchTab('tab-seo')">
            <i class="fa-solid fa-magnifying-glass-chart"></i> Cấu Hình SEO & Meta
        </button>
        <button class="editor-tab-btn" onclick="switchTab('tab-versions')">
            <i class="fa-solid fa-history"></i> Lịch Sử Phiên Bản (<?= count($versions) ?>)
        </button>
    </div>
</div>

<!-- NỘI DUNG CÁC TAB -->
<form id="editorForm" onsubmit="saveAllSettings(event)">
    <?= csrf_field() ?>

    <!-- TAB 1: THƯƠNG HIỆU & MÀU SẮC -->
    <div id="tab-general" class="editor-tab-content active">
        <div class="admin-card mb-4">
            <div class="admin-card-header">
                <h3 class="admin-card-title"><i class="fa-solid fa-brush"></i> Nhận Diện Thương Hiệu</h3>
            </div>
            <div class="admin-card-body">
                <div class="row" style="display:flex; gap:20px; flex-wrap:wrap;">
                    <div style="flex:1; min-width:280px;" class="form-group mb-3">
                        <label class="form-label">Tên Website / Thương hiệu</label>
                        <input type="text" name="settings[site_name]" class="form-control" 
                               value="<?= e($settings['site_name'] ?? 'LongTech') ?>" required>
                    </div>
                    <div style="flex:1; min-width:280px;" class="form-group mb-3">
                        <label class="form-label">Logo Chữ (Text Logo)</label>
                        <input type="text" name="settings[site_logo_text]" class="form-control" 
                               value="<?= e($settings['site_logo_text'] ?? 'LONGTECH') ?>" required>
                    </div>
                </div>

                <div class="row" style="display:flex; gap:20px; flex-wrap:wrap;">
                    <div style="flex:1; min-width:200px;" class="form-group mb-3">
                        <label class="form-label">Màu Chủ Đạo (Primary Color)</label>
                        <div style="display:flex; gap:10px; align-items:center;">
                            <input type="color" name="settings[site_primary_color]" id="primaryColorPicker" 
                                   value="<?= e($settings['site_primary_color'] ?? '#D70018') ?>" 
                                   style="width:50px; height:40px; padding:0; border:none; cursor:pointer;"
                                   onchange="document.getElementById('primaryColorText').value = this.value">
                            <input type="text" id="primaryColorText" class="form-control" 
                                   value="<?= e($settings['site_primary_color'] ?? '#D70018') ?>"
                                   onchange="document.getElementById('primaryColorPicker').value = this.value">
                        </div>
                    </div>
                    <div style="flex:1; min-width:200px;" class="form-group mb-3">
                        <label class="form-label">Màu Phụ / Header (Secondary Color)</label>
                        <div style="display:flex; gap:10px; align-items:center;">
                            <input type="color" name="settings[site_secondary_color]" id="secondaryColorPicker" 
                                   value="<?= e($settings['site_secondary_color'] ?? '#0A2540') ?>" 
                                   style="width:50px; height:40px; padding:0; border:none; cursor:pointer;"
                                   onchange="document.getElementById('secondaryColorText').value = this.value">
                            <input type="text" id="secondaryColorText" class="form-control" 
                                   value="<?= e($settings['site_secondary_color'] ?? '#0A2540') ?>"
                                   onchange="document.getElementById('secondaryColorPicker').value = this.value">
                        </div>
                    </div>
                    <div style="flex:1; min-width:200px;" class="form-group mb-3">
                        <label class="form-label">Phông Chữ (Font Family)</label>
                        <select name="settings[site_font]" class="form-control">
                            <?php $currFont = $settings['site_font'] ?? 'Inter'; ?>
                            <option value="Inter" <?= $currFont === 'Inter' ? 'selected' : '' ?>>Inter (Chuẩn hiện đại)</option>
                            <option value="Roboto" <?= $currFont === 'Roboto' ? 'selected' : '' ?>>Roboto (Google Fonts)</option>
                            <option value="Segoe UI" <?= $currFont === 'Segoe UI' ? 'selected' : '' ?>>Segoe UI (Hệ thống)</option>
                            <option value="Montserrat" <?= $currFont === 'Montserrat' ? 'selected' : '' ?>>Montserrat (Thanh lịch)</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- TAB 2: BỐ CỤC TRANG CHỦ -->
    <div id="tab-sections" class="editor-tab-content">
        <div class="admin-card mb-4">
            <div class="admin-card-header">
                <div>
                    <h3 class="admin-card-title"><i class="fa-solid fa-arrows-up-down"></i> Sắp Xếp & Ẩn/Hiện Các Khối Trang Chủ</h3>
                    <p class="admin-card-subtitle" style="font-size:0.88rem; color:#6b7280; margin-top:4px;">
                        Kéo thả hoặc dùng mũi tên để đổi thứ tự xuất hiện các phân đoạn trên trang chủ website
                    </p>
                </div>
                <button type="button" class="btn btn-sm btn-primary" onclick="saveSectionsLayout()">
                    <i class="fa-solid fa-floppy-disk"></i> Lưu Thứ Tự Khối
                </button>
            </div>
            <div class="admin-card-body">
                <div id="sectionList" style="display:flex; flex-direction:column; gap:10px;">
                    <?php foreach ($sections as $index => $sec): ?>
                    <div class="section-drag-item" data-key="<?= e($sec['section_key']) ?>" 
                         style="display:flex; align-items:center; justify-content:space-between; padding:14px 18px; background:#f9fafb; border:1px solid #e5e7eb; border-radius:8px;">
                        <div style="display:flex; align-items:center; gap:15px;">
                            <span class="drag-handle" style="cursor:grab; color:#9ca3af; font-size:1.1rem;"><i class="fa-solid fa-grip-vertical"></i></span>
                            <span class="badge badge-secondary" style="font-size:0.9rem;"><?= $index + 1 ?></span>
                            <div>
                                <strong><?= e($sec['title']) ?></strong>
                                <small style="display:block; color:#6b7280; font-family:monospace;">key: <?= e($sec['section_key']) ?></small>
                            </div>
                        </div>
                        <div style="display:flex; align-items:center; gap:15px;">
                            <label style="display:flex; align-items:center; gap:6px; cursor:pointer; font-size:0.95rem;">
                                <input type="checkbox" class="section-visible-check" <?= !empty($sec['is_visible']) ? 'checked' : '' ?> style="width:18px; height:18px;">
                                <span>Hiển thị</span>
                            </label>
                            <div style="display:flex; gap:4px;">
                                <button type="button" class="btn btn-sm btn-secondary" onclick="moveSection(this, -1)" title="Lên trên"><i class="fa-solid fa-arrow-up"></i></button>
                                <button type="button" class="btn btn-sm btn-secondary" onclick="moveSection(this, 1)" title="Xuống dưới"><i class="fa-solid fa-arrow-down"></i></button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- TAB 3: LIÊN HỆ & FOOTER -->
    <div id="tab-contact" class="editor-tab-content">
        <div class="admin-card mb-4">
            <div class="admin-card-header">
                <h3 class="admin-card-title"><i class="fa-solid fa-phone"></i> Thông Tin Liên Hệ Cửa Hàng</h3>
            </div>
            <div class="admin-card-body">
                <div class="row" style="display:flex; gap:20px; flex-wrap:wrap;">
                    <div style="flex:1; min-width:250px;" class="form-group mb-3">
                        <label class="form-label">Hotline Chăm Sóc Khách Hàng</label>
                        <input type="text" name="settings[hotline]" class="form-control" 
                               value="<?= e($settings['hotline'] ?? '1900 6868') ?>">
                    </div>
                    <div style="flex:1; min-width:250px;" class="form-group mb-3">
                        <label class="form-label">Email Hỗ Trợ Kỹ Thuật</label>
                        <input type="email" name="settings[contact_email]" class="form-control" 
                               value="<?= e($settings['contact_email'] ?? 'support@longtech.vn') ?>">
                    </div>
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Địa Chỉ Trụ Sở Cửa Hàng</label>
                    <input type="text" name="settings[store_address]" class="form-control" 
                           value="<?= e($settings['store_address'] ?? 'Số 123 Đường Công Nghệ, Cầu Giấy, Hà Nội') ?>">
                </div>

                <div class="row" style="display:flex; gap:20px; flex-wrap:wrap;">
                    <div style="flex:1; min-width:250px;" class="form-group mb-3">
                        <label class="form-label">Đường Dẫn Facebook</label>
                        <input type="url" name="settings[facebook_url]" class="form-control" 
                               value="<?= e($settings['facebook_url'] ?? 'https://facebook.com/longtech') ?>">
                    </div>
                    <div style="flex:1; min-width:250px;" class="form-group mb-3">
                        <label class="form-label">Đường Dẫn Kênh Youtube</label>
                        <input type="url" name="settings[youtube_url]" class="form-control" 
                               value="<?= e($settings['youtube_url'] ?? 'https://youtube.com/longtech') ?>">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- TAB 4: CẤU HÌNH SEO -->
    <div id="tab-seo" class="editor-tab-content">
        <div class="admin-card mb-4">
            <div class="admin-card-header">
                <h3 class="admin-card-title"><i class="fa-solid fa-chart-line"></i> Tối Ưu Hóa Tìm Kiếm (SEO Google)</h3>
            </div>
            <div class="admin-card-body">
                <div class="form-group mb-3">
                    <label class="form-label">Tiêu Đề Trang Chủ (SEO Title)</label>
                    <input type="text" name="settings[seo_title]" class="form-control" 
                           value="<?= e($settings['seo_title'] ?? '') ?>" placeholder="Tối đa 70 ký tự">
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Mô Tả Trang Chủ (SEO Meta Description)</label>
                    <textarea name="settings[seo_description]" class="form-control" rows="3" placeholder="Tối đa 160 ký tự"><?= e($settings['seo_description'] ?? '') ?></textarea>
                </div>

                <div class="form-group mb-3">
                    <label class="form-label">Từ Khóa Chính (SEO Keywords)</label>
                    <input type="text" name="settings[seo_keywords]" class="form-control" 
                           value="<?= e($settings['seo_keywords'] ?? '') ?>" placeholder="dien thoai, laptop, phu kien...">
                </div>
            </div>
        </div>
    </div>

    <!-- NÚT LƯU CỐ ĐỊNH PHÍA DƯỚI -->
    <div class="mt-4" style="display:flex; gap:12px; align-items:center;">
        <button type="submit" class="btn btn-primary" id="btnSaveGeneral">
            <i class="fa-solid fa-floppy-disk"></i> Xuất Bản Cấu Hình
        </button>
        <button type="button" class="btn btn-secondary" onclick="window.location.reload()">
            <i class="fa-solid fa-rotate-left"></i> Hoàn Tác
        </button>
    </div>
</form>

<!-- TAB 5: LỊCH SỬ PHIÊN BẢN -->
<div id="tab-versions" class="editor-tab-content">
    <div class="admin-card mb-4">
        <div class="admin-card-header">
            <h3 class="admin-card-title"><i class="fa-solid fa-clock-rotate-left"></i> Danh Sách Bản Lưu Lịch Sử</h3>
        </div>
        <div class="admin-card-body">
            <?php if (empty($versions)): ?>
                <div style="text-align:center; padding:30px; color:#9ca3af;">
                    <i class="fa-solid fa-box-archive" style="font-size:2.5rem; margin-bottom:10px;"></i>
                    <p>Chưa có bản lưu phiên bản nào. Hãy bấm nút "Tạo Bản Sao Lưu Phiên Bản" để lưu lại trạng thái giao diện hiện tại.</p>
                </div>
            <?php else: ?>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Mã Bản Lưu</th>
                            <th>Tên Phiên Bản</th>
                            <th>Người Tạo</th>
                            <th>Thời Gian Lưu</th>
                            <th>Thao Tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($versions as $ver): ?>
                        <tr>
                            <td><strong>#<?= $ver['id'] ?></strong></td>
                            <td><strong><?= e($ver['version_name']) ?></strong></td>
                            <td><?= e($ver['creator_name'] ?? 'Quản trị viên') ?></td>
                            <td><?= date('d/m/Y H:i:s', strtotime($ver['created_at'])) ?></td>
                            <td>
                                <button type="button" class="btn btn-sm btn-primary" onclick="restoreVersion(<?= $ver['id'] ?>, '<?= e($ver['version_name']) ?>')">
                                    <i class="fa-solid fa-clock-rotate-left"></i> Khôi Phục
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.editor-tab-btn {
    padding: 14px 22px;
    background: transparent;
    border: none;
    border-bottom: 3px solid transparent;
    font-size: 0.95rem;
    font-weight: 600;
    color: #64748b;
    cursor: pointer;
    transition: all 0.2s;
    white-space: nowrap;
}
.editor-tab-btn:hover { color: #D70018; }
.editor-tab-btn.active {
    color: #D70018;
    border-bottom-color: #D70018;
    background: rgba(215, 0, 24, 0.03);
}
.editor-tab-content { display: none; }
.editor-tab-content.active { display: block; }
</style>

<script>
function switchTab(tabId) {
    document.querySelectorAll('.editor-tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.editor-tab-content').forEach(tab => tab.classList.remove('active'));
    
    event.currentTarget.classList.add('active');
    document.getElementById(tabId).classList.add('active');
}

function moveSection(btn, direction) {
    const item = btn.closest('.section-drag-item');
    if (direction === -1 && item.previousElementSibling) {
        item.parentNode.insertBefore(item, item.previousElementSibling);
    } else if (direction === 1 && item.nextElementSibling) {
        item.parentNode.insertBefore(item.nextElementSibling, item);
    }
    updateSectionBadges();
}

function updateSectionBadges() {
    const items = document.querySelectorAll('#sectionList .section-drag-item');
    items.forEach((item, index) => {
        const badge = item.querySelector('.badge');
        if (badge) badge.innerText = index + 1;
    });
}

function saveSectionsLayout() {
    const items = document.querySelectorAll('#sectionList .section-drag-item');
    const sections = [];
    items.forEach((item, index) => {
        sections.push({
            section_key: item.getAttribute('data-key'),
            sort_order: index + 1,
            is_visible: item.querySelector('.section-visible-check').checked ? 1 : 0
        });
    });

    const formData = new FormData();
    formData.append('csrf_token', '<?= csrf_token() ?>');
    formData.append('sections', JSON.stringify(sections));

    fetch('<?= APP_URL ?>/admin.php?act=appearance/save-sections', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status) {
            showToast(data.message, 'success');
        } else {
            showToast(data.message || 'Lỗi khi lưu bố cục', 'error');
        }
    })
    .catch(() => showToast('Không thể kết nối đến máy chủ', 'error'));
}

function saveAllSettings(e) {
    e.preventDefault();
    const form = document.getElementById('editorForm');
    const formData = new FormData(form);

    fetch('<?= APP_URL ?>/admin.php?act=appearance/save-settings', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status) {
            showToast(data.message, 'success');
        } else {
            showToast(data.message || 'Lỗi khi lưu cài đặt', 'error');
        }
    })
    .catch(() => showToast('Không thể kết nối máy chủ', 'error'));
}

function createVersionSnapshot() {
    const name = prompt('Nhập tên hoặc ghi chú cho bản sao lưu phiên bản này:', 'Bản cập nhật ngày ' + new Date().toLocaleDateString('vi-VN'));
    if (!name) return;

    const formData = new FormData();
    formData.append('csrf_token', '<?= csrf_token() ?>');
    formData.append('version_name', name);

    fetch('<?= APP_URL ?>/admin.php?act=appearance/create-version', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status) {
            showToast(data.message, 'success');
            setTimeout(() => window.location.reload(), 1000);
        } else {
            showToast(data.message || 'Lỗi lưu bản sao lưu', 'error');
        }
    });
}

function restoreVersion(versionId, versionName) {
    if (!confirm('Bạn có chắc chắn muốn khôi phục lại toàn bộ cài đặt từ: ' + versionName + '?')) {
        return;
    }
    const formData = new FormData();
    formData.append('csrf_token', '<?= csrf_token() ?>');
    formData.append('version_id', versionId);

    fetch('<?= APP_URL ?>/admin.php?act=appearance/restore-version', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status) {
            showToast(data.message, 'success');
            setTimeout(() => window.location.reload(), 1200);
        } else {
            showToast(data.message || 'Lỗi khôi phục', 'error');
        }
    });
}
</script>

