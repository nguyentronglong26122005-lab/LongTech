<?php
/**
 * ========================================================
 * LONGTECH - VIEW SOẠN THẢO / SỬA BÀI VIẾT (admin/pages/posts/add-edit.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
$isEdit = !empty($post);
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title">
            <i class="fa-solid fa-newspaper text-primary"></i> <?= $isEdit ? 'Sửa Bài Viết #' . e($post['id']) : 'Viết Bài Mới' ?>
        </h1>
        <p class="page-subtitle">Soạn thảo nội dung tin tức, bài viết chuẩn SEO và hình ảnh</p>
    </div>
    <div>
        <a href="<?= APP_URL ?>/admin.php?act=posts" class="btn btn-secondary">
            <i class="fa-solid fa-arrow-left"></i> Quay lại danh sách
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<div class="admin-card">
    <div class="admin-card-body">
        <form method="POST" action="<?= APP_URL ?>/admin.php?act=posts/add-edit<?= $isEdit ? '&id=' . $post['id'] : '' ?>" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <div class="form-group mb-3">
                <label class="form-label" for="title">Tiêu Đề Bài Viết <span class="text-danger">*</span></label>
                <input type="text" id="title" name="title" class="form-control" required
                       value="<?= e($post['title'] ?? '') ?>" placeholder="Tiêu đề bài viết...">
            </div>

            <div class="form-group mb-3">
                <label class="form-label" for="slug">Đường Dẫn URL Thân Thiện (Slug)</label>
                <input type="text" id="slug" name="slug" class="form-control"
                       value="<?= e($post['slug'] ?? '') ?>" placeholder="Để trống hệ thống sẽ tự động tạo từ tiêu đề">
            </div>

            <div class="form-group mb-3">
                <label class="form-label" for="summary">Tóm Tắt Ngắn (Mô tả hiển thị danh sách)</label>
                <textarea id="summary" name="summary" class="form-control" rows="3" placeholder="Đoạn trích tóm tắt bài viết..."><?= e($post['summary'] ?? '') ?></textarea>
            </div>

            <div class="form-group mb-3">
                <label class="form-label" for="content">Nội Dung Chi Tiết</label>
                <textarea id="content" name="content" class="form-control" rows="12" placeholder="Nội dung bài viết chi tiết..."><?= e($post['content'] ?? '') ?></textarea>
            </div>

            <div class="row" style="display: flex; gap: 15px; flex-wrap: wrap;">
                <div class="form-group mb-3" style="flex: 2; min-width: 280px;">
                    <label class="form-label">Ảnh Bìa Bài Viết (Thumbnail)</label>
                    <div style="display: flex; gap: 15px; align-items: flex-start;">
                        <?php if (!empty($post['thumbnail'])): ?>
                            <img src="<?= e($post['thumbnail']) ?>" alt="Thumbnail" style="max-width: 140px; height: auto; border-radius: 4px; border: 1px solid #ddd;">
                        <?php endif; ?>
                        <div style="flex: 1;">
                            <input type="file" name="thumbnail_file" class="form-control mb-2" accept="image/*">
                            <input type="text" name="thumbnail" class="form-control" placeholder="Hoặc nhập liên kết URL ảnh..." value="<?= e($post['thumbnail'] ?? '') ?>">
                        </div>
                    </div>
                </div>

                <div class="form-group mb-3" style="flex: 1; min-width: 180px;">
                    <label class="form-label" for="status">Trạng Thái Xuất Bản</label>
                    <select name="status" id="status" class="form-control">
                        <option value="published" <?= ($post['status'] ?? 'published') === 'published' ? 'selected' : '' ?>>Xuất bản ngay (Published)</option>
                        <option value="draft" <?= ($post['status'] ?? '') === 'draft' ? 'selected' : '' ?>>Lưu nháp (Draft)</option>
                    </select>
                </div>
            </div>

            <div class="mt-4" style="display: flex; gap: 10px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> <?= $isEdit ? 'Cập Nhật Bài Viết' : 'Lưu & Đăng Bài' ?>
                </button>
                <a href="<?= APP_URL ?>/admin.php?act=posts" class="btn btn-secondary">Hủy bỏ</a>
            </div>
        </form>
    </div>
</div>

