<?php
/**
 * ========================================================
 * LONGTECH - VIEW DANH SÁCH BÀI VIẾT (admin/pages/posts/list.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-newspaper text-primary"></i> Quản Lý Bài Viết & Tin Tức</h1>
        <p class="page-subtitle">Tin tức công nghệ, đánh giá thiết bị và bài viết hướng dẫn</p>
    </div>
    <div>
        <a href="<?= APP_URL ?>/admin.php?act=posts/add-edit" class="btn btn-primary">
            <i class="fa-solid fa-plus"></i> Viết Bài Mới
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<!-- BỘ LỌC TÌM KIẾM -->
<div class="admin-card mb-4">
    <div class="admin-card-body" style="padding:16px 20px;">
        <form method="GET" action="<?= APP_URL ?>/admin.php" style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;">
            <input type="hidden" name="act" value="posts">
            <div style="flex:2;min-width:200px;">
                <input type="text" name="search" class="form-control" placeholder="🔍 Tìm kiếm bài viết..."
                       value="<?= e($search ?? '') ?>">
            </div>
            <div style="min-width:160px;">
                <select name="status" class="form-control">
                    <option value="">-- Tất cả trạng thái --</option>
                    <option value="published" <?= ($status??'')==='published' ? 'selected' : '' ?>>Đã xuất bản (Published)</option>
                    <option value="draft" <?= ($status??'')==='draft' ? 'selected' : '' ?>>Bản nháp (Draft)</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-filter"></i> Lọc</button>
            <a href="<?= APP_URL ?>/admin.php?act=posts" class="btn btn-secondary">Đặt lại</a>
        </form>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <h3 class="admin-card-title">
            <i class="fa-solid fa-list"></i> Danh Sách Bài Viết
            <span class="badge badge-primary"><?= $totalItems ?? count($posts) ?></span>
        </h3>
    </div>
    <div class="admin-card-body">
        <?php if (empty($posts)): ?>
            <div style="text-align:center;padding:40px;color:#9ca3af;">
                <i class="fa-solid fa-file-pen" style="font-size:3rem;margin-bottom:12px;display:block;"></i>
                <p>Chưa có bài viết nào. <a href="<?= APP_URL ?>/admin.php?act=posts/add-edit">Tạo bài đầu tiên!</a></p>
            </div>
        <?php else: ?>
        <div style="overflow-x:auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width:60px;">ID</th>
                        <th style="width:90px;">Ảnh bìa</th>
                        <th>Tiêu Đề</th>
                        <th>Tác Giả</th>
                        <th style="width:120px;">Trạng Thái</th>
                        <th style="width:130px;">Ngày Đăng</th>
                        <th style="width:130px;">Thao Tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($posts as $post): ?>
                    <tr>
                        <td><strong>#<?= e($post['id']) ?></strong></td>
                        <td>
                            <?php if (!empty($post['thumbnail'])): ?>
                                <img src="<?= e($post['thumbnail']) ?>" alt="thumbnail"
                                     style="width:70px;height:45px;object-fit:cover;border-radius:4px;border:1px solid #ddd;">
                            <?php else: ?>
                                <div style="width:70px;height:45px;background:#f3f4f6;border-radius:4px;display:flex;align-items:center;justify-content:center;">
                                    <i class="fa-solid fa-image" style="color:#9ca3af;"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= e($post['title']) ?></strong>
                            <?php if (!empty($post['summary'])): ?>
                                <br><small class="text-muted"><?= e(truncate_words($post['summary'], 10)) ?></small>
                            <?php endif; ?>
                        </td>
                        <td><?= e($post['author_name'] ?? 'Quản trị viên') ?></td>
                        <td>
                            <?php if (($post['status'] ?? '') === 'published'): ?>
                                <span class="badge badge-success">Đã xuất bản</span>
                            <?php else: ?>
                                <span class="badge badge-warning">Bản nháp</span>
                            <?php endif; ?>
                        </td>
                        <td><small><?= date('d/m/Y H:i', strtotime($post['created_at'])) ?></small></td>
                        <td>
                            <a href="<?= APP_URL ?>/admin.php?act=posts/add-edit&id=<?= $post['id'] ?>" class="btn btn-sm btn-primary" title="Sửa">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </a>
                            <form method="POST" action="<?= APP_URL ?>/admin.php?act=posts/delete" style="display:inline;">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= $post['id'] ?>">
                                <button type="button" class="btn btn-sm btn-danger" title="Xóa"
                                        onclick="confirmAdminDelete(this.closest('form'), '<?= e($post['title']) ?>')">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <?= $pagination ?? '' ?>
    </div>
</div>

