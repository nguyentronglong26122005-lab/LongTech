<?php
/**
 * ========================================================
 * LONGTECH - TRANG TỔNG QUAN ADMIN (admin/pages/dashboard.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="admin-dashboard-page">
    <!-- 1. BỐN THẺ CHỈ SỐ KPI KINH DOANH -->
    <div class="kpi-cards-grid">
        <!-- KPI 1: Doanh Thu -->
        <div class="kpi-card">
            <div class="kpi-icon icon-revenue"><i class="fa-solid fa-sack-dollar"></i></div>
            <div class="kpi-data">
                <span class="kpi-title">Tổng Doanh Thu</span>
                <span class="kpi-value text-success"><?= format_money($totalRevenue) ?></span>
                <span class="kpi-subtext"><i class="fa-solid fa-arrow-trend-up text-success"></i> Tăng trưởng bán lẻ ổn định</span>
            </div>
        </div>

        <!-- KPI 2: Đơn Hàng -->
        <div class="kpi-card">
            <div class="kpi-icon icon-orders"><i class="fa-solid fa-cart-shopping"></i></div>
            <div class="kpi-data">
                <span class="kpi-title">Tổng Đơn Hàng</span>
                <span class="kpi-value text-primary"><?= number_format($totalOrders) ?></span>
                <span class="kpi-subtext">Đơn đặt từ website</span>
            </div>
        </div>

        <!-- KPI 3: Sản Phẩm -->
        <div class="kpi-card">
            <div class="kpi-icon icon-products"><i class="fa-solid fa-mobile-screen"></i></div>
            <div class="kpi-data">
                <span class="kpi-title">Tổng Sản Phẩm</span>
                <span class="kpi-value" style="color:var(--admin-secondary);"><?= number_format($totalProducts) ?></span>
                <span class="kpi-subtext">Đang kinh doanh hoạt động</span>
            </div>
        </div>

        <!-- KPI 4: Khách Hàng -->
        <div class="kpi-card">
            <div class="kpi-icon icon-users"><i class="fa-solid fa-users"></i></div>
            <div class="kpi-data">
                <span class="kpi-title">Khách Hàng</span>
                <span class="kpi-value" style="color:#7c3aed;"><?= number_format($totalCustomers) ?></span>
                <span class="kpi-subtext">Tài khoản thành viên</span>
            </div>
        </div>
    </div>

    <!-- 2. HÀNG GIỮA: BIỂU ĐỒ DOANH THU & CẢNH BÁO TỒN KHO -->
    <div class="dashboard-middle-grid">
        <!-- Biểu đồ doanh thu 12 tháng -->
        <div class="chart-card">
            <div class="card-header-flex">
                <h3><i class="fa-solid fa-chart-line text-secondary"></i> Biểu Đồ Doanh Thu 12 Tháng (Năm <?= date('Y') ?>)</h3>
                <span style="font-size:12px;color:#64748b;">Đơn vị: VNĐ</span>
            </div>
            <div class="chart-canvas-wrap">
                <canvas id="revenueChart"></canvas>
            </div>
        </div>

        <!-- Cảnh báo tồn kho sắp hết (Ngưỡng tồn <= 5) -->
        <div class="alert-stock-card">
            <div class="card-header-flex">
                <h3><i class="fa-solid fa-triangle-exclamation text-danger"></i> Cảnh Báo Sắp Hết Hàng</h3>
                <span class="stock-warning-badge">Tồn kho &le; 5</span>
            </div>
            <div class="low-stock-list">
                <?php if (!empty($lowStockProducts)): ?>
                    <?php foreach ($lowStockProducts as $prod): ?>
                        <div class="low-stock-item">
                            <img src="<?= e($prod['thumbnail']) ?>" alt="<?= e($prod['name']) ?>" class="low-stock-thumb">
                            <div class="low-stock-info">
                                <h5 class="low-stock-name">
                                    <a href="<?= APP_URL ?>/admin.php?act=products/edit&id=<?= $prod['id'] ?>" target="_blank"><?= e($prod['name']) ?></a>
                                </h5>
                                <span class="low-stock-count"><i class="fa-solid fa-box-open"></i> Chỉ còn: <strong><?= $prod['stock_quantity'] ?></strong> máy</span>
                            </div>
                            <a href="<?= APP_URL ?>/admin.php?act=products/edit&id=<?= $prod['id'] ?>" class="btn-action-view" title="Cập nhật tồn kho">
                                <i class="fa-solid fa-pen-to-square"></i> Nhập kho
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="font-size:13px;color:#64748b;text-align:center;padding:30px 0;">
                        <i class="fa-solid fa-circle-check text-success" style="font-size:24px;display:block;margin-bottom:8px;"></i>
                        Tất cả sản phẩm trong kho đều có số lượng tồn an toàn (&gt; 5).
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 3. DANH SÁCH ĐƠN HÀNG MỚI CẦN XỬ LÝ -->
    <div class="admin-table-card">
        <div class="card-header-flex">
            <h3><i class="fa-solid fa-clock-rotate-left text-primary"></i> Đơn Hàng Mới Nhất</h3>
            <a href="<?= APP_URL ?>/admin.php?act=orders" class="btn-action-view" style="font-weight:700;">
                Xem tất cả đơn hàng <i class="fa-solid fa-angle-right"></i>
            </a>
        </div>

        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Mã Đơn</th>
                        <th>Khách Hàng</th>
                        <th>Số Điện Thoại</th>
                        <th>Ngày Đặt</th>
                        <th>Tổng Tiền</th>
                        <th>Phương Thức</th>
                        <th>Trạng Thái</th>
                        <th>Hành Động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($recentOrders)): ?>
                        <?php foreach ($recentOrders as $order): ?>
                            <tr>
                                <td><strong class="text-primary"><?= e($order['order_code']) ?></strong></td>
                                <td><strong><?= e($order['customer_name']) ?></strong></td>
                                <td><?= e($order['customer_phone']) ?></td>
                                <td><?= date('d/m/Y H:i', strtotime($order['created_at'])) ?></td>
                                <td><strong class="text-danger"><?= format_money($order['total_amount']) ?></strong></td>
                                <td>
                                    <span style="font-size:11px;font-weight:700;padding:2px 6px;background:#f1f5f9;border-radius:4px;">
                                        <?= strtoupper($order['payment_method']) ?>
                                    </span>
                                </td>
                                <td>
                                    <?php
                                        $statusClassMap = [
                                            'pending'    => 'status-pending',
                                            'confirmed'  => 'status-confirmed',
                                            'processing' => 'status-processing',
                                            'shipping'   => 'status-shipping',
                                            'completed'  => 'status-completed',
                                            'cancelled'  => 'status-cancelled',
                                            'refunded'   => 'status-refunded'
                                        ];
                                        $statusNameMap = [
                                            'pending'    => 'Chờ xác nhận',
                                            'confirmed'  => 'Đã xác nhận',
                                            'processing' => 'Đang xử lý',
                                            'shipping'   => 'Đang giao',
                                            'completed'  => 'Hoàn thành',
                                            'cancelled'  => 'Đã hủy',
                                            'refunded'   => 'Hoàn tiền'
                                        ];
                                        $stClass = $statusClassMap[$order['status']] ?? 'status-pending';
                                        $stName = $statusNameMap[$order['status']] ?? $order['status'];
                                    ?>
                                    <span class="badge-status <?= $stClass ?>"><?= $stName ?></span>
                                </td>
                                <td>
                                    <a href="<?= APP_URL ?>/admin.php?act=orders/detail&id=<?= $order['id'] ?>" class="btn-action-view">
                                        <i class="fa-solid fa-eye"></i> Xem & Duyệt
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align:center;padding:30px;color:#64748b;">
                                Chưa có đơn hàng nào phát sinh trên hệ thống.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Nạp dữ liệu vào biến toàn cục JS để Chart.js vẽ biểu đồ -->
<script>
    window.adminChartLabels = <?= json_encode($chartLabels) ?>;
    window.adminChartData = <?= json_encode($chartData) ?>;
</script>

