<?php
/**
 * ========================================================
 * LONGTECH - VIEW QUẢN LÝ LIÊN HỆ & GÓP Ý (admin/pages/contacts/list.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-envelope-open-text text-primary"></i> Quản Lý Phản Hồi & Liên Hệ</h1>
        <p class="page-subtitle">Tin nhắn liên hệ, yêu cầu báo giá và phản hồi của khách hàng gửi từ website</p>
    </div>
    <div>
        <a href="<?= APP_URL ?>/admin.php?act=contacts/export-csv" class="btn btn-secondary">
            <i class="fa-solid fa-file-csv"></i> Xuất CSV
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<!-- BỘ LỌC TÌM KIẾM -->
<div class="admin-card mb-4">
    <div class="admin-card-body" style="padding:16px 20px;">
        <form method="GET" action="<?= APP_URL ?>/admin.php" style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;">
            <input type="hidden" name="act" value="contacts">
            <div style="flex:2;min-width:200px;">
                <input type="text" name="search" class="form-control" placeholder="🔍 Tìm theo tên, email, tiêu đề..."
                       value="<?= e($search ?? '') ?>">
            </div>
            <div style="min-width:160px;">
                <select name="status" class="form-control">
                    <option value="">-- Tất cả trạng thái --</option>
                    <option value="unread" <?= ($status??'')==='unread' ? 'selected' : '' ?>>Chưa đọc (<?= (int)($counts['unread'] ?? 0) ?>)</option>
                    <option value="read" <?= ($status??'')==='read' ? 'selected' : '' ?>>Đã xem (<?= (int)($counts['read'] ?? 0) ?>)</option>
                    <option value="replied" <?= ($status??'')==='replied' ? 'selected' : '' ?>>Đã phản hồi (<?= (int)($counts['replied'] ?? 0) ?>)</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-filter"></i> Lọc</button>
            <a href="<?= APP_URL ?>/admin.php?act=contacts" class="btn btn-secondary">Đặt lại</a>
        </form>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <h3 class="admin-card-title">
            <i class="fa-solid fa-inbox"></i> Danh Sách Thư Liên Hệ
            <span class="badge badge-primary"><?= $totalItems ?? count($contacts) ?></span>
        </h3>
    </div>
    <div class="admin-card-body">
        <?php if (empty($contacts)): ?>
            <div style="text-align:center;padding:40px;color:#9ca3af;">
                <i class="fa-regular fa-envelope-open" style="font-size:3rem;margin-bottom:12px;display:block;"></i>
                <p>Không có thông điệp hoặc phản hồi nào.</p>
            </div>
        <?php else: ?>
        <div style="overflow-x:auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width:60px;">ID</th>
                        <th>Họ & Tên</th>
                        <th>Thông Tin Liên Hệ</th>
                        <th>Chủ Đề & Nội Dung</th>
                        <th style="width:120px;">Trạng Thái</th>
                        <th style="width:130px;">Ngày Gửi</th>
                        <th style="width:130px;">Thao Tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($contacts as $contact): ?>
                    <tr style="<?= $contact['status'] === 'unread' ? 'background: rgba(215, 0, 24, 0.03); font-weight: 500;' : '' ?>">
                        <td><strong>#<?= e($contact['id']) ?></strong></td>
                        <td><strong><?= e($contact['full_name']) ?></strong></td>
                        <td>
                            <i class="fa-regular fa-envelope"></i> <?= e($contact['email']) ?><br>
                            <?php if (!empty($contact['phone'])): ?>
                                <small><i class="fa-solid fa-phone"></i> <?= e($contact['phone']) ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= e($contact['subject']) ?></strong>
                            <div style="color: #6b7280; font-size: 0.9rem; margin-top: 4px; max-width: 320px; word-break: break-word;">
                                <?= nl2br(e($contact['message'])) ?>
                            </div>
                        </td>
                        <td>
                            <?php if ($contact['status'] === 'unread'): ?>
                                <span class="badge badge-danger">Chưa đọc</span>
                            <?php elseif ($contact['status'] === 'replied'): ?>
                                <span class="badge badge-success">Đã phản hồi</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">Đã đọc</span>
                            <?php endif; ?>
                        </td>
                        <td><small><?= date('d/m/Y H:i', strtotime($contact['created_at'])) ?></small></td>
                        <td>
                            <div style="display: flex; gap: 5px;">
                                <?php if ($contact['status'] === 'unread'): ?>
                                <form method="POST" action="<?= APP_URL ?>/admin.php?act=contacts/mark-read" style="display:inline;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= $contact['id'] ?>">
                                    <input type="hidden" name="new_status" value="read">
                                    <button type="submit" class="btn btn-sm btn-primary" title="Đánh dấu đã đọc">
                                        <i class="fa-regular fa-eye"></i>
                                    </button>
                                </form>
                                <?php endif; ?>

                                <?php if ($contact['status'] !== 'replied'): ?>
                                <form method="POST" action="<?= APP_URL ?>/admin.php?act=contacts/mark-read" style="display:inline;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= $contact['id'] ?>">
                                    <input type="hidden" name="new_status" value="replied">
                                    <button type="submit" class="btn btn-sm btn-success" title="Đánh dấu đã phản hồi">
                                        <i class="fa-solid fa-reply"></i>
                                    </button>
                                </form>
                                <?php endif; ?>

                                <form method="POST" action="<?= APP_URL ?>/admin.php?act=contacts/delete" style="display:inline;">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= $contact['id'] ?>">
                                    <button type="button" class="btn btn-sm btn-danger" title="Xóa"
                                            onclick="confirmAdminDelete(this.closest('form'), 'Thư từ <?= e($contact['full_name']) ?>')">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <?= $pagination ?? '' ?>
    </div>
</div>

