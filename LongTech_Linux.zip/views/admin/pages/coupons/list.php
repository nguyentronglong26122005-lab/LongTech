<?php
/**
 * ========================================================
 * LONGTECH - VIEW DANH SÁCH MÃ GIẢM GIÁ (admin/pages/coupons/list.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-ticket text-primary"></i> Quản Lý Mã Giảm Giá</h1>
        <p class="page-subtitle">Tạo và kiểm soát các mã khuyến mãi, voucher giảm giá cho đơn hàng</p>
    </div>
    <div>
        <a href="<?= APP_URL ?>/admin.php?act=coupons/add-edit" class="btn btn-primary">
            <i class="fa-solid fa-plus"></i> Tạo Mã Khuyến Mãi
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<div class="admin-card">
    <div class="admin-card-header">
        <h3 class="admin-card-title">
            <i class="fa-solid fa-list"></i> Danh sách Voucher
            <span class="badge badge-primary"><?= count($coupons) ?></span>
        </h3>
    </div>
    <div class="admin-card-body">
        <?php if (empty($coupons)): ?>
            <div style="text-align:center;padding:40px;color:#9ca3af;">
                <i class="fa-solid fa-ticket-simple" style="font-size:3rem;margin-bottom:12px;display:block;"></i>
                <p>Chưa có mã giảm giá nào. <a href="<?= APP_URL ?>/admin.php?act=coupons/add-edit">Tạo mã đầu tiên!</a></p>
            </div>
        <?php else: ?>
        <div style="overflow-x:auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Mã Code</th>
                        <th>Loại Giảm</th>
                        <th>Giá Trị</th>
                        <th>Đơn Tối Thiểu</th>
                        <th>Lượt Dùng</th>
                        <th>Thời Hạn</th>
                        <th>Trạng Thái</th>
                        <th>Thao Tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($coupons as $coupon): ?>
                    <tr>
                        <td>
                            <strong style="color: var(--primary-color, #d70018); letter-spacing: 1px; font-family: monospace; font-size: 1.05rem;">
                                <?= e($coupon['code']) ?>
                            </strong>
                        </td>
                        <td>
                            <?= ($coupon['type'] ?? '') === 'percentage' ? 'Phần trăm (%)' : 'Cố định (VNĐ)' ?>
                        </td>
                        <td>
                            <strong>
                                <?= ($coupon['type'] ?? '') === 'percentage' 
                                    ? ((float)$coupon['value']) . '%' 
                                    : format_money($coupon['value']) ?>
                            </strong>
                            <?php if (($coupon['type'] ?? '') === 'percentage' && !empty($coupon['max_discount'])): ?>
                                <br><small class="text-muted">(Tối đa <?= format_money($coupon['max_discount']) ?>)</small>
                            <?php endif; ?>
                        </td>
                        <td><?= format_money($coupon['min_order_value'] ?? 0) ?></td>
                        <td>
                            <?= (int)($coupon['used_count'] ?? 0) ?> / <?= !empty($coupon['usage_limit']) ? (int)$coupon['usage_limit'] : '∞' ?>
                        </td>
                        <td>
                            <small>
                                Từ: <?= !empty($coupon['start_date']) ? date('d/m/Y', strtotime($coupon['start_date'])) : 'Ngay' ?><br>
                                Đến: <?= !empty($coupon['end_date']) ? date('d/m/Y', strtotime($coupon['end_date'])) : 'Vô hạn' ?>
                            </small>
                        </td>
                        <td>
                            <?php if (($coupon['status'] ?? 'inactive') === 'active'): ?>
                                <span class="badge badge-success">Hoạt động</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Tạm khóa</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?= APP_URL ?>/admin.php?act=coupons/add-edit&id=<?= $coupon['id'] ?>" class="btn btn-sm btn-primary" title="Sửa">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </a>
                            <form method="POST" action="<?= APP_URL ?>/admin.php?act=coupons/delete" style="display:inline;">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= $coupon['id'] ?>">
                                <button type="button" class="btn btn-sm btn-danger" title="Xóa"
                                        onclick="confirmAdminDelete(this.closest('form'), 'Mã <?= e($coupon['code']) ?>')">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

