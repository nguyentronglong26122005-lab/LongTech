<?php
/**
 * ========================================================
 * LONGTECH - VIEW THÊM / SỬA MÃ GIẢM GIÁ (admin/pages/coupons/add-edit.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
$isEdit = !empty($coupon);
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title">
            <i class="fa-solid fa-ticket text-primary"></i> <?= $isEdit ? 'Sửa Mã Giảm Giá #' . e($coupon['code']) : 'Tạo Mã Giảm Giá Mới' ?>
        </h1>
        <p class="page-subtitle">Thiết lập điều kiện áp dụng, hạn sử dụng và mức giảm</p>
    </div>
    <div>
        <a href="<?= APP_URL ?>/admin.php?act=coupons" class="btn btn-secondary">
            <i class="fa-solid fa-arrow-left"></i> Quay lại danh sách
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<div class="admin-card">
    <div class="admin-card-body">
        <form method="POST" action="<?= APP_URL ?>/admin.php?act=coupons/add-edit<?= $isEdit ? '&id=' . $coupon['id'] : '' ?>">
            <?= csrf_field() ?>

            <div class="row" style="display: flex; gap: 15px; flex-wrap: wrap;">
                <div class="form-group mb-3" style="flex: 1; min-width: 250px;">
                    <label class="form-label" for="code">Mã Khuyến Mãi (Code) <span class="text-danger">*</span></label>
                    <input type="text" id="code" name="code" class="form-control" style="text-transform: uppercase;" required
                           value="<?= e($coupon['code'] ?? '') ?>" placeholder="VD: SALE2026, FREESHIP">
                </div>

                <div class="form-group mb-3" style="flex: 1; min-width: 200px;">
                    <label class="form-label" for="type">Loại Giảm Giá</label>
                    <select name="type" id="type" class="form-control">
                        <option value="percentage" <?= ($coupon['type'] ?? '') === 'percentage' ? 'selected' : '' ?>>Giảm theo phần trăm (%)</option>
                        <option value="fixed_amount" <?= ($coupon['type'] ?? '') === 'fixed_amount' ? 'selected' : '' ?>>Giảm số tiền cố định (VNĐ)</option>
                    </select>
                </div>

                <div class="form-group mb-3" style="flex: 1; min-width: 200px;">
                    <label class="form-label" for="value">Giá Trị Giảm <span class="text-danger">*</span></label>
                    <input type="number" step="any" id="value" name="value" class="form-control" required
                           value="<?= e($coupon['value'] ?? '') ?>" placeholder="VD: 10 (cho 10%) hoặc 50000 (cho 50k)">
                </div>
            </div>

            <div class="row" style="display: flex; gap: 15px; flex-wrap: wrap;">
                <div class="form-group mb-3" style="flex: 1; min-width: 200px;">
                    <label class="form-label" for="min_order_value">Giá Trị Đơn Hàng Tối Thiểu (VNĐ)</label>
                    <input type="number" id="min_order_value" name="min_order_value" class="form-control"
                           value="<?= e($coupon['min_order_value'] ?? 0) ?>">
                </div>

                <div class="form-group mb-3" style="flex: 1; min-width: 200px;">
                    <label class="form-label" for="max_discount">Giảm Tối Đa (VNĐ - Cho loại %)</label>
                    <input type="number" id="max_discount" name="max_discount" class="form-control"
                           value="<?= e($coupon['max_discount'] ?? '') ?>" placeholder="Để trống nếu không giới hạn">
                </div>

                <div class="form-group mb-3" style="flex: 1; min-width: 200px;">
                    <label class="form-label" for="usage_limit">Giới Hạn Lượt Dùng Toàn Hệ Thống</label>
                    <input type="number" id="usage_limit" name="usage_limit" class="form-control"
                           value="<?= e($coupon['usage_limit'] ?? '') ?>" placeholder="Để trống nếu không giới hạn">
                </div>
            </div>

            <div class="row" style="display: flex; gap: 15px; flex-wrap: wrap;">
                <div class="form-group mb-3" style="flex: 1; min-width: 200px;">
                    <label class="form-label" for="start_date">Ngày Bắt Đầu Áp Dụng</label>
                    <input type="date" id="start_date" name="start_date" class="form-control"
                           value="<?= !empty($coupon['start_date']) ? date('Y-m-d', strtotime($coupon['start_date'])) : '' ?>">
                </div>

                <div class="form-group mb-3" style="flex: 1; min-width: 200px;">
                    <label class="form-label" for="end_date">Ngày Hết Hạn</label>
                    <input type="date" id="end_date" name="end_date" class="form-control"
                           value="<?= !empty($coupon['end_date']) ? date('Y-m-d', strtotime($coupon['end_date'])) : '' ?>">
                </div>

                <div class="form-group mb-3" style="flex: 1; min-width: 200px;">
                    <label class="form-label" for="status">Trạng Thái</label>
                    <select name="status" id="status" class="form-control">
                        <option value="active" <?= ($coupon['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>Kích hoạt (Active)</option>
                        <option value="inactive" <?= ($coupon['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>Vô hiệu hóa (Inactive)</option>
                    </select>
                </div>
            </div>

            <div class="mt-4" style="display: flex; gap: 10px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> <?= $isEdit ? 'Lưu Cập Nhật' : 'Tạo Mã Giảm Giá' ?>
                </button>
                <a href="<?= APP_URL ?>/admin.php?act=coupons" class="btn btn-secondary">Hủy bỏ</a>
            </div>
        </form>
    </div>
</div>

