<?php
/**
 * ========================================================
 * LONGTECH - VIEW THÊM THÀNH VIÊN MỚI TINH GỌN (admin/pages/users/add.php)
 * Chỉ gồm: Tài khoản + Mật khẩu + Tích chọn Vai trò chức năng
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
$allPermissions = get_all_permissions_list();
$postedPerms = isset($_POST['permissions']) && is_array($_POST['permissions']) ? $_POST['permissions'] : ['manage_products'];
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-user-plus text-primary"></i> Thêm Thành Viên Mới</h1>
        <p class="page-subtitle">Tạo nhanh tài khoản nhân viên: chỉ cần nhập Tài khoản, Mật khẩu và tích chọn Vai trò chức năng</p>
    </div>
    <div>
        <a href="<?= APP_URL ?>/admin.php?act=users" class="btn btn-secondary">
            <i class="fa-solid fa-arrow-left"></i> Quay lại danh sách
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<div class="admin-card" style="max-width: 780px;">
    <div class="admin-card-body" style="padding: 26px;">
        <!-- Thông báo cơ chế phê duyệt -->
        <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-left: 4px solid #2563eb; border-radius: 10px; padding: 12px 16px; margin-bottom: 22px; color: #1e3a8a; font-size: 13.5px; line-height: 1.5;">
            <i class="fa-solid fa-shield-check text-primary"></i>
            <strong>Cơ chế Kiểm duyệt tự động:</strong> Khi thành viên được cấp vai trò thực hiện các thao tác (thêm/sửa/xóa sản phẩm, duyệt đơn hàng, cập nhật nội dung...), hệ thống sẽ <strong>gửi yêu cầu lên Admin</strong>. Ngay khi Admin bấm <strong>Duyệt</strong>, thay đổi mới được áp dụng lập tức trên website.
        </div>

        <form method="POST" action="<?= APP_URL ?>/admin.php?act=users/add">
            <?= csrf_field() ?>

            <!-- 1. TÀI KHOẢN & 2. MẬT KHẨU -->
            <div class="row" style="display:flex; gap:20px; flex-wrap:wrap; margin-bottom: 10px;">
                <div class="form-group mb-3" style="flex:1; min-width:250px;">
                    <label class="form-label" for="username" style="font-weight: 700; font-size: 14px;">
                        1. Tài Khoản (Tên Đăng Nhập) <span class="text-danger">*</span>
                    </label>
                    <input type="text" id="username" name="username" class="form-control" required autofocus
                           placeholder="Nhập tài khoản (VD: nvkho01, nvbanhang...)" value="<?= e($_POST['username'] ?? '') ?>">
                </div>

                <div class="form-group mb-3" style="flex:1; min-width:250px;">
                    <label class="form-label" for="password" style="font-weight: 700; font-size: 14px;">
                        2. Mật Khẩu <span class="text-danger">*</span>
                    </label>
                    <input type="password" id="password" name="password" class="form-control" required
                           placeholder="Nhập mật khẩu đăng nhập...">
                </div>
            </div>

            <!-- 3. TÍCH CHỌN VAI TRÒ / CHỨC NĂNG -->
            <div class="form-group mb-4" style="background: #f8fafc; border: 1.5px solid #cbd5e1; border-radius: 12px; padding: 18px 20px;">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 14px;">
                    <div>
                        <label class="form-label" style="font-size: 14.5px; font-weight: 700; color: #0f172a; margin-bottom: 2px; display: block;">
                            3. Tích Chọn Vai Trò Đảm Nhận <span class="text-danger">*</span>
                        </label>
                        <small style="color: #475569;">Có thể tích chọn <strong>1 hoặc nhiều vai trò</strong> cho cùng 1 người:</small>
                    </div>
                    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                        <button type="button" class="btn btn-sm btn-secondary" style="font-size: 12px; padding: 4px 10px;" onclick="selectPreset(['manage_products', 'manage_users'])">
                            <i class="fa-solid fa-bolt text-warning"></i> Kho + Tài khoản
                        </button>
                        <button type="button" class="btn btn-sm btn-secondary" style="font-size: 12px; padding: 4px 10px;" onclick="selectAllPerms(true)">
                            Tích tất cả
                        </button>
                        <button type="button" class="btn btn-sm btn-secondary" style="font-size: 12px; padding: 4px 10px;" onclick="selectAllPerms(false)">
                            Bỏ chọn
                        </button>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(290px, 1fr)); gap: 12px;">
                    <?php foreach ($allPermissions as $permKey => $permInfo): ?>
                        <?php $isChecked = in_array($permKey, $postedPerms, true); ?>
                        <label class="perm-card-item" style="display: flex; align-items: flex-start; gap: 12px; background: <?= $isChecked ? '#eff6ff' : '#fff' ?>; border: 1.5px solid <?= $isChecked ? '#2563eb' : '#e2e8f0' ?>; border-radius: 10px; padding: 12px 14px; cursor: pointer; transition: all 0.2s;">
                            <input type="checkbox" name="permissions[]" value="<?= e($permKey) ?>" class="perm-checkbox"
                                   <?= $isChecked ? 'checked' : '' ?>
                                   onchange="updatePermCardStyle(this)"
                                   style="width: 19px; height: 19px; margin-top: 2px; accent-color: #2563eb; flex-shrink: 0;">
                            <div>
                                <div style="font-weight: 700; font-size: 13.5px; color: #0f172a; display: flex; align-items: center; gap: 6px;">
                                    <i class="fa-solid <?= e($permInfo['icon']) ?>" style="color: <?= e($permInfo['color']) ?>;"></i>
                                    <?= e($permInfo['label']) ?>
                                </div>
                                <?php if (!empty($permInfo['dept'])): ?>
                                    <div style="font-size: 11px; font-weight: 600; color: <?= e($permInfo['color']) ?>; margin-top: 1px;">
                                        <i class="fa-solid fa-sitemap"></i> Thuộc: <?= e($permInfo['dept']) ?>
                                    </div>
                                <?php endif; ?>
                                <div style="font-size: 12px; color: #64748b; margin-top: 3px; line-height: 1.4;">
                                    <?= e($permInfo['desc']) ?>
                                </div>
                            </div>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="mt-4" style="display:flex; gap:10px;">
                <button type="submit" class="btn btn-primary" style="padding: 10px 22px; font-size: 14px;">
                    <i class="fa-solid fa-user-plus"></i> Tạo Tài Khoản Ngay
                </button>
                <a href="<?= APP_URL ?>/admin.php?act=users" class="btn btn-secondary">Hủy bỏ</a>
            </div>
        </form>
    </div>
</div>

<script>
function updatePermCardStyle(checkbox) {
    const card = checkbox.closest('.perm-card-item');
    if (!card) return;
    card.style.borderColor = checkbox.checked ? '#2563eb' : '#e2e8f0';
    card.style.background = checkbox.checked ? '#eff6ff' : '#ffffff';
}

function selectAllPerms(check) {
    document.querySelectorAll('.perm-checkbox').forEach(cb => {
        cb.checked = check;
        updatePermCardStyle(cb);
    });
}

function selectPreset(keys) {
    document.querySelectorAll('.perm-checkbox').forEach(cb => {
        cb.checked = keys.includes(cb.value);
        updatePermCardStyle(cb);
    });
}
</script>
