<?php
/**
 * ========================================================
 * LONGTECH - VIEW THÊM THÀNH VIÊN MỚI (admin/pages/users/add.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
$currentUserRole = current_role();
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-user-plus text-primary"></i> Thêm Thành Viên Mới</h1>
        <p class="page-subtitle">Khởi tạo tài khoản nhân viên hoặc khách hàng và phân quyền truy cập hệ thống</p>
    </div>
    <div>
        <a href="<?= APP_URL ?>/admin.php?act=users" class="btn btn-secondary">
            <i class="fa-solid fa-arrow-left"></i> Quay lại danh sách
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<div class="admin-card">
    <div class="admin-card-body">
        <form method="POST" action="<?= APP_URL ?>/admin.php?act=users/add">
            <?= csrf_field() ?>

            <div class="row" style="display:flex; gap:20px; flex-wrap:wrap;">
                <div class="form-group mb-3" style="flex:1; min-width:250px;">
                    <label class="form-label" for="username">Tên Đăng Nhập (Username) <span class="text-danger">*</span></label>
                    <input type="text" id="username" name="username" class="form-control" required
                           placeholder="Ví dụ: nvsanpham3, ketoan01..." value="<?= e($_POST['username'] ?? '') ?>">
                    <small class="form-text text-muted">Chỉ chứa chữ cái, số, không dấu và không dấu cách.</small>
                </div>

                <div class="form-group mb-3" style="flex:1; min-width:250px;">
                    <label class="form-label" for="email">Địa Chỉ Email <span class="text-danger">*</span></label>
                    <input type="email" id="email" name="email" class="form-control" required
                           placeholder="Ví dụ: nhanvien@longtech.vn" value="<?= e($_POST['email'] ?? '') ?>">
                </div>
            </div>

            <div class="row" style="display:flex; gap:20px; flex-wrap:wrap;">
                <div class="form-group mb-3" style="flex:1; min-width:250px;">
                    <label class="form-label" for="password">Mật Khẩu Khởi Tạo <span class="text-danger">*</span></label>
                    <input type="password" id="password" name="password" class="form-control" required
                           placeholder="Tối thiểu 6 ký tự...">
                </div>

                <div class="form-group mb-3" style="flex:1; min-width:250px;">
                    <label class="form-label" for="role_id">Vai Trò & Quyền Hạn <span class="text-danger">*</span></label>
                    <select name="role_id" id="role_id" class="form-control" required>
                        <?php foreach ($roles as $r): ?>
                            <?php 
                            // Nếu không phải super_admin thì không được tạo tài khoản super_admin
                            if ($r['name'] === 'super_admin' && $currentUserRole !== 'super_admin') {
                                continue;
                            }
                            ?>
                            <option value="<?= $r['id'] ?>" <?= ($r['name'] === 'customer') ? 'selected' : '' ?>>
                                <?= e($r['display_name']) ?> (<?= e($r['name']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="row" style="display:flex; gap:20px; flex-wrap:wrap;">
                <div class="form-group mb-3" style="flex:1; min-width:250px;">
                    <label class="form-label" for="full_name">Họ & Tên Đầy Đủ <span class="text-danger">*</span></label>
                    <input type="text" id="full_name" name="full_name" class="form-control" required
                           placeholder="Ví dụ: Nguyễn Văn An" value="<?= e($_POST['full_name'] ?? '') ?>">
                </div>

                <div class="form-group mb-3" style="flex:1; min-width:250px;">
                    <label class="form-label" for="phone">Số Điện Thoại</label>
                    <input type="text" id="phone" name="phone" class="form-control"
                           placeholder="Ví dụ: 0987654321" value="<?= e($_POST['phone'] ?? '') ?>">
                </div>
            </div>

            <div class="form-group mb-3">
                <label class="form-label" for="address">Địa Chỉ</label>
                <input type="text" id="address" name="address" class="form-control"
                       placeholder="Ví dụ: Số 123 Cầu Giấy, Hà Nội" value="<?= e($_POST['address'] ?? '') ?>">
            </div>

            <div class="form-group mb-3">
                <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                    <input type="checkbox" name="require_password_change" value="1" checked style="width:18px; height:18px;">
                    <span>Bắt buộc người dùng phải đổi mật khẩu ở lần đầu đăng nhập</span>
                </label>
            </div>

            <div class="mt-4" style="display:flex; gap:10px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-user-plus"></i> Khởi Tạo Tài Khoản
                </button>
                <a href="<?= APP_URL ?>/admin.php?act=users" class="btn btn-secondary">Hủy bỏ</a>
            </div>
        </form>
    </div>
</div>

