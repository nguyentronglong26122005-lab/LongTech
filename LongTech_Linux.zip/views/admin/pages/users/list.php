<?php
/**
 * ========================================================
 * LONGTECH - VIEW QUẢN LÝ THÀNH VIÊN & PHÂN QUYỀN (admin/pages/users/list.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

$currentUserId = (int)($_SESSION['user']['id'] ?? 0);
$currentUserRole = current_role();
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-users-gear text-primary"></i> Quản Lý Thành Viên & Phân Quyền</h1>
        <p class="page-subtitle">Kiểm soát danh sách thành viên và phân quyền 5 vai trò chuẩn bảo mật hệ thống</p>
    </div>
    <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
        <a href="<?= APP_URL ?>/admin.php?act=users/add" class="btn btn-primary">
            <i class="fa-solid fa-user-plus"></i> Thêm Thành Viên Mới
        </a>
        <a href="<?= APP_URL ?>/admin.php?act=users/export" class="btn btn-secondary">
            <i class="fa-solid fa-file-csv"></i> Xuất CSV
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<!-- BỘ LỌC TÌM KIẾM THÀNH VIÊN -->
<div class="admin-card mb-4">
    <div class="admin-card-body" style="padding: 16px 20px;">
        <form action="<?= APP_URL ?>/admin.php" method="GET" style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
            <input type="hidden" name="act" value="users">

            <div style="flex: 2; min-width: 220px;">
                <input type="text" name="keyword" class="form-control" 
                       placeholder="Nhập tên đăng nhập, họ tên, email hoặc SĐT..." 
                       value="<?= e($keyword) ?>">
            </div>

            <div style="flex: 1; min-width: 170px;">
                <select name="role" class="form-control">
                    <option value="">-- Tất cả vai trò --</option>
                    <?php foreach ($roles as $r): ?>
                        <option value="<?= e($r['name']) ?>" <?= ($roleFilter === $r['name']) ? 'selected' : '' ?>>
                            <?= e($r['display_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="flex: 1; min-width: 150px;">
                <select name="status" class="form-control">
                    <option value="">-- Tất cả trạng thái --</option>
                    <option value="active" <?= ($statusFilter === 'active') ? 'selected' : '' ?>>Đang hoạt động</option>
                    <option value="locked" <?= ($statusFilter === 'locked') ? 'selected' : '' ?>>Đã bị khóa</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-filter"></i> Lọc Dữ Liệu
            </button>

            <?php if (!empty($keyword) || !empty($roleFilter) || !empty($statusFilter)): ?>
                <a href="<?= APP_URL ?>/admin.php?act=users" class="btn btn-secondary">
                    <i class="fa-solid fa-rotate-left"></i> Xóa Lọc
                </a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- BẢNG DANH SÁCH THÀNH VIÊN -->
<div class="admin-card">
    <div class="admin-card-header">
        <div class="card-title">
            <span>Danh Sách Tài Khoản</span>
            <span class="badge badge-info" style="margin-left: 8px;"><?= count($users) ?> thành viên</span>
        </div>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width: 70px;">ID</th>
                        <th>Thông Tin Thành Viên</th>
                        <th>Liên Hệ</th>
                        <th>Vai Trò Phân Quyền</th>
                        <th style="text-align: center;">Đơn Hàng</th>
                        <th style="text-align: center;">Trạng Thái</th>
                        <th style="text-align: right; width: 220px;">Hành Động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($users)): ?>
                        <tr>
                            <td colspan="7" class="text-center" style="padding: 40px; color: #64748b;">
                                <i class="fa-solid fa-user-slash" style="font-size: 32px; margin-bottom: 10px; display: block;"></i>
                                Không tìm thấy thành viên nào phù hợp với điều kiện tìm kiếm.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($users as $u): ?>
                            <?php 
                            $isSelf = ($u['id'] == $currentUserId); 
                            $isTargetSuperAdmin = ($u['role_id'] == 1);
                            $canManageThisUser = ($currentUserRole === 'super_admin' || !$isTargetSuperAdmin);
                            ?>
                            <tr>
                                <td><strong>#<?= $u['id'] ?></strong></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 12px;">
                                        <div style="width: 40px; height: 40px; border-radius: 50%; background: #0A2540; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 15px; flex-shrink: 0;">
                                            <?= strtoupper(substr($u['full_name'] ?: $u['username'], 0, 1)) ?>
                                        </div>
                                        <div>
                                            <div style="font-weight: 600; color: #0f172a;">
                                                <?= e($u['full_name']) ?>
                                                <?php if ($isSelf): ?>
                                                    <span class="badge badge-info" style="font-size: 10px; margin-left: 4px;">Bạn</span>
                                                <?php endif; ?>
                                            </div>
                                            <small style="color: #64748b;">@<?= e($u['username']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div style="font-size: 13px; color: #334155;">
                                        <i class="fa-solid fa-envelope" style="width: 16px; color: #94a3b8;"></i> <?= e($u['email']) ?>
                                    </div>
                                    <?php if (!empty($u['phone'])): ?>
                                        <div style="font-size: 12px; color: #64748b; margin-top: 2px;">
                                            <i class="fa-solid fa-phone" style="width: 16px; color: #94a3b8;"></i> <?= e($u['phone']) ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <!-- FORM ĐỔI VAI TRÒ NHANH -->
                                    <?php if ($canManageThisUser && !$isSelf): ?>
                                        <form action="<?= APP_URL ?>/admin.php?act=users/change-role" method="POST" style="display: flex; gap: 6px; align-items: center;">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                            <select name="role_id" class="form-control" style="font-size: 12px; padding: 4px 8px; height: auto;" onchange="this.form.submit()">
                                                <?php foreach ($roles as $r): ?>
                                                    <?php 
                                                    // Chỉ Super Admin mới được gán quyền Super Admin
                                                    if ($r['id'] == 1 && $currentUserRole !== 'super_admin') continue; 
                                                    ?>
                                                    <option value="<?= $r['id'] ?>" <?= ($u['role_id'] == $r['id']) ? 'selected' : '' ?>>
                                                        <?= e($r['display_name']) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </form>
                                    <?php else: ?>
                                        <?php
                                        $roleBadgeClass = match($u['role_id']) {
                                            1 => 'badge-danger',
                                            2 => 'badge-primary',
                                            3 => 'badge-info',
                                            4 => 'badge-warning',
                                            default => 'badge-secondary'
                                        };
                                        ?>
                                        <span class="badge <?= $roleBadgeClass ?>" style="font-size: 12px;">
                                            <?= e($u['role_display'] ?? 'Khách hàng') ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: center;">
                                    <span class="badge badge-secondary" style="font-size: 12px;">
                                        <?= (int)($u['total_orders'] ?? 0) ?> đơn
                                    </span>
                                </td>
                                <td style="text-align: center;">
                                    <?php if ($u['status'] === 'active'): ?>
                                        <span class="badge badge-success"><i class="fa-solid fa-check"></i> Hoạt động</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger"><i class="fa-solid fa-lock"></i> Đã bị khóa</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: right;">
                                    <div style="display: flex; gap: 6px; justify-content: flex-end; align-items: center;">
                                        <?php if ($isSelf): ?>
                                            <span style="font-size: 12px; color: #94a3b8; font-style: italic;">(Tài khoản hiện tại)</span>
                                        <?php elseif (!$canManageThisUser): ?>
                                            <span style="font-size: 12px; color: #94a3b8; font-style: italic;">(Bảo vệ cấp cao)</span>
                                        <?php else: ?>
                                            <?php if ($u['status'] === 'active'): ?>
                                                <a href="<?= APP_URL ?>/admin.php?act=users/toggle&id=<?= $u['id'] ?>" 
                                                   class="btn btn-sm btn-danger" 
                                                   style="padding: 5px 10px; font-size: 12px;"
                                                   onclick="return confirm('Bạn có chắc chắn muốn KHÓA tài khoản &quot;<?= addslashes($u['username']) ?>&quot;?\nTài khoản này sẽ không thể đăng nhập vào hệ thống nữa.');">
                                                    <i class="fa-solid fa-lock"></i> Khóa Nick
                                                </a>
                                            <?php else: ?>
                                                <a href="<?= APP_URL ?>/admin.php?act=users/toggle&id=<?= $u['id'] ?>" 
                                                   class="btn btn-sm btn-success" 
                                                   style="padding: 5px 10px; font-size: 12px;"
                                                   onclick="return confirm('Mở khóa cho tài khoản &quot;<?= addslashes($u['username']) ?>&quot;?');">
                                                    <i class="fa-solid fa-lock-open"></i> Mở Khóa
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

