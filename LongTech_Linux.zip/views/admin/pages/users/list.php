<?php
/**
 * ========================================================
 * LONGTECH - VIEW QUẢN LÝ THÀNH VIÊN & PHÂN QUYỀN ĐA CHỨC NĂNG (admin/pages/users/list.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

$currentUserId = (int)($_SESSION['user']['id'] ?? 0);
$currentUserRole = current_role();
$allPermissions = get_all_permissions_list();
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-users-gear text-primary"></i> Quản Lý Thành Viên & Phân Quyền Đa Chức Năng</h1>
        <p class="page-subtitle">Cấp quyền linh hoạt: 1 nhân viên có thể kiêm nhiệm nhiều chức năng (Kho hàng, Đơn hàng, Tài khoản, Marketing, Giao diện)</p>
    </div>
    <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
        <a href="<?= APP_URL ?>/admin.php?act=users/add" class="btn btn-primary">
            <i class="fa-solid fa-user-plus"></i> Thêm Thành Viên Mới
        </a>
        <a href="<?= APP_URL ?>/admin.php?act=users/export" class="btn btn-secondary">
            <i class="fa-solid fa-file-csv"></i> Xuất CSV
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<!-- BỘ LỌC TÌM KIẾM THÀNH VIÊN -->
<div class="admin-card mb-4">
    <div class="admin-card-body" style="padding: 16px 20px;">
        <form action="<?= APP_URL ?>/admin.php" method="GET" style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
            <input type="hidden" name="act" value="users">

            <div style="flex: 2; min-width: 220px;">
                <input type="text" name="keyword" class="form-control" 
                       placeholder="Nhập tên đăng nhập, họ tên, email hoặc SĐT..." 
                       value="<?= e($keyword) ?>">
            </div>

            <div style="flex: 1; min-width: 170px;">
                <select name="role" class="form-control">
                    <option value="">-- Tất cả vai trò --</option>
                    <?php foreach ($roles as $r): ?>
                        <option value="<?= e($r['name']) ?>" <?= ($roleFilter === $r['name']) ? 'selected' : '' ?>>
                            <?= e($r['display_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="flex: 1; min-width: 150px;">
                <select name="status" class="form-control">
                    <option value="">-- Tất cả trạng thái --</option>
                    <option value="active" <?= ($statusFilter === 'active') ? 'selected' : '' ?>>Đang hoạt động</option>
                    <option value="locked" <?= ($statusFilter === 'locked') ? 'selected' : '' ?>>Đã bị khóa</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-filter"></i> Lọc Dữ Liệu
            </button>

            <?php if (!empty($keyword) || !empty($roleFilter) || !empty($statusFilter)): ?>
                <a href="<?= APP_URL ?>/admin.php?act=users" class="btn btn-secondary">
                    <i class="fa-solid fa-rotate-left"></i> Xóa Lọc
                </a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- BẢNG DANH SÁCH THÀNH VIÊN -->
<div class="admin-card">
    <div class="admin-card-header">
        <div class="card-title">
            <span>Danh Sách Tài Khoản & Quyền Chức Năng</span>
            <span class="badge badge-info" style="margin-left: 8px;"><?= count($users) ?> thành viên</span>
        </div>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width: 60px;">ID</th>
                        <th>Thông Tin Thành Viên</th>
                        <th>Liên Hệ</th>
                        <th style="min-width: 280px;">Vai Trò & Các Chức Năng Đảm Nhận</th>
                        <th style="text-align: center;">Đơn Hàng</th>
                        <th style="text-align: center;">Trạng Thái</th>
                        <th style="text-align: right; width: 230px;">Hành Động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($users)): ?>
                        <tr>
                            <td colspan="7" class="text-center" style="padding: 40px; color: #64748b;">
                                <i class="fa-solid fa-user-slash" style="font-size: 32px; margin-bottom: 10px; display: block;"></i>
                                Không tìm thấy thành viên nào phù hợp với điều kiện tìm kiếm.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($users as $u): ?>
                            <?php 
                            $isSelf = ($u['id'] == $currentUserId); 
                            $isTargetSuperAdmin = ($u['role_id'] == 1);
                            $canManageThisUser = ($currentUserRole === 'super_admin' || !$isTargetSuperAdmin);
                            $userPerms = get_user_permissions($u);
                            $roleBadgeClass = match((int)$u['role_id']) {
                                1 => 'badge-danger',
                                2 => 'badge-primary',
                                3 => 'badge-info',
                                4 => 'badge-warning',
                                default => 'badge-secondary'
                            };
                            ?>
                            <tr>
                                <td><strong>#<?= $u['id'] ?></strong></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 12px;">
                                        <div style="width: 40px; height: 40px; border-radius: 50%; background: #0A2540; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 15px; flex-shrink: 0;">
                                            <?= strtoupper(substr($u['full_name'] ?: $u['username'], 0, 1)) ?>
                                        </div>
                                        <div>
                                            <div style="font-weight: 600; color: #0f172a;">
                                                <?= e($u['full_name']) ?>
                                                <?php if ($isSelf): ?>
                                                    <span class="badge badge-info" style="font-size: 10px; margin-left: 4px;">Bạn</span>
                                                <?php endif; ?>
                                            </div>
                                            <small style="color: #64748b;">@<?= e($u['username']) ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div style="font-size: 13px; color: #334155;">
                                        <i class="fa-solid fa-envelope" style="width: 16px; color: #94a3b8;"></i> <?= e($u['email']) ?>
                                    </div>
                                    <?php if (!empty($u['phone'])): ?>
                                        <div style="font-size: 12px; color: #64748b; margin-top: 2px;">
                                            <i class="fa-solid fa-phone" style="width: 16px; color: #94a3b8;"></i> <?= e($u['phone']) ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div style="margin-bottom: 6px; display: flex; align-items: center; gap: 6px; flex-wrap: wrap;">
                                        <span class="badge <?= $roleBadgeClass ?>" style="font-size: 11.5px;">
                                            <?= e($u['role_display'] ?? 'Khách hàng') ?>
                                        </span>
                                        <?php if ($canManageThisUser && !$isSelf): ?>
                                            <button type="button" class="btn btn-sm btn-secondary"
                                                    style="padding: 2px 8px; font-size: 11px; border-color: #cbd5e1;"
                                                    onclick='openPermModal(<?= (int)$u["id"] ?>, <?= json_encode($u["full_name"] ?: $u["username"]) ?>, <?= (int)$u["role_id"] ?>, <?= json_encode(array_values($userPerms)) ?>)'>
                                                <i class="fa-solid fa-sliders text-primary"></i> Chọn chức năng
                                            </button>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Hiển thị các badge chức năng được cấp -->
                                    <?php if ((int)$u['role_id'] === 1): ?>
                                        <div style="font-size: 11.5px; color: #dc2626; font-weight: 600;">
                                            <i class="fa-solid fa-crown"></i> Toàn quyền quản trị tối cao (Tất cả chức năng)
                                        </div>
                                    <?php elseif (!empty($userPerms)): ?>
                                        <div style="display: flex; flex-wrap: wrap; gap: 4px;">
                                            <?php foreach ($userPerms as $pk): ?>
                                                <?php if (isset($allPermissions[$pk])): ?>
                                                    <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 11px; padding: 2px 8px; border-radius: 99px; background: #f1f5f9; color: #1e293b; border: 1px solid #cbd5e1; font-weight: 500;">
                                                        <i class="fa-solid <?= e($allPermissions[$pk]['icon']) ?>" style="color: <?= e($allPermissions[$pk]['color']) ?>;"></i>
                                                        <?= e($allPermissions[$pk]['label']) ?>
                                                    </span>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <small style="color: #94a3b8;">Khách mua hàng (Không có quyền Admin)</small>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: center;">
                                    <span class="badge badge-secondary" style="font-size: 12px;">
                                        <?= (int)($u['total_orders'] ?? 0) ?> đơn
                                    </span>
                                </td>
                                <td style="text-align: center;">
                                    <?php if ($u['status'] === 'active'): ?>
                                        <span class="badge badge-success"><i class="fa-solid fa-check"></i> Hoạt động</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger"><i class="fa-solid fa-lock"></i> Đã bị khóa</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: right;">
                                    <div style="display: flex; gap: 6px; justify-content: flex-end; align-items: center; flex-wrap: wrap;">
                                        <?php if ($isSelf): ?>
                                            <span style="font-size: 12px; color: #94a3b8; font-style: italic;">(Tài khoản hiện tại)</span>
                                        <?php elseif (!$canManageThisUser): ?>
                                            <span style="font-size: 12px; color: #94a3b8; font-style: italic;">(Bảo vệ cấp cao)</span>
                                        <?php else: ?>
                                            <button type="button" class="btn btn-sm btn-primary"
                                                    style="padding: 5px 10px; font-size: 12px;"
                                                    onclick='openPermModal(<?= (int)$u["id"] ?>, <?= json_encode($u["full_name"] ?: $u["username"]) ?>, <?= (int)$u["role_id"] ?>, <?= json_encode(array_values($userPerms)) ?>)'>
                                                <i class="fa-solid fa-user-shield"></i> Phân quyền
                                            </button>
                                            <?php if ($u['status'] === 'active'): ?>
                                                <a href="<?= APP_URL ?>/admin.php?act=users/toggle&id=<?= $u['id'] ?>" 
                                                   class="btn btn-sm btn-danger" 
                                                   style="padding: 5px 10px; font-size: 12px;"
                                                   onclick="return confirm('Bạn có chắc chắn muốn KHÓA tài khoản &quot;<?= addslashes($u['username']) ?>&quot;?');">
                                                    <i class="fa-solid fa-lock"></i> Khóa
                                                </a>
                                            <?php else: ?>
                                                <a href="<?= APP_URL ?>/admin.php?act=users/toggle&id=<?= $u['id'] ?>" 
                                                   class="btn btn-sm btn-success" 
                                                   style="padding: 5px 10px; font-size: 12px;"
                                                   onclick="return confirm('Mở khóa cho tài khoản &quot;<?= addslashes($u['username']) ?>&quot;?');">
                                                    <i class="fa-solid fa-lock-open"></i> Mở
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- MODAL PHÂN QUYỀN ĐA CHỨC NĂNG CHO THÀNH VIÊN -->
<div id="permModalOverlay" style="display: none; position: fixed; inset: 0; background: rgba(15, 23, 42, 0.6); z-index: 9999; align-items: center; justify-content: center; padding: 16px;">
    <div style="background: #fff; border-radius: 14px; max-width: 620px; width: 100%; box-shadow: 0 20px 45px rgba(0,0,0,0.25); overflow: hidden;">
        <div style="padding: 16px 22px; background: #0A2540; color: #fff; display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; font-size: 16px; font-weight: 700;">
                <i class="fa-solid fa-user-shield text-warning"></i> Phân Quyền Đa Chức Năng: <span id="modalUserName" style="color: #38bdf8;"></span>
            </h3>
            <button type="button" onclick="closePermModal()" style="background: transparent; border: none; color: #fff; font-size: 20px; cursor: pointer;">&times;</button>
        </div>

        <form action="<?= APP_URL ?>/admin.php?act=users/change-role" method="POST" style="padding: 20px 22px;">
            <?= csrf_field() ?>
            <input type="hidden" name="user_id" id="modalUserId" value="">
            <input type="hidden" name="is_multi_perm" value="1">
            <input type="hidden" name="role_id" id="modalRoleId" value="3">

            <div class="form-group mb-3">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 6px;">
                    <label class="form-label" style="font-weight: 700; margin: 0;">Tích Chọn Các Vai Trò / Chức Năng Được Phép Quản Lý:</label>
                    <div style="display: flex; gap: 6px;">
                        <button type="button" class="btn btn-sm btn-secondary" style="font-size: 11px; padding: 3px 8px;" onclick="setModalPreset(['manage_products', 'manage_users'])">
                            <i class="fa-solid fa-bolt text-warning"></i> Kho + Account
                        </button>
                        <button type="button" class="btn btn-sm btn-secondary" style="font-size: 11px; padding: 3px 8px;" onclick="setModalAllPerms(true)">Tất cả</button>
                        <button type="button" class="btn btn-sm btn-secondary" style="font-size: 11px; padding: 3px 8px;" onclick="setModalAllPerms(false)">Bỏ hết</button>
                    </div>
                </div>

                <div style="display: flex; flex-direction: column; gap: 8px; max-height: 310px; overflow-y: auto;">
                    <?php foreach ($allPermissions as $permKey => $permInfo): ?>
                        <label style="display: flex; align-items: center; gap: 12px; padding: 10px 14px; border: 1.5px solid #e2e8f0; border-radius: 10px; cursor: pointer; background: #f8fafc;">
                            <input type="checkbox" name="permissions[]" value="<?= e($permKey) ?>" class="modal-perm-cb" style="width: 18px; height: 18px; accent-color: #2563eb;">
                            <div>
                                <div style="font-weight: 700; font-size: 13.5px; color: #0f172a;">
                                    <i class="fa-solid <?= e($permInfo['icon']) ?>" style="color: <?= e($permInfo['color']) ?>; width: 18px;"></i>
                                    <?= e($permInfo['label']) ?>
                                </div>
                                <?php if (!empty($permInfo['dept'])): ?>
                                    <div style="font-size: 11px; font-weight: 600; color: <?= e($permInfo['color']) ?>;">
                                        <i class="fa-solid fa-sitemap"></i> Thuộc: <?= e($permInfo['dept']) ?>
                                    </div>
                                <?php endif; ?>
                                <div style="font-size: 12px; color: #64748b;"><?= e($permInfo['desc']) ?></div>
                            </div>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; border-top: 1px solid #e2e8f0; padding-top: 14px;">
                <button type="button" class="btn btn-secondary" onclick="closePermModal()">Hủy</button>
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> Lưu Phân Quyền Chức Năng
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function openPermModal(userId, userName, roleId, perms) {
    document.getElementById('modalUserId').value = userId;
    document.getElementById('modalUserName').textContent = userName;
    const roleSelect = document.getElementById('modalRoleId');
    if (roleSelect) {
        roleSelect.value = (roleId == 5 && perms.length > 0) ? 3 : roleId;
    }
    document.querySelectorAll('.modal-perm-cb').forEach(cb => {
        cb.checked = Array.isArray(perms) && perms.includes(cb.value);
    });
    document.getElementById('permModalOverlay').style.display = 'flex';
}

function closePermModal() {
    document.getElementById('permModalOverlay').style.display = 'none';
}

function setModalAllPerms(check) {
    document.querySelectorAll('.modal-perm-cb').forEach(cb => cb.checked = check);
}

function setModalPreset(keys) {
    const roleSelect = document.getElementById('modalRoleId');
    if (roleSelect && roleSelect.value == '5') {
        roleSelect.value = '3';
    }
    document.querySelectorAll('.modal-perm-cb').forEach(cb => {
        cb.checked = keys.includes(cb.value);
    });
}
</script>
