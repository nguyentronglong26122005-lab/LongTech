<?php
/**
 * ========================================================
 * LONGTECH - VIEW DANH SÁCH BANNER (admin/pages/banners/list.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title"><i class="fa-solid fa-images text-primary"></i> Quản Lý Banner</h1>
        <p class="page-subtitle">Quản lý banner quảng cáo hiển thị trên trang chủ và các vị trí đặc biệt</p>
    </div>
    <div>
        <a href="<?= APP_URL ?>/admin.php?act=banners/add-edit" class="btn btn-primary">
            <i class="fa-solid fa-plus"></i> Thêm Banner Mới
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<!-- BỘ LỌC -->
<div class="admin-card mb-4">
    <div class="admin-card-body" style="padding:16px 20px;">
        <form method="GET" action="<?= APP_URL ?>/admin.php" style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;">
            <input type="hidden" name="act" value="banners">
            <div style="flex:2;min-width:200px;">
                <input type="text" name="search" class="form-control" placeholder="🔍 Tìm theo tiêu đề..."
                       value="<?= e($search ?? '') ?>">
            </div>
            <div style="min-width:160px;">
                <select name="position" class="form-control">
                    <option value="">-- Tất cả vị trí --</option>
                    <option value="home_slider"  <?= ($position??'')==='home_slider'  ? 'selected' : '' ?>>Slider trang chủ</option>
                    <option value="home_sidebar" <?= ($position??'')==='home_sidebar' ? 'selected' : '' ?>>Sidebar trang chủ</option>
                    <option value="sale_popup"   <?= ($position??'')==='sale_popup'   ? 'selected' : '' ?>>Popup khuyến mãi</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-filter"></i> Lọc</button>
            <a href="<?= APP_URL ?>/admin.php?act=banners" class="btn btn-secondary">Đặt lại</a>
        </form>
    </div>
</div>

<!-- BẢNG DANH SÁCH BANNER -->
<div class="admin-card">
    <div class="admin-card-header">
        <h3 class="admin-card-title">
            <i class="fa-solid fa-list"></i> Danh sách Banner
            <span class="badge badge-primary"><?= $totalItems ?? count($banners) ?></span>
        </h3>
    </div>
    <div class="admin-card-body">
        <?php if (empty($banners)): ?>
            <div style="text-align:center;padding:40px;color:#9ca3af;">
                <i class="fa-solid fa-images" style="font-size:3rem;margin-bottom:12px;display:block;"></i>
                <p>Chưa có banner nào. <a href="<?= APP_URL ?>/admin.php?act=banners/add-edit">Thêm ngay!</a></p>
            </div>
        <?php else: ?>
        <div style="overflow-x:auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width:50px;">ID</th>
                        <th style="width:100px;">Hình ảnh</th>
                        <th>Tiêu đề</th>
                        <th>Phụ đề</th>
                        <th style="width:140px;">Vị trí</th>
                        <th style="width:70px;">Thứ tự</th>
                        <th style="width:100px;">Trạng thái</th>
                        <th style="width:130px;">Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($banners as $banner): ?>
                    <tr>
                        <td><strong>#<?= e($banner['id']) ?></strong></td>
                        <td>
                            <?php if (!empty($banner['image_url'])): ?>
                                <img src="<?= e($banner['image_url']) ?>" alt="banner"
                                     style="width:80px;height:50px;object-fit:cover;border-radius:6px;border:1px solid #e5e7eb;">
                            <?php else: ?>
                                <div style="width:80px;height:50px;background:#f3f4f6;border-radius:6px;display:flex;align-items:center;justify-content:center;">
                                    <i class="fa-solid fa-image" style="color:#9ca3af;"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= e($banner['title']) ?></strong>
                            <?php if (!empty($banner['link'])): ?>
                                <br><small><a href="<?= e($banner['link']) ?>" target="_blank" style="color:#3b82f6;">
                                    <i class="fa-solid fa-link"></i> <?= e(substr($banner['link'], 0, 40)) ?>...</a></small>
                            <?php endif; ?>
                        </td>
                        <td><span style="color:#6b7280;"><?= e(truncate_words($banner['subtitle'] ?? '', 8)) ?></span></td>
                        <td>
                            <?php
                            $posLabels = [
                                'home_slider'  => ['label' => 'Slider Chủ', 'color' => '#3b82f6'],
                                'home_sidebar' => ['label' => 'Sidebar',    'color' => '#8b5cf6'],
                                'sale_popup'   => ['label' => 'Popup Sale', 'color' => '#f59e0b'],
                            ];
                            $p = $posLabels[$banner['position'] ?? ''] ?? ['label' => $banner['position'] ?? 'N/A', 'color' => '#9ca3af'];
                            ?>
                            <span class="badge" style="background:<?= $p['color'] ?>1a;color:<?= $p['color'] ?>;border:1px solid <?= $p['color'] ?>40;">
                                <?= $p['label'] ?>
                            </span>
                        </td>
                        <td style="text-align:center;">
                            <span style="font-weight:600;"><?= (int)($banner['sort_order'] ?? 0) ?></span>
                        </td>
                        <td>
                            <?php if (($banner['status'] ?? 'inactive') === 'active'): ?>
                                <span class="badge badge-success"><i class="fa-solid fa-eye"></i> Hiển thị</span>
                            <?php else: ?>
                                <span class="badge badge-danger"><i class="fa-solid fa-eye-slash"></i> Ẩn</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?= APP_URL ?>/admin.php?act=banners/add-edit&id=<?= $banner['id'] ?>"
                               class="btn btn-sm btn-primary" title="Sửa">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </a>
                            <form method="POST" action="<?= APP_URL ?>/admin.php?act=banners/delete" style="display:inline;">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= $banner['id'] ?>">
                                <button type="button" class="btn btn-sm btn-danger" title="Xóa"
                                        onclick="confirmAdminDelete(this.closest('form'), '<?= e($banner['title']) ?>')">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <!-- Phân trang -->
        <?= $pagination ?? '' ?>
    </div>
</div>

