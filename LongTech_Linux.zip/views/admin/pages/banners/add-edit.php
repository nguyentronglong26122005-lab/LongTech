<?php
/**
 * ========================================================
 * LONGTECH - VIEW THÊM / SỬA BANNER (admin/pages/banners/add-edit.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
$isEdit = !empty($banner);
?>

<div class="admin-content-header">
    <div>
        <h1 class="page-title">
            <i class="fa-solid fa-images text-primary"></i> <?= $isEdit ? 'Chỉnh Sửa Banner #' . e($banner['id']) : 'Thêm Banner Mới' ?>
        </h1>
        <p class="page-subtitle">Cấu hình banner trình chiếu, vị trí hiển thị và liên kết khuyến mãi</p>
    </div>
    <div>
        <a href="<?= APP_URL ?>/admin.php?act=banners" class="btn btn-secondary">
            <i class="fa-solid fa-arrow-left"></i> Quay lại danh sách
        </a>
    </div>
</div>

<?= render_flash_messages() ?>

<div class="admin-card">
    <div class="admin-card-body">
        <form method="POST" action="<?= APP_URL ?>/admin.php?act=banners/add-edit<?= $isEdit ? '&id=' . $banner['id'] : '' ?>" enctype="multipart/form-data">
            <?= csrf_field() ?>

            <div class="form-group mb-3">
                <label class="form-label" for="title">Tiêu đề Banner <span class="text-danger">*</span></label>
                <input type="text" id="title" name="title" class="form-control" required
                       value="<?= e($banner['title'] ?? '') ?>" placeholder="Ví dụ: Siêu Sale iPhone 16 Pro Max">
            </div>

            <div class="form-group mb-3">
                <label class="form-label" for="subtitle">Phụ đề / Mô tả ngắn</label>
                <input type="text" id="subtitle" name="subtitle" class="form-control"
                       value="<?= e($banner['subtitle'] ?? '') ?>" placeholder="Ví dụ: Giảm sốc đến 5 triệu đồng">
            </div>

            <div class="form-group mb-3">
                <label class="form-label" for="link">Đường dẫn liên kết (Link)</label>
                <input type="text" id="link" name="link" class="form-control"
                       value="<?= e($banner['link'] ?? '') ?>" placeholder="https://... hoặc ?act=products&category=1">
            </div>

            <div class="form-group mb-3">
                <label class="form-label">Hình ảnh Banner</label>
                <div style="display: flex; gap: 15px; align-items: flex-start; flex-wrap: wrap;">
                    <?php if (!empty($banner['image_url'])): ?>
                        <div>
                            <img src="<?= e($banner['image_url']) ?>" alt="Banner Preview" style="max-width: 200px; height: auto; border-radius: 6px; border: 1px solid #ddd;">
                            <div class="form-text">Ảnh hiện tại</div>
                        </div>
                    <?php endif; ?>
                    <div style="flex: 1; min-width: 250px;">
                        <input type="file" name="image_file" class="form-control mb-2" accept="image/*">
                        <input type="text" name="image_url" class="form-control" placeholder="Hoặc dán URL ảnh trực tiếp" value="<?= e($banner['image_url'] ?? '') ?>">
                        <small class="form-text text-muted">Hỗ trợ JPG, PNG, WEBP. Nếu tải file mới, URL sẽ tự động cập nhật.</small>
                    </div>
                </div>
            </div>

            <div class="row" style="display: flex; gap: 15px; flex-wrap: wrap;">
                <div class="form-group mb-3" style="flex: 1; min-width: 200px;">
                    <label class="form-label" for="position">Vị trí hiển thị</label>
                    <select name="position" id="position" class="form-control">
                        <option value="home_slider" <?= ($banner['position'] ?? '') === 'home_slider' ? 'selected' : '' ?>>Slider chính Trang Chủ</option>
                        <option value="home_sidebar" <?= ($banner['position'] ?? '') === 'home_sidebar' ? 'selected' : '' ?>>Banner Phụ Sidebar</option>
                        <option value="sale_popup" <?= ($banner['position'] ?? '') === 'sale_popup' ? 'selected' : '' ?>>Popup Khuyến Mãi</option>
                    </select>
                </div>

                <div class="form-group mb-3" style="flex: 1; min-width: 150px;">
                    <label class="form-label" for="sort_order">Thứ tự ưu tiên</label>
                    <input type="number" id="sort_order" name="sort_order" class="form-control" value="<?= (int)($banner['sort_order'] ?? 0) ?>">
                    <small class="form-text text-muted">Số nhỏ xếp trước</small>
                </div>

                <div class="form-group mb-3" style="flex: 1; min-width: 150px;">
                    <label class="form-label" for="status">Trạng thái</label>
                    <select name="status" id="status" class="form-control">
                        <option value="active" <?= ($banner['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>Hiển thị (Active)</option>
                        <option value="inactive" <?= ($banner['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>Ẩn (Inactive)</option>
                    </select>
                </div>
            </div>

            <div class="mt-4" style="display: flex; gap: 10px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> <?= $isEdit ? 'Lưu Thay Đổi' : 'Thêm Mới' ?>
                </button>
                <a href="<?= APP_URL ?>/admin.php?act=banners" class="btn btn-secondary">Hủy bỏ</a>
            </div>
        </form>
    </div>
</div>

