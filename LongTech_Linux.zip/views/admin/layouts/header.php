<?php
/**
 * ========================================================
 * LONGTECH - HEADER TRANG QUẢN TRỊ (admin/layouts/header.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

$currentUser = current_user();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title><?= e($pageTitle ?? 'Quản Trị Hệ Thống - LongTech') ?></title>

    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- FontAwesome 6 Icons CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <!-- CSS Style Admin -->
    <link rel="stylesheet" href="<?= ASSET_URL ?>/css/admin.css?v=<?= time() ?>">

    <!-- Dark Mode CSS inline (kích hoạt ngay trước khi render để tránh nháy) -->
    <style>
    /* ========= DARK MODE ========= */
    body.dark-mode {
        --admin-bg: #0f172a;
        --admin-card-bg: #1e293b;
        --admin-border: #334155;
        --admin-text-main: #e2e8f0;
        --admin-text-muted: #94a3b8;
        --admin-sidebar: #0d1b2e;
        --admin-sidebar-hover: #1e293b;
    }
    body.dark-mode .admin-header { background: #1e293b; border-color: #334155; }
    body.dark-mode .admin-table th { background: #334155; color: #cbd5e1; }
    body.dark-mode .admin-table tr:hover td { background: #1e293b; }
    body.dark-mode .form-control { background: #1e293b; border-color: #475569; color: #e2e8f0; }
    body.dark-mode .btn-secondary { background: #334155; color: #e2e8f0; border-color: #475569; }
    body.dark-mode .admin-footer { background: #1e293b; border-color: #334155; }
    </style>
    <script>
    // Áp dụng dark mode ngay để không bị "flash" trắng
    if (localStorage.getItem('adminDarkMode') === '1') {
        document.documentElement.classList.add('dark-mode-init');
        document.addEventListener('DOMContentLoaded', () => document.body.classList.add('dark-mode'));
    }
    </script>
</head>
<body class="admin-body">

<div class="admin-wrapper">
