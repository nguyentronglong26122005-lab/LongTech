<?php
/**
 * ========================================================
 * LONGTECH - HEADER TRANG QUẢN TRỊ (admin/layouts/header.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

$currentUser = current_user();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title><?= e($pageTitle ?? 'Quản Trị Hệ Thống - LongTech') ?></title>

    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- FontAwesome 6 Icons CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <!-- CSS Style Admin -->
    <link rel="stylesheet" href="<?= ASSET_URL ?>/css/admin.css?v=<?= time() ?>">

    <!-- Dark Mode CSS toàn diện (kích hoạt ngay trước khi render để tránh nháy) -->
    <style>
    /* ========= DARK MODE TOÀN DIỆN ========= */
    html.dark,
    html.dark body.admin-body,
    body.dark-mode {
        --admin-bg: #0f172a;
        --admin-card-bg: #1e293b;
        --admin-border: #334155;
        --admin-text-main: #f1f5f9;
        --admin-text-muted: #94a3b8;
        --admin-sidebar: #091526;
        --admin-sidebar-hover: #1e293b;
        --admin-primary: #38bdf8;
        background-color: #0f172a !important;
        color: #f1f5f9 !important;
    }
    html.dark .admin-main,
    body.dark-mode .admin-main {
        background-color: #0f172a !important;
    }
    html.dark .admin-card,
    html.dark .stat-card,
    body.dark-mode .admin-card,
    body.dark-mode .stat-card {
        background-color: #1e293b !important;
        border-color: #334155 !important;
        color: #f1f5f9 !important;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25) !important;
    }
    html.dark .admin-card-header,
    body.dark-mode .admin-card-header {
        background-color: #1e293b !important;
        border-bottom-color: #334155 !important;
    }
    html.dark .page-title,
    html.dark .card-title,
    html.dark .stat-value,
    html.dark h1, html.dark h2, html.dark h3, html.dark h4,
    html.dark .form-label,
    body.dark-mode .page-title,
    body.dark-mode .card-title,
    body.dark-mode .stat-value,
    body.dark-mode .form-label {
        color: #f8fafc !important;
    }
    html.dark .page-subtitle,
    html.dark .stat-label,
    body.dark-mode .page-subtitle,
    body.dark-mode .stat-label {
        color: #94a3b8 !important;
    }
    html.dark .admin-table th,
    body.dark-mode .admin-table th {
        background-color: #0f172a !important;
        color: #cbd5e1 !important;
        border-bottom-color: #334155 !important;
    }
    html.dark .admin-table td,
    body.dark-mode .admin-table td {
        border-bottom-color: #334155 !important;
        color: #e2e8f0 !important;
    }
    html.dark .admin-table tr[style*="background: #fffbeb"] td,
    body.dark-mode .admin-table tr[style*="background: #fffbeb"] td {
        background-color: rgba(245, 158, 11, 0.12) !important;
    }
    html.dark .admin-table tbody tr:hover td,
    body.dark-mode .admin-table tbody tr:hover td {
        background-color: #26354d !important;
    }
    html.dark .admin-table td div[style*="color: #0f172a"],
    html.dark .admin-table td div[style*="color: #334155"],
    body.dark-mode .admin-table td div[style*="color: #0f172a"],
    body.dark-mode .admin-table td div[style*="color: #334155"] {
        color: #f1f5f9 !important;
    }
    html.dark .form-control,
    html.dark input[type="text"],
    html.dark input[type="email"],
    html.dark input[type="password"],
    html.dark input[type="number"],
    html.dark select,
    html.dark textarea,
    body.dark-mode .form-control {
        background-color: #0f172a !important;
        border-color: #475569 !important;
        color: #f8fafc !important;
    }
    html.dark .form-control::placeholder,
    body.dark-mode .form-control::placeholder {
        color: #64748b !important;
    }
    html.dark .btn-secondary,
    body.dark-mode .btn-secondary {
        background-color: #334155 !important;
        color: #f1f5f9 !important;
        border-color: #475569 !important;
    }
    html.dark .btn-secondary:hover,
    body.dark-mode .btn-secondary:hover {
        background-color: #475569 !important;
    }
    html.dark .perm-card-item,
    html.dark #multi-permission-box,
    html.dark .form-group[style*="background: #f8fafc"],
    body.dark-mode .perm-card-item,
    body.dark-mode #multi-permission-box {
        background-color: #0f172a !important;
        border-color: #334155 !important;
        color: #f1f5f9 !important;
    }
    html.dark .perm-card-item div[style*="color: #0f172a"],
    html.dark .form-group label[style*="color: #0f172a"],
    body.dark-mode .perm-card-item div[style*="color: #0f172a"] {
        color: #f8fafc !important;
    }
    html.dark .quick-search-box,
    body.dark-mode .quick-search-box {
        background-color: #1e293b !important;
        border: 1px solid #334155 !important;
    }
    html.dark .quick-search-header,
    body.dark-mode .quick-search-header {
        border-bottom-color: #334155 !important;
    }
    html.dark .quick-search-header input,
    html.dark .quick-link-item,
    body.dark-mode .quick-search-header input,
    body.dark-mode .quick-link-item {
        color: #f1f5f9 !important;
    }
    html.dark .quick-link-item:hover,
    body.dark-mode .quick-link-item:hover {
        background-color: #334155 !important;
    }
    html.dark .admin-footer,
    body.dark-mode .admin-footer {
        background-color: #0f172a !important;
        border-top-color: #1e293b !important;
        color: #94a3b8 !important;
    }
    </style>
    <script>
    // Áp dụng dark mode ngay lập tức trước khi render để không bị nháy trắng
    (function() {
        var saved = localStorage.getItem('longtech_admin_theme') || (localStorage.getItem('adminDarkMode') === '1' ? 'dark' : 'light');
        if (saved === 'dark') {
            document.documentElement.classList.add('dark');
            document.addEventListener('DOMContentLoaded', function() {
                document.body.classList.add('dark-mode');
            });
        }
    })();
    </script>
</head>
<body class="admin-body">

<div class="admin-wrapper">
