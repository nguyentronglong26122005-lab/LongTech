<?php
/**
 * ========================================================
 * LONGTECH - SIDEBAR QUẢN TRỊ TINH GỌN (admin/layouts/sidebar.php)
 * Menu Accordion mượt mà, ghi nhớ trạng thái localStorage,
 * Phân quyền hiển thị menu động và Tìm kiếm nhanh (Ctrl+K)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }

$currentAct = $_GET['act'] ?? 'dashboard';
$userRole   = current_role();
$userName   = current_user()['full_name'] ?? 'Quản trị viên';
$isSuperOrAdmin = in_array($userRole, ['super_admin', 'admin'], true);
$isProductMgr   = ($userRole === 'product_manager');
$isOrderMgr     = ($userRole === 'order_manager');

require_once ROOT_PATH . '/models/ApprovalModel.php';
$sidebarApprovalModel = new ApprovalModel();
$pendingApprovalCount = $sidebarApprovalModel->countPending($userRole === 'super_admin' ? null : (int)current_user_id());
?>

<!-- SIDEBAR DỌC BÊN TRÁI -->
<aside class="admin-sidebar" id="adminSidebar">
    <!-- Brand Header & Toggle Collapse -->
    <div class="sidebar-brand">
        <a href="<?= APP_URL ?>/admin.php" style="display:flex; align-items:center; gap:10px; text-decoration:none; color:inherit;">
            <div class="logo-icon"><i class="fa-solid fa-microchip"></i></div>
            <div class="brand-text">
                <span class="brand-name">LONG<span>TECH</span></span>
                <span class="brand-badge"><?= strtoupper($userRole) ?></span>
            </div>
        </a>
        <button type="button" class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Thu gọn/Mở rộng menu">
            <i class="fa-solid fa-bars-staggered"></i>
        </button>
    </div>

    <!-- Ô TÌM KIẾM NHANH (CTRL + K) -->
    <div class="sidebar-search-box">
        <button type="button" class="sidebar-search-btn" onclick="openQuickSearch()">
            <i class="fa-solid fa-magnifying-glass"></i>
            <span class="search-placeholder">Tìm nhanh trang...</span>
            <kbd class="search-kbd">Ctrl K</kbd>
        </button>
    </div>

    <!-- DANH SÁCH MENU DẠNG ACCORDION -->
    <nav class="sidebar-nav" id="sidebarNav">

        <!-- 1. TỔNG QUAN (DASHBOARD) -->
        <div class="nav-item">
            <a href="<?= APP_URL ?>/admin.php?act=dashboard" class="nav-link single-link <?= $currentAct === 'dashboard' ? 'active' : '' ?>">
                <i class="fa-solid fa-chart-pie nav-icon"></i>
                <span class="nav-text">Tổng Quan (Dashboard)</span>
            </a>
        </div>

        <!-- 1.0 SƠ ĐỒ 12 BỘ PHẬN & PHÒNG BAN (NẰM NGAY ĐẦU MENU DỄ THẤY) -->
        <div class="nav-item">
            <a href="<?= APP_URL ?>/admin.php?act=departments" class="nav-link single-link <?= $currentAct === 'departments' ? 'active' : '' ?>" style="background: <?= $currentAct === 'departments' ? '#f59e0b' : 'rgba(245, 158, 11, 0.12)' ?>; border-left: 3px solid #f59e0b;">
                <i class="fa-solid fa-sitemap nav-icon" style="color: <?= $currentAct === 'departments' ? '#fff' : '#f59e0b' ?>;"></i>
                <span class="nav-text" style="color: <?= $currentAct === 'departments' ? '#fff' : '#fef08a' ?>; font-weight: 700;">Sơ Đồ 12 Bộ Phận</span>
            </a>
        </div>

        <!-- 1.1 PHÊ DUYỆT YÊU CẦU THAO TÁC -->
        <div class="nav-item">
            <a href="<?= APP_URL ?>/admin.php?act=approvals" class="nav-link single-link <?= str_starts_with($currentAct, 'approvals') ? 'active' : '' ?>" style="display:flex; align-items:center; justify-content:space-between;">
                <span style="display:flex; align-items:center; gap:10px;">
                    <i class="fa-solid fa-clipboard-check nav-icon" style="color:#f59e0b;"></i>
                    <span class="nav-text"><?= $userRole === 'super_admin' ? 'Duyệt Yêu Cầu NV' : 'Yêu Cầu Đã Gửi' ?></span>
                </span>
                <?php if ($pendingApprovalCount > 0): ?>
                    <span style="background:#ef4444; color:#fff; font-size:11px; font-weight:700; padding:2px 7px; border-radius:99px;">
                        <?= (int)$pendingApprovalCount ?>
                    </span>
                <?php endif; ?>
            </a>
        </div>

        <!-- 2. NHÓM SẢN PHẨM & KHO HÀNG (BỘ PHẬN MUA HÀNG & KHO) -->
        <?php if (has_permission('manage_products')): ?>
        <?php $isProdActive = in_array($currentAct, ['products', 'products/add', 'products/edit', 'categories', 'categories/add-edit', 'reviews'], true); ?>
        <div class="nav-group <?= $isProdActive ? 'open' : '' ?>" data-group="products">
            <button type="button" class="nav-group-header">
                <div class="header-left">
                    <i class="fa-solid fa-boxes-stacked nav-icon" style="color:#0284c7;"></i>
                    <span class="nav-text">Bộ Phận Mua Hàng & Kho</span>
                </div>
                <i class="fa-solid fa-chevron-right group-arrow"></i>
            </button>
            <div class="nav-sub-menu">
                <a href="<?= APP_URL ?>/admin.php?act=products" class="sub-link <?= $currentAct === 'products' ? 'active' : '' ?>">
                    <i class="fa-solid fa-list"></i> Danh sách Sản phẩm
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=products/add" class="sub-link <?= $currentAct === 'products/add' ? 'active' : '' ?>">
                    <i class="fa-solid fa-plus-circle"></i> Thêm Sản phẩm mới
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=categories" class="sub-link <?= in_array($currentAct, ['categories', 'categories/add-edit'], true) ? 'active' : '' ?>">
                    <i class="fa-solid fa-layer-group"></i> 8 Ngành hàng Công nghệ
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=reviews" class="sub-link <?= $currentAct === 'reviews' ? 'active' : '' ?>">
                    <i class="fa-solid fa-star-half-stroke"></i> Đánh giá từ Khách
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- 3. NHÓM ĐƠN HÀNG & VẬN CHUYỂN (BỘ PHẬN LOGISTICS) -->
        <?php if (has_permission('manage_orders')): ?>
        <?php $isOrderActive = in_array($currentAct, ['orders', 'orders/detail'], true); ?>
        <div class="nav-group <?= $isOrderActive ? 'open' : '' ?>" data-group="orders">
            <button type="button" class="nav-group-header">
                <div class="header-left">
                    <i class="fa-solid fa-truck-fast nav-icon" style="color:#d97706;"></i>
                    <span class="nav-text">Bộ Phận Kho Vận & Đơn</span>
                </div>
                <i class="fa-solid fa-chevron-right group-arrow"></i>
            </button>
            <div class="nav-sub-menu">
                <a href="<?= APP_URL ?>/admin.php?act=orders" class="sub-link <?= ($currentAct === 'orders' && empty($_GET['status'])) ? 'active' : '' ?>">
                    <i class="fa-solid fa-receipt"></i> Tất cả Đơn hàng
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=orders&status=pending" class="sub-link <?= ($currentAct === 'orders' && ($_GET['status'] ?? '') === 'pending') ? 'active' : '' ?>">
                    <i class="fa-solid fa-clock-rotate-left"></i> Chờ duyệt xử lý
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=orders&status=shipping" class="sub-link <?= ($currentAct === 'orders' && ($_GET['status'] ?? '') === 'shipping') ? 'active' : '' ?>">
                    <i class="fa-solid fa-motorcycle"></i> Đang giao nhận (2H)
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- 4. NHÓM GIAO DIỆN & LIVE EDITOR (BỘ PHẬN CÔNG NGHỆ IT) -->
        <?php if (has_permission('manage_appearance')): ?>
        <?php $isAppearActive = in_array($currentAct, ['appearance/editor', 'banners', 'banners/add-edit'], true); ?>
        <div class="nav-group <?= $isAppearActive ? 'open' : '' ?>" data-group="appearance">
            <button type="button" class="nav-group-header">
                <div class="header-left">
                    <i class="fa-solid fa-laptop-code nav-icon" style="color:#2563eb;"></i>
                    <span class="nav-text">Bộ Phận IT & Giao Diện</span>
                </div>
                <i class="fa-solid fa-chevron-right group-arrow"></i>
            </button>
            <div class="nav-sub-menu">
                <a href="<?= APP_URL ?>/admin.php?act=appearance/editor" class="sub-link <?= $currentAct === 'appearance/editor' ? 'active' : '' ?>">
                    <i class="fa-solid fa-wand-magic-sparkles"></i> Live Editor Trang Chủ
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=banners" class="sub-link <?= in_array($currentAct, ['banners', 'banners/add-edit'], true) ? 'active' : '' ?>">
                    <i class="fa-solid fa-images"></i> Quản lý Banner Slider
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- 5. NHÓM MARKETING & CSKH (BỘ PHẬN MARKETING & CSKH) -->
        <?php if (has_permission(['manage_marketing', 'manage_cskh'])): ?>
        <?php $isMktActive = in_array($currentAct, ['coupons', 'coupons/add-edit', 'posts', 'posts/add-edit', 'contacts', 'faq'], true); ?>
        <div class="nav-group <?= $isMktActive ? 'open' : '' ?>" data-group="marketing">
            <button type="button" class="nav-group-header">
                <div class="header-left">
                    <i class="fa-solid fa-bullhorn nav-icon" style="color:#16a34a;"></i>
                    <span class="nav-text">Bộ Phận Marketing & CSKH</span>
                </div>
                <i class="fa-solid fa-chevron-right group-arrow"></i>
            </button>
            <div class="nav-sub-menu">
                <?php if (has_permission('manage_marketing')): ?>
                <a href="<?= APP_URL ?>/admin.php?act=coupons" class="sub-link <?= in_array($currentAct, ['coupons', 'coupons/add-edit'], true) ? 'active' : '' ?>">
                    <i class="fa-solid fa-ticket"></i> Mã giảm giá (Coupons)
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=posts" class="sub-link <?= in_array($currentAct, ['posts', 'posts/add-edit'], true) ? 'active' : '' ?>">
                    <i class="fa-solid fa-newspaper"></i> Bài viết Review (LongStudio)
                </a>
                <?php endif; ?>
                <?php if (has_permission(['manage_marketing', 'manage_cskh'])): ?>
                <a href="<?= APP_URL ?>/admin.php?act=faq" class="sub-link <?= $currentAct === 'faq' ? 'active' : '' ?>">
                    <i class="fa-solid fa-headset" style="color:#dc2626;"></i> Hỏi &amp; Đáp Khách Hàng (FAQ)
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=contacts" class="sub-link <?= $currentAct === 'contacts' ? 'active' : '' ?>">
                    <i class="fa-solid fa-envelope-open-text"></i> Hộp thư Góp ý / Khiếu nại
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- 6. NHÓM TÀI KHOẢN & PHÂN QUYỀN BỘ PHẬN -->
        <?php if (has_permission('manage_users')): ?>
        <?php $isUserActive = in_array($currentAct, ['departments', 'users', 'users/add', 'system/logs'], true); ?>
        <div class="nav-group <?= $isUserActive ? 'open' : '' ?>" data-group="users">
            <button type="button" class="nav-group-header">
                <div class="header-left">
                    <i class="fa-solid fa-users-gear nav-icon"></i>
                    <span class="nav-text">Bộ Phận & Thành Viên</span>
                </div>
                <i class="fa-solid fa-chevron-right group-arrow"></i>
            </button>
            <div class="nav-sub-menu">
                <a href="<?= APP_URL ?>/admin.php?act=departments" class="sub-link <?= $currentAct === 'departments' ? 'active' : '' ?>" style="color:#f59e0b; font-weight:700;">
                    <i class="fa-solid fa-sitemap" style="color:#f59e0b;"></i> Sơ đồ 12 Bộ Phận
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=users" class="sub-link <?= $currentAct === 'users' ? 'active' : '' ?>">
                    <i class="fa-solid fa-user-shield"></i> Quản lý Thành viên
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=users/add" class="sub-link <?= $currentAct === 'users/add' ? 'active' : '' ?>">
                    <i class="fa-solid fa-user-plus"></i> Thêm Nhân viên mới
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=system/logs" class="sub-link <?= $currentAct === 'system/logs' ? 'active' : '' ?>">
                    <i class="fa-solid fa-clock-rotate-left"></i> Nhật ký hoạt động
                </a>
            </div>
        </div>
        <?php endif; ?>

    </nav>

    <!-- FOOTER SIDEBAR: PROFILE & NÚT DARK MODE -->
    <div class="sidebar-footer">
        <button type="button" class="btn-dark-toggle" id="btnToggleDark" title="Chuyển đổi giao diện Sáng / Tối">
            <i class="fa-solid fa-moon"></i>
            <span class="dark-label">Chế độ Tối</span>
        </button>
        <div class="user-mini-card">
            <div class="user-avatar-mini"><i class="fa-solid fa-user-astronaut"></i></div>
            <div class="user-meta-mini">
                <div class="user-name-mini"><?= e($userName) ?></div>
                <div class="user-role-mini"><?= strtoupper($userRole) ?></div>
            </div>
            <a href="<?= APP_URL ?>/dang-xuat" class="btn-logout-mini" title="Đăng xuất"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
        </div>
    </div>
</aside>

<!-- MODAL TÌM KIẾM NHANH (CTRL + K) -->
<div class="quick-search-backdrop" id="quickSearchModal" style="display:none;" onclick="if(event.target===this) closeQuickSearch()">
    <div class="quick-search-box">
        <div class="quick-search-header">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" id="quickSearchInput" placeholder="Gõ tên trang bạn muốn đến (vd: đơn hàng, sản phẩm, banner...)" oninput="filterQuickLinks()">
            <span class="quick-search-esc" onclick="closeQuickSearch()">ESC</span>
        </div>
        <div class="quick-search-results" id="quickSearchResults">
            <!-- Dynamic results populated by JS -->
        </div>
    </div>
</div>

<div class="admin-main">
    <div class="admin-content">
        <?php if ($userRole === 'super_admin' && $pendingApprovalCount > 0 && !str_starts_with($currentAct, 'approvals')): ?>
            <div style="background: #fffbeb; border: 1.5px solid #f59e0b; border-radius: 10px; padding: 12px 18px; margin-bottom: 18px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
                <div style="color: #92400e; font-size: 14px; font-weight: 600;">
                    <i class="fa-solid fa-bell text-warning" style="margin-right: 6px;"></i>
                    Đang có <strong><?= (int)$pendingApprovalCount ?> yêu cầu thao tác</strong> từ thành viên chờ bạn phê duyệt để áp dụng lên web!
                </div>
                <a href="<?= APP_URL ?>/admin.php?act=approvals&status=pending" class="btn btn-sm btn-primary" style="background: #d97706; border-color: #d97706;">
                    <i class="fa-solid fa-clipboard-check"></i> Xem & Duyệt Ngay
                </a>
            </div>
        <?php endif; ?>
        <?= render_flash_messages() ?>
