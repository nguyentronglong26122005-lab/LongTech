<?php
/**
 * ========================================================
 * LONGTECH - SIDEBAR QUẢN TRỊ TINH GỌN (admin/layouts/sidebar.php)
 * Menu Accordion mượt mà, ghi nhớ trạng thái localStorage,
 * Phân quyền hiển thị menu động và Tìm kiếm nhanh (Ctrl+K)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }

$currentAct = $_GET['act'] ?? 'dashboard';
$userRole   = current_role();
$userName   = current_user()['full_name'] ?? 'Quản trị viên';
$isSuperOrAdmin = in_array($userRole, ['super_admin', 'admin'], true);
$isProductMgr   = ($userRole === 'product_manager');
$isOrderMgr     = ($userRole === 'order_manager');
?>

<!-- SIDEBAR DỌC BÊN TRÁI -->
<aside class="admin-sidebar" id="adminSidebar">
    <!-- Brand Header & Toggle Collapse -->
    <div class="sidebar-brand">
        <a href="<?= APP_URL ?>/admin.php" style="display:flex; align-items:center; gap:10px; text-decoration:none; color:inherit;">
            <div class="logo-icon"><i class="fa-solid fa-microchip"></i></div>
            <div class="brand-text">
                <span class="brand-name">LONG<span>TECH</span></span>
                <span class="brand-badge"><?= strtoupper($userRole) ?></span>
            </div>
        </a>
        <button type="button" class="sidebar-collapse-btn" id="sidebarCollapseBtn" title="Thu gọn/Mở rộng menu">
            <i class="fa-solid fa-bars-staggered"></i>
        </button>
    </div>

    <!-- Ô TÌM KIẾM NHANH (CTRL + K) -->
    <div class="sidebar-search-box">
        <button type="button" class="sidebar-search-btn" onclick="openQuickSearch()">
            <i class="fa-solid fa-magnifying-glass"></i>
            <span class="search-placeholder">Tìm nhanh trang...</span>
            <kbd class="search-kbd">Ctrl K</kbd>
        </button>
    </div>

    <!-- DANH SÁCH MENU DẠNG ACCORDION -->
    <nav class="sidebar-nav" id="sidebarNav">

        <!-- 1. TỔNG QUAN (DASHBOARD) -->
        <div class="nav-item">
            <a href="<?= APP_URL ?>/admin.php?act=dashboard" class="nav-link single-link <?= $currentAct === 'dashboard' ? 'active' : '' ?>">
                <i class="fa-solid fa-chart-pie nav-icon"></i>
                <span class="nav-text">Tổng Quan (Dashboard)</span>
            </a>
        </div>

        <!-- 2. NHÓM SẢN PHẨM & KHO HÀNG (Admin + Product Manager) -->
        <?php if ($isSuperOrAdmin || $isProductMgr): ?>
        <?php $isProdActive = in_array($currentAct, ['products', 'products/add', 'products/edit', 'categories', 'categories/add-edit', 'reviews'], true); ?>
        <div class="nav-group <?= $isProdActive ? 'open' : '' ?>" data-group="products">
            <button type="button" class="nav-group-header">
                <div class="header-left">
                    <i class="fa-solid fa-boxes-stacked nav-icon"></i>
                    <span class="nav-text">Sản Phẩm & Kho</span>
                </div>
                <i class="fa-solid fa-chevron-right group-arrow"></i>
            </button>
            <div class="nav-sub-menu">
                <a href="<?= APP_URL ?>/admin.php?act=products" class="sub-link <?= $currentAct === 'products' ? 'active' : '' ?>">
                    <i class="fa-solid fa-list"></i> Danh sách Sản phẩm
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=products/add" class="sub-link <?= $currentAct === 'products/add' ? 'active' : '' ?>">
                    <i class="fa-solid fa-plus-circle"></i> Thêm Sản phẩm mới
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=categories" class="sub-link <?= in_array($currentAct, ['categories', 'categories/add-edit'], true) ? 'active' : '' ?>">
                    <i class="fa-solid fa-layer-group"></i> Danh mục Sản phẩm
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=reviews" class="sub-link <?= $currentAct === 'reviews' ? 'active' : '' ?>">
                    <i class="fa-solid fa-star-half-stroke"></i> Đánh giá từ Khách
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- 3. NHÓM ĐƠN HÀNG & VẬN CHUYỂN (Admin + Order Manager) -->
        <?php if ($isSuperOrAdmin || $isOrderMgr): ?>
        <?php $isOrderActive = in_array($currentAct, ['orders', 'orders/detail'], true); ?>
        <div class="nav-group <?= $isOrderActive ? 'open' : '' ?>" data-group="orders">
            <button type="button" class="nav-group-header">
                <div class="header-left">
                    <i class="fa-solid fa-cart-shopping nav-icon"></i>
                    <span class="nav-text">Đơn Hàng & Vận Chuyển</span>
                </div>
                <i class="fa-solid fa-chevron-right group-arrow"></i>
            </button>
            <div class="nav-sub-menu">
                <a href="<?= APP_URL ?>/admin.php?act=orders" class="sub-link <?= ($currentAct === 'orders' && empty($_GET['status'])) ? 'active' : '' ?>">
                    <i class="fa-solid fa-receipt"></i> Tất cả Đơn hàng
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=orders&status=pending" class="sub-link <?= ($currentAct === 'orders' && ($_GET['status'] ?? '') === 'pending') ? 'active' : '' ?>">
                    <i class="fa-solid fa-clock-rotate-left"></i> Chờ duyệt xử lý
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=orders&status=shipping" class="sub-link <?= ($currentAct === 'orders' && ($_GET['status'] ?? '') === 'shipping') ? 'active' : '' ?>">
                    <i class="fa-solid fa-truck-fast"></i> Đang giao nhận
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- 4. NHÓM GIAO DIỆN & LIVE EDITOR (Chỉ Super Admin & Admin) -->
        <?php if ($isSuperOrAdmin): ?>
        <?php $isAppearActive = in_array($currentAct, ['appearance/editor', 'banners', 'banners/add-edit'], true); ?>
        <div class="nav-group <?= $isAppearActive ? 'open' : '' ?>" data-group="appearance">
            <button type="button" class="nav-group-header">
                <div class="header-left">
                    <i class="fa-solid fa-wand-magic-sparkles nav-icon"></i>
                    <span class="nav-text">Giao Diện & Live Editor</span>
                </div>
                <i class="fa-solid fa-chevron-right group-arrow"></i>
            </button>
            <div class="nav-sub-menu">
                <a href="<?= APP_URL ?>/admin.php?act=appearance/editor" class="sub-link <?= $currentAct === 'appearance/editor' ? 'active' : '' ?>">
                    <i class="fa-solid fa-sliders"></i> Live Editor Bố Cục
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=banners" class="sub-link <?= in_array($currentAct, ['banners', 'banners/add-edit'], true) ? 'active' : '' ?>">
                    <i class="fa-solid fa-images"></i> Quản lý Banner Slider
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- 5. NHÓM MARKETING & KHUYẾN MÃI (Chỉ Super Admin & Admin) -->
        <?php if ($isSuperOrAdmin): ?>
        <?php $isMktActive = in_array($currentAct, ['coupons', 'coupons/add-edit', 'posts', 'posts/add-edit', 'contacts'], true); ?>
        <div class="nav-group <?= $isMktActive ? 'open' : '' ?>" data-group="marketing">
            <button type="button" class="nav-group-header">
                <div class="header-left">
                    <i class="fa-solid fa-bullhorn nav-icon"></i>
                    <span class="nav-text">Marketing & Tin Tức</span>
                </div>
                <i class="fa-solid fa-chevron-right group-arrow"></i>
            </button>
            <div class="nav-sub-menu">
                <a href="<?= APP_URL ?>/admin.php?act=coupons" class="sub-link <?= in_array($currentAct, ['coupons', 'coupons/add-edit'], true) ? 'active' : '' ?>">
                    <i class="fa-solid fa-ticket"></i> Mã giảm giá (Coupons)
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=posts" class="sub-link <?= in_array($currentAct, ['posts', 'posts/add-edit'], true) ? 'active' : '' ?>">
                    <i class="fa-solid fa-newspaper"></i> Bài viết & Tin tức
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=contacts" class="sub-link <?= $currentAct === 'contacts' ? 'active' : '' ?>">
                    <i class="fa-solid fa-envelope-open-text"></i> Hộp thư Khách hàng
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- 6. NHÓM TÀI KHOẢN & PHÂN QUYỀN (Chỉ Super Admin & Admin) -->
        <?php if ($isSuperOrAdmin): ?>
        <?php $isUserActive = in_array($currentAct, ['users'], true); ?>
        <div class="nav-group <?= $isUserActive ? 'open' : '' ?>" data-group="users">
            <button type="button" class="nav-group-header">
                <div class="header-left">
                    <i class="fa-solid fa-users-gear nav-icon"></i>
                    <span class="nav-text">Thành Viên & Quyền</span>
                </div>
                <i class="fa-solid fa-chevron-right group-arrow"></i>
            </button>
            <div class="nav-sub-menu">
                <a href="<?= APP_URL ?>/admin.php?act=users" class="sub-link <?= $currentAct === 'users' ? 'active' : '' ?>">
                    <i class="fa-solid fa-user-shield"></i> Quản lý Thành viên
                </a>
                <a href="<?= APP_URL ?>/admin.php?act=system/logs" class="sub-link <?= $currentAct === 'system/logs' ? 'active' : '' ?>">
                    <i class="fa-solid fa-clock-rotate-left"></i> Nhật ký hoạt động
                </a>
            </div>
        </div>
        <?php endif; ?>

    </nav>

    <!-- FOOTER SIDEBAR: PROFILE & NÚT DARK MODE -->
    <div class="sidebar-footer">
        <button type="button" class="btn-dark-toggle" id="btnToggleDark" title="Chuyển đổi giao diện Sáng / Tối">
            <i class="fa-solid fa-moon"></i>
            <span class="dark-label">Chế độ Tối</span>
        </button>
        <div class="user-mini-card">
            <div class="user-avatar-mini"><i class="fa-solid fa-user-astronaut"></i></div>
            <div class="user-meta-mini">
                <div class="user-name-mini"><?= e($userName) ?></div>
                <div class="user-role-mini"><?= strtoupper($userRole) ?></div>
            </div>
            <a href="<?= APP_URL ?>/dang-xuat" class="btn-logout-mini" title="Đăng xuất"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
        </div>
    </div>
</aside>

<!-- MODAL TÌM KIẾM NHANH (CTRL + K) -->
<div class="quick-search-backdrop" id="quickSearchModal" style="display:none;" onclick="if(event.target===this) closeQuickSearch()">
    <div class="quick-search-box">
        <div class="quick-search-header">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" id="quickSearchInput" placeholder="Gõ tên trang bạn muốn đến (vd: đơn hàng, sản phẩm, banner...)" oninput="filterQuickLinks()">
            <span class="quick-search-esc" onclick="closeQuickSearch()">ESC</span>
        </div>
        <div class="quick-search-results" id="quickSearchResults">
            <!-- Dynamic results populated by JS -->
        </div>
    </div>
</div>

<div class="admin-main">
    <div class="admin-content">
        <?= render_flash_messages() ?>
