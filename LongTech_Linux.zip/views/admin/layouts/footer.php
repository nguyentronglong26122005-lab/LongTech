<?php
/**
 * ========================================================
 * LONGTECH - FOOTER TRANG QUẢN TRỊ (admin/layouts/footer.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>
    </div> <!-- Đóng thẻ .admin-content từ sidebar.php -->

    <!-- Chân trang Admin -->
    <footer class="admin-footer">
        <p>© 2026 <strong>LongTech E-Commerce</strong>. Hệ thống quản trị bán lẻ thiết bị công nghệ hiện đại.</p>
        <p>Phiên bản lõi: <strong>v1.0.0 MVC</strong> | PHP 8+</p>
    </footer>
</div> <!-- Đóng thẻ .admin-main từ sidebar.php -->

</div> <!-- Đóng thẻ .admin-wrapper từ header.php -->

<!-- Chart.js CDN phục vụ vẽ biểu đồ doanh thu -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Script xử lý trang Admin của LongTech -->
<script src="<?= ASSET_URL ?>/js/admin.js?v=<?= time() ?>"></script>

</body>
</html>

