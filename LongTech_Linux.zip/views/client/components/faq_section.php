<?php
/**
 * ========================================================
 * LONGTECH - KHU VỰC HỎI VÀ ĐÁP CHUẨN CELLPHONES (components/faq_section.php)
 * ========================================================
 */
require_once ROOT_PATH . '/models/FaqModel.php';
$faqModel = new FaqModel();
$faqQuestions = $faqModel->getQuestions($productId ?? null, 10);
$currentUser = current_user();
?>

<div class="faq-section-wrapper" id="faqSection">
    <div class="faq-header-title">
        <h2 style="font-size: 20px; font-weight: 800; color: #0A2540; display: flex; align-items: center; gap: 8px;">
            <i class="fa-solid fa-comments text-primary"></i> Hỏi và đáp
        </h2>
    </div>

    <!-- KHUNG ĐẶT CÂU HỎI MẪU CELLPHONES -->
    <div class="faq-ask-card">
        <div class="faq-mascot">
            <div class="mascot-avatar">
                <i class="fa-solid fa-robot"></i>
            </div>
        </div>
        <div class="faq-ask-content">
            <h3 class="faq-ask-title">Hãy đặt câu hỏi cho chúng tôi</h3>
            <p class="faq-ask-desc">
                LongTech sẽ phản hồi trong vòng 1 giờ. Nếu Quý khách gửi câu hỏi sau 22h, chúng tôi sẽ trả lời vào sáng hôm sau. 
                Thông tin có thể thay đổi theo thời gian, vui lòng đặt câu hỏi để nhận được cập nhật mới nhất!
            </p>
            <form id="faqAskForm" onsubmit="submitQuestion(event)">
                <?= csrf_field() ?>
                <input type="hidden" name="product_id" value="<?= $productId ?? '' ?>">
                
                <div class="faq-input-group">
                    <input type="text" id="faqQuestionInput" name="question" class="faq-input" 
                           placeholder="Viết câu hỏi của bạn tại đây (VD: Sản phẩm này còn màu đen không? Có hỗ trợ trả góp không?...)" required>
                    <button type="submit" class="faq-btn-submit" id="faqSubmitBtn">
                        Gửi câu hỏi <i class="fa-solid fa-paper-plane"></i>
                    </button>
                </div>

                <?php if (!is_logged_in()): ?>
                <div class="faq-guest-fields" style="display: flex; gap: 10px; margin-top: 10px; flex-wrap: wrap;">
                    <input type="text" name="author_name" class="faq-input-small" placeholder="Họ và tên của bạn *" required style="flex: 1; min-width: 180px;">
                    <input type="tel" name="author_phone" class="faq-input-small" placeholder="Số điện thoại (để nhận phản hồi)" style="flex: 1; min-width: 180px;">
                </div>
                <?php else: ?>
                    <input type="hidden" name="author_name" value="<?= e($currentUser['full_name']) ?>">
                    <input type="hidden" name="author_phone" value="<?= e($currentUser['phone'] ?? '') ?>">
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- DANH SÁCH CÂU HỎI & TRẢ LỜI CỦA QTV -->
    <div class="faq-list" id="faqList">
        <?php foreach ($faqQuestions as $q): ?>
        <div class="faq-item-card">
            <!-- Câu hỏi của khách -->
            <div class="faq-question-row">
                <div class="user-avatar-initial">
                    <?= mb_substr(trim($q['author_name']), 0, 1, 'UTF-8') ?>
                </div>
                <div class="faq-question-body">
                    <div class="faq-user-meta">
                        <strong class="faq-author-name"><?= e($q['author_name']) ?></strong>
                        <span class="faq-time"><i class="fa-regular fa-clock"></i> <?= date('d/m/Y H:i', strtotime($q['created_at'])) ?></span>
                    </div>
                    <div class="faq-question-text">
                        <?= nl2br(e($q['question_text'])) ?>
                    </div>
                    <div class="faq-actions">
                        <button type="button" class="faq-action-btn" onclick="toggleReplyBox(<?= $q['id'] ?>)">
                            <i class="fa-regular fa-comment-dots"></i> Phản hồi
                        </button>
                    </div>
                </div>
            </div>

            <!-- Các câu trả lời từ Quản trị viên (QTV) -->
            <?php if (!empty($q['replies'])): ?>
            <div class="faq-replies-list">
                <?php foreach ($q['replies'] as $reply): ?>
                <div class="faq-reply-row">
                    <div class="qtv-avatar">
                        <i class="fa-solid fa-microchip"></i>
                    </div>
                    <div class="faq-reply-body">
                        <div class="faq-user-meta">
                            <strong class="faq-author-name"><?= e($reply['admin_name'] ?? 'Quản trị viên') ?></strong>
                            <span class="badge-qtv">QTV</span>
                            <span class="faq-time"><i class="fa-regular fa-clock"></i> <?= date('d/m/Y H:i', strtotime($reply['created_at'])) ?></span>
                        </div>
                        <div class="faq-reply-text">
                            <?= nl2br(e($reply['reply_text'])) ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- Hộp trả lời nhanh inline (dành cho Admin khi đang xem trang ngoài) -->
            <?php if (has_role(['super_admin', 'admin', 'product_manager', 'order_manager'])): ?>
            <div class="admin-reply-box" id="replyBox_<?= $q['id'] ?>" style="display: none; margin-top: 12px; margin-left: 48px;">
                <form onsubmit="submitAdminReply(event, <?= $q['id'] ?>)">
                    <?= csrf_field() ?>
                    <div style="display: flex; gap: 8px;">
                        <input type="text" class="faq-input" placeholder="Trả lời với tư cách Quản trị viên QTV..." required style="flex: 1;">
                        <button type="submit" class="btn btn-primary" style="padding: 6px 14px; font-size: 13px;">Gửi phản hồi</button>
                    </div>
                </form>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<style>
/* CSS KHU VỰC HỎI ĐÁP PHONG CÁCH CELLPHONES */
.faq-section-wrapper {
    margin-top: 35px;
    margin-bottom: 35px;
}
.faq-ask-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 24px;
    display: flex;
    gap: 20px;
    margin-top: 15px;
    margin-bottom: 25px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.03);
}
.faq-mascot {
    flex-shrink: 0;
}
.mascot-avatar {
    width: 64px;
    height: 64px;
    background: linear-gradient(135deg, #fee2e2, #fecaca);
    color: #D70018;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
}
.faq-ask-content {
    flex: 1;
}
.faq-ask-title {
    font-size: 17px;
    font-weight: 700;
    color: #0A2540;
    margin-bottom: 6px;
}
.faq-ask-desc {
    font-size: 13px;
    color: #64748b;
    line-height: 1.5;
    margin-bottom: 14px;
}
.faq-input-group {
    display: flex;
    gap: 10px;
}
.faq-input {
    flex: 1;
    padding: 10px 16px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 14px;
    outline: none;
    transition: border-color 0.2s;
}
.faq-input:focus {
    border-color: #D70018;
}
.faq-input-small {
    padding: 8px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    font-size: 13px;
    outline: none;
}
.faq-btn-submit {
    background: #D70018;
    color: #ffffff;
    border: none;
    padding: 10px 20px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 14px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: background 0.2s;
    white-space: nowrap;
}
.faq-btn-submit:hover {
    background: #b90014;
}

/* Danh sách câu hỏi */
.faq-item-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 18px 20px;
    margin-bottom: 15px;
}
.faq-question-row {
    display: flex;
    gap: 14px;
}
.user-avatar-initial {
    width: 36px;
    height: 36px;
    background: #bbf7d0;
    color: #166534;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 15px;
    flex-shrink: 0;
}
.faq-question-body {
    flex: 1;
}
.faq-user-meta {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 4px;
}
.faq-author-name {
    color: #1e293b;
    font-size: 14px;
}
.faq-time {
    color: #94a3b8;
    font-size: 12px;
}
.faq-question-text {
    font-size: 14px;
    color: #334155;
    line-height: 1.6;
}
.faq-actions {
    margin-top: 6px;
}
.faq-action-btn {
    background: transparent;
    border: none;
    color: #D70018;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    padding: 0;
}

/* Câu trả lời của QTV */
.faq-replies-list {
    margin-top: 14px;
    padding-left: 48px;
    border-left: 2px solid #f1f5f9;
    display: flex;
    flex-direction: column;
    gap: 12px;
}
.faq-reply-row {
    display: flex;
    gap: 12px;
    background: #f8fafc;
    padding: 12px 16px;
    border-radius: 8px;
}
.qtv-avatar {
    width: 32px;
    height: 32px;
    background: #D70018;
    color: #fff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    flex-shrink: 0;
}
.badge-qtv {
    background: #D70018;
    color: #ffffff;
    padding: 1px 6px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 0.5px;
}
.faq-reply-text {
    font-size: 13.5px;
    color: #334155;
    line-height: 1.6;
}
</style>

<script>
function toggleReplyBox(id) {
    const box = document.getElementById('replyBox_' + id);
    if (box) {
        box.style.display = (box.style.display === 'none') ? 'block' : 'none';
    }
}

function submitQuestion(e) {
    e.preventDefault();
    const form = document.getElementById('faqAskForm');
    const formData = new FormData(form);

    fetch('<?= APP_URL ?>/index.php?route=api/faq/add', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(res => {
        if (res.status) {
            alert('Cảm ơn bạn đã gửi câu hỏi! LongTech sẽ phản hồi trong giây lát.');
            window.location.reload();
        } else {
            alert(res.message || 'Lỗi khi gửi câu hỏi');
        }
    })
    .catch(() => alert('Không thể kết nối đến máy chủ'));
}

function submitAdminReply(e, questionId) {
    e.preventDefault();
    const input = e.target.querySelector('input');
    const replyText = input.value.trim();
    if (!replyText) return;

    const formData = new FormData();
    formData.append('csrf_token', '<?= csrf_token() ?>');
    formData.append('question_id', questionId);
    formData.append('reply_text', replyText);

    fetch('<?= APP_URL ?>/index.php?route=api/faq/reply', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(res => {
        if (res.status) {
            window.location.reload();
        } else {
            alert(res.message || 'Lỗi khi gửi phản hồi');
        }
    });
}
</script>

