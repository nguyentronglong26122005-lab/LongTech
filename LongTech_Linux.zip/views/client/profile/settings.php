<?php
/**
 * ========================================================
 * LONGTECH - CÀI ĐẶT TÀI KHOẢN & ĐỔI MẬT KHẨU (settings.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="profile-page-wrapper">
    <div class="container">
        <div class="profile-layout">
            <!-- 1. SIDEBAR ĐIỀU HƯỚNG TÀI KHOẢN -->
            <aside class="profile-sidebar">
                <div class="user-card-mini">
                    <div class="user-avatar-large">
                        <?= strtoupper(substr(e($user['full_name'] ?? 'U'), 0, 1)) ?>
                    </div>
                    <div class="user-meta-info">
                        <h3 class="user-name"><?= e($user['full_name']) ?></h3>
                        <span class="user-email"><?= e($user['email']) ?></span>
                        <span class="user-role-badge"><i class="fa-solid fa-gem text-warning"></i> <?= e($user['role_display'] ?? 'Khách hàng') ?></span>
                    </div>
                </div>

                <ul class="profile-menu">
                    <li>
                        <a href="<?= APP_URL ?>/tai-khoan" class="profile-menu-item <?= ($activeTab ?? '') === 'dashboard' ? 'active' : '' ?>">
                            <i class="fa-solid fa-gauge-high"></i> Tổng quan tài khoản
                        </a>
                    </li>
                    <li>
                        <a href="<?= APP_URL ?>/tai-khoan/don-hang" class="profile-menu-item <?= ($activeTab ?? '') === 'orders' ? 'active' : '' ?>">
                            <i class="fa-solid fa-boxes-packing"></i> Đơn hàng của tôi
                        </a>
                    </li>
                    <li>
                        <a href="<?= APP_URL ?>/tai-khoan/cai-dat" class="profile-menu-item <?= ($activeTab ?? '') === 'settings' ? 'active' : '' ?>">
                            <i class="fa-solid fa-gear"></i> Cài đặt & Đổi mật khẩu
                        </a>
                    </li>
                    <?php if (in_array(current_role(), ['super_admin', 'admin', 'product_manager', 'order_manager'])): ?>
                        <li>
                            <a href="<?= APP_URL ?>/admin.php" class="profile-menu-item admin-access-item" target="_blank">
                                <i class="fa-solid fa-shield-halved"></i> Trang Quản Trị Hệ Thống
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="menu-divider"></li>
                    <li>
                        <a href="<?= APP_URL ?>/dang-xuat" class="profile-menu-item text-danger">
                            <i class="fa-solid fa-right-from-bracket"></i> Đăng xuất tài khoản
                        </a>
                    </li>
                </ul>
            </aside>

            <!-- 2. KHU VỰC CÀI ĐẶT -->
            <main class="profile-content">
                <div class="content-header">
                    <h2 class="content-title">Cài Đặt Tài Khoản</h2>
                    <p class="content-subtitle">Quản lý hồ sơ cá nhân và nâng cao tính bảo mật cho tài khoản của bạn.</p>
                </div>

                <!-- FORM 1: CẬP NHẬT THÔNG TIN CÁ NHÂN -->
                <div class="profile-card-box">
                    <div class="card-box-header">
                        <h4><i class="fa-regular fa-id-card text-primary"></i> Thông Tin Hồ Sơ</h4>
                    </div>
                    <form action="<?= APP_URL ?>/tai-khoan/cai-dat" method="POST" class="profile-form">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="update_profile">

                        <div class="form-row-2">
                            <div class="form-group">
                                <label class="form-label">Tên tài khoản (Username)</label>
                                <input type="text" class="form-control" value="<?= e($user['username']) ?>" disabled style="background:#f1f5f9;cursor:not-allowed;">
                                <small style="color:#94a3b8;font-size:11px;">Tên tài khoản là định danh duy nhất không thể thay đổi.</small>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Địa chỉ Email</label>
                                <input type="email" class="form-control" value="<?= e($user['email']) ?>" disabled style="background:#f1f5f9;cursor:not-allowed;">
                                <small style="color:#94a3b8;font-size:11px;">Email đăng ký được dùng để nhận hóa đơn và thông báo đơn hàng.</small>
                            </div>
                        </div>

                        <div class="form-row-2">
                            <div class="form-group">
                                <label for="full_name" class="form-label">Họ và tên <span class="required">*</span></label>
                                <input type="text" name="full_name" id="full_name" class="form-control" value="<?= e($user['full_name']) ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="phone" class="form-label">Số điện thoại nhận hàng</label>
                                <input type="tel" name="phone" id="phone" class="form-control" value="<?= e($user['phone'] ?? '') ?>" placeholder="0912345678">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="address" class="form-label">Địa chỉ giao hàng mặc định</label>
                            <textarea name="address" id="address" rows="3" class="form-control" placeholder="Số nhà, tên đường, phường/xã, quận/huyện, tỉnh/thành..."><?= e($user['address'] ?? '') ?></textarea>
                        </div>

                        <div style="text-align: right; margin-top: 10px;">
                            <button type="submit" class="btn-primary-tech">
                                <i class="fa-solid fa-floppy-disk"></i> Lưu Thông Tin Hồ Sơ
                            </button>
                        </div>
                    </form>
                </div>

                <!-- FORM 2: ĐỔI MẬT KHẨU -->
                <div class="profile-card-box">
                    <div class="card-box-header">
                        <h4><i class="fa-solid fa-shield-halved text-danger"></i> Đổi Mật Khẩu Đăng Nhập</h4>
                    </div>
                    <form action="<?= APP_URL ?>/tai-khoan/cai-dat" method="POST" class="profile-form" onsubmit="return validateChangePwdForm(event)">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="change_password">

                        <div class="form-group">
                            <label for="old_password" class="form-label">Mật khẩu hiện tại <span class="required">*</span></label>
                            <div class="input-with-icon">
                                <i class="fa-solid fa-lock input-icon"></i>
                                <input type="password" name="old_password" id="old_password" class="form-control" placeholder="Nhập mật khẩu cũ của bạn" required>
                                <button type="button" class="btn-toggle-password" onclick="togglePasswordVisibility('old_password', this)">
                                    <i class="fa-regular fa-eye"></i>
                                </button>
                            </div>
                        </div>

                        <div class="form-row-2">
                            <div class="form-group">
                                <label for="new_password" class="form-label">Mật khẩu mới <span class="required">*</span></label>
                                <div class="input-with-icon">
                                    <i class="fa-solid fa-key input-icon"></i>
                                    <input type="password" name="new_password" id="new_password" class="form-control" placeholder="Tối thiểu 6 ký tự" required>
                                    <button type="button" class="btn-toggle-password" onclick="togglePasswordVisibility('new_password', this)">
                                        <i class="fa-regular fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password" class="form-label">Nhập lại mật khẩu mới <span class="required">*</span></label>
                                <div class="input-with-icon">
                                    <i class="fa-solid fa-check-double input-icon"></i>
                                    <input type="password" name="confirm_password" id="confirm_password" class="form-control" placeholder="Trùng khớp mật khẩu mới" required>
                                    <button type="button" class="btn-toggle-password" onclick="togglePasswordVisibility('confirm_password', this)">
                                        <i class="fa-regular fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div style="text-align: right; margin-top: 10px;">
                            <button type="submit" class="btn-secondary-tech">
                                <i class="fa-solid fa-key"></i> Đổi Mật Khẩu Ngay
                            </button>
                        </div>
                    </form>
                </div>
            </main>
        </div>
    </div>
</div>

<script>
function togglePasswordVisibility(inputId, btn) {
    const input = document.getElementById(inputId);
    const icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

function validateChangePwdForm(e) {
    const p1 = document.getElementById('new_password').value;
    const p2 = document.getElementById('confirm_password').value;
    if (p1.length < 6) {
        showToast('Mật khẩu mới phải có ít nhất 6 ký tự!', 'error');
        return false;
    }
    if (p1 !== p2) {
        showToast('Mật khẩu xác nhận không khớp!', 'error');
        return false;
    }
    return true;
}
</script>

