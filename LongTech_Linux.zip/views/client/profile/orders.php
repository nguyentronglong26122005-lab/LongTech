<?php
/**
 * ========================================================
 * LONGTECH - LỊCH SỬ ĐƠN HÀNG CỦA USER (orders.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="profile-page-wrapper">
    <div class="container">
        <div class="profile-layout">
            <!-- 1. SIDEBAR ĐIỀU HƯỚNG TÀI KHOẢN -->
            <aside class="profile-sidebar">
                <div class="user-card-mini">
                    <div class="user-avatar-large">
                        <?= strtoupper(substr(e($user['full_name'] ?? 'U'), 0, 1)) ?>
                    </div>
                    <div class="user-meta-info">
                        <h3 class="user-name"><?= e($user['full_name']) ?></h3>
                        <span class="user-email"><?= e($user['email']) ?></span>
                        <span class="user-role-badge"><i class="fa-solid fa-gem text-warning"></i> <?= e($user['role_display'] ?? 'Khách hàng') ?></span>
                    </div>
                </div>

                <ul class="profile-menu">
                    <li>
                        <a href="<?= APP_URL ?>/tai-khoan" class="profile-menu-item <?= ($activeTab ?? '') === 'dashboard' ? 'active' : '' ?>">
                            <i class="fa-solid fa-gauge-high"></i> Tổng quan tài khoản
                        </a>
                    </li>
                    <li>
                        <a href="<?= APP_URL ?>/tai-khoan/don-hang" class="profile-menu-item <?= ($activeTab ?? '') === 'orders' ? 'active' : '' ?>">
                            <i class="fa-solid fa-boxes-packing"></i> Đơn hàng của tôi
                            <span class="badge-count"><?= count($orders) ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= APP_URL ?>/tai-khoan/cai-dat" class="profile-menu-item <?= ($activeTab ?? '') === 'settings' ? 'active' : '' ?>">
                            <i class="fa-solid fa-gear"></i> Cài đặt & Đổi mật khẩu
                        </a>
                    </li>
                    <?php if (in_array(current_role(), ['super_admin', 'admin', 'product_manager', 'order_manager'])): ?>
                        <li>
                            <a href="<?= APP_URL ?>/admin.php" class="profile-menu-item admin-access-item" target="_blank">
                                <i class="fa-solid fa-shield-halved"></i> Trang Quản Trị Hệ Thống
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="menu-divider"></li>
                    <li>
                        <a href="<?= APP_URL ?>/dang-xuat" class="profile-menu-item text-danger">
                            <i class="fa-solid fa-right-from-bracket"></i> Đăng xuất tài khoản
                        </a>
                    </li>
                </ul>
            </aside>

            <!-- 2. KHU VỰC DANH SÁCH ĐƠN HÀNG -->
            <main class="profile-content">
                <div class="content-header">
                    <h2 class="content-title">Lịch Sử Mua Hàng (<?= count($orders) ?> đơn)</h2>
                    <p class="content-subtitle">Chi tiết lịch sử và tiến độ giao hàng các đơn hàng đã đặt tại hệ thống LongTech.</p>
                </div>

                <div class="profile-card-box">
                    <?php if (!empty($orders)): ?>
                        <div class="table-responsive">
                            <table class="profile-table">
                                <thead>
                                    <tr>
                                        <th>Mã Đơn</th>
                                        <th>Thời Gian</th>
                                        <th>Người Nhận / Địa Chỉ</th>
                                        <th>Thanh Toán</th>
                                        <th>Tổng Tiền</th>
                                        <th>Trạng Thái Đơn</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($orders as $order): ?>
                                        <tr>
                                            <td>
                                                <strong class="text-primary"><?= e($order['order_code']) ?></strong>
                                            </td>
                                            <td>
                                                <span class="text-muted" style="font-size:12px;display:block;">
                                                    <?= date('d/m/Y', strtotime($order['created_at'])) ?>
                                                </span>
                                                <span style="font-size:11px;color:#94a3b8;">
                                                    <?= date('H:i', strtotime($order['created_at'])) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <strong><?= e($order['customer_name']) ?></strong>
                                                <div style="font-size:12px;color:#64748b;line-height:1.4;">
                                                    <i class="fa-solid fa-phone" style="font-size:10px;"></i> <?= e($order['customer_phone']) ?><br>
                                                    <i class="fa-solid fa-location-dot" style="font-size:10px;"></i> <?= e($order['customer_address']) ?>, <?= e($order['ward']) ?>, <?= e($order['district']) ?>, <?= e($order['city']) ?>
                                                </div>
                                            </td>
                                            <td>
                                                <span class="pay-method-badge"><?= strtoupper($order['payment_method']) ?></span>
                                                <span class="status-badge <?= $order['payment_status'] === 'paid' ? 'badge-success' : 'badge-pending' ?>" style="display:inline-block;margin-top:4px;font-size:10px;">
                                                    <?= $order['payment_status'] === 'paid' ? 'Đã thanh toán' : 'Chưa thanh toán' ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="font-bold text-danger" style="font-size:15px;">
                                                    <?= format_money($order['total_amount']) ?>
                                                </div>
                                                <?php if ((float)$order['shipping_fee'] > 0): ?>
                                                    <small style="color:#64748b;font-size:11px;">Ship: <?= format_money($order['shipping_fee']) ?></small>
                                                <?php else: ?>
                                                    <small style="color:#16a34a;font-size:11px;">Freeship</small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php
                                                    $statusMap = [
                                                        'pending'    => ['label' => 'Chờ xác nhận', 'class' => 'badge-pending'],
                                                        'confirmed'  => ['label' => 'Đã xác nhận',  'class' => 'badge-info'],
                                                        'processing' => ['label' => 'Đang xử lý',   'class' => 'badge-warning'],
                                                        'shipping'   => ['label' => 'Đang giao',     'class' => 'badge-primary'],
                                                        'completed'  => ['label' => 'Hoàn thành',   'class' => 'badge-success'],
                                                        'cancelled'  => ['label' => 'Đã hủy',       'class' => 'badge-danger'],
                                                        'refunded'   => ['label' => 'Hoàn tiền',     'class' => 'badge-secondary']
                                                    ];
                                                    $st = $statusMap[$order['status']] ?? ['label' => $order['status'], 'class' => 'badge-secondary'];
                                                ?>
                                                <span class="status-badge <?= $st['class'] ?>"><?= $st['label'] ?></span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="empty-box">
                            <i class="fa-solid fa-boxes-packing empty-icon"></i>
                            <p>Bạn chưa có lịch sử mua hàng nào tại LongTech.</p>
                            <a href="<?= APP_URL ?>" class="btn-primary-tech" style="margin-top: 14px; display: inline-block;">Khám phá các thiết bị công nghệ mới</a>
                        </div>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
</div>

