<?php
/**
 * ========================================================
 * LONGTECH - TỔNG QUAN TÀI KHOẢN (dashboard.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="profile-page-wrapper">
    <div class="container">
        <div class="profile-layout">
            <!-- 1. SIDEBAR ĐIỀU HƯỚNG TÀI KHOẢN -->
            <aside class="profile-sidebar">
                <div class="user-card-mini">
                    <div class="user-avatar-large">
                        <?= strtoupper(substr(e($user['full_name'] ?? 'U'), 0, 1)) ?>
                    </div>
                    <div class="user-meta-info">
                        <h3 class="user-name"><?= e($user['full_name']) ?></h3>
                        <span class="user-email"><?= e($user['email']) ?></span>
                        <span class="user-role-badge"><i class="fa-solid fa-gem text-warning"></i> <?= e($user['role_display'] ?? 'Khách hàng') ?></span>
                    </div>
                </div>

                <ul class="profile-menu">
                    <li>
                        <a href="<?= APP_URL ?>/tai-khoan" class="profile-menu-item <?= ($activeTab ?? '') === 'dashboard' ? 'active' : '' ?>">
                            <i class="fa-solid fa-gauge-high"></i> Tổng quan tài khoản
                        </a>
                    </li>
                    <li>
                        <a href="<?= APP_URL ?>/tai-khoan/don-hang" class="profile-menu-item <?= ($activeTab ?? '') === 'orders' ? 'active' : '' ?>">
                            <i class="fa-solid fa-boxes-packing"></i> Đơn hàng của tôi
                            <span class="badge-count"><?= $totalOrders ?? 0 ?></span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= APP_URL ?>/tai-khoan/cai-dat" class="profile-menu-item <?= ($activeTab ?? '') === 'settings' ? 'active' : '' ?>">
                            <i class="fa-solid fa-gear"></i> Cài đặt & Đổi mật khẩu
                        </a>
                    </li>
                    <?php if (in_array(current_role(), ['super_admin', 'admin', 'product_manager', 'order_manager'])): ?>
                        <li>
                            <a href="<?= APP_URL ?>/admin.php" class="profile-menu-item admin-access-item" target="_blank">
                                <i class="fa-solid fa-shield-halved"></i> Trang Quản Trị Hệ Thống
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="menu-divider"></li>
                    <li>
                        <a href="<?= APP_URL ?>/dang-xuat" class="profile-menu-item text-danger">
                            <i class="fa-solid fa-right-from-bracket"></i> Đăng xuất tài khoản
                        </a>
                    </li>
                </ul>
            </aside>

            <!-- 2. KHU VỰC NỘI DUNG TỔNG QUAN -->
            <main class="profile-content">
                <div class="content-header">
                    <h2 class="content-title">Chào mừng trở lại, <?= e($user['full_name']) ?>!</h2>
                    <p class="content-subtitle">Theo dõi trạng thái đơn hàng và các hoạt động mua sắm công nghệ của bạn.</p>
                </div>

                <!-- Thẻ thống kê nhanh -->
                <div class="stats-cards-grid">
                    <div class="stat-card">
                        <div class="stat-icon icon-blue"><i class="fa-solid fa-bag-shopping"></i></div>
                        <div class="stat-data">
                            <span class="stat-number"><?= $totalOrders ?></span>
                            <span class="stat-label">Tổng số đơn hàng</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon icon-green"><i class="fa-solid fa-money-bill-trend-up"></i></div>
                        <div class="stat-data">
                            <span class="stat-number"><?= format_money($totalSpent) ?></span>
                            <span class="stat-label">Tổng chi tiêu tích lũy</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon icon-orange"><i class="fa-solid fa-shield-heart"></i></div>
                        <div class="stat-data">
                            <span class="stat-number">Hạng Bạc</span>
                            <span class="stat-label">Cấp bậc thành viên</span>
                        </div>
                    </div>
                </div>

                <!-- Thông tin cá nhân tóm tắt -->
                <div class="profile-card-box">
                    <div class="card-box-header">
                        <h4><i class="fa-regular fa-address-card text-primary"></i> Thông Tin Liên Hệ Của Bạn</h4>
                        <a href="<?= APP_URL ?>/tai-khoan/cai-dat" class="link-edit"><i class="fa-solid fa-pen"></i> Chỉnh sửa</a>
                    </div>
                    <div class="user-info-list">
                        <div class="info-row">
                            <span class="info-label">Họ và tên:</span>
                            <span class="info-value font-bold"><?= e($user['full_name']) ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Tên đăng nhập:</span>
                            <span class="info-value">@<?= e($user['username']) ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Email:</span>
                            <span class="info-value"><?= e($user['email']) ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Số điện thoại:</span>
                            <span class="info-value"><?= e($user['phone'] ?: 'Chưa cập nhật') ?></span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Địa chỉ mặc định:</span>
                            <span class="info-value"><?= e($user['address'] ?: 'Chưa cập nhật địa chỉ giao hàng') ?></span>
                        </div>
                    </div>
                </div>

                <!-- Đơn hàng gần đây -->
                <div class="profile-card-box">
                    <div class="card-box-header">
                        <h4><i class="fa-solid fa-clock-rotate-left text-primary"></i> Đơn Hàng Gần Đây</h4>
                        <a href="<?= APP_URL ?>/tai-khoan/don-hang" class="link-edit">Xem tất cả đơn hàng</a>
                    </div>

                    <?php if (!empty($orders)): ?>
                        <div class="table-responsive">
                            <table class="profile-table">
                                <thead>
                                    <tr>
                                        <th>Mã Đơn</th>
                                        <th>Ngày Đặt</th>
                                        <th>Tổng Tiền</th>
                                        <th>Trạng Thái</th>
                                        <th>Thanh Toán</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($orders as $order): ?>
                                        <tr>
                                            <td class="font-bold text-primary"><?= e($order['order_code']) ?></td>
                                            <td><?= date('d/m/Y H:i', strtotime($order['created_at'])) ?></td>
                                            <td class="font-bold text-danger"><?= format_money($order['total_amount']) ?></td>
                                            <td>
                                                <?php
                                                    $statusMap = [
                                                        'pending'    => ['label' => 'Chờ xác nhận', 'class' => 'badge-pending'],
                                                        'confirmed'  => ['label' => 'Đã xác nhận',  'class' => 'badge-info'],
                                                        'processing' => ['label' => 'Đang xử lý',   'class' => 'badge-warning'],
                                                        'shipping'   => ['label' => 'Đang giao',     'class' => 'badge-primary'],
                                                        'completed'  => ['label' => 'Hoàn thành',   'class' => 'badge-success'],
                                                        'cancelled'  => ['label' => 'Đã hủy',       'class' => 'badge-danger'],
                                                        'refunded'   => ['label' => 'Hoàn tiền',     'class' => 'badge-secondary']
                                                    ];
                                                    $st = $statusMap[$order['status']] ?? ['label' => $order['status'], 'class' => 'badge-secondary'];
                                                ?>
                                                <span class="status-badge <?= $st['class'] ?>"><?= $st['label'] ?></span>
                                            </td>
                                            <td>
                                                <span class="pay-method-badge"><?= strtoupper($order['payment_method']) ?></span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="empty-box">
                            <i class="fa-solid fa-cart-arrow-down empty-icon"></i>
                            <p>Bạn chưa có đơn đặt hàng nào tại LongTech.</p>
                            <a href="<?= APP_URL ?>" class="btn-primary-tech" style="margin-top: 12px; display: inline-block;">Khám phá sản phẩm ngay</a>
                        </div>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
</div>

