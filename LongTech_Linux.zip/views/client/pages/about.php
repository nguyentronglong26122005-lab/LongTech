<?php
/**
 * ========================================================
 * LONGTECH - GIỚI THIỆU & CƠ CẤU TỔ CHỨC CÁC BỘ PHẬN (about.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

$departments = $departments ?? [];
$groups = [
    'all'     => 'Tất cả bộ phận',
    'core'    => 'Khối cốt lõi',
    'ops'     => 'Khối vận hành & dịch vụ',
    'support' => 'Khối hỗ trợ',
];
?>
<div class="about-page">
    <!-- 1. HERO GIỚI THIỆU -->
    <section class="about-hero">
        <div class="container">
            <nav class="breadcrumb-nav about-bc">
                <a href="<?= APP_URL ?>"><i class="fa-solid fa-house"></i> Trang chủ</a>
                <span class="bc-sep">/</span>
                <span class="bc-current">Giới thiệu &amp; Cơ cấu tổ chức</span>
            </nav>
            <div class="about-hero-grid">
                <div>
                    <span class="about-eyebrow">VỀ LONGTECH</span>
                    <h1>Hệ thống bán lẻ công nghệ chính hãng<br>vận hành bởi <span><?= count($departments) ?> bộ phận chuyên trách</span></h1>
                    <p>Mỗi đơn hàng tại LongTech là kết quả phối hợp của nhiều đội ngũ: từ Ban điều hành hoạch định chiến lược, đội Công nghệ giữ website nhanh &amp; an toàn, Marketing mang ưu đãi đến bạn, Kho vận giao hàng 2H cho tới Chăm sóc khách hàng đồng hành sau mua.</p>
                    <div class="about-hero-actions">
                        <a href="#departments" class="about-btn primary"><i class="fa-solid fa-sitemap"></i> Xem các bộ phận</a>
                        <a href="<?= APP_URL ?>/hoi-dap" class="about-btn ghost"><i class="fa-regular fa-circle-question"></i> Câu hỏi thường gặp</a>
                    </div>
                </div>
                <div class="about-stats">
                    <div class="about-stat"><strong><?= count($departments) ?></strong><span>Bộ phận chuyên trách</span></div>
                    <div class="about-stat"><strong>250+</strong><span>Nhân sự toàn hệ thống</span></div>
                    <div class="about-stat"><strong>24/7</strong><span>Hỗ trợ khách hàng</span></div>
                    <div class="about-stat"><strong>99.9%</strong><span>Uptime website</span></div>
                </div>
            </div>
        </div>
    </section>

    <!-- 2. SƠ ĐỒ TỔ CHỨC -->
    <section class="container about-section">
        <div class="about-section-head">
            <h2><i class="fa-solid fa-diagram-project"></i> Sơ đồ tổ chức</h2>
            <p>Mô hình quản trị theo khối chức năng, báo cáo trực tiếp về Ban Giám đốc.</p>
        </div>
        <div class="org-chart">
            <div class="org-top">
                <div class="org-node ceo">
                    <i class="fa-solid fa-crown"></i>
                    <strong>Hội đồng quản trị &amp; Ban Giám đốc (CEO)</strong>
                    <small>Chiến lược • Ngân sách • Quyết định trọng yếu</small>
                </div>
            </div>
            <div class="org-branches">
                <?php foreach (['core' => 'fa-bolt', 'ops' => 'fa-truck-fast', 'support' => 'fa-life-ring'] as $gKey => $gIcon): ?>
                    <div class="org-branch">
                        <div class="org-node group-<?= $gKey ?>">
                            <i class="fa-solid <?= $gIcon ?>"></i>
                            <strong><?= e($groups[$gKey]) ?></strong>
                        </div>
                        <ul class="org-children">
                            <?php foreach ($departments as $d): if ($d['group'] !== $gKey) continue; ?>
                                <li><a href="#dept-<?= e($d['key']) ?>"><i class="fa-solid <?= e($d['icon']) ?>" style="color:<?= e($d['color']) ?>"></i> <?= e($d['name']) ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- 3. DANH SÁCH BỘ PHẬN CHI TIẾT -->
    <section class="container about-section" id="departments">
        <div class="about-section-head with-tabs">
            <div>
                <h2><i class="fa-solid fa-people-group"></i> Chức năng &amp; nhiệm vụ từng bộ phận</h2>
                <p>Bấm vào thẻ để xem đầy đủ nhiệm vụ, chỉ số KPI và kênh liên hệ trực tiếp.</p>
            </div>
            <div class="dept-filter-tabs">
                <?php foreach ($groups as $gKey => $gLabel): ?>
                    <button type="button" class="dept-tab <?= $gKey === 'all' ? 'active' : '' ?>" data-group="<?= $gKey ?>"><?= e($gLabel) ?></button>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="dept-grid">
            <?php foreach ($departments as $d): ?>
                <article class="dept-card" id="dept-<?= e($d['key']) ?>" data-group="<?= e($d['group']) ?>" style="--dept-color: <?= e($d['color']) ?>;">
                    <div class="dept-card-head">
                        <div class="dept-icon"><i class="fa-solid <?= e($d['icon']) ?>"></i></div>
                        <div class="dept-title">
                            <span class="dept-group-tag"><?= e($groups[$d['group']]) ?></span>
                            <h3><?= e($d['name']) ?></h3>
                            <small><i class="fa-solid fa-user-tie"></i> <?= e($d['lead']) ?></small>
                        </div>
                        <?php if (!empty($d['new'])): ?><span class="dept-new-badge">BỔ SUNG</span><?php endif; ?>
                    </div>

                    <p class="dept-summary"><?= e($d['summary']) ?></p>

                    <ul class="dept-tasks">
                        <?php foreach ($d['tasks'] as $i => $t): ?>
                            <li class="<?= $i >= 3 ? 'is-extra' : '' ?>"><i class="fa-solid fa-circle-check"></i> <span><?= $t ?></span></li>
                        <?php endforeach; ?>
                    </ul>

                    <div class="dept-extra">
                        <div class="dept-kpis">
                            <?php foreach ($d['kpis'] as $k): ?>
                                <span class="dept-kpi"><i class="fa-solid fa-chart-line"></i> <?= e($k) ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="dept-card-foot">
                        <button type="button" class="dept-toggle" onclick="toggleDeptCard(this)">
                            <span>Xem thêm</span> <i class="fa-solid fa-chevron-down"></i>
                        </button>
                        <div class="dept-actions">
                            <a href="mailto:<?= e($d['email']) ?>" class="dept-mail" title="Gửi email cho bộ phận"><i class="fa-regular fa-envelope"></i></a>
                            <?php if (!empty($d['link'])): ?>
                                <a href="<?= APP_URL . e($d['link']['url']) ?>" class="dept-link"><?= e($d['link']['label']) ?> <i class="fa-solid fa-arrow-right"></i></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- 4. QUY TRÌNH PHỐI HỢP GIỮA CÁC BỘ PHẬN -->
    <section class="container about-section">
        <div class="about-section-head">
            <h2><i class="fa-solid fa-arrows-spin"></i> Hành trình một đơn hàng qua các bộ phận</h2>
            <p>Các bộ phận phối hợp liên tục để đơn hàng của bạn được xử lý nhanh, chính xác và minh bạch.</p>
        </div>
        <div class="flow-steps">
            <?php
            $flow = [
                ['fa-bullhorn',        '#db2777', 'Tiếp thị',       'SEO, quảng cáo & email đưa ưu đãi tới khách hàng'],
                ['fa-laptop-code',     '#2563eb', 'Công nghệ',      'Website tải nhanh, thanh toán online an toàn'],
                ['fa-handshake',       '#ea580c', 'Kinh doanh',     'Xác nhận đơn, tư vấn cấu hình & trả góp'],
                ['fa-warehouse',       '#0891b2', 'Kho vận',        'Xuất kho, đóng gói, giao hỏa tốc 2H'],
                ['fa-file-invoice',    '#16a34a', 'Kế toán',        'Đối soát thanh toán, xuất hoá đơn VAT điện tử'],
                ['fa-headset',         '#D70018', 'CSKH',           'Hỏi thăm sau mua, xử lý đổi trả & khiếu nại'],
                ['fa-screwdriver-wrench','#7c3aed','LongCare',      'Bảo hành, sửa chữa, thu cũ đổi mới'],
            ];
            foreach ($flow as $idx => $f): ?>
                <div class="flow-step">
                    <span class="flow-num"><?= $idx + 1 ?></span>
                    <div class="flow-icon" style="background:<?= $f[1] ?>1a; color:<?= $f[1] ?>;"><i class="fa-solid <?= $f[0] ?>"></i></div>
                    <strong><?= $f[2] ?></strong>
                    <small><?= $f[3] ?></small>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- 5. CTA LIÊN HỆ -->
    <section class="container about-section">
        <div class="about-cta-grid">
            <a href="<?= APP_URL ?>/hoi-dap" class="about-cta red">
                <i class="fa-regular fa-circle-question"></i>
                <div><strong>Trung tâm Hỏi đáp (FAQ)</strong><small>Tự giải đáp nhanh 30+ câu hỏi phổ biến</small></div>
            </a>
            <a href="<?= APP_URL ?>/lien-he" class="about-cta blue">
                <i class="fa-solid fa-headset"></i>
                <div><strong>Liên hệ Chăm sóc khách hàng</strong><small>Hotline <?= HOTLINE ?> • Email • Live chat</small></div>
            </a>
            <a href="<?= APP_URL ?>/tuyen-dung" class="about-cta dark">
                <i class="fa-solid fa-user-plus"></i>
                <div><strong>Gia nhập đội ngũ LongTech</strong><small>Xem các vị trí đang tuyển dụng</small></div>
            </a>
        </div>
    </section>
</div>

<script>
    (function () {
        const tabs = document.querySelectorAll('.dept-tab');
        const cards = document.querySelectorAll('.dept-card');
        tabs.forEach(function (tab) {
            tab.addEventListener('click', function () {
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                const g = tab.dataset.group;
                cards.forEach(function (c) {
                    c.style.display = (g === 'all' || c.dataset.group === g) ? '' : 'none';
                });
            });
        });

        // Tự động mở & làm nổi bật thẻ khi bấm từ sơ đồ tổ chức
        function highlightFromHash() {
            if (!location.hash.startsWith('#dept-')) return;
            const card = document.querySelector(location.hash);
            if (!card) return;
            card.style.display = '';
            card.classList.add('expanded', 'flash');
            const btn = card.querySelector('.dept-toggle span');
            if (btn) btn.textContent = 'Thu gọn';
            setTimeout(() => card.classList.remove('flash'), 1800);
        }
        window.addEventListener('hashchange', highlightFromHash);
        highlightFromHash();
    })();

    function toggleDeptCard(btn) {
        const card = btn.closest('.dept-card');
        const expanded = card.classList.toggle('expanded');
        btn.querySelector('span').textContent = expanded ? 'Thu gọn' : 'Xem thêm';
    }
</script>

