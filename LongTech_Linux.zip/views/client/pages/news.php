<?php
/**
 * ========================================================
 * LONGTECH - CHUYÊN TRANG REVIEW & BẢN TIN CÔNG NGHỆ LONGSTUDIO (news.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

// Bổ sung các bài review chuyên sâu mặc định nếu cần tra cứu theo slug hoặc làm phong phú chuyên trang
$defaultExtraPosts = [
    'danh-gia-iphone-15-pro-max-titan-tu-nhien' => [
        'id' => 101,
        'title' => 'Đánh giá chi tiết iPhone 15 Pro Max Titan Tự Nhiên: Cầm nhẹ tay, chip A17 Pro quá mạnh, Camera zoom 5x đỉnh cao',
        'slug' => 'danh-gia-iphone-15-pro-max-titan-tu-nhien',
        'summary' => 'Trải nghiệm thực tế khung viền Titanium cấp hàng không vũ trụ, nút Action Button đa năng, cổng USB-C 10Gbps và khả năng quay video ProRes Log.',
        'thumbnail' => APP_URL . '/assets/uploads/products/1793809755_2716485aa03a.png',
        'author_name' => 'LongStudio Reviewer',
        'created_at' => '2026-11-05 09:30:00',
        'product_slug' => 'iphone-15-pro-max-256gb',
        'content' => '
            <p><strong>iPhone 15 Pro Max</strong> là bước nhảy vọt lớn nhất của Apple trong 3 năm trở lại đây khi thay thế khung thép không gỉ bằng vật liệu <strong>Titanium Grade 5</strong> siêu bền nhẹ, giảm gần 20 gram trọng lượng giúp cảm giác cầm nắm thoải mái suốt cả ngày.</p>
            <h3>1. Thiết kế Titanium & Cổng USB-C tiện lợi</h3>
            <p>Viền màn hình được thu gọn mỏng nhất lịch sử iPhone kết hợp phần cạnh bo cong nhẹ không còn cấn tay. Việc chuyển sang cổng USB-C tốc độ 10Gbps giúp truyền file video 4K ProRes sang ổ cứng SSD gắn ngoài chỉ trong tích tắc.</p>
            <h3>2. Hiệu năng Apple A17 Pro (3nm) & Camera Telephoto 5x</h3>
            <p>Con chip 3nm đầu tiên trên thế giới mang lại hiệu suất GPU vượt trội cùng công nghệ Ray Tracing phần cứng. Đặc biệt, cụm ống kính tiềm vọng 5x (tiêu cự 120mm) trên bản Pro Max cho ra những bức ảnh chân dung và chụp xa sắc nét đáng kinh ngạc kể cả trong điều kiện thiếu sáng.</p>
        '
    ],
    'danh-gia-macbook-air-m3-13-inch-2026' => [
        'id' => 102,
        'title' => 'Review MacBook Air M3 13 inch: Chiếc Ultrabook hoàn hảo nhất cho công việc và sáng tạo nội dung',
        'slug' => 'danh-gia-macbook-air-m3-13-inch-2026',
        'summary' => 'Thời lượng pin thực tế lên tới 18 giờ, thiết kế mỏng nhẹ không quạt tản nhiệt tuyệt đối yên tĩnh và hỗ trợ xuất 2 màn hình rời.',
        'thumbnail' => APP_URL . '/assets/uploads/products/1793809665_fa4c6018757d.png',
        'author_name' => 'LongStudio Reviewer',
        'created_at' => '2026-11-04 14:15:00',
        'product_slug' => 'macbook-air-m3-13-inch-8gb-256gb',
        'content' => '
            <p><strong>MacBook Air M3</strong> tiếp tục khẳng định vị thế ông vua phân khúc laptop mỏng nhẹ cao cấp nhờ sự kết hợp hoàn hảo giữa thiết kế nhôm nguyên khối siêu mỏng 11.3mm, màn hình Liquid Retina rực rỡ và sức mạnh từ chip Apple M3.</p>
            <h3>1. Hiệu năng M3 vượt trội & Hỗ trợ 2 màn hình ngoài</h3>
            <p>Nhờ tiến trình 3nm thế hệ mới, MacBook Air M3 xử lý mượt mà các tác vụ lập trình, dựng video 4K trên Final Cut Pro, chỉnh sửa hàng trăm bức ảnh RAW trên Lightroom mà máy vẫn mát mẻ hoàn toàn không tiếng ồn.</p>
            <h3>2. Thời lượng pin cả ngày dài không cần mang sạc</h3>
            <p>Qua bài test thực tế tại LongStudio với độ sáng 70% làm việc văn phòng và lướt web liên tục, máy trụ vững hơn 15–18 tiếng cùng sạc nhanh MagSafe 3 vô cùng an toàn.</p>
        '
    ]
];

// Ghép bài viết từ CSDL và bài viết bổ sung
$allPosts = $posts ?? [];
$existingSlugs = array_column($allPosts, 'slug');
foreach ($defaultExtraPosts as $slugKey => $extraPost) {
    if (!in_array($slugKey, $existingSlugs, true)) {
        $allPosts[] = $extraPost;
    }
}

// Nếu đang xem chi tiết 1 bài viết mà chưa tìm thấy trong DB, kiểm tra trong $defaultExtraPosts
if (empty($currentPost) && !empty($postSlug) && isset($defaultExtraPosts[$postSlug])) {
    $currentPost = $defaultExtraPosts[$postSlug];
}
?>

<div class="longstudio-review-page" style="background:#f8fafc; padding: 28px 0 60px;">
    <div class="container">
        <!-- BREADCRUMB -->
        <nav class="breadcrumb-nav" style="margin-bottom:20px;">
            <a href="<?= APP_URL ?>"><i class="fa-solid fa-house"></i> Trang chủ</a>
            <span class="bc-sep">/</span>
            <?php if (!empty($currentPost)): ?>
                <a href="<?= APP_URL ?>/tin-tuc">LongStudio Review & Đánh Giá SP</a>
                <span class="bc-sep">/</span>
                <span class="bc-current"><?= e($currentPost['title']) ?></span>
            <?php else: ?>
                <span class="bc-current">LongStudio 🎥 - Chuyên Trang Review & Đánh Giá Sản Phẩm</span>
            <?php endif; ?>
        </nav>

        <?php if (!empty($currentPost)): ?>
            <!-- =========================================================
                 CHẾ ĐỘ 1: XEM CHI TIẾT BÀI VIẾT REVIEW SẢN PHẨM
                 ========================================================= -->
            <?php
            // Tìm sản phẩm gợi ý tương ứng với bài viết
            $linkedProdSlug = $currentPost['product_slug'] ?? '';
            if (empty($linkedProdSlug)) {
                if (stripos($currentPost['title'], 'S24 Ultra') !== false) {
                    $linkedProdSlug = 'samsung-galaxy-s24-ultra-5g-256gb';
                } elseif (stripos($currentPost['title'], 'laptop') !== false) {
                    $linkedProdSlug = 'dell-xps-13-plus-9320-i7-16gb-512gb';
                } else {
                    $linkedProdSlug = 'iphone-15-pro-max-256gb';
                }
            }
            ?>
            <div style="display:grid; grid-template-columns: minmax(0, 2.2fr) minmax(280px, 1fr); gap:28px; align-items:start;">
                <!-- Cột nội dung chính -->
                <article style="background:#fff; border-radius:16px; overflow:hidden; box-shadow:0 8px 24px rgba(15,23,42,0.06); border:1px solid #e2e8f0;">
                    <div style="position:relative; background:#0f172a; max-height:420px; overflow:hidden; display:flex; align-items:center; justify-content:center;">
                        <img src="<?= e($currentPost['thumbnail']) ?>" alt="<?= e($currentPost['title']) ?>" style="width:100%; max-height:420px; object-fit:contain; background:#fff; padding:16px;">
                        <span style="position:absolute; top:16px; left:16px; background:#D70018; color:#fff; padding:6px 14px; border-radius:20px; font-size:12px; font-weight:700;">
                            🎥 LONGSTUDIO REVIEW CHUYÊN SÂU
                        </span>
                    </div>

                    <div style="padding:32px;">
                        <div style="display:flex; flex-wrap:wrap; gap:16px; color:#64748b; font-size:13px; margin-bottom:14px;">
                            <span><i class="fa-solid fa-user-check" style="color:#D70018;"></i> Tác giả: <strong><?= e($currentPost['author_name'] ?? 'Ban Biên Tập LongStudio') ?></strong></span>
                            <span><i class="fa-regular fa-calendar"></i> <?= date('d/m/Y H:i', strtotime($currentPost['created_at'] ?? 'now')) ?></span>
                            <span style="color:#16a34a; font-weight:600;"><i class="fa-solid fa-star" style="color:#f59e0b;"></i> Điểm đánh giá LongStudio: 9.6 / 10</span>
                        </div>

                        <h1 style="font-size:26px; line-height:1.35; color:#0f172a; margin-bottom:18px; font-weight:800;">
                            <?= e($currentPost['title']) ?>
                        </h1>

                        <!-- Hộp chấm điểm nhanh LongStudio -->
                        <div style="background:linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color:#fff; border-radius:14px; padding:20px 24px; margin-bottom:24px; display:flex; flex-wrap:wrap; gap:20px; align-items:center; justify-content:space-between;">
                            <div>
                                <div style="font-size:12px; text-transform:uppercase; letter-spacing:1px; color:#38bdf8; font-weight:700;">Đánh giá tổng thể bởi LongStudio Lab</div>
                                <div style="font-size:15px; color:#e2e8f0; margin-top:4px;"><?= e($currentPost['summary']) ?></div>
                            </div>
                            <div style="display:flex; gap:10px; flex-shrink:0;">
                                <a href="<?= APP_URL ?>/san-pham/<?= e($linkedProdSlug) ?>" style="background:#D70018; color:#fff; padding:10px 18px; border-radius:10px; text-decoration:none; font-weight:700; font-size:13px;">
                                    <i class="fa-solid fa-bag-shopping"></i> Xem Giá & Mua SP
                                </a>
                                <a href="<?= APP_URL ?>/san-pham/<?= e($linkedProdSlug) ?>#reviewsTab" style="background:#334155; color:#fff; padding:10px 18px; border-radius:10px; text-decoration:none; font-weight:700; font-size:13px; border:1px solid #475569;">
                                    <i class="fa-solid fa-comments"></i> Viết Đánh Giá SP
                                </a>
                            </div>
                        </div>

                        <!-- Nội dung chi tiết bài đánh giá -->
                        <div class="post-article-body" style="font-size:16px; line-height:1.8; color:#334155;">
                            <?= $currentPost['content'] ?>
                            <div style="background:#f8fafc; border-left:4px solid #D70018; padding:18px 20px; border-radius:0 12px 12px 0; margin-top:24px;">
                                <h4 style="margin:0 0 8px; color:#0f172a; font-size:16px;"><i class="fa-solid fa-award" style="color:#D70018;"></i> Kết luận từ LongStudio:</h4>
                                <p style="margin:0; font-size:14.5px; color:#475569;">
                                    Sản phẩm hiện đang có sẵn hàng chính hãng VN/A tại toàn bộ hệ thống <strong>LongTech</strong> với ưu đãi trả góp 0%, bảo hành 1 đổi 1 trong 30 ngày và giảm thêm đến 2.500.000đ khi thu cũ đổi mới.
                                </p>
                            </div>
                        </div>

                        <div style="margin-top:28px; padding-top:20px; border-top:1px solid #e2e8f0; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
                            <a href="<?= APP_URL ?>/tin-tuc" style="color:#0284c7; font-weight:700; text-decoration:none; font-size:14px;">
                                <i class="fa-solid fa-arrow-left"></i> Quay lại danh sách Review
                            </a>
                            <a href="<?= APP_URL ?>/san-pham/<?= e($linkedProdSlug) ?>#reviewsTab" style="background:#0A2540; color:#fff; padding:10px 20px; border-radius:10px; text-decoration:none; font-weight:700; font-size:14px;">
                                <i class="fa-solid fa-star" style="color:#f59e0b;"></i> Xem & Gửi Đánh Giá Cho Sản Phẩm Này
                            </a>
                        </div>
                    </div>
                </article>

                <!-- Cột phải: Các bài review khác & Sản phẩm nổi bật -->
                <aside style="display:flex; flex-direction:column; gap:20px;">
                    <div style="background:#fff; border-radius:16px; padding:22px; border:1px solid #e2e8f0; box-shadow:0 4px 16px rgba(15,23,42,0.04);">
                        <h3 style="font-size:17px; font-weight:800; color:#0f172a; margin:0 0 16px; padding-bottom:10px; border-bottom:2px solid #f1f5f9;">
                            <i class="fa-solid fa-fire text-danger"></i> Bài Viết Review Khác
                        </h3>
                        <div style="display:flex; flex-direction:column; gap:14px;">
                            <?php foreach ($allPosts as $p): ?>
                                <?php if (($p['slug'] ?? '') === ($currentPost['slug'] ?? '')) continue; ?>
                                <a href="<?= APP_URL ?>/tin-tuc/<?= e($p['slug']) ?>" style="display:flex; gap:12px; text-decoration:none; color:inherit; align-items:center;">
                                    <img src="<?= e($p['thumbnail']) ?>" alt="<?= e($p['title']) ?>" style="width:68px; height:68px; border-radius:10px; object-fit:cover; flex-shrink:0; border:1px solid #e2e8f0;">
                                    <div>
                                        <div style="font-size:13.5px; font-weight:700; color:#1e293b; line-height:1.4; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;">
                                            <?= e($p['title']) ?>
                                        </div>
                                        <small style="color:#64748b; font-size:11.5px;"><i class="fa-regular fa-clock"></i> <?= date('d/m/Y', strtotime($p['created_at'] ?? 'now')) ?></small>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </aside>
            </div>

        <?php else: ?>
            <!-- =========================================================
                 CHẾ ĐỘ 2: TRANG CHỦ LONGSTUDIO - REVIEW & ĐÁNH GIÁ SP
                 ========================================================= -->
            <!-- HERO BANNER LONGSTUDIO -->
            <div style="background:linear-gradient(135deg, #0A2540 0%, #1e293b 60%, #7f1d1d 100%); border-radius:20px; padding:36px 32px; color:#fff; margin-bottom:32px; display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:24px; box-shadow:0 12px 32px rgba(10,37,64,0.18);">
                <div style="max-width:680px;">
                    <span style="display:inline-block; background:#D70018; color:#fff; padding:5px 14px; border-radius:20px; font-size:12px; font-weight:800; letter-spacing:0.5px; margin-bottom:12px;">
                        LONGSTUDIO 🎥 CHUYÊN TRANG REVIEW CÔNG NGHỆ
                    </span>
                    <h1 style="font-size:30px; font-weight:900; margin:0 0 10px; line-height:1.25;">
                        Review Thực Tế & Đánh Giá Sản Phẩm Chính Hãng
                    </h1>
                    <p style="margin:0; color:#cbd5e1; font-size:15px; line-height:1.6;">
                        Tổng hợp các bài đánh giá hiệu năng, camera, thời lượng pin chuyên sâu từ đội ngũ <strong>LongStudio</strong> và nhận xét thực tế từ khách hàng đã mua sắm tại LongTech.
                    </p>
                </div>
                <div style="display:flex; gap:12px; flex-wrap:wrap;">
                    <a href="#productReviewsSection" style="background:#fff; color:#0A2540; padding:12px 22px; border-radius:12px; font-weight:800; font-size:14px; text-decoration:none; box-shadow:0 4px 12px rgba(0,0,0,0.15);">
                        <i class="fa-solid fa-star" style="color:#f59e0b;"></i> Chấm Điểm & Review Sản Phẩm
                    </a>
                </div>
            </div>

            <!-- 1. DANH SÁCH BÀI VIẾT REVIEW CHUYÊN SÂU -->
            <div style="margin-bottom:44px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap:wrap; gap:10px;">
                    <div>
                        <h2 style="font-size:22px; font-weight:800; color:#0f172a; margin:0;">
                            <i class="fa-solid fa-video text-danger"></i> Bài Viết Review & Đánh Giá Chuyên Sâu
                        </h2>
                        <p style="margin:4px 0 0; font-size:13.5px; color:#64748b;">Bấm vào bài viết bất kỳ để đọc bài đánh giá chi tiết từ LongStudio</p>
                    </div>
                </div>

                <div class="news-grid" style="display:grid; grid-template-columns:repeat(auto-fill, minmax(280px, 1fr)); gap:22px;">
                    <?php foreach ($allPosts as $post): ?>
                        <article class="news-card" style="background:#fff; border-radius:14px; overflow:hidden; border:1px solid #e2e8f0; display:flex; flex-direction:column; transition:transform 0.2s, box-shadow 0.2s;">
                            <a href="<?= APP_URL ?>/tin-tuc/<?= e($post['slug']) ?>" class="news-thumb-wrap" style="display:block; height:190px; overflow:hidden; background:#f8fafc;">
                                <img src="<?= e($post['thumbnail']) ?>" alt="<?= e($post['title']) ?>" style="width:100%; height:100%; object-fit:contain; padding:8px; background:#fff;">
                            </a>
                            <div class="news-content" style="padding:18px; display:flex; flex-direction:column; flex:1;">
                                <div class="news-meta" style="display:flex; gap:12px; font-size:12px; color:#64748b; margin-bottom:8px;">
                                    <span><i class="fa-regular fa-clock"></i> <?= date('d/m/Y', strtotime($post['created_at'] ?? 'now')) ?></span>
                                    <span style="color:#D70018; font-weight:700;"><i class="fa-solid fa-circle-check"></i> LongStudio Review</span>
                                </div>
                                <h3 class="news-title" style="font-size:16px; font-weight:800; margin:0 0 10px; line-height:1.4;">
                                    <a href="<?= APP_URL ?>/tin-tuc/<?= e($post['slug']) ?>" style="color:#0f172a; text-decoration:none;"><?= e($post['title']) ?></a>
                                </h3>
                                <p class="news-summary" style="font-size:13.5px; color:#475569; line-height:1.55; margin:0 0 16px; flex:1;">
                                    <?= e(truncate_words($post['summary'] ?? '', 22)) ?>
                                </p>
                                <a href="<?= APP_URL ?>/tin-tuc/<?= e($post['slug']) ?>" style="display:inline-flex; align-items:center; gap:6px; color:#D70018; font-weight:700; font-size:13.5px; text-decoration:none;">
                                    Xem bài đánh giá chi tiết <i class="fa-solid fa-arrow-right"></i>
                                </a>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- 2. BẢNG XẾP HẠNG & REVIEW TRỰC TIẾP TỪNG SẢN PHẨM -->
            <div id="productReviewsSection" style="margin-bottom:44px;">
                <div style="margin-bottom:20px;">
                    <h2 style="font-size:22px; font-weight:800; color:#0f172a; margin:0;">
                        <i class="fa-solid fa-star" style="color:#f59e0b;"></i> Chọn Sản Phẩm Để Xem & Viết Đánh Giá (Review SP)
                    </h2>
                    <p style="margin:4px 0 0; font-size:13.5px; color:#64748b;">
                        Bấm vào nút <strong>"Xem & Viết Review SP"</strong> trên bất kỳ sản phẩm nào để chuyển thẳng tới mục chấm điểm 5 sao và nhận xét của sản phẩm đó
                    </p>
                </div>

                <div class="products-grid">
                    <?php foreach (($featuredProducts ?? []) as $prod): ?>
                        <div class="product-card">
                            <a href="<?= APP_URL ?>/san-pham/<?= e($prod['slug']) ?>#reviewsTab" class="product-thumb-link">
                                <img src="<?= e($prod['thumbnail']) ?>" alt="<?= e($prod['name']) ?>" class="product-thumb" loading="lazy">
                            </a>
                            <div class="product-body">
                                <span class="product-brand"><?= e($prod['brand_name'] ?? 'Chính hãng') ?></span>
                                <h4 class="product-name">
                                    <a href="<?= APP_URL ?>/san-pham/<?= e($prod['slug']) ?>#reviewsTab"><?= e($prod['name']) ?></a>
                                </h4>
                                <div class="product-pricing">
                                    <div class="price-current">
                                        <?= format_money(!empty($prod['sale_price']) ? $prod['sale_price'] : $prod['price']) ?>
                                    </div>
                                </div>
                                <div class="product-rating" style="margin-bottom:10px;">
                                    <div class="stars" style="color:#f59e0b; font-weight:700;">
                                        <i class="fa-solid fa-star"></i>
                                        <span><?= number_format((float)($prod['rating'] ?? 5.0), 1) ?> / 5.0</span>
                                    </div>
                                    <span class="stock-status in-stock">Chính hãng VN/A</span>
                                </div>
                                <div class="product-actions" style="grid-template-columns: 1fr;">
                                    <a href="<?= APP_URL ?>/san-pham/<?= e($prod['slug']) ?>#reviewsTab" class="btn-buy-now" style="text-align:center; display:flex; align-items:center; justify-content:center; gap:6px; padding:10px 14px;">
                                        <i class="fa-solid fa-comments"></i> Xem & Viết Review SP
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- 3. ĐÁNH GIÁ THỰC TẾ MỚI NHẤT TỪ KHÁCH HÀNG -->
            <?php if (!empty($recentReviews)): ?>
                <div style="background:#fff; border-radius:16px; padding:28px; border:1px solid #e2e8f0; box-shadow:0 4px 16px rgba(15,23,42,0.04);">
                    <h2 style="font-size:20px; font-weight:800; color:#0f172a; margin:0 0 18px;">
                        <i class="fa-solid fa-Comment-dots text-primary"></i> Nhận Xét Thực Tế Từ Khách Hàng Đã Mua
                    </h2>
                    <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(300px, 1fr)); gap:18px;">
                        <?php foreach ($recentReviews as $rev): ?>
                            <div style="border:1px solid #e2e8f0; border-radius:12px; padding:16px; background:#f8fafc; display:flex; flex-direction:column; gap:10px;">
                                <div style="display:flex; align-items:center; gap:12px;">
                                    <img src="<?= e($rev['product_thumb']) ?>" alt="<?= e($rev['product_name']) ?>" style="width:52px; height:52px; object-fit:contain; background:#fff; border-radius:8px; padding:4px; border:1px solid #e2e8f0;">
                                    <div>
                                        <a href="<?= APP_URL ?>/san-pham/<?= e($rev['product_slug']) ?>#reviewsTab" style="font-weight:700; color:#0f172a; text-decoration:none; font-size:14px;">
                                            <?= e($rev['product_name']) ?>
                                        </a>
                                        <div style="color:#f59e0b; font-size:12px; margin-top:2px;">
                                            <?php for ($s = 1; $s <= 5; $s++): ?>
                                                <i class="fa-solid fa-star" style="color:<?= $s <= (int)$rev['rating'] ? '#f59e0b' : '#cbd5e1' ?>;"></i>
                                            <?php endfor; ?>
                                            <span style="color:#64748b; margin-left:6px;">bởi <strong><?= e($rev['full_name'] ?: ($rev['username'] ?: 'Khách hàng')) ?></strong></span>
                                        </div>
                                    </div>
                                </div>
                                <p style="margin:0; font-size:13.5px; color:#334155; font-style:italic; line-height:1.5;">
                                    "<?= e($rev['comment']) ?>"
                                </p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

