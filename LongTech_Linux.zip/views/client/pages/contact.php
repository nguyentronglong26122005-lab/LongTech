<?php
/**
 * ========================================================
 * LONGTECH - TRANG LIÊN HỆ & HỖ TRỢ (contact.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

$currentUser = current_user();
?>

<div class="contact-page-wrapper">
    <div class="container">
        <!-- 1. BREADCRUMBS -->
        <nav class="breadcrumb-nav">
            <a href="<?= APP_URL ?>"><i class="fa-solid fa-house"></i> Trang chủ</a>
            <span class="bc-sep">/</span>
            <span class="bc-current">Liên hệ & Hỗ trợ khách hàng</span>
        </nav>

        <div class="contact-header-section text-center">
            <h1 class="contact-main-title">Liên Hệ Với Hệ Thống LongTech</h1>
            <p class="contact-subtitle">Chúng tôi luôn sẵn sàng lắng nghe mọi ý kiến đóng góp, thắc mắc và khiếu nại của quý khách hàng 24/7.</p>
        </div>

        <div class="contact-grid-layout">
            <!-- Cột trái: Thông tin liên hệ trực tiếp & Showroom -->
            <div class="contact-info-cards">
                <div class="contact-info-card">
                    <div class="info-card-icon icon-hotline"><i class="fa-solid fa-phone-volume"></i></div>
                    <div class="info-card-text">
                        <h4>Tổng Đài Mua Hàng & CSKH</h4>
                        <p class="phone-highlight"><a href="tel:<?= str_replace(' ', '', HOTLINE) ?>"><?= HOTLINE ?></a></p>
                        <small>Hoạt động từ 8h00 - 21h30 (Kể cả Thứ 7, CN)</small>
                    </div>
                </div>

                <div class="contact-info-card">
                    <div class="info-card-icon icon-email"><i class="fa-solid fa-envelope"></i></div>
                    <div class="info-card-text">
                        <h4>Hộp Thư Điện Tử</h4>
                        <p><a href="mailto:<?= CONTACT_EMAIL ?>"><?= CONTACT_EMAIL ?></a></p>
                        <small>Phản hồi trong vòng 2 giờ làm việc</small>
                    </div>
                </div>

                <div class="contact-info-card">
                    <div class="info-card-icon icon-location"><i class="fa-solid fa-store"></i></div>
                    <div class="info-card-text">
                        <h4>Showroom Công Nghệ LongTech</h4>
                        <p><strong><?= STORE_ADDRESS ?></strong></p>
                        <small>Có bãi đỗ xe ô tô và xe máy miễn phí</small>
                    </div>
                </div>

                <div class="contact-info-card">
                    <div class="info-card-icon icon-warranty"><i class="fa-solid fa-screwdriver-wrench"></i></div>
                    <div class="info-card-text">
                        <h4>Trung Tâm Bảo Hành & Kỹ Thuật</h4>
                        <p>Tầng 2, Tòa nhà LongTech, Cầu Giấy, Hà Nội</p>
                        <small>Tiếp nhận bảo hành, đổi trả và sửa chữa ủy quyền</small>
                    </div>
                </div>
            </div>

            <!-- Cột phải: Biểu mẫu gửi phản hồi -->
            <div class="contact-form-box">
                <h3 class="form-box-title"><i class="fa-regular fa-paper-plane text-primary"></i> Gửi Tin Nhắn / Yêu Cầu Cho LongTech</h3>
                <p class="form-box-desc">Hãy để lại thông tin của bạn, đội ngũ hỗ trợ sẽ liên hệ lại trong thời gian sớm nhất.</p>

                <form action="<?= APP_URL ?>/lien-he" method="POST" class="contact-main-form" onsubmit="return validateContactForm(event)">
                    <?= csrf_field() ?>

                    <div class="form-row-2">
                        <div class="form-group">
                            <label for="contact_name" class="form-label">Họ và tên của bạn <span class="required">*</span></label>
                            <input type="text" name="full_name" id="contact_name" class="form-control" placeholder="Nguyễn Văn A" value="<?= e($currentUser['full_name'] ?? '') ?>" required autofocus>
                        </div>
                        <div class="form-group">
                            <label for="contact_phone" class="form-label">Số điện thoại liên hệ</label>
                            <input type="tel" name="phone" id="contact_phone" class="form-control" placeholder="0912345678" value="<?= e($currentUser['phone'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="form-row-2">
                        <div class="form-group">
                            <label for="contact_email" class="form-label">Địa chỉ Email <span class="required">*</span></label>
                            <input type="email" name="email" id="contact_email" class="form-control" placeholder="email@gmail.com" value="<?= e($currentUser['email'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="contact_subject" class="form-label">Chủ đề cần hỗ trợ</label>
                            <select name="subject" id="contact_subject" class="form-control" style="cursor: pointer;">
                                <option value="Tư vấn mua hàng">Tư vấn mua thiết bị công nghệ</option>
                                <option value="Hỗ trợ đơn hàng">Hỗ trợ tra cứu tiến độ đơn hàng</option>
                                <option value="Bảo hành & Kỹ thuật">Yêu cầu bảo hành & kỹ thuật phần cứng</option>
                                <option value="Khiếu nại dịch vụ">Góp ý & Khiếu nại dịch vụ</option>
                                <option value="Hợp tác kinh doanh">Liên hệ hợp tác phân phối</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="contact_message" class="form-label">Nội dung chi tiết <span class="required">*</span></label>
                        <textarea name="message" id="contact_message" rows="5" class="form-control" placeholder="Mô tả cụ thể yêu cầu hoặc thắc mắc của bạn..." required></textarea>
                    </div>

                    <button type="submit" class="btn-primary-tech" style="padding: 12px 28px; font-size: 14px;">
                        <i class="fa-solid fa-paper-plane"></i> Gửi Tin Nhắn Đi
                    </button>
                </form>
            </div>
        </div>

        <!-- 3. BẢN ĐỒ VỊ TRÍ SHOWROOM -->
        <div class="contact-map-section">
            <h3 class="section-title text-center" style="margin-bottom: 16px;">Vị Trí Showroom Trên Bản Đồ</h3>
            <div class="map-container">
                <iframe 
                    title="Bản đồ chỉ đường LongTech"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3723.863855881395!2d105.78926737503164!3d21.03813278061358!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab361a357f87%3A0xe67864f7b4946765!2zQ-G6p3UgR2nhuqV5LCBIw6AgTuG7mWksIFZp4buHdCBOYW0!5e0!3m2!1svi!2s!4v1700000000000!5m2!1svi!2s" 
                    width="100%" 
                    height="360" 
                    style="border:0; border-radius: 12px;" 
                    allowfullscreen="" 
                    loading="lazy" 
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>
        </div>
    </div>
</div>

<script>
function validateContactForm(e) {
    const form = document.querySelector('.contact-main-form');
    const name = form.full_name.value.trim();
    const email = form.email.value.trim();
    const msg = form.message.value.trim();

    if (!name || !email || !msg) {
        showToast('Vui lòng điền đầy đủ họ tên, email và nội dung tin nhắn!', 'error');
        return false;
    }
    return true;
}
</script>

