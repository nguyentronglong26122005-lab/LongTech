<?php
/**
 * ========================================================
 * LONGTECH - GIAO DIỆN GIỎ HÀNG (cart.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="cart-page-wrapper">
    <div class="container">
        <!-- 1. BREADCRUMBS -->
        <nav class="breadcrumb-nav">
            <a href="<?= APP_URL ?>"><i class="fa-solid fa-house"></i> Trang chủ</a>
            <span class="bc-sep">/</span>
            <span class="bc-current">Giỏ hàng của bạn</span>
        </nav>

        <h1 class="cart-page-title">
            <i class="fa-solid fa-cart-shopping text-primary"></i> Giỏ Hàng Công Nghệ 
            <small>(<?= $cartTotals['total_items'] ?> sản phẩm)</small>
        </h1>

        <?php if (!empty($cart)): ?>
            <!-- Thanh thông báo trạng thái Miễn phí giao hàng (Freeship) -->
            <div class="freeship-notice-bar <?= $cartTotals['is_freeship'] ? 'qualified' : '' ?>">
                <?php if ($cartTotals['is_freeship']): ?>
                    <i class="fa-solid fa-circle-check text-success"></i>
                    <span>Tuyệt vời! Đơn hàng của bạn đã đạt điều kiện <strong>MIỄN PHÍ VẬN CHUYỂN</strong> toàn quốc.</span>
                <?php else: ?>
                    <i class="fa-solid fa-truck-fast text-secondary"></i>
                    <span>Bạn chỉ cần mua thêm <strong><?= format_money($cartTotals['amount_to_freeship']) ?></strong> để được <strong>MIỄN PHÍ VẬN CHUYỂN</strong>!</span>
                <?php endif; ?>
            </div>

            <!-- BỐ CỤC 2 CỘT: DANH SÁCH SẢN PHẨM & TỔNG KẾT ĐƠN -->
            <div class="cart-layout-grid">
                <!-- Cột trái: Bảng sản phẩm trong giỏ -->
                <div class="cart-items-column">
                    <div class="table-responsive">
                        <table class="cart-table">
                            <thead>
                                <tr>
                                    <th>Sản Phẩm</th>
                                    <th>Đơn Giá</th>
                                    <th>Số Lượng</th>
                                    <th>Thành Tiền</th>
                                    <th>Xóa</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cart as $key => $item): ?>
                                    <?php $lineTotal = (float)$item['price'] * (int)$item['quantity']; ?>
                                    <tr>
                                        <!-- Cột Sản phẩm & Phân loại -->
                                        <td class="cart-product-cell">
                                            <a href="<?= APP_URL ?>/san-pham/<?= e($item['slug']) ?>" class="cart-item-thumb">
                                                <img src="<?= e($item['thumbnail']) ?>" alt="<?= e($item['name']) ?>">
                                            </a>
                                            <div class="cart-item-info">
                                                <h4 class="cart-item-name">
                                                    <a href="<?= APP_URL ?>/san-pham/<?= e($item['slug']) ?>"><?= e($item['name']) ?></a>
                                                </h4>
                                                <div class="cart-item-variants">
                                                    <?php if (!empty($item['color'])): ?>
                                                        <span class="variant-tag"><i class="fa-solid fa-palette"></i> <?= e($item['color']) ?></span>
                                                    <?php endif; ?>
                                                    <?php if (!empty($item['storage'])): ?>
                                                        <span class="variant-tag"><i class="fa-solid fa-hard-drive"></i> <?= e($item['storage']) ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>

                                        <!-- Cột Đơn giá -->
                                        <td class="cart-price-cell">
                                            <span class="cell-price"><?= format_money($item['price']) ?></span>
                                        </td>

                                        <!-- Cột Tăng / Giảm số lượng -->
                                        <td class="cart-qty-cell">
                                            <form action="<?= APP_URL ?>/gio-hang/cap-nhat" method="POST" class="cart-qty-form">
                                                <input type="hidden" name="item_key" value="<?= e($key) ?>">
                                                <button type="submit" name="action" value="decrease" class="btn-cart-qty minus" aria-label="Giảm">-</button>
                                                <span class="qty-display"><?= $item['quantity'] ?></span>
                                                <button type="submit" name="action" value="increase" class="btn-cart-qty plus" aria-label="Tăng">+</button>
                                            </form>
                                        </td>

                                        <!-- Cột Thành tiền -->
                                        <td class="cart-total-cell">
                                            <span class="cell-line-total"><?= format_money($lineTotal) ?></span>
                                        </td>

                                        <!-- Cột Xóa -->
                                        <td class="cart-action-cell">
                                            <a href="<?= APP_URL ?>/gio-hang/xoa?key=<?= urlencode($key) ?>" class="btn-remove-cart" onclick="return confirm('Bạn có chắc muốn xóa sản phẩm này khỏi giỏ hàng?')" title="Xóa khỏi giỏ">
                                                <i class="fa-regular fa-trash-can"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="cart-actions-row">
                        <a href="<?= APP_URL ?>/san-pham" class="btn-continue-shopping">
                            <i class="fa-solid fa-arrow-left"></i> Tiếp tục mua sản phẩm khác
                        </a>
                    </div>
                </div>

                <!-- Cột phải: Hộp tính tiền & Áp mã giảm giá -->
                <div class="cart-summary-column">
                    <div class="cart-summary-card">
                        <h3 class="summary-title">Tóm Tắt Đơn Hàng</h3>

                        <!-- Form Áp Dụng Mã Giảm Giá -->
                        <div class="coupon-box">
                            <form action="<?= APP_URL ?>/gio-hang/coupon" method="POST" class="coupon-form">
                                <?= csrf_field() ?>
                                <input type="text" name="coupon_code" class="coupon-input" placeholder="Nhập mã coupon (LONGTECH50K, VIP10)" value="<?= e($cartTotals['coupon_code'] ?? '') ?>">
                                <button type="submit" class="btn-apply-coupon">Áp dụng</button>
                            </form>
                            <?php if (!empty($cartTotals['coupon_code'])): ?>
                                <div class="applied-coupon-tag">
                                    <span><i class="fa-solid fa-tag"></i> Đã dùng mã: <strong><?= e($cartTotals['coupon_code']) ?></strong></span>
                                    <a href="<?= APP_URL ?>/gio-hang/xoa-coupon" class="btn-remove-coupon" title="Hủy mã">&times;</a>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Bảng kê chi phí -->
                        <div class="summary-lines">
                            <div class="summary-line">
                                <span>Tạm tính (<?= $cartTotals['total_items'] ?> sản phẩm):</span>
                                <span class="font-bold"><?= format_money($cartTotals['subtotal']) ?></span>
                            </div>

                            <?php if ($cartTotals['discount'] > 0): ?>
                                <div class="summary-line text-success">
                                    <span>Giảm giá coupon:</span>
                                    <span>-<?= format_money($cartTotals['discount']) ?></span>
                                </div>
                            <?php endif; ?>

                            <div class="summary-line">
                                <span>Phí vận chuyển:</span>
                                <span>
                                    <?php if ($cartTotals['is_freeship']): ?>
                                        <strong class="text-success">MIỄN PHÍ</strong>
                                    <?php else: ?>
                                        <?= format_money($cartTotals['shipping_fee']) ?>
                                    <?php endif; ?>
                                </span>
                            </div>

                            <hr class="summary-divider">

                            <div class="summary-line total-line">
                                <span>Tổng cộng:</span>
                                <span class="total-price-large"><?= format_money($cartTotals['total_amount']) ?></span>
                            </div>
                            <small class="vat-note">(Đã bao gồm thuế VAT và bảo hành 12 tháng chính hãng)</small>
                        </div>

                        <!-- Nút Chuyển Đến Thanh Toán -->
                        <a href="<?= APP_URL ?>/thanh-toan" class="btn-checkout-now">
                            TIẾN HÀNH ĐẶT HÀNG <i class="fa-solid fa-arrow-right"></i>
                        </a>

                        <!-- Cam kết bảo mật -->
                        <div class="summary-trust-badges">
                            <div class="badge-item"><i class="fa-solid fa-shield-halved text-primary"></i> Bảo mật thông tin tuyệt đối</div>
                            <div class="badge-item"><i class="fa-solid fa-arrows-rotate text-secondary"></i> Đổi trả 30 ngày nếu lỗi NSX</div>
                        </div>
                    </div>
                </div>
            </div>

        <?php else: ?>
            <!-- Giao diện giỏ hàng trống -->
            <div class="empty-cart-view">
                <div class="empty-cart-icon"><i class="fa-solid fa-cart-arrow-down"></i></div>
                <h2>Giỏ hàng của bạn đang trống!</h2>
                <p>Hãy khám phá thêm hàng ngàn thiết bị công nghệ chính hãng giá tốt tại LongTech.</p>
                <a href="<?= APP_URL ?>" class="btn-primary-tech" style="margin-top: 18px; padding: 12px 28px;">
                    <i class="fa-solid fa-store"></i> Bắt đầu mua sắm ngay
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

