<?php
/**
 * ========================================================
 * LONGTECH - GIAO DIỆN TRANG CHỦ (home.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="home-wrapper">
    <!-- 1. HERO SECTION: BỘ 8 BANNER SLIDER ĐA CHIẾN DỊCH & 3 BANNER PHỤ -->
    <section class="hero-section">
        <div class="container hero-grid">
            <!-- Slider chính bên trái kèm Thanh Tab Chiến Dịch kiểu CellphoneS -->
            <div class="hero-slider-wrap">
                <?php
                // Danh sách 8 chiến dịch Banner mặc định kết hợp dữ liệu từ bảng banners
                $slideThemes = [
                    [
                        'bg'       => 'linear-gradient(135deg, #090d16 0%, #1e293b 55%, #78350f 100%)',
                        'badge'    => '🔥 FLAGSHIP BÁN CHẠY NHẤT 2026',
                        'title'    => 'iPhone 16 Pro Max Titan Sa Mạc',
                        'subtitle' => 'Siêu chip A18 Pro 3nm • Nút Camera Control • Giảm ngay 3.000.000đ + Trả góp 0%',
                        'price'    => 'Chỉ từ 31.990.000đ',
                        'img'      => APP_URL . '/assets/uploads/products/prod_13.png',
                        'link'     => 'san-pham/iphone-16-pro-max-256gb',
                        'tab'      => 'iPhone 16 Pro Max'
                    ],
                    [
                        'bg'       => 'linear-gradient(135deg, #0A2540 0%, #1e3a8a 55%, #0284c7 100%)',
                        'badge'    => '✨ QUYỀN NĂNG GALAXY AI MỚI',
                        'title'    => 'Samsung Galaxy Z Fold6 & S24 Ultra',
                        'subtitle' => 'Tuyệt tác màn hình gập & Camera 200MP • Thu cũ đổi mới trợ giá tới 4.000.000đ',
                        'price'    => 'Ưu đãi độc quyền',
                        'img'      => APP_URL . '/assets/uploads/products/prod_14.png',
                        'link'     => 'san-pham/samsung-galaxy-z-fold6-5g-256gb',
                        'tab'      => 'Galaxy Z Fold6 AI'
                    ],
                    [
                        'bg'       => 'linear-gradient(135deg, #0f172a 0%, #334155 60%, #4f46e5 100%)',
                        'badge'    => '💻 SIÊU PHẨM ĐỒ HỌA & AI',
                        'title'    => 'MacBook Pro 14 M3 Pro Space Black',
                        'subtitle' => 'Chip M3 Pro 18GB/512GB • Màn hình Liquid Retina XDR 120Hz • Giảm thêm 5% HSSV',
                        'price'    => 'Giá sốc 45.990.000đ',
                        'img'      => APP_URL . '/assets/uploads/products/prod_16.png',
                        'link'     => 'san-pham/macbook-pro-14-m3-pro-512gb',
                        'tab'      => 'MacBook M3 Pro'
                    ],
                    [
                        'bg'       => 'linear-gradient(135deg, #1e1b4b 0%, #312e81 55%, #7c3aed 100%)',
                        'badge'    => '🎨 TANDEM OLED MỎNG NHẤT LỊCH SỬ',
                        'title'    => 'iPad Pro M4 13 inch Ultra Retina',
                        'subtitle' => 'Siêu mỏng 5.1mm • Hỗ trợ Apple Pencil Pro & Magic Keyboard nhôm nguyên khối',
                        'price'    => 'Chỉ từ 34.490.000đ',
                        'img'      => APP_URL . '/assets/uploads/products/prod_15.png',
                        'link'     => 'san-pham/ipad-pro-m4-13-inch-wifi-256gb',
                        'tab'      => 'iPad Pro M4 OLED'
                    ],
                    [
                        'bg'       => 'linear-gradient(135deg, #18181b 0%, #27272a 55%, #ea580c 100%)',
                        'badge'    => '⌚ ĐỒNG HỒ THỂ THAO TITAN ĐEN',
                        'title'    => 'Apple Watch Ultra 2 49mm 4G',
                        'subtitle' => 'Khung viền Satin Black Titanium • Kính Sapphire 3000 nits • Pin bền bỉ 72 giờ',
                        'price'    => 'Ưu đãi 19.890.000đ',
                        'img'      => APP_URL . '/assets/uploads/products/prod_17.png',
                        'link'     => 'san-pham/apple-watch-ultra-2-49mm-titan-den',
                        'tab'      => 'Watch Ultra 2 Đen'
                    ],
                    [
                        'bg'       => 'linear-gradient(135deg, #042f2e 0%, #065f46 55%, #0284c7 100%)',
                        'badge'    => '🎮 ĐẠI TIỆC CONSOLE & GAMING',
                        'title'    => 'Sony PlayStation 5 Slim & ROG Strix',
                        'subtitle' => 'Chiến mượt mọi tựa game AAA 4K 120Hz Ray Tracing • Tặng kèm tay cầm DualSense',
                        'price'    => 'Chỉ 12.690.000đ',
                        'img'      => APP_URL . '/assets/uploads/products/prod_21.png',
                        'link'     => 'san-pham/may-choi-game-sony-ps5-slim',
                        'tab'      => 'Sony PS5 Slim'
                    ],
                    [
                        'bg'       => 'linear-gradient(135deg, #1c1917 0%, #44403c 55%, #b45309 100%)',
                        'badge'    => '🎵 ÂM THANH STUDIO ANH QUỐC',
                        'title'    => 'Loa Marshall Stanmore III & Sony XM5',
                        'subtitle' => 'Chất âm Hi-Res sống động • Chống ồn chủ động ANC đỉnh cao • Giảm tới 20%',
                        'price'    => 'Từ 6.890.000đ',
                        'img'      => APP_URL . '/assets/uploads/products/prod_20.png',
                        'link'     => 'am-thanh',
                        'tab'      => 'Loa Marshall & Sony'
                    ],
                    [
                        'bg'       => 'linear-gradient(135deg, #3b0764 0%, #4c1d95 55%, #be123c 100%)',
                        'badge'    => '🖥️ MÀN HÌNH ESPORTS OLED 240HZ',
                        'title'    => 'LG UltraGear OLED 27" & Mac Studio',
                        'subtitle' => 'Tần số quét 240Hz 0.03ms nhanh nhất thế giới • Trạm làm việc M2 Max siêu mạnh',
                        'price'    => 'Giảm ngay 4.5 Triệu',
                        'img'      => APP_URL . '/assets/uploads/products/prod_23.png',
                        'link'     => 'man-hinh-pc',
                        'tab'      => 'Màn hình OLED 240Hz'
                    ],
                ];
                ?>
                <div class="hero-slider" id="mainHeroSlider">
                    <?php foreach ($slideThemes as $index => $s): ?>
                        <?php
                        // Nếu admin có sửa tiêu đề/link trong bảng banners thì ưu tiên lấy
                        $dbBanner = $banners[$index] ?? null;
                        $sTitle = !empty($dbBanner['title']) ? $dbBanner['title'] : $s['title'];
                        $sSub   = !empty($dbBanner['subtitle']) ? $dbBanner['subtitle'] : $s['subtitle'];
                        $sLink  = !empty($dbBanner['link']) && $dbBanner['link'] !== '#' ? $dbBanner['link'] : $s['link'];
                        $sImg   = $s['img'];
                        if (!empty($dbBanner['image_url']) && !str_contains($dbBanner['image_url'], 'unsplash.com')) {
                            $rawImg = $dbBanner['image_url'];
                            $sImg = (str_starts_with($rawImg, 'http://') || str_starts_with($rawImg, 'https://'))
                                ? $rawImg
                                : (APP_URL . '/' . ltrim($rawImg, '/'));
                        }
                        ?>
                        <div class="hero-slide <?= $index === 0 ? 'active' : '' ?>" style="background: <?= $s['bg'] ?>;">
                            <a href="<?= APP_URL ?>/<?= ltrim(e($sLink), '/') ?>" class="hero-slide-rich-inner">
                                <div class="hero-slide-left">
                                    <span class="hero-promo-pill"><?= e($s['badge']) ?></span>
                                    <h2 class="slide-title"><?= e($sTitle) ?></h2>
                                    <p class="slide-subtitle"><?= e($sSub) ?></p>
                                    <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap; margin-top:4px;">
                                        <span class="slide-btn">Mua ngay <i class="fa-solid fa-arrow-right"></i></span>
                                        <span class="slide-price-tag"><?= e($s['price']) ?></span>
                                    </div>
                                </div>
                                <div class="hero-slide-right">
                                    <div class="hero-product-showcase-frame">
                                        <img src="<?= e($sImg) ?>" alt="<?= e($sTitle) ?>" class="hero-showcase-img">
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>

                    <!-- Nút điều hướng Trái / Phải -->
                    <div class="slider-controls">
                        <button type="button" class="slider-arrow prev" onclick="stepHeroSlide(-1)" aria-label="Slide trước"><i class="fa-solid fa-chevron-left"></i></button>
                        <button type="button" class="slider-arrow next" onclick="stepHeroSlide(1)" aria-label="Slide sau"><i class="fa-solid fa-chevron-right"></i></button>
                    </div>
                </div>

                <!-- Thanh Tab Chuyển Nhanh 8 Banner Chiến Dịch (Phong cách CellphoneS) -->
                <div class="hero-slider-tabs" id="heroSliderTabs">
                    <?php foreach ($slideThemes as $index => $s): ?>
                        <button type="button" class="hero-tab-item <?= $index === 0 ? 'active' : '' ?>" onclick="goToHeroSlide(<?= $index ?>)">
                            <strong><?= e($s['tab']) ?></strong>
                            <span><?= e($s['price']) ?></span>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- 3 Banner khuyến mãi phụ bên phải kèm Ảnh Sản Phẩm Thật -->
            <div class="hero-side-banners">
                <a href="<?= APP_URL ?>/san-pham/iphone-15-pro-max-256gb" class="side-banner-card promo-orange" style="text-decoration:none;">
                    <div class="side-banner-info">
                        <span class="badge-mini" style="background:#ffedd5; color:#c2410c;">THU CŨ ĐỔI MỚI</span>
                        <h3>iPhone 15 Pro Max</h3>
                        <p>Trợ giá lên đến <strong>2.500.000đ</strong></p>
                        <span class="side-link">Lên đời ngay <i class="fa-solid fa-angle-right"></i></span>
                    </div>
                    <img src="<?= APP_URL ?>/assets/uploads/products/1793809755_2716485aa03a.png" alt="iPhone 15 Pro Max" class="side-banner-thumb">
                </a>

                <a href="<?= APP_URL ?>/san-pham/samsung-galaxy-s24-ultra-5g-256gb" class="side-banner-card promo-blue" style="text-decoration:none;">
                    <div class="side-banner-info">
                        <span class="badge-mini" style="background:#dcfce7; color:#15803d;">TRẢ GÓP 0% LÃI SUẤT</span>
                        <h3>Galaxy S24 Ultra 5G</h3>
                        <p>Giảm sốc còn <strong>28.490.000đ</strong></p>
                        <span class="side-link">Săn deal ngay <i class="fa-solid fa-angle-right"></i></span>
                    </div>
                    <img src="<?= APP_URL ?>/assets/uploads/products/1793809745_c0e380be3c3f.png" alt="Galaxy S24 Ultra" class="side-banner-thumb">
                </a>

                <a href="<?= APP_URL ?>/san-pham/laptop-asus-rog-strix-g16-g614jvr" class="side-banner-card promo-purple" style="text-decoration:none;">
                    <div class="side-banner-info">
                        <span class="badge-mini" style="background:#ede9fe; color:#6d28d9;">ĐẶC QUYỀN HSSV -5%</span>
                        <h3>ROG Strix G16 RTX 4080</h3>
                        <p>Tặng Balo ROG & Chuột Gaming</p>
                        <span class="side-link">Nhận ưu đãi <i class="fa-solid fa-angle-right"></i></span>
                    </div>
                    <img src="<?= APP_URL ?>/assets/uploads/products/1793809689_d08e00dd79ba.png" alt="ASUS ROG Strix G16" class="side-banner-thumb">
                </a>
            </div>
        </div>
    </section>

    <!-- 2. DANH MỤC TRỌNG TÂM (8 NGÀNH HÀNG CÔNG NGHỆ HOT) -->
    <section class="home-section category-section">
        <div class="container">
            <div class="section-header-flex">
                <div>
                    <h3 class="section-title"><i class="fa-solid fa-layer-group text-danger"></i> Khám Phá Hệ Sinh Thái Công Nghệ</h3>
                    <span class="section-desc">Đầy đủ 8 ngành hàng Flagship chính hãng VN/A bảo hành toàn quốc</span>
                </div>
                <a href="<?= APP_URL ?>/san-pham" class="link-view-all">Xem tất cả 24+ siêu phẩm <i class="fa-solid fa-angle-right"></i></a>
            </div>
            
            <?php
            $catStyleMap = [
                'dien-thoai'         => ['grad' => 'linear-gradient(135deg, #ef4444, #b91c1c)', 'sub' => 'iPhone 16, S24 Ultra, Z Fold6', 'badge' => 'HOT'],
                'may-tinh-bang'      => ['grad' => 'linear-gradient(135deg, #0284c7, #0369a1)', 'sub' => 'iPad Pro M4, Galaxy Tab S9', 'badge' => ''],
                'laptop'             => ['grad' => 'linear-gradient(135deg, #2563eb, #1d4ed8)', 'sub' => 'MacBook M3 Pro, ROG, XPS', 'badge' => ''],
                'phu-kien'           => ['grad' => 'linear-gradient(135deg, #0d9488, #0f766e)', 'sub' => 'AirPods Pro 2, Anker, Logitech', 'badge' => ''],
                'dong-ho-thong-minh' => ['grad' => 'linear-gradient(135deg, #f97316, #c2410c)', 'sub' => 'Watch Ultra 2, Galaxy Watch Ultra', 'badge' => 'MỚI'],
                'am-thanh'           => ['grad' => 'linear-gradient(135deg, #8b5cf6, #6d28d9)', 'sub' => 'Sony XM5, Loa Marshall', 'badge' => 'MỚI'],
                'gaming-gear'        => ['grad' => 'linear-gradient(135deg, #10b981, #047857)', 'sub' => 'Sony PS5 Slim, Phím ROG Azoth', 'badge' => 'HOT'],
                'man-hinh-pc'        => ['grad' => 'linear-gradient(135deg, #334155, #0f172a)', 'sub' => 'LG OLED 240Hz, Mac Studio M2', 'badge' => 'MỚI'],
            ];
            ?>
            <div class="categories-grid">
                <?php foreach ($categories as $cat): ?>
                    <?php
                    $cSlug = $cat['slug'] ?? '';
                    $cMeta = $catStyleMap[$cSlug] ?? ['grad' => 'linear-gradient(135deg, #0A2540, #1e3a8a)', 'sub' => 'Sản phẩm chính hãng', 'badge' => ''];
                    ?>
                    <a href="<?= APP_URL ?>/<?= e($cSlug) ?>" class="category-card">
                        <?php if (!empty($cMeta['badge'])): ?>
                            <span class="cat-badge-pill <?= $cMeta['badge'] === 'HOT' ? 'hot' : 'new' ?>"><?= e($cMeta['badge']) ?></span>
                        <?php endif; ?>
                        <div class="category-icon-box" style="background: <?= $cMeta['grad'] ?>; color: #fff; box-shadow: 0 6px 14px rgba(15,23,42,0.14);">
                            <i class="fa-solid <?= e($cat['icon'] ?? 'fa-laptop') ?>"></i>
                        </div>
                        <div style="flex:1; min-width:0;">
                            <h4 class="category-name"><?= e($cat['name']) ?></h4>
                            <small class="category-subtext"><?= e($cMeta['sub']) ?></small>
                        </div>
                        <span class="category-arrow"><i class="fa-solid fa-arrow-right"></i></span>
                    </a>
                <?php endforeach; ?>
            </div>

            <!-- DẢI 2 BANNER ĐÔI CHIẾN DỊCH LỚN (DUAL CAMPAIGN BANNERS) -->
            <div class="dual-campaign-banners" style="margin-top: 26px;">
                <a href="<?= APP_URL ?>/dien-thoai" class="campaign-banner-box campaign-apple">
                    <div class="campaign-banner-text">
                        <span class="campaign-pill">APPLE AUTHORIZED RESELLER</span>
                        <h3>Đại Tiệc Táo Khuyết VN/A</h3>
                        <p>iPhone 16 Pro Max • iPad Pro M4 • MacBook M3 Pro giảm đến <strong>4.000.000đ</strong></p>
                        <span class="campaign-btn">Khám phá Apple Store <i class="fa-solid fa-arrow-right"></i></span>
                    </div>
                    <div class="campaign-banner-imgs">
                        <img src="<?= APP_URL ?>/assets/uploads/products/prod_13.png" alt="iPhone 16 Pro Max">
                        <img src="<?= APP_URL ?>/assets/uploads/products/prod_15.png" alt="iPad Pro M4">
                    </div>
                </a>

                <a href="<?= APP_URL ?>/laptop" class="campaign-banner-box campaign-laptop">
                    <div class="campaign-banner-text">
                        <span class="campaign-pill">BACK TO SCHOOL & WORK 2026</span>
                        <h3>Tuần Lễ Laptop AI & Gaming</h3>
                        <p>ASUS ROG • Dell XPS OLED • Lenovo Legion giảm sốc + Tặng quà <strong>3.500.000đ</strong></p>
                        <span class="campaign-btn">Săn deal Laptop <i class="fa-solid fa-arrow-right"></i></span>
                    </div>
                    <div class="campaign-banner-imgs">
                        <img src="<?= APP_URL ?>/assets/uploads/products/1793809671_7784e5f8f562.png" alt="Dell XPS 13">
                        <img src="<?= APP_URL ?>/assets/uploads/products/1793809657_346c0d86e1e4.png" alt="Lenovo Legion Slim 5">
                    </div>
                </a>
            </div>
        </div>
    </section>

    <!-- 3. FLASH SALE GIÁ SỐC (SẢN PHẨM KHUYẾN MÃI) -->
    <?php if (!empty($hotDeals)): ?>
    <section class="home-section flash-sale-section">
        <div class="container">
            <div class="flash-sale-header">
                <div class="flash-title-group">
                    <div class="flame-icon"><i class="fa-solid fa-bolt"></i></div>
                    <div>
                        <h3 class="flash-sale-title">FLASH SALE SĂN DEAL ĐỈNH CAO</h3>
                        <span class="flash-sale-subtitle">Cam kết giá tốt nhất thị trường - Bảo hành chính hãng 1 đổi 1</span>
                    </div>
                </div>
                <div class="flash-timer-box">
                    <span class="timer-label"><i class="fa-regular fa-clock"></i> Kết thúc sau:</span>
                    <div class="countdown-digits">
                        <span class="digit-box" id="timerHours">08</span> :
                        <span class="digit-box" id="timerMinutes">45</span> :
                        <span class="digit-box" id="timerSeconds">30</span>
                    </div>
                </div>
            </div>

            <div class="products-grid flash-sale-grid">
                <?php foreach ($hotDeals as $idx => $product): ?>
                    <?php 
                        $discountPercent = 0;
                        $savedMoney = 0;
                        if (!empty($product['sale_price']) && $product['sale_price'] < $product['price']) {
                            $discountPercent = round((($product['price'] - $product['sale_price']) / $product['price']) * 100);
                            $savedMoney = $product['price'] - $product['sale_price'];
                        }
                        $soldFake = min(19, 11 + (($idx * 3) % 8));
                        $soldPct = round(($soldFake / 20) * 100);
                    ?>
                    <div class="product-card flash-card">
                        <?php if ($discountPercent > 0): ?>
                            <span class="discount-badge">Giảm <?= $discountPercent ?>%</span>
                        <?php endif; ?>
                        <span class="installment-badge">Trả góp 0%</span>
                        
                        <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="product-thumb-link">
                            <img src="<?= e($product['thumbnail']) ?>" alt="<?= e($product['name']) ?>" class="product-thumb" loading="lazy">
                        </a>

                        <div class="product-body">
                            <span class="product-brand"><?= e($product['brand_name'] ?? 'Chính hãng') ?></span>
                            <h4 class="product-name">
                                <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>"><?= e($product['name']) ?></a>
                            </h4>

                            <div class="product-specs">
                                <?php if (!empty($product['ram_options']) && $product['ram_options'] !== 'Không áp dụng'): ?>
                                    <span class="spec-tag"><?= e(explode(',', $product['ram_options'])[0]) ?></span>
                                <?php endif; ?>
                                <?php if (!empty($product['storage_options']) && $product['storage_options'] !== 'Không áp dụng'): ?>
                                    <span class="spec-tag"><?= e(explode(',', $product['storage_options'])[0]) ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="product-pricing">
                                <div class="price-current">
                                    <?= format_money(!empty($product['sale_price']) ? $product['sale_price'] : $product['price']) ?>
                                </div>
                                <?php if ($savedMoney > 0): ?>
                                    <div class="price-original"><?= format_money($product['price']) ?></div>
                                <?php endif; ?>
                            </div>

                            <!-- Thanh tiến độ Flash Sale -->
                            <div class="flash-progress-bar">
                                <div class="flash-progress-fill" style="width: <?= $soldPct ?>%;"></div>
                                <span class="flash-progress-text">🔥 Đã bán <?= $soldFake ?>/20 suất</span>
                            </div>

                            <div class="product-actions">
                                <button type="button" class="btn-add-cart" onclick="addToCart(<?= $product['id'] ?>)" title="Thêm vào giỏ">
                                    <i class="fa-solid fa-cart-plus"></i> Thêm giỏ
                                </button>
                                <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="btn-buy-now">
                                    Mua ngay
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- 4. SẢN PHẨM NỔI BẬT & BÁN CHẠY (FEATURED PRODUCTS) -->
    <section class="home-section featured-section">
        <div class="container">
            <div class="section-header-flex">
                <div>
                    <h3 class="section-title"><i class="fa-solid fa-fire-flame-curved text-danger"></i> Siêu Phẩm Công Nghệ Nổi Bật</h3>
                    <span class="section-desc">Những thiết bị được cộng đồng công nghệ săn đón nhiều nhất 2026</span>
                </div>
                <div class="filter-tabs" id="homeFeaturedFilterTabs">
                    <button type="button" class="filter-tab active" onclick="filterHomeProducts('all', this)">Tất cả</button>
                    <button type="button" class="filter-tab" onclick="filterHomeProducts('dien-thoai', this)">Điện thoại</button>
                    <button type="button" class="filter-tab" onclick="filterHomeProducts('laptop', this)">Laptop</button>
                    <button type="button" class="filter-tab" onclick="filterHomeProducts('may-tinh-bang', this)">Tablet</button>
                    <button type="button" class="filter-tab" onclick="filterHomeProducts('dong-ho-thong-minh', this)">Đồng hồ</button>
                    <button type="button" class="filter-tab" onclick="filterHomeProducts('am-thanh', this)">Âm thanh</button>
                    <button type="button" class="filter-tab" onclick="filterHomeProducts('gaming-gear', this)">Gaming & PC</button>
                </div>
            </div>

            <div class="products-grid" id="featuredProductsGrid">
                <?php foreach ($featuredProducts as $product): ?>
                    <?php 
                        $discountPercent = 0;
                        if (!empty($product['sale_price']) && $product['sale_price'] < $product['price']) {
                            $discountPercent = round((($product['price'] - $product['sale_price']) / $product['price']) * 100);
                        }
                        $catSlugAttr = $product['category_slug'] ?? '';
                    ?>
                    <div class="product-card" data-category="<?= e($product['category_name']) ?>" data-cat-slug="<?= e($catSlugAttr) ?>">
                        <?php if ($discountPercent > 0): ?>
                            <span class="discount-badge">Giảm <?= $discountPercent ?>%</span>
                        <?php endif; ?>
                        <span class="installment-badge">Trả góp 0%</span>

                        <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="product-thumb-link">
                            <img src="<?= e($product['thumbnail']) ?>" alt="<?= e($product['name']) ?>" class="product-thumb" loading="lazy">
                        </a>

                        <div class="product-body">
                            <span class="product-brand"><?= e($product['brand_name'] ?? 'LongTech') ?></span>
                            <h4 class="product-name">
                                <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>"><?= e($product['name']) ?></a>
                            </h4>

                            <div class="product-specs">
                                <?php if (!empty($product['ram_options']) && $product['ram_options'] !== 'Không áp dụng'): ?>
                                    <span class="spec-tag"><?= e(explode(',', $product['ram_options'])[0]) ?></span>
                                <?php endif; ?>
                                <?php if (!empty($product['storage_options']) && $product['storage_options'] !== 'Không áp dụng'): ?>
                                    <span class="spec-tag"><?= e(explode(',', $product['storage_options'])[0]) ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="product-pricing">
                                <div class="price-current">
                                    <?= format_money(!empty($product['sale_price']) ? $product['sale_price'] : $product['price']) ?>
                                </div>
                                <?php if (!empty($product['sale_price']) && $product['sale_price'] < $product['price']): ?>
                                    <div class="price-original"><?= format_money($product['price']) ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="product-rating">
                                <div class="stars">
                                    <i class="fa-solid fa-star"></i>
                                    <span><?= number_format((float)$product['rating'], 1) ?></span>
                                </div>
                                <span class="stock-status in-stock"><i class="fa-solid fa-shield-halved"></i> Chính hãng VN/A</span>
                            </div>

                            <div class="product-actions">
                                <button type="button" class="btn-add-cart" onclick="addToCart(<?= $product['id'] ?>)">
                                    <i class="fa-solid fa-cart-plus"></i> Thêm giỏ
                                </button>
                                <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="btn-buy-now">
                                    Chi tiết
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="view-more-center">
                <a href="<?= APP_URL ?>/san-pham" class="btn-outline-tech">
                    Khám phá trọn bộ 24+ sản phẩm công nghệ <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>
        </div>
    </section>

    <!-- 4.5 BENTO BANNER HỆ SINH THÁI MỚI (SMARTWATCH, AUDIO, GAMING) -->
    <section class="home-section bento-ecosystem-section">
        <div class="container">
            <div class="bento-promo-grid">
                <a href="<?= APP_URL ?>/dong-ho-thong-minh" class="bento-promo-card bento-watch">
                    <div class="bento-content">
                        <span class="bento-tag">THẾ HỆ MỚI 2026</span>
                        <h3>Đồng Hồ Thông Minh Titanium</h3>
                        <p>Apple Watch Ultra 2 Đen Satin & Galaxy Watch Ultra trợ lý sức khỏe AI</p>
                        <span class="bento-cta">Khám phá ngay <i class="fa-solid fa-arrow-right"></i></span>
                    </div>
                    <img src="<?= APP_URL ?>/assets/uploads/products/prod_17.png" alt="Apple Watch Ultra 2" class="bento-img">
                </a>

                <a href="<?= APP_URL ?>/am-thanh" class="bento-promo-card bento-audio">
                    <div class="bento-content">
                        <span class="bento-tag">HI-RES AUDIO</span>
                        <h3>Đỉnh Cao Âm Thanh Studio</h3>
                        <p>Loa Marshall Stanmore III & Tai nghe chống ồn Sony WH-1000XM5</p>
                        <span class="bento-cta">Trải nghiệm ngay <i class="fa-solid fa-arrow-right"></i></span>
                    </div>
                    <img src="<?= APP_URL ?>/assets/uploads/products/prod_20.png" alt="Marshall Stanmore III" class="bento-img">
                </a>

                <a href="<?= APP_URL ?>/gaming-gear" class="bento-promo-card bento-gaming">
                    <div class="bento-content">
                        <span class="bento-tag">ESPORTS & CONSOLE</span>
                        <h3>Thế Giới Gaming & PS5 Slim</h3>
                        <p>PlayStation 5 Slim, Màn hình OLED 240Hz & Bàn phím cơ ROG Azoth</p>
                        <span class="bento-cta">Chiến game ngay <i class="fa-solid fa-arrow-right"></i></span>
                    </div>
                    <img src="<?= APP_URL ?>/assets/uploads/products/prod_21.png" alt="Sony PS5 Slim" class="bento-img">
                </a>
            </div>
        </div>
    </section>

    <!-- 5. ĐỐI TÁC THƯƠNG HIỆU HÀNG ĐẦU (BRANDS ROW) -->
    <section class="home-section brands-section">
        <div class="container">
            <h3 class="section-title text-center" style="justify-content:center; margin-bottom:18px;">Đối Tác Thương Hiệu Toàn Cầu</h3>
            <div class="brands-carousel">
                <a href="<?= APP_URL ?>/san-pham?brand=apple" class="brand-item"><span class="brand-badge"><i class="fa-brands fa-apple"></i> Apple</span></a>
                <a href="<?= APP_URL ?>/san-pham?brand=samsung" class="brand-item"><span class="brand-badge">SAMSUNG</span></a>
                <a href="<?= APP_URL ?>/san-pham?brand=sony" class="brand-item"><span class="brand-badge">SONY</span></a>
                <a href="<?= APP_URL ?>/san-pham?brand=marshall" class="brand-item"><span class="brand-badge">MARSHALL</span></a>
                <a href="<?= APP_URL ?>/san-pham?brand=asus" class="brand-item"><span class="brand-badge">ASUS ROG</span></a>
                <a href="<?= APP_URL ?>/san-pham?brand=dell" class="brand-item"><span class="brand-badge">DELL</span></a>
                <a href="<?= APP_URL ?>/san-pham?brand=lg" class="brand-item"><span class="brand-badge">LG ULTRAGEAR</span></a>
                <a href="<?= APP_URL ?>/san-pham?brand=xiaomi" class="brand-item"><span class="brand-badge">XIAOMI</span></a>
                <a href="<?= APP_URL ?>/san-pham?brand=logitech" class="brand-item"><span class="brand-badge">LOGITECH</span></a>
                <a href="<?= APP_URL ?>/san-pham?brand=anker" class="brand-item"><span class="brand-badge">ANKER</span></a>
            </div>
        </div>
    </section>

    <!-- 5.5 SIÊU BANNER NGANG TOÀN TRANG (MEGA CYBER BANNER) -->
    <section class="home-section" style="padding: 10px 0 24px;">
        <div class="container">
            <div class="mega-cyber-banner">
                <div class="mega-cyber-content">
                    <span class="mega-cyber-badge"><i class="fa-solid fa-bolt"></i> SIÊU SỰ KIỆN CÔNG NGHỆ LONGTECH 2026</span>
                    <h2>Nâng Cấp Góc Làm Việc & Giải Trí Đỉnh Cao 8K</h2>
                    <p>Trọn bộ <strong>Apple Mac Studio M2 Max</strong>, <strong>Màn hình LG UltraGear OLED 240Hz</strong>, <strong>Bàn phím cơ ROG Azoth</strong> & <strong>Chuột Logitech MX Master 3S</strong> — Nhập mã <code style="background:#fde047; color:#0f172a; padding:2px 8px; border-radius:6px; font-weight:900;">VIP10</code> giảm ngay 10% tới 1.000.000đ!</p>
                    <div style="display:flex; gap:12px; flex-wrap:wrap; margin-top:16px;">
                        <a href="<?= APP_URL ?>/man-hinh-pc" class="mega-cyber-btn primary">Mua Trọn Bộ Setup <i class="fa-solid fa-arrow-right"></i></a>
                        <a href="<?= APP_URL ?>/khuyen-mai" class="mega-cyber-btn secondary">Xem Tất Cả Deal Sốc</a>
                    </div>
                </div>
                <div class="mega-cyber-showcase">
                    <img src="<?= APP_URL ?>/assets/uploads/products/prod_23.png" alt="LG UltraGear OLED">
                    <img src="<?= APP_URL ?>/assets/uploads/products/prod_24.png" alt="Mac Studio M2 Max">
                    <img src="<?= APP_URL ?>/assets/uploads/products/prod_22.png" alt="ASUS ROG Azoth">
                </div>
            </div>
        </div>
    </section>

    <!-- 6. HÀNG MỚI LÊN KỆ (NEW ARRIVALS - 8 SIÊU PHẨM MỚI NHẤT) -->
    <?php if (!empty($newProducts)): ?>
    <section class="home-section new-arrivals-section">
        <div class="container">
            <div class="section-header-flex">
                <div>
                    <h3 class="section-title"><i class="fa-solid fa-wand-magic-sparkles text-warning"></i> Siêu Phẩm Mới Lên Kệ 2026</h3>
                    <span class="section-desc">Bộ sưu tập thiết bị công nghệ thế hệ mới vừa cập bến LongTech</span>
                </div>
                <a href="<?= APP_URL ?>/san-pham?sort=newest" class="link-view-all">Xem tất cả hàng mới <i class="fa-solid fa-angle-right"></i></a>
            </div>

            <div class="products-grid">
                <?php foreach (array_slice($newProducts, 0, 8) as $product): ?>
                    <div class="product-card">
                        <span class="new-tag">MỚI 2026</span>
                        <span class="installment-badge">Trả góp 0%</span>
                        <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="product-thumb-link">
                            <img src="<?= e($product['thumbnail']) ?>" alt="<?= e($product['name']) ?>" class="product-thumb" loading="lazy">
                        </a>
                        <div class="product-body">
                            <span class="product-brand"><?= e($product['brand_name'] ?? 'Chính hãng') ?></span>
                            <h4 class="product-name">
                                <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>"><?= e($product['name']) ?></a>
                            </h4>
                            <div class="product-pricing">
                                <div class="price-current">
                                    <?= format_money(!empty($product['sale_price']) ? $product['sale_price'] : $product['price']) ?>
                                </div>
                                <?php if (!empty($product['sale_price']) && $product['sale_price'] < $product['price']): ?>
                                    <div class="price-original"><?= format_money($product['price']) ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="product-rating">
                                <div class="stars">
                                    <i class="fa-solid fa-star"></i>
                                    <span><?= number_format((float)$product['rating'], 1) ?></span>
                                </div>
                                <span class="stock-status in-stock"><i class="fa-solid fa-check"></i> Sẵn hàng</span>
                            </div>
                            <div class="product-actions">
                                <button type="button" class="btn-add-cart" onclick="addToCart(<?= $product['id'] ?>)">
                                    <i class="fa-solid fa-cart-plus"></i> Thêm giỏ
                                </button>
                                <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="btn-buy-now">
                                    Chi tiết
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- 7. TIN TỨC & ĐÁNH GIÁ CÔNG NGHỆ (POSTS) -->
    <?php if (!empty($latestPosts)): ?>
    <section class="home-section news-section">
        <div class="container">
            <div class="section-header-flex">
                <div>
                    <h3 class="section-title"><i class="fa-regular fa-newspaper text-primary"></i> Bản Tin Công Nghệ LongTech</h3>
                    <span class="section-desc">Đánh giá chuyên sâu, thủ thuật và xu hướng công nghệ mới</span>
                </div>
                <a href="<?= APP_URL ?>/tin-tuc" class="link-view-all">Xem tất cả bài viết <i class="fa-solid fa-angle-right"></i></a>
            </div>

            <div class="news-grid">
                <?php foreach ($latestPosts as $post): ?>
                    <article class="news-card">
                        <a href="<?= APP_URL ?>/tin-tuc/<?= e($post['slug']) ?>" class="news-thumb-wrap">
                            <img src="<?= e($post['thumbnail']) ?>" alt="<?= e($post['title']) ?>" class="news-thumb" loading="lazy">
                        </a>
                        <div class="news-content">
                            <div class="news-meta">
                                <span><i class="fa-regular fa-clock"></i> <?= date('d/m/Y', strtotime($post['created_at'])) ?></span>
                                <span><i class="fa-solid fa-tag"></i> Tin công nghệ</span>
                            </div>
                            <h4 class="news-title">
                                <a href="<?= APP_URL ?>/tin-tuc/<?= e($post['slug']) ?>"><?= e($post['title']) ?></a>
                            </h4>
                            <p class="news-summary"><?= e(truncate_words($post['summary'], 18)) ?></p>
                            <a href="<?= APP_URL ?>/tin-tuc/<?= e($post['slug']) ?>" class="news-read-more">
                                Đọc tiếp <i class="fa-solid fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- 8. KHU VỰC HỎI VÀ ĐÁP KHÁCH HÀNG (CELLPHONES STYLE) -->
    <section class="container mb-4">
        <?php 
        $productId = null; // Toàn trang
        require VIEW_PATH . '/client/components/faq_section.php'; 
        ?>
    </section>

    <!-- 9. HỘP ĐĂNG KÝ NHẬN TIN KHUYẾN MÃI -->
    <section class="newsletter-section">
        <div class="container newsletter-box">
            <div class="newsletter-text">
                <h3>Đăng Ký Nhận Bản Tin LongTech</h3>
                <p>Nhận ngay mã giảm giá <strong>50.000đ</strong> cho đơn hàng đầu tiên cùng thông báo Flash Sale sớm nhất.</p>
            </div>
            <form class="newsletter-form" onsubmit="event.preventDefault(); showToast('Đăng ký nhận tin thành công!', 'success');">
                <input type="email" placeholder="Nhập địa chỉ email của bạn..." required class="newsletter-input">
                <button type="submit" class="btn-newsletter">Đăng ký ngay</button>
            </form>
        </div>
    </section>
</div>

<script>
// Điều khiển Hero Slider 8 Chiến Dịch + Tự động chuyển mượt mà
let currentHeroIdx = 0;
let heroSlideTimer = null;

function goToHeroSlide(idx) {
    const slides = document.querySelectorAll('#mainHeroSlider .hero-slide');
    const tabs   = document.querySelectorAll('#heroSliderTabs .hero-tab-item');
    if (!slides.length) return;
    currentHeroIdx = (idx + slides.length) % slides.length;
    slides.forEach((s, i) => s.classList.toggle('active', i === currentHeroIdx));
    tabs.forEach((t, i) => t.classList.toggle('active', i === currentHeroIdx));
    resetHeroSlideTimer();
}

function stepHeroSlide(step) {
    goToHeroSlide(currentHeroIdx + step);
}

function resetHeroSlideTimer() {
    if (heroSlideTimer) clearInterval(heroSlideTimer);
    heroSlideTimer = setInterval(() => {
        goToHeroSlide(currentHeroIdx + 1);
    }, 4500);
}

document.addEventListener('DOMContentLoaded', () => {
    resetHeroSlideTimer();
});

function filterHomeProducts(slug, btn) {
    document.querySelectorAll('#homeFeaturedFilterTabs .filter-tab').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    const cards = document.querySelectorAll('#featuredProductsGrid .product-card');
    cards.forEach(card => {
        const cardSlug = card.getAttribute('data-cat-slug') || '';
        if (slug === 'all') {
            card.style.display = '';
        } else if (slug === 'gaming-gear') {
            card.style.display = (cardSlug === 'gaming-gear' || cardSlug === 'man-hinh-pc') ? '' : 'none';
        } else {
            card.style.display = (cardSlug === slug) ? '' : 'none';
        }
    });
}
</script>

