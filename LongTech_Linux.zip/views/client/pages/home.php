<?php
/**
 * ========================================================
 * LONGTECH - GIAO DIỆN TRANG CHỦ (home.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="home-wrapper">
    <!-- 1. HERO SECTION: BANNER SLIDER & ƯU ĐÃI NỔI BẬT -->
    <section class="hero-section">
        <div class="container hero-grid">
            <!-- Slider chính bên trái -->
            <div class="hero-slider-wrap">
                <div class="hero-slider" id="mainHeroSlider">
                    <?php if (!empty($banners)): ?>
                        <?php foreach ($banners as $index => $banner): ?>
                            <div class="hero-slide <?= $index === 0 ? 'active' : '' ?>">
                                <a href="<?= APP_URL ?>/<?= ltrim(e($banner['link']), '/') ?>">
                                    <img src="<?= e($banner['image_url']) ?>" alt="<?= e($banner['title']) ?>" class="hero-slide-img">
                                    <div class="hero-slide-overlay">
                                        <h2 class="slide-title"><?= e($banner['title']) ?></h2>
                                        <p class="slide-subtitle"><?= e($banner['subtitle']) ?></p>
                                        <span class="slide-btn">Khám phá ngay <i class="fa-solid fa-arrow-right"></i></span>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <!-- Banner mặc định nếu chưa thêm trong database -->
                        <div class="hero-slide active">
                            <div class="hero-default-banner">
                                <span class="tag-tech">SIÊU PHẨM CÔNG NGHỆ 2026</span>
                                <h2>iPhone 15 Pro Max & Galaxy S24 Ultra</h2>
                                <p>Trải nghiệm quyền năng Titanium đỉnh phong và trí tuệ AI vượt thời đại</p>
                                <a href="<?= APP_URL ?>/dien-thoai" class="btn-primary-tech">Mua ngay hôm nay</a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Điều hướng Slider -->
                <div class="slider-controls">
                    <button class="slider-arrow prev" id="sliderPrev" aria-label="Slide trước"><i class="fa-solid fa-chevron-left"></i></button>
                    <button class="slider-arrow next" id="sliderNext" aria-label="Slide sau"><i class="fa-solid fa-chevron-right"></i></button>
                </div>
            </div>

            <!-- Banner khuyến mãi phụ bên phải -->
            <div class="hero-side-banners">
                <div class="side-banner-card promo-orange">
                    <div class="side-banner-info">
                        <span class="badge-mini">HOT DEAL</span>
                        <h3>Thu cũ đổi mới</h3>
                        <p>Trợ giá lên đến <strong>2.500.000đ</strong></p>
                        <a href="<?= APP_URL ?>/khuyen-mai" class="side-link">Đổi ngay <i class="fa-solid fa-angle-right"></i></a>
                    </div>
                    <div class="side-icon"><i class="fa-solid fa-repeat"></i></div>
                </div>

                <div class="side-banner-card promo-blue">
                    <div class="side-banner-info">
                        <span class="badge-mini">TRẢ GÓP 0%</span>
                        <h3>Ưu đãi thẻ tín dụng</h3>
                        <p>Kỳ hạn tới 12 tháng không lãi suất</p>
                        <a href="<?= APP_URL ?>/tin-tuc" class="side-link">Xem điều kiện <i class="fa-solid fa-angle-right"></i></a>
                    </div>
                    <div class="side-icon"><i class="fa-solid fa-credit-card"></i></div>
                </div>

                <div class="side-banner-card promo-purple">
                    <div class="side-banner-info">
                        <span class="badge-mini">ĐỘC QUYỀN</span>
                        <h3>Học sinh - Sinh viên</h3>
                        <p>Giảm thêm <strong>5%</strong> cho Laptop & Tablet</p>
                        <a href="<?= APP_URL ?>/laptop" class="side-link">Nhận ưu đãi <i class="fa-solid fa-angle-right"></i></a>
                    </div>
                    <div class="side-icon"><i class="fa-solid fa-graduation-cap"></i></div>
                </div>
            </div>
        </div>
    </section>

    <!-- 2. DANH MỤC TRỌNG TÂM (CATEGORY SHOWCASE) -->
    <section class="home-section category-section">
        <div class="container">
            <div class="section-header">
                <h3 class="section-title"><i class="fa-solid fa-cubes text-primary"></i> Khám Phá Danh Mục</h3>
                <span class="section-desc">Đầy đủ các dòng thiết bị công nghệ chính hãng mới nhất</span>
            </div>
            
            <div class="categories-grid">
                <?php foreach ($categories as $cat): ?>
                    <a href="<?= APP_URL ?>/<?= e($cat['slug']) ?>" class="category-card">
                        <div class="category-icon-box">
                            <i class="fa-solid <?= e($cat['icon'] ?? 'fa-laptop') ?>"></i>
                        </div>
                        <h4 class="category-name"><?= e($cat['name']) ?></h4>
                        <span class="category-arrow"><i class="fa-solid fa-arrow-right"></i></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- 3. FLASH SALE GIÁ SỐC (SẢN PHẨM KHUYẾN MÃI) -->
    <?php if (!empty($hotDeals)): ?>
    <section class="home-section flash-sale-section">
        <div class="container">
            <div class="flash-sale-header">
                <div class="flash-title-group">
                    <div class="flame-icon"><i class="fa-solid fa-bolt"></i></div>
                    <div>
                        <h3 class="flash-sale-title">FLASH SALE GIÁ SỐC</h3>
                        <span class="flash-sale-subtitle">Số lượng có hạn - Mua ngay kẻo lỡ</span>
                    </div>
                </div>
                <div class="flash-timer-box">
                    <span class="timer-label">Kết thúc trong:</span>
                    <div class="countdown-digits">
                        <span class="digit-box" id="timerHours">08</span> :
                        <span class="digit-box" id="timerMinutes">45</span> :
                        <span class="digit-box" id="timerSeconds">30</span>
                    </div>
                </div>
            </div>

            <div class="products-grid flash-sale-grid">
                <?php foreach ($hotDeals as $product): ?>
                    <?php 
                        $discountPercent = 0;
                        if (!empty($product['sale_price']) && $product['sale_price'] < $product['price']) {
                            $discountPercent = round((($product['price'] - $product['sale_price']) / $product['price']) * 100);
                        }
                    ?>
                    <div class="product-card">
                        <?php if ($discountPercent > 0): ?>
                            <span class="discount-badge">Giảm <?= $discountPercent ?>%</span>
                        <?php endif; ?>
                        
                        <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="product-thumb-link">
                            <img src="<?= e($product['thumbnail']) ?>" alt="<?= e($product['name']) ?>" class="product-thumb" loading="lazy">
                        </a>

                        <div class="product-body">
                            <span class="product-brand"><?= e($product['brand_name'] ?? 'Chính hãng') ?></span>
                            <h4 class="product-name">
                                <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>"><?= e($product['name']) ?></a>
                            </h4>

                            <div class="product-specs">
                                <?php if (!empty($product['ram_options'])): ?>
                                    <span class="spec-tag"><?= e(explode(',', $product['ram_options'])[0]) ?></span>
                                <?php endif; ?>
                                <?php if (!empty($product['storage_options'])): ?>
                                    <span class="spec-tag"><?= e(explode(',', $product['storage_options'])[0]) ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="product-pricing">
                                <div class="price-current">
                                    <?= format_money(!empty($product['sale_price']) ? $product['sale_price'] : $product['price']) ?>
                                </div>
                                <?php if (!empty($product['sale_price']) && $product['sale_price'] < $product['price']): ?>
                                    <div class="price-original"><?= format_money($product['price']) ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="product-rating">
                                <div class="stars">
                                    <i class="fa-solid fa-star"></i>
                                    <span><?= number_format((float)$product['rating'], 1) ?></span>
                                </div>
                                <span class="stock-status in-stock"><i class="fa-solid fa-check"></i> Còn hàng</span>
                            </div>

                            <div class="product-actions">
                                <button type="button" class="btn-add-cart" onclick="addToCart(<?= $product['id'] ?>)" title="Thêm vào giỏ">
                                    <i class="fa-solid fa-cart-plus"></i> Thêm giỏ
                                </button>
                                <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="btn-buy-now">
                                    Xem chi tiết
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- 4. SẢN PHẨM NỔI BẬT & BÁN CHẠY (FEATURED PRODUCTS) -->
    <section class="home-section featured-section">
        <div class="container">
            <div class="section-header-flex">
                <div>
                    <h3 class="section-title"><i class="fa-solid fa-fire-flame-curved text-danger"></i> Sản Phẩm Nổi Bật</h3>
                    <span class="section-desc">Những thiết bị được cộng đồng công nghệ săn đón nhiều nhất</span>
                </div>
                <div class="filter-tabs">
                    <button class="filter-tab active" data-filter="all">Tất cả</button>
                    <button class="filter-tab" data-filter="dien-thoai">Điện thoại</button>
                    <button class="filter-tab" data-filter="laptop">Laptop</button>
                    <button class="filter-tab" data-filter="may-tinh-bang">Máy tính bảng</button>
                    <button class="filter-tab" data-filter="phu-kien">Phụ kiện</button>
                </div>
            </div>

            <div class="products-grid" id="featuredProductsGrid">
                <?php foreach ($featuredProducts as $product): ?>
                    <?php 
                        $discountPercent = 0;
                        if (!empty($product['sale_price']) && $product['sale_price'] < $product['price']) {
                            $discountPercent = round((($product['price'] - $product['sale_price']) / $product['price']) * 100);
                        }
                    ?>
                    <div class="product-card" data-category="<?= e($product['category_name']) ?>">
                        <?php if ($discountPercent > 0): ?>
                            <span class="discount-badge">Giảm <?= $discountPercent ?>%</span>
                        <?php endif; ?>

                        <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="product-thumb-link">
                            <img src="<?= e($product['thumbnail']) ?>" alt="<?= e($product['name']) ?>" class="product-thumb" loading="lazy">
                        </a>

                        <div class="product-body">
                            <span class="product-brand"><?= e($product['brand_name'] ?? 'LongTech') ?></span>
                            <h4 class="product-name">
                                <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>"><?= e($product['name']) ?></a>
                            </h4>

                            <div class="product-specs">
                                <?php if (!empty($product['ram_options'])): ?>
                                    <span class="spec-tag"><?= e(explode(',', $product['ram_options'])[0]) ?></span>
                                <?php endif; ?>
                                <?php if (!empty($product['storage_options'])): ?>
                                    <span class="spec-tag"><?= e(explode(',', $product['storage_options'])[0]) ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="product-pricing">
                                <div class="price-current">
                                    <?= format_money(!empty($product['sale_price']) ? $product['sale_price'] : $product['price']) ?>
                                </div>
                                <?php if (!empty($product['sale_price']) && $product['sale_price'] < $product['price']): ?>
                                    <div class="price-original"><?= format_money($product['price']) ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="product-rating">
                                <div class="stars">
                                    <i class="fa-solid fa-star"></i>
                                    <span><?= number_format((float)$product['rating'], 1) ?></span>
                                </div>
                                <span class="stock-status in-stock"><i class="fa-solid fa-shield"></i> BH 12 tháng</span>
                            </div>

                            <div class="product-actions">
                                <button type="button" class="btn-add-cart" onclick="addToCart(<?= $product['id'] ?>)">
                                    <i class="fa-solid fa-cart-plus"></i> Thêm giỏ
                                </button>
                                <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="btn-buy-now">
                                    Chi tiết
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="view-more-center">
                <a href="<?= APP_URL ?>/san-pham" class="btn-outline-tech">
                    Xem tất cả sản phẩm công nghệ <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>
        </div>
    </section>

    <!-- 5. ĐỐI TÁC THƯƠNG HIỆU HÀNG ĐẦU (BRANDS ROW) -->
    <section class="home-section brands-section">
        <div class="container">
            <h3 class="section-title text-center">Thương Hiệu Đồng Hành Đẳng Cấp</h3>
            <div class="brands-carousel">
                <div class="brand-item"><span class="brand-badge"><i class="fa-brands fa-apple"></i> Apple</span></div>
                <div class="brand-item"><span class="brand-badge">SAMSUNG</span></div>
                <div class="brand-item"><span class="brand-badge">XIAOMI</span></div>
                <div class="brand-item"><span class="brand-badge">OPPO</span></div>
                <div class="brand-item"><span class="brand-badge">ASUS ROG</span></div>
                <div class="brand-item"><span class="brand-badge">DELL</span></div>
                <div class="brand-item"><span class="brand-badge">LENOVO</span></div>
                <div class="brand-item"><span class="brand-badge">LOGITECH</span></div>
                <div class="brand-item"><span class="brand-badge">ANKER</span></div>
            </div>
        </div>
    </section>

    <!-- 6. HÀNG MỚI LÊN KỆ (NEW ARRIVALS) -->
    <?php if (!empty($newProducts)): ?>
    <section class="home-section new-arrivals-section">
        <div class="container">
            <div class="section-header">
                <h3 class="section-title"><i class="fa-solid fa-sparkles text-warning"></i> Hàng Mới Lên Kệ</h3>
                <span class="section-desc">Cập nhật công nghệ tiên tiến nhất thị trường</span>
            </div>

            <div class="products-grid">
                <?php foreach (array_slice($newProducts, 0, 4) as $product): ?>
                    <div class="product-card">
                        <span class="new-tag">MỚI</span>
                        <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="product-thumb-link">
                            <img src="<?= e($product['thumbnail']) ?>" alt="<?= e($product['name']) ?>" class="product-thumb" loading="lazy">
                        </a>
                        <div class="product-body">
                            <span class="product-brand"><?= e($product['brand_name'] ?? 'Chính hãng') ?></span>
                            <h4 class="product-name">
                                <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>"><?= e($product['name']) ?></a>
                            </h4>
                            <div class="product-pricing">
                                <div class="price-current">
                                    <?= format_money(!empty($product['sale_price']) ? $product['sale_price'] : $product['price']) ?>
                                </div>
                            </div>
                            <div class="product-actions">
                                <button type="button" class="btn-add-cart" onclick="addToCart(<?= $product['id'] ?>)">
                                    <i class="fa-solid fa-cart-plus"></i> Thêm giỏ
                                </button>
                                <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="btn-buy-now">
                                    Chi tiết
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- 7. TIN TỨC & ĐÁNH GIÁ CÔNG NGHỆ (POSTS) -->
    <?php if (!empty($latestPosts)): ?>
    <section class="home-section news-section">
        <div class="container">
            <div class="section-header-flex">
                <div>
                    <h3 class="section-title"><i class="fa-regular fa-newspaper text-primary"></i> Bản Tin Công Nghệ LongTech</h3>
                    <span class="section-desc">Đánh giá chuyên sâu, thủ thuật và xu hướng công nghệ mới</span>
                </div>
                <a href="<?= APP_URL ?>/tin-tuc" class="link-view-all">Xem tất cả bài viết <i class="fa-solid fa-angle-right"></i></a>
            </div>

            <div class="news-grid">
                <?php foreach ($latestPosts as $post): ?>
                    <article class="news-card">
                        <a href="<?= APP_URL ?>/tin-tuc/<?= e($post['slug']) ?>" class="news-thumb-wrap">
                            <img src="<?= e($post['thumbnail']) ?>" alt="<?= e($post['title']) ?>" class="news-thumb" loading="lazy">
                        </a>
                        <div class="news-content">
                            <div class="news-meta">
                                <span><i class="fa-regular fa-clock"></i> <?= date('d/m/Y', strtotime($post['created_at'])) ?></span>
                                <span><i class="fa-solid fa-tag"></i> Tin công nghệ</span>
                            </div>
                            <h4 class="news-title">
                                <a href="<?= APP_URL ?>/tin-tuc/<?= e($post['slug']) ?>"><?= e($post['title']) ?></a>
                            </h4>
                            <p class="news-summary"><?= e(truncate_words($post['summary'], 18)) ?></p>
                            <a href="<?= APP_URL ?>/tin-tuc/<?= e($post['slug']) ?>" class="news-read-more">
                                Đọc tiếp <i class="fa-solid fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- 8. KHU VỰC HỎI VÀ ĐÁP KHÁCH HÀNG (CELLPHONES STYLE) -->
    <section class="container mb-4">
        <?php 
        $productId = null; // Toàn trang
        require VIEW_PATH . '/client/components/faq_section.php'; 
        ?>
    </section>

    <!-- 9. HỘP ĐĂNG KÝ NHẬN TIN KHUYẾN MÃI -->
    <section class="newsletter-section">
        <div class="container newsletter-box">
            <div class="newsletter-text">
                <h3>Đăng Ký Nhận Bản Tin LongTech</h3>
                <p>Nhận ngay mã giảm giá <strong>50.000đ</strong> cho đơn hàng đầu tiên cùng thông báo Flash Sale sớm nhất.</p>
            </div>
            <form class="newsletter-form" onsubmit="event.preventDefault(); showToast('Đăng ký nhận tin thành công!', 'success');">
                <input type="email" placeholder="Nhập địa chỉ email của bạn..." required class="newsletter-input">
                <button type="submit" class="btn-newsletter">Đăng ký ngay</button>
            </form>
        </div>
    </section>
</div>

