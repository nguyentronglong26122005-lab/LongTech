<?php
/**
 * ========================================================
 * LONGTECH - TRUNG TÂM HỖ TRỢ & CÂU HỎI THƯỜNG GẶP (faq.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

$faqGroups = $faqGroups ?? [];
$communityQuestions = $communityQuestions ?? [];
$totalFaq = array_sum(array_map(fn($g) => count($g['items']), $faqGroups));
?>
<div class="faq-page">
    <!-- 1. HERO + Ô TÌM KIẾM -->
    <section class="faq-hero">
        <div class="container">
            <nav class="breadcrumb-nav about-bc">
                <a href="<?= APP_URL ?>"><i class="fa-solid fa-house"></i> Trang chủ</a>
                <span class="bc-sep">/</span>
                <span class="bc-current">Câu hỏi thường gặp</span>
            </nav>
            <span class="about-eyebrow">TRUNG TÂM HỖ TRỢ KHÁCH HÀNG</span>
            <h1>Xin chào, LongTech có thể giúp gì cho bạn?</h1>
            <div class="faq-search-box">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" id="faqSearch" placeholder="Nhập câu hỏi, ví dụ: đổi trả, trả góp, giao hàng..." autocomplete="off">
                <button type="button" id="faqClear" title="Xoá">&times;</button>
            </div>
            <div class="faq-hot-tags">
                <span>Tìm nhiều:</span>
                <?php foreach (['Đổi trả', 'Bảo hành', 'Trả góp', 'Giao hàng', 'Mã giảm giá', 'Hoàn tiền'] as $tag): ?>
                    <button type="button" class="faq-tag" data-q="<?= e($tag) ?>"><?= e($tag) ?></button>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <div class="container faq-layout">
        <!-- 2. CỘT TRÁI: DANH MỤC CHỦ ĐỀ -->
        <aside class="faq-sidebar">
            <div class="faq-side-card">
                <h4>Chủ đề hỗ trợ</h4>
                <button type="button" class="faq-cat active" data-cat="all">
                    <i class="fa-solid fa-layer-group"></i> <span>Tất cả câu hỏi</span> <em><?= $totalFaq ?></em>
                </button>
                <?php foreach ($faqGroups as $key => $g): ?>
                    <button type="button" class="faq-cat" data-cat="<?= e($key) ?>">
                        <i class="fa-solid <?= e($g['icon']) ?>"></i> <span><?= e($g['label']) ?></span> <em><?= count($g['items']) ?></em>
                    </button>
                <?php endforeach; ?>
            </div>

            <div class="faq-side-card faq-channels">
                <h4>Kênh liên hệ CSKH</h4>
                <a href="tel:<?= str_replace(' ', '', HOTLINE) ?>" class="faq-channel">
                    <span class="ch-ico red"><i class="fa-solid fa-phone-volume"></i></span>
                    <div><strong><?= HOTLINE ?></strong><small>Hotline miễn phí 7h30 – 22h00</small></div>
                </a>
                <a href="https://zalo.me/<?= preg_replace('/[^0-9]/', '', HOTLINE) ?>" target="_blank" rel="noopener" class="faq-channel">
                    <span class="ch-ico blue">Z</span>
                    <div><strong>Chat Zalo / Live chat</strong><small>Phản hồi trung bình &lt; 5 phút</small></div>
                </a>
                <a href="mailto:<?= e(CONTACT_EMAIL) ?>" class="faq-channel">
                    <span class="ch-ico green"><i class="fa-regular fa-envelope"></i></span>
                    <div><strong><?= e(CONTACT_EMAIL) ?></strong><small>Phản hồi trong 24 giờ</small></div>
                </a>
                <a href="<?= APP_URL ?>/lien-he" class="faq-channel">
                    <span class="ch-ico dark"><i class="fa-solid fa-triangle-exclamation"></i></span>
                    <div><strong>Gửi khiếu nại / góp ý</strong><small>Xử lý trong vòng 24 giờ</small></div>
                </a>
            </div>
        </aside>

        <!-- 3. CỘT PHẢI: DANH SÁCH CÂU HỎI DẠNG ACCORDION -->
        <main class="faq-main">
            <div id="faqResultInfo" class="faq-result-info" style="display:none;"></div>

            <?php foreach ($faqGroups as $key => $g): ?>
                <section class="faq-group" data-cat="<?= e($key) ?>">
                    <h3 class="faq-group-title"><i class="fa-solid <?= e($g['icon']) ?>"></i> <?= e($g['label']) ?></h3>
                    <?php foreach ($g['items'] as $idx => $item): ?>
                        <div class="faq-item" data-id="<?= e($key . '-' . $idx) ?>">
                            <button type="button" class="faq-question" aria-expanded="false">
                                <span><?= e($item['q']) ?></span>
                                <i class="fa-solid fa-plus"></i>
                            </button>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    <p><?= $item['a'] ?></p>
                                    <div class="faq-feedback">
                                        <span>Câu trả lời có hữu ích không?</span>
                                        <button type="button" class="fb-btn" data-v="yes"><i class="fa-regular fa-thumbs-up"></i> Có</button>
                                        <button type="button" class="fb-btn" data-v="no"><i class="fa-regular fa-thumbs-down"></i> Không</button>
                                        <em class="fb-thanks"></em>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </section>
            <?php endforeach; ?>

            <div id="faqEmpty" class="faq-empty" style="display:none;">
                <i class="fa-regular fa-face-frown-open"></i>
                <p>Không tìm thấy câu hỏi phù hợp. Hãy gửi câu hỏi cho đội ngũ CSKH bên dưới nhé!</p>
            </div>

            <!-- 4. CÂU HỎI CỘNG ĐỒNG ĐÃ ĐƯỢC CSKH TRẢ LỜI -->
            <?php
            $answered = array_values(array_filter($communityQuestions, fn($q) => !empty($q['replies'])));
            if (!empty($answered)): ?>
                <section class="faq-group faq-community" data-cat="community">
                    <h3 class="faq-group-title"><i class="fa-solid fa-comments"></i> Câu hỏi từ khách hàng đã được giải đáp</h3>
                    <?php foreach (array_slice($answered, 0, 6) as $cq): ?>
                        <div class="faq-item">
                            <button type="button" class="faq-question" aria-expanded="false">
                                <span><?= e($cq['question_text']) ?> <small class="cq-author">— <?= e($cq['author_name']) ?></small></span>
                                <i class="fa-solid fa-plus"></i>
                            </button>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    <?php foreach ($cq['replies'] as $r): ?>
                                        <p><strong class="cq-staff"><i class="fa-solid fa-circle-check"></i> CSKH LongTech:</strong> <?= nl2br(e($r['reply_text'])) ?></p>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </section>
            <?php endif; ?>

            <!-- 5. FORM GỬI CÂU HỎI CHO BỘ PHẬN CSKH -->
            <section class="faq-ask-card" id="faqAsk">
                <div class="faq-ask-head">
                    <div class="faq-ask-ico"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h3>Chưa tìm thấy câu trả lời?</h3>
                        <p>Gửi câu hỏi tới Bộ phận Chăm sóc khách hàng — chúng tôi phản hồi trong giờ làm việc.</p>
                    </div>
                </div>
                <form id="faqAskForm" class="faq-ask-form">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <div class="faq-ask-row">
                        <input type="text" name="author_name" required maxlength="100" placeholder="Họ và tên *" value="<?= e(current_user()['full_name'] ?? '') ?>">
                        <input type="tel" name="author_phone" maxlength="20" placeholder="Số điện thoại (để CSKH gọi lại)" value="<?= e(current_user()['phone'] ?? '') ?>">
                    </div>
                    <textarea name="question" required maxlength="1000" rows="3" placeholder="Nội dung câu hỏi của bạn *"></textarea>
                    <div class="faq-ask-foot">
                        <span id="faqAskMsg" class="faq-ask-msg"></span>
                        <button type="submit" class="nl-btn-submit" style="width:auto; padding:10px 22px;"><i class="fa-solid fa-paper-plane"></i> Gửi câu hỏi</button>
                    </div>
                </form>
            </section>
        </main>
    </div>
</div>

<script>
    (function () {
        const items = Array.from(document.querySelectorAll('.faq-main .faq-item'));
        const groups = Array.from(document.querySelectorAll('.faq-main .faq-group'));
        const search = document.getElementById('faqSearch');
        const clearBtn = document.getElementById('faqClear');
        const emptyBox = document.getElementById('faqEmpty');
        const info = document.getElementById('faqResultInfo');
        let currentCat = 'all';

        // Accordion
        document.querySelectorAll('.faq-question').forEach(function (btn) {
            btn.addEventListener('click', function () {
                const item = btn.closest('.faq-item');
                const open = item.classList.toggle('open');
                btn.setAttribute('aria-expanded', open ? 'true' : 'false');
            });
        });

        // Bỏ dấu tiếng Việt để tìm kiếm linh hoạt
        function norm(s) {
            return (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd');
        }

        function applyFilter() {
            const q = norm(search.value.trim());
            let visible = 0;
            groups.forEach(function (g) {
                const catOk = currentCat === 'all' || g.dataset.cat === currentCat;
                let groupVisible = 0;
                g.querySelectorAll('.faq-item').forEach(function (it) {
                    const ok = catOk && (!q || norm(it.textContent).includes(q));
                    it.style.display = ok ? '' : 'none';
                    if (ok) groupVisible++;
                    if (q && ok) it.classList.add('open');
                });
                g.style.display = groupVisible ? '' : 'none';
                visible += groupVisible;
            });
            emptyBox.style.display = visible ? 'none' : '';
            clearBtn.style.display = search.value ? 'block' : 'none';
            if (q) {
                info.style.display = '';
                info.innerHTML = 'Tìm thấy <strong>' + visible + '</strong> kết quả cho “' + search.value.replace(/[<>&"]/g, '') + '”';
            } else {
                info.style.display = 'none';
            }
        }

        search.addEventListener('input', applyFilter);
        clearBtn.addEventListener('click', function () {
            search.value = '';
            items.forEach(it => it.classList.remove('open'));
            applyFilter();
            search.focus();
        });
        document.querySelectorAll('.faq-tag').forEach(function (t) {
            t.addEventListener('click', function () {
                search.value = t.dataset.q;
                applyFilter();
            });
        });
        document.querySelectorAll('.faq-cat').forEach(function (c) {
            c.addEventListener('click', function () {
                document.querySelectorAll('.faq-cat').forEach(x => x.classList.remove('active'));
                c.classList.add('active');
                currentCat = c.dataset.cat;
                applyFilter();
                document.querySelector('.faq-main').scrollIntoView({ behavior: 'smooth', block: 'start' });
            });
        });

        // Phản hồi "Hữu ích?" (lưu cục bộ để không bình chọn lặp lại)
        const votes = JSON.parse(localStorage.getItem('lt_faq_votes') || '{}');
        document.querySelectorAll('.faq-main .faq-item[data-id]').forEach(function (it) {
            const id = it.dataset.id;
            const thanks = it.querySelector('.fb-thanks');
            if (votes[id] && thanks) thanks.textContent = 'Cảm ơn phản hồi của bạn!';
            it.querySelectorAll('.fb-btn').forEach(function (b) {
                b.addEventListener('click', function () {
                    votes[id] = b.dataset.v;
                    localStorage.setItem('lt_faq_votes', JSON.stringify(votes));
                    thanks.textContent = b.dataset.v === 'yes'
                        ? 'Cảm ơn phản hồi của bạn!'
                        : 'Rất tiếc! Hãy gửi câu hỏi chi tiết ở cuối trang để CSKH hỗ trợ.';
                });
            });
        });

        // Gửi câu hỏi tới CSKH (lưu vào hệ thống Hỏi & Đáp, QTV trả lời trong trang quản trị)
        const form = document.getElementById('faqAskForm');
        const msg = document.getElementById('faqAskMsg');
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            const btn = form.querySelector('button[type="submit"]');
            btn.disabled = true;
            msg.className = 'faq-ask-msg';
            msg.textContent = 'Đang gửi...';
            fetch('<?= APP_URL ?>/api/faq/add?route=api/faq/add', { method: 'POST', body: new FormData(form) })
                .then(r => r.json())
                .then(function (res) {
                    msg.className = 'faq-ask-msg ' + (res.status ? 'ok' : 'err');
                    msg.textContent = res.status ? '✔ Đã gửi! CSKH sẽ phản hồi sớm nhất.' : (res.message || 'Gửi thất bại, vui lòng thử lại.');
                    if (res.status) form.querySelector('textarea').value = '';
                })
                .catch(function () {
                    msg.className = 'faq-ask-msg err';
                    msg.textContent = 'Phiên làm việc hết hạn, vui lòng tải lại trang và thử lại.';
                })
                .finally(() => { btn.disabled = false; });
        });

        // Mở sẵn câu hỏi đầu tiên
        if (items[0]) items[0].classList.add('open');
    })();
</script>
