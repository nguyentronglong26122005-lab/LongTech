<?php
/**
 * ========================================================
 * LONGTECH - TRANG THÔNG TIN CHÍNH SÁCH & HƯỚNG DẪN (policy.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>
<div style="background:#f8fafc; padding:32px 0 60px;">
    <div class="container">
        <nav class="breadcrumb-nav" style="margin-bottom:20px;">
            <a href="<?= APP_URL ?>"><i class="fa-solid fa-house"></i> Trang chủ</a>
            <span class="bc-sep">/</span>
            <span class="bc-current"><?= e($policyTitle ?? 'Chính sách LongTech') ?></span>
        </nav>

        <div style="background:#fff; border-radius:16px; padding:36px; border:1px solid #e2e8f0; box-shadow:0 8px 24px rgba(15,23,42,0.05); max-width:920px; margin:0 auto;">
            <span style="display:inline-block; background:#fef2f2; color:#D70018; padding:5px 14px; border-radius:20px; font-size:12px; font-weight:800; margin-bottom:12px;">
                TRUNG TÂM CHĂM SÓC KHÁCH HÀNG LONGTECH
            </span>
            <h1 style="font-size:26px; font-weight:800; color:#0f172a; margin:0 0 18px;">
                <?= e($policyTitle ?? 'Chính Sách Dịch Vụ Chính Hãng LongTech') ?>
            </h1>
            <div style="font-size:15px; line-height:1.8; color:#334155;">
                <?= $policyContent ?? '' ?>
            </div>
            <div style="margin-top:28px; padding-top:20px; border-top:1px solid #e2e8f0; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
                <span style="font-size:14px; color:#64748b;">Cần hỗ trợ trực tiếp? Gọi ngay Hotline miễn phí: <strong style="color:#D70018;"><?= HOTLINE ?></strong></span>
                <a href="<?= APP_URL ?>/lien-he" style="background:#D70018; color:#fff; padding:10px 20px; border-radius:10px; text-decoration:none; font-weight:700; font-size:13.5px;">
                    <i class="fa-solid fa-headset"></i> Liên hệ Tư vấn viên
                </a>
            </div>
        </div>
    </div>
</div>

