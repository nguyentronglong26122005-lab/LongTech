<?php
/**
 * ========================================================
 * LONGTECH - GIAO DIỆN ĐĂNG NHẬP (login.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="auth-page-wrapper">
    <div class="container">
        <div class="auth-card">
            <!-- Header của thẻ Auth -->
            <div class="auth-card-header">
                <div class="auth-logo">
                    <div class="logo-icon"><i class="fa-solid fa-microchip"></i></div>
                    <span class="logo-text">LONG<span>TECH</span></span>
                </div>
                <h2 class="auth-title">Đăng Nhập Tài Khoản</h2>
                <p class="auth-subtitle">Truy cập để quản lý đơn hàng, giỏ hàng và nhận ưu đãi độc quyền</p>
            </div>

            <!-- Form đăng nhập -->
            <form action="<?= APP_URL ?>/dang-nhap" method="POST" class="auth-form" id="loginForm" onsubmit="return validateLoginForm(event)">
                <?= csrf_field() ?>

                <!-- Tên đăng nhập hoặc Email -->
                <div class="form-group">
                    <label for="username" class="form-label">Tên đăng nhập hoặc Email <span class="required">*</span></label>
                    <div class="input-with-icon">
                        <i class="fa-regular fa-envelope input-icon"></i>
                        <input type="text" name="username" id="username" class="form-control" placeholder="admin hoặc email@domain.com" required autofocus>
                    </div>
                </div>

                <!-- Mật khẩu -->
                <div class="form-group">
                    <div class="form-label-row">
                        <label for="password" class="form-label">Mật khẩu <span class="required">*</span></label>
                        <a href="<?= APP_URL ?>/lien-he" class="forgot-pwd-link">Quên mật khẩu?</a>
                    </div>
                    <div class="input-with-icon">
                        <i class="fa-solid fa-lock input-icon"></i>
                        <input type="password" name="password" id="password" class="form-control" placeholder="Nhập mật khẩu của bạn" required>
                        <button type="button" class="btn-toggle-password" onclick="togglePasswordVisibility('password', this)" aria-label="Hiện/Ẩn mật khẩu">
                            <i class="fa-regular fa-eye"></i>
                        </button>
                    </div>
                </div>

                <!-- Nút Đăng nhập Submit -->
                <button type="submit" class="btn-auth-submit">
                    <i class="fa-solid fa-arrow-right-to-bracket"></i> Đăng Nhập
                </button>
            </form>

            <!-- Hộp gợi ý tài khoản mẫu để kiểm thử phân quyền -->
            <div class="auth-test-accounts">
                <div class="test-acc-header">
                    <i class="fa-solid fa-circle-info"></i> Tài khoản mẫu kiểm thử:
                </div>
                <div class="test-acc-row">
                    <span class="acc-tag admin-tag">Super Admin:</span>
                    <code>admin</code> / <code>admin123</code>
                </div>
                <div class="test-acc-row">
                    <span class="acc-tag customer-tag">Khách hàng:</span>
                    <code>customer</code> / <code>123456</code>
                </div>
            </div>

            <!-- Footer của thẻ Auth -->
            <div class="auth-card-footer">
                <p>Chưa có tài khoản LongTech? <a href="<?= APP_URL ?>/dang-ky" class="auth-switch-link">Đăng ký ngay tại đây</a></p>
            </div>
        </div>
    </div>
</div>

<script>
function togglePasswordVisibility(inputId, btn) {
    const input = document.getElementById(inputId);
    const icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

function validateLoginForm(e) {
    const form = document.getElementById('loginForm');
    const u = form.username.value.trim();
    const p = form.password.value;
    if (!u || !p) {
        showToast('Vui lòng nhập đầy đủ tài khoản và mật khẩu!', 'error');
        return false;
    }
    return true;
}
</script>

