<?php
/**
 * ========================================================
 * LONGTECH - CHI TIẾT SẢN PHẨM CÔNG NGHỆ (product-detail.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

$currentUser = current_user();
$currentPrice = !empty($product['sale_price']) ? $product['sale_price'] : $product['price'];
$hasDiscount = !empty($product['sale_price']) && $product['sale_price'] < $product['price'];
$discountAmount = $hasDiscount ? ($product['price'] - $product['sale_price']) : 0;
?>

<div class="product-detail-page">
    <div class="container">
        <!-- 1. BREADCRUMBS -->
        <nav class="breadcrumb-nav">
            <a href="<?= APP_URL ?>"><i class="fa-solid fa-house"></i> Trang chủ</a>
            <span class="bc-sep">/</span>
            <a href="<?= APP_URL ?>/<?= e($product['category_slug'] ?? 'san-pham') ?>">
                <?= e($product['category_name'] ?? 'Sản phẩm') ?>
            </a>
            <span class="bc-sep">/</span>
            <span class="bc-current"><?= e($product['name']) ?></span>
        </nav>

        <!-- 2. KHUNG CHI TIẾT SẢN PHẨM TRÊN (TOP SECTION) -->
        <div class="product-detail-top-grid">
            <!-- Cột trái: Gallery Ảnh -->
            <div class="product-gallery-box">
                <div class="main-image-wrap">
                    <?php if ($hasDiscount): ?>
                        <span class="detail-discount-badge">Giảm <?= $product['discount_percent'] ?? 10 ?>%</span>
                    <?php endif; ?>
                    <img src="<?= e($product['thumbnail']) ?>" alt="<?= e($product['name']) ?>" id="mainDetailImg" class="main-detail-img">
                </div>

                <!-- Dải ảnh thu nhỏ (Thumbnails Strip) -->
                <div class="gallery-thumbs-row">
                    <div class="thumb-item active" onclick="switchProductImage('<?= e($product['thumbnail']) ?>', this)">
                        <img src="<?= e($product['thumbnail']) ?>" alt="Ảnh chính">
                    </div>
                    <?php if (!empty($productImages)): ?>
                        <?php foreach ($productImages as $img): ?>
                            <div class="thumb-item" onclick="switchProductImage('<?= e($img['image_url']) ?>', this)">
                                <img src="<?= e($img['image_url']) ?>" alt="Ảnh phụ">
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Hộp cam kết mua hàng bên dưới ảnh -->
                <div class="product-commitments">
                    <div class="commit-item">
                        <i class="fa-solid fa-shield-halved text-primary"></i>
                        <span>Bảo hành chính hãng <strong><?= e($product['warranty_months']) ?> tháng</strong></span>
                    </div>
                    <div class="commit-item">
                        <i class="fa-solid fa-arrows-rotate text-secondary"></i>
                        <span>1 đổi 1 trong <strong>30 ngày</strong> nếu có lỗi nhà sản xuất</span>
                    </div>
                    <div class="commit-item">
                        <i class="fa-solid fa-truck-fast text-success"></i>
                        <span>Miễn phí giao hàng cho đơn từ <strong><?= format_money(FREE_SHIPPING_MIN) ?></strong></span>
                    </div>
                </div>
            </div>

            <!-- Cột phải: Thông tin, Cấu hình & Mua hàng -->
            <div class="product-info-column">
                <div class="product-brand-tag"><?= e($product['brand_name'] ?? 'Chính hãng') ?></div>
                <h1 class="product-detail-title"><?= e($product['name']) ?></h1>

                <div class="product-detail-meta">
                    <div class="meta-item">
                        <span>Mã SP:</span> <strong><?= e($product['product_code']) ?></strong>
                    </div>
                    <div class="meta-item rating-item" onclick="openReviewsTabAndScroll()" style="cursor:pointer;" title="Bấm để xem & viết đánh giá sản phẩm">
                        <i class="fa-solid fa-star"></i>
                        <span><?= number_format((float)$product['rating'], 1) ?></span>
                        <small style="text-decoration:underline;">(<?= count($reviews) ?> đánh giá)</small>
                    </div>
                    <div class="meta-item">
                        <i class="fa-regular fa-eye"></i> <?= number_format($product['view_count']) ?> lượt xem
                    </div>
                    <div class="meta-item stock-badge <?= $product['stock_quantity'] > 0 ? 'in-stock' : 'out-stock' ?>">
                        <i class="fa-solid <?= $product['stock_quantity'] > 0 ? 'fa-circle-check' : 'fa-circle-xmark' ?>"></i>
                        <?= $product['stock_quantity'] > 0 ? 'Còn hàng (' . $product['stock_quantity'] . ' máy)' : 'Tạm hết hàng' ?>
                    </div>
                </div>

                <!-- Khung hiển thị Giá bán -->
                <div class="product-price-box">
                    <div class="price-main-row">
                        <span class="detail-price-current"><?= format_money($currentPrice) ?></span>
                        <?php if ($hasDiscount): ?>
                            <span class="detail-price-original"><?= format_money($product['price']) ?></span>
                            <span class="savings-tag">Tiết kiệm <?= format_money($discountAmount) ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="price-note">
                        <i class="fa-solid fa-credit-card"></i> Trả góp 0% chỉ từ <?= format_money($currentPrice / 6) ?>/tháng
                    </div>
                </div>

                <!-- Mô tả ngắn gọn -->
                <?php if (!empty($product['short_description'])): ?>
                    <p class="product-short-desc"><?= e($product['short_description']) ?></p>
                <?php endif; ?>

                <!-- Form lựa chọn phiên bản & Thêm vào giỏ hàng -->
                <form id="productBuyForm">
                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">

                    <!-- Chọn Dung Lượng / Bộ Nhớ -->
                    <?php if (!empty($storageOptions)): ?>
                        <div class="option-select-group">
                            <label class="option-group-label">Chọn Bộ Nhớ Trong:</label>
                            <div class="option-pills-row">
                                <?php foreach ($storageOptions as $idx => $storage): ?>
                                    <label class="custom-variant-pill">
                                        <input type="radio" name="selected_storage" value="<?= e($storage) ?>" <?= $idx === 0 ? 'checked' : '' ?>>
                                        <span><?= e($storage) ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Chọn Màu Sắc -->
                    <?php if (!empty($colorOptions)): ?>
                        <div class="option-select-group">
                            <label class="option-group-label">Chọn Màu Sắc:</label>
                            <div class="option-pills-row">
                                <?php foreach ($colorOptions as $idx => $color): ?>
                                    <label class="custom-variant-pill">
                                        <input type="radio" name="selected_color" value="<?= e($color) ?>" <?= $idx === 0 ? 'checked' : '' ?>>
                                        <span><?= e($color) ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Chọn Số lượng -->
                    <div class="quantity-select-group">
                        <label class="option-group-label">Số lượng:</label>
                        <div class="qty-counter-box">
                            <button type="button" class="btn-qty minus" onclick="decreaseQty()">-</button>
                            <input type="number" name="quantity" id="productQuantity" value="1" min="1" max="<?= $product['stock_quantity'] ?>" readonly>
                            <button type="button" class="btn-qty plus" onclick="increaseQty(<?= $product['stock_quantity'] ?>)">+</button>
                        </div>
                    </div>

                    <!-- Nút Mua Hàng & Thêm vào Giỏ -->
                    <div class="product-buy-actions">
                        <button type="button" class="btn-detail-buynow" onclick="handleBuyNow(<?= $product['id'] ?>)">
                            <i class="fa-solid fa-bolt"></i>
                            <div>
                                <strong>MUA NGAY</strong>
                                <small>Giao siêu tốc 2H hoặc nhận tại cửa hàng</small>
                            </div>
                        </button>
                        <button type="button" class="btn-detail-addcart" onclick="handleAddDetailCart(<?= $product['id'] ?>)">
                            <i class="fa-solid fa-cart-plus"></i>
                            <span>Thêm Giỏ Hàng</span>
                        </button>
                    </div>
                </form>

                <!-- Hộp Ưu Đãi Độc Quyền LongTech -->
                <div class="exclusive-promos-box">
                    <div class="promos-header">
                        <i class="fa-solid fa-gift text-danger"></i> <strong>Ưu Đãi Đặc Quyền Tại LongTech:</strong>
                    </div>
                    <ul class="promos-list">
                        <li><i class="fa-solid fa-circle-check"></i> Tặng ngay mã giảm giá <strong>50.000đ</strong> cho khách hàng thân thiết.</li>
                        <li><i class="fa-solid fa-circle-check"></i> Trợ giá thu cũ đổi mới lên đến <strong>2.500.000đ</strong>.</li>
                        <li><i class="fa-solid fa-circle-check"></i> Giảm thêm <strong>5%</strong> cho Học sinh - Sinh viên khi mua Laptop & Tablet.</li>
                        <li><i class="fa-solid fa-circle-check"></i> Miễn phí dán màn hình cường lực và vệ sinh máy trọn đời.</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- 3. KHUNG CHI TIẾT BÊN DƯỚI: MÔ TẢ & THÔNG SỐ KỸ THUẬT -->
        <div class="product-tabs-wrapper">
            <div class="tabs-header">
                <button type="button" class="tab-btn active" onclick="switchDetailTab('descTab', this)">
                    <i class="fa-solid fa-file-lines"></i> Đặc Điểm Nổi Bật
                </button>
                <button type="button" class="tab-btn" onclick="switchDetailTab('specsTab', this)">
                    <i class="fa-solid fa-sliders"></i> Thông Số Kỹ Thuật
                </button>
                <button type="button" class="tab-btn" onclick="switchDetailTab('reviewsTab', this)">
                    <i class="fa-solid fa-comments"></i> Đánh Giá (<?= count($reviews) ?>)
                </button>
            </div>

            <!-- Tab 1: Bài viết mô tả chi tiết -->
            <div class="tab-pane active" id="descTab">
                <div class="product-description-content">
                    <?= !empty($product['description']) ? $product['description'] : '<p>' . e($product['short_description']) . '</p>' ?>
                </div>
            </div>

            <!-- Tab 2: Bảng thông số kỹ thuật chi tiết -->
            <div class="tab-pane" id="specsTab">
                <div class="specs-table-wrapper">
                    <table class="specs-table">
                        <tbody>
                            <?php if (!empty($product['screen'])): ?>
                                <tr><th>Kích thước màn hình</th><td><?= e($product['screen']) ?></td></tr>
                            <?php endif; ?>
                            <?php if (!empty($product['camera'])): ?>
                                <tr><th>Hệ thống Camera</th><td><?= e($product['camera']) ?></td></tr>
                            <?php endif; ?>
                            <?php if (!empty($product['ram_options'])): ?>
                                <tr><th>Bộ nhớ RAM</th><td><?= e($product['ram_options']) ?></td></tr>
                            <?php endif; ?>
                            <?php if (!empty($product['storage_options'])): ?>
                                <tr><th>Dung lượng lưu trữ</th><td><?= e($product['storage_options']) ?></td></tr>
                            <?php endif; ?>
                            <?php if (!empty($product['battery'])): ?>
                                <tr><th>Dung lượng Pin & Sạc</th><td><?= e($product['battery']) ?></td></tr>
                            <?php endif; ?>
                            <?php if (!empty($product['colors'])): ?>
                                <tr><th>Các phiên bản màu</th><td><?= e($product['colors']) ?></td></tr>
                            <?php endif; ?>
                            <tr><th>Thời gian bảo hành</th><td><strong><?= e($product['warranty_months']) ?> Tháng</strong> chính hãng</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Tab 3: Đánh giá của khách hàng -->
            <div class="tab-pane" id="reviewsTab">
                <div class="reviews-section-layout">
                    <!-- Form gửi đánh giá -->
                    <div class="write-review-box">
                        <h4>Viết đánh giá của bạn</h4>
                        <?php if ($currentUser): ?>
                            <form action="<?= APP_URL ?>/san-pham/danh-gia" method="POST">
                                <?= csrf_field() ?>
                                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                <input type="hidden" name="slug" value="<?= $product['slug'] ?>">

                                <div class="rating-stars-select">
                                    <span>Chấm điểm:</span>
                                    <div class="star-inputs">
                                        <input type="radio" name="rating" id="star5" value="5" checked><label for="star5">★ 5 Sao</label>
                                        <input type="radio" name="rating" id="star4" value="4"><label for="star4">★ 4 Sao</label>
                                        <input type="radio" name="rating" id="star3" value="3"><label for="star3">★ 3 Sao</label>
                                        <input type="radio" name="rating" id="star2" value="2"><label for="star2">★ 2 Sao</label>
                                        <input type="radio" name="rating" id="star1" value="1"><label for="star1">★ 1 Sao</label>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <textarea name="comment" rows="4" class="form-control" placeholder="Chia sẻ cảm nhận chân thực của bạn về sản phẩm này..." required></textarea>
                                </div>

                                <button type="submit" class="btn-primary-tech">
                                    <i class="fa-solid fa-paper-plane"></i> Gửi Đánh Giá Ngay
                                </button>
                            </form>
                        <?php else: ?>
                            <div class="login-to-review-alert">
                                <p><i class="fa-solid fa-lock"></i> Bạn cần đăng nhập để có thể viết đánh giá cho sản phẩm này.</p>
                                <a href="<?= APP_URL ?>/dang-nhap" class="btn-primary-tech" style="margin-top:10px;">Đăng nhập tài khoản</a>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Danh sách đánh giá -->
                    <div class="reviews-list-box">
                        <h4>Đánh giá từ khách hàng đã mua (<?= count($reviews) ?>)</h4>
                        <?php if (!empty($reviews)): ?>
                            <div class="reviews-list">
                                <?php foreach ($reviews as $rev): ?>
                                    <div class="review-item">
                                        <div class="review-user-row">
                                            <div class="reviewer-avatar">
                                                <?= strtoupper(substr(e($rev['full_name'] ?? 'U'), 0, 1)) ?>
                                            </div>
                                            <div>
                                                <strong><?= e($rev['full_name']) ?></strong>
                                                <div class="review-stars-gold">
                                                    <?php for ($s = 1; $s <= 5; $s++): ?>
                                                        <i class="fa-solid fa-star <?= $s <= $rev['rating'] ? 'text-warning' : 'text-gray' ?>"></i>
                                                    <?php endfor; ?>
                                                </div>
                                            </div>
                                            <span class="review-date"><?= date('d/m/Y', strtotime($rev['created_at'])) ?></span>
                                        </div>
                                        <p class="review-comment"><?= nl2br(e($rev['comment'])) ?></p>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted" style="font-size:13px;padding:20px 0;">Chưa có đánh giá nào cho sản phẩm này. Hãy là người đầu tiên để lại nhận xét!</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- 4. KHU VỰC HỎI VÀ ĐÁP (Q&A THEO PHONG CÁCH CELLPHONES) -->
        <?php 
        $productId = $product['id'];
        require VIEW_PATH . '/client/components/faq_section.php'; 
        ?>

        <!-- 5. SẢN PHẨM LIÊN QUAN (RELATED PRODUCTS) -->
        <?php if (!empty($relatedProducts)): ?>
            <div class="related-products-section">
                <h3 class="section-title"><i class="fa-solid fa-fire text-danger"></i> Sản Phẩm Tương Tự Cùng Phân Khúc</h3>
                <div class="products-grid">
                    <?php foreach ($relatedProducts as $relProd): ?>
                        <div class="product-card">
                            <a href="<?= APP_URL ?>/san-pham/<?= e($relProd['slug']) ?>" class="product-thumb-link">
                                <img src="<?= e($relProd['thumbnail']) ?>" alt="<?= e($relProd['name']) ?>" class="product-thumb" loading="lazy">
                            </a>
                            <div class="product-body">
                                <span class="product-brand"><?= e($relProd['brand_name'] ?? 'LongTech') ?></span>
                                <h4 class="product-name">
                                    <a href="<?= APP_URL ?>/san-pham/<?= e($relProd['slug']) ?>"><?= e($relProd['name']) ?></a>
                                </h4>
                                <div class="product-pricing">
                                    <div class="price-current">
                                        <?= format_money(!empty($relProd['sale_price']) ? $relProd['sale_price'] : $relProd['price']) ?>
                                    </div>
                                </div>
                                <div class="product-actions">
                                    <button type="button" class="btn-add-cart" onclick="addToCart(<?= $relProd['id'] ?>)">
                                        <i class="fa-solid fa-cart-plus"></i> Thêm giỏ
                                    </button>
                                    <a href="<?= APP_URL ?>/san-pham/<?= e($relProd['slug']) ?>" class="btn-buy-now">
                                        Chi tiết
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Đổi ảnh chính khi bấm vào thumbnail
function switchProductImage(imgUrl, thumbEl) {
    document.getElementById('mainDetailImg').src = imgUrl;
    document.querySelectorAll('.thumb-item').forEach(el => el.classList.remove('active'));
    thumbEl.classList.add('active');
}

// Tăng giảm số lượng mua
function increaseQty(maxStock) {
    const qtyInput = document.getElementById('productQuantity');
    let val = parseInt(qtyInput.value) || 1;
    if (val < maxStock) {
        qtyInput.value = val + 1;
    } else {
        showToast('Số lượng đã đạt giới hạn tồn kho hiện có!', 'warning');
    }
}

function decreaseQty() {
    const qtyInput = document.getElementById('productQuantity');
    let val = parseInt(qtyInput.value) || 1;
    if (val > 1) {
        qtyInput.value = val - 1;
    }
}

// Chuyển tab mô tả / thông số / đánh giá
function switchDetailTab(tabId, btn) {
    document.querySelectorAll('.tab-pane').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    document.getElementById(tabId).classList.add('active');
    if (btn) btn.classList.add('active');
}

function openReviewsTabAndScroll() {
    const reviewBtn = document.querySelector("button[onclick*='reviewsTab']");
    switchDetailTab('reviewsTab', reviewBtn);
    const tabEl = document.getElementById('reviewsTab');
    if (tabEl) {
        tabEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

document.addEventListener('DOMContentLoaded', function() {
    if (window.location.hash === '#reviewsTab' || window.location.hash === '#reviews') {
        openReviewsTabAndScroll();
    }
});

// Xử lý Thêm giỏ hàng từ trang chi tiết
function handleAddDetailCart(productId) {
    const form = document.getElementById('productBuyForm');
    const qty = form.quantity.value;
    const color = form.selected_color ? form.selected_color.value : '';
    const storage = form.selected_storage ? form.selected_storage.value : '';
    addToCart(productId, qty, color, storage);
}

// Xử lý Mua ngay (Thêm vào giỏ và chuyển thẳng sang Thanh toán)
function handleBuyNow(productId) {
    const form = document.getElementById('productBuyForm');
    const qty = form.quantity.value;
    const color = form.selected_color ? form.selected_color.value : '';
    const storage = form.selected_storage ? form.selected_storage.value : '';

    const formData = new FormData();
    formData.append('product_id', productId);
    formData.append('quantity', qty);
    formData.append('color', color);
    formData.append('storage', storage);
    formData.append('csrf_token', CSRF_TOKEN);

    fetch(APP_URL + '/gio-hang/them', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        window.location.href = APP_URL + '/thanh-toan';
    })
    .catch(() => {
        window.location.href = APP_URL + '/gio-hang/them?id=' + productId + '&buynow=1';
    });
}
</script>

