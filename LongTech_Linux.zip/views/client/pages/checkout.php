<?php
/**
 * ========================================================
 * LONGTECH - TRANG THANH TOÁN & ĐẶT HÀNG (checkout.php)
 * ========================================================
 * - Tối ưu 100% hiển thị 1 cột trên màn hình điện thoại
 * - Tự động điền dữ liệu nếu khách hàng đã đăng nhập
 * - BẢO MẬT: Chống kẹt overlay/modal xám đen khi mua hàng
 * - Hỗ trợ COD và Chuyển khoản ngân hàng kèm mã QR tiện lợi
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="checkout-page-wrapper">
    <div class="container">
        <!-- 1. BREADCRUMBS -->
        <nav class="breadcrumb-nav">
            <a href="<?= APP_URL ?>"><i class="fa-solid fa-house"></i> Trang chủ</a>
            <span class="bc-sep">/</span>
            <a href="<?= APP_URL ?>/gio-hang">Giỏ hàng</a>
            <span class="bc-sep">/</span>
            <span class="bc-current">Thanh toán & Đặt hàng</span>
        </nav>

        <?php if (!empty($successOrder)): ?>
            <!-- GIAO DIỆN ĐẶT HÀNG THÀNH CÔNG CHO KHÁCH VÃNG LAI -->
            <div class="order-success-card">
                <div class="success-icon-box"><i class="fa-solid fa-circle-check"></i></div>
                <h2 class="success-title">Đặt Hàng Thành Công!</h2>
                <p class="success-subtitle">Cảm ơn bạn đã tin tưởng và mua sắm tại hệ thống LongTech.</p>

                <div class="success-details-box">
                    <p>Mã đơn hàng của bạn: <strong class="text-primary" style="font-size:18px;"><?= e($successOrder) ?></strong></p>
                    <p>Bộ phận CSKH LongTech sẽ liên hệ xác nhận đơn hàng và điều phối giao nhanh trong vòng <strong>2 giờ</strong>.</p>
                </div>

                <div class="success-actions">
                    <a href="<?= APP_URL ?>" class="btn-primary-tech"><i class="fa-solid fa-store"></i> Tiếp tục mua sắm</a>
                    <?php if (is_logged_in()): ?>
                        <a href="<?= APP_URL ?>/tai-khoan/don-hang" class="btn-secondary-tech"><i class="fa-solid fa-box-open"></i> Xem đơn hàng của tôi</a>
                    <?php endif; ?>
                </div>
            </div>

        <?php else: ?>
            <!-- FORM THANH TOÁN CHÍNH -->
            <h1 class="checkout-heading"><i class="fa-solid fa-credit-card text-primary"></i> Thông Tin Thanh Toán & Nhận Hàng</h1>

            <form action="<?= APP_URL ?>/thanh-toan" method="POST" id="checkoutForm" onsubmit="return handleCheckoutSubmit(event)">
                <?= csrf_field() ?>

                <div class="checkout-grid-layout">
                    <!-- Cột trái: Thông tin người nhận hàng & Phương thức thanh toán -->
                    <div class="checkout-form-column">
                        <!-- Khung 1: Địa chỉ giao hàng -->
                        <div class="checkout-box">
                            <h3 class="checkout-box-title">
                                <i class="fa-solid fa-location-dot text-danger"></i> 1. Địa Chỉ Nhận Hàng
                            </h3>

                            <div class="form-row-2">
                                <div class="form-group">
                                    <label for="customer_name" class="form-label">Họ và tên người nhận <span class="required">*</span></label>
                                    <input type="text" name="customer_name" id="customer_name" class="form-control" placeholder="Nguyễn Văn A" value="<?= e($currentUser['full_name'] ?? '') ?>" required autofocus>
                                </div>
                                <div class="form-group">
                                    <label for="customer_phone" class="form-label">Số điện thoại nhận hàng <span class="required">*</span></label>
                                    <input type="tel" name="customer_phone" id="customer_phone" class="form-control" placeholder="0912345678" value="<?= e($currentUser['phone'] ?? '') ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="customer_email" class="form-label">Email nhận thông báo đơn hàng</label>
                                <input type="email" name="customer_email" id="customer_email" class="form-control" placeholder="email@domain.com" value="<?= e($currentUser['email'] ?? '') ?>">
                            </div>

                            <div class="form-row-3">
                                <div class="form-group">
                                    <label for="city" class="form-label">Tỉnh / Thành phố <span class="required">*</span></label>
                                    <input type="text" name="city" id="city" class="form-control" placeholder="Hà Nội, TP.HCM..." value="Hà Nội" required>
                                </div>
                                <div class="form-group">
                                    <label for="district" class="form-label">Quận / Huyện <span class="required">*</span></label>
                                    <input type="text" name="district" id="district" class="form-control" placeholder="Cầu Giấy, Ba Đình..." value="Quận Cầu Giấy" required>
                                </div>
                                <div class="form-group">
                                    <label for="ward" class="form-label">Phường / Xã <span class="required">*</span></label>
                                    <input type="text" name="ward" id="ward" class="form-control" placeholder="Dịch Vọng Hậu..." value="Phường Dịch Vọng" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="customer_address" class="form-label">Địa chỉ cụ thể (Số nhà, Tên đường) <span class="required">*</span></label>
                                <input type="text" name="customer_address" id="customer_address" class="form-control" placeholder="Số 123 Đường Cầu Giấy..." value="<?= e($currentUser['address'] ?? '') ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="note" class="form-label">Ghi chú giao hàng (Tùy chọn)</label>
                                <textarea name="note" id="note" rows="2" class="form-control" placeholder="Ví dụ: Giao giờ hành chính, gọi điện trước khi tới..."></textarea>
                            </div>
                        </div>

                        <!-- Khung 2: Phương thức thanh toán -->
                        <div class="checkout-box">
                            <h3 class="checkout-box-title">
                                <i class="fa-solid fa-wallet text-secondary"></i> 2. Phương Thức Thanh Toán
                            </h3>

                            <div class="payment-methods-selector">
                                <!-- Lựa chọn 1: COD -->
                                <label class="payment-method-option active" onclick="selectPaymentMethod('cod', this)">
                                    <div class="payment-radio-wrap">
                                        <input type="radio" name="payment_method" value="cod" checked>
                                    </div>
                                    <div class="payment-icon-box"><i class="fa-solid fa-money-bill-wave text-success"></i></div>
                                    <div class="payment-text-info">
                                        <strong>Thanh toán tiền mặt khi nhận hàng (COD)</strong>
                                        <p>Nhận hàng, kiểm tra sản phẩm chính hãng trước khi thanh toán tiền cho shipper.</p>
                                    </div>
                                </label>

                                <!-- Lựa chọn 2: Chuyển khoản ngân hàng -->
                                <label class="payment-method-option" onclick="selectPaymentMethod('bank_transfer', this)">
                                    <div class="payment-radio-wrap">
                                        <input type="radio" name="payment_method" value="bank_transfer">
                                    </div>
                                    <div class="payment-icon-box"><i class="fa-solid fa-building-columns text-primary"></i></div>
                                    <div class="payment-text-info">
                                        <strong>Chuyển khoản qua Ngân hàng / Quét mã VietQR</strong>
                                        <p>Hỗ trợ tất cả ứng dụng ngân hàng và ví điện tử, xử lý tự động 24/7.</p>
                                    </div>
                                </label>
                            </div>

                            <!-- Thông tin chuyển khoản (Hiện khi chọn Bank Transfer) -->
                            <div class="bank-transfer-details" id="bankTransferDetails" style="display: none;">
                                <h4><i class="fa-solid fa-qrcode"></i> Thông Tin Chuyển Khoản Ngân Hàng:</h4>
                                <div class="bank-info-grid">
                                    <div class="bank-row">
                                        <span>Ngân hàng thụ hưởng:</span>
                                        <strong>Ngân Hàng Ngoại Thương (Vietcombank)</strong>
                                    </div>
                                    <div class="bank-row">
                                        <span>Số tài khoản:</span>
                                        <strong class="text-danger" style="font-size:16px;">1900 6868 99</strong>
                                    </div>
                                    <div class="bank-row">
                                        <span>Chủ tài khoản:</span>
                                        <strong>CONG TY CO PHAN CONG NGHE LONGTECH</strong>
                                    </div>
                                    <div class="bank-row">
                                        <span>Nội dung chuyển khoản:</span>
                                        <strong class="text-primary">LT [Họ tên] [SĐT người nhận]</strong>
                                    </div>
                                </div>
                                <small class="text-muted" style="display:block;margin-top:8px;">
                                    * Sau khi chuyển khoản, đơn hàng sẽ được kích hoạt chuyển ngay cho đối tác vận chuyển.
                                </small>
                            </div>
                        </div>
                    </div>

                    <!-- Cột phải: Xem lại đơn hàng & Nút Xác nhận đặt hàng -->
                    <div class="checkout-review-column">
                        <div class="checkout-summary-card">
                            <h3 class="summary-title">Đơn Hàng Của Bạn (<?= $cartTotals['total_items'] ?> món)</h3>

                            <!-- Danh sách rút gọn sản phẩm -->
                            <div class="checkout-items-list">
                                <?php foreach ($cart as $item): ?>
                                    <div class="checkout-mini-item">
                                        <img src="<?= e($item['thumbnail']) ?>" alt="<?= e($item['name']) ?>" class="mini-item-thumb">
                                        <div class="mini-item-info">
                                            <h5 class="mini-item-title"><?= e($item['name']) ?></h5>
                                            <small class="mini-item-variant">
                                                <?= !empty($item['color']) ? e($item['color']) : '' ?>
                                                <?= !empty($item['storage']) ? ' - ' . e($item['storage']) : '' ?>
                                                &times; <?= $item['quantity'] ?>
                                            </small>
                                        </div>
                                        <span class="mini-item-price"><?= format_money((float)$item['price'] * (int)$item['quantity']) ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <!-- Tính tiền -->
                            <div class="summary-lines">
                                <div class="summary-line">
                                    <span>Tạm tính:</span>
                                    <span class="font-bold"><?= format_money($cartTotals['subtotal']) ?></span>
                                </div>
                                <?php if ($cartTotals['discount'] > 0): ?>
                                    <div class="summary-line text-success">
                                        <span>Giảm giá (<?= e($cartTotals['coupon_code']) ?>):</span>
                                        <span>-<?= format_money($cartTotals['discount']) ?></span>
                                    </div>
                                <?php endif; ?>
                                <div class="summary-line">
                                    <span>Phí giao hàng:</span>
                                    <span>
                                        <?php if ($cartTotals['is_freeship']): ?>
                                            <strong class="text-success">MIỄN PHÍ</strong>
                                        <?php else: ?>
                                            <?= format_money($cartTotals['shipping_fee']) ?>
                                        <?php endif; ?>
                                    </span>
                                </div>
                                <hr class="summary-divider">
                                <div class="summary-line total-line">
                                    <span>Tổng thanh toán:</span>
                                    <span class="total-price-large"><?= format_money($cartTotals['total_amount']) ?></span>
                                </div>
                            </div>

                            <!-- Nút Xác nhận đặt hàng -->
                            <button type="submit" class="btn-confirm-order" id="btnConfirmOrder">
                                <i class="fa-solid fa-lock"></i> XÁC NHẬN ĐẶT HÀNG NGAY
                            </button>

                            <p class="checkout-safe-notice">
                                <i class="fa-solid fa-shield-check text-success"></i> Nhấn "Xác nhận đặt hàng" đồng nghĩa với việc bạn đồng ý tuân theo Quy chế hoạt động của LongTech.
                            </p>
                        </div>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>

<script>
// Đổi phương thức thanh toán
function selectPaymentMethod(method, labelEl) {
    document.querySelectorAll('.payment-method-option').forEach(el => el.classList.remove('active'));
    labelEl.classList.add('active');
    
    const bankDetails = document.getElementById('bankTransferDetails');
    if (method === 'bank_transfer') {
        bankDetails.style.display = 'block';
    } else {
        bankDetails.style.display = 'none';
    }
}

// Xử lý gửi Form & Dọn dẹp overlay chống kẹt màn hình xám đen
function handleCheckoutSubmit(e) {
    const btn = document.getElementById('btnConfirmOrder');
    if (btn) {
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> ĐANG XỬ LÝ ĐƠN HÀNG...';
        btn.style.pointerEvents = 'none';
    }
    // Đảm bảo không còn bất kỳ overlay nào bị kẹt
    if (typeof cleanAllOverlays === 'function') {
        cleanAllOverlays();
    }
    return true;
}
</script>

