<?php
/**
 * ========================================================
 * LONGTECH - GIAO DIỆN ĐĂNG KÝ (register.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}
?>

<div class="auth-page-wrapper">
    <div class="container">
        <div class="auth-card register-card">
            <!-- Header của thẻ Auth -->
            <div class="auth-card-header">
                <div class="auth-logo">
                    <div class="logo-icon"><i class="fa-solid fa-microchip"></i></div>
                    <span class="logo-text">LONG<span>TECH</span></span>
                </div>
                <h2 class="auth-title">Đăng Ký Thành Viên Mới</h2>
                <p class="auth-subtitle">Tạo tài khoản để nhận voucher 50.000đ và hưởng ưu đãi dành riêng cho bạn</p>
            </div>

            <!-- Form Đăng ký -->
            <form action="<?= APP_URL ?>/dang-ky" method="POST" class="auth-form" id="registerForm" onsubmit="return validateRegisterForm(event)">
                <?= csrf_field() ?>

                <!-- Họ và tên -->
                <div class="form-group">
                    <label for="full_name" class="form-label">Họ và tên của bạn <span class="required">*</span></label>
                    <div class="input-with-icon">
                        <i class="fa-regular fa-user input-icon"></i>
                        <input type="text" name="full_name" id="full_name" class="form-control" placeholder="Ví dụ: Nguyễn Văn Long" required autofocus>
                    </div>
                </div>

                <!-- Hàng gồm Username & Số điện thoại -->
                <div class="form-row-2">
                    <div class="form-group">
                        <label for="username" class="form-label">Tên tài khoản <span class="required">*</span></label>
                        <div class="input-with-icon">
                            <i class="fa-solid fa-at input-icon"></i>
                            <input type="text" name="username" id="username" class="form-control" placeholder="longtech_2026" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="phone" class="form-label">Số điện thoại</label>
                        <div class="input-with-icon">
                            <i class="fa-solid fa-phone input-icon"></i>
                            <input type="tel" name="phone" id="phone" class="form-control" placeholder="0912345678">
                        </div>
                    </div>
                </div>

                <!-- Địa chỉ Email -->
                <div class="form-group">
                    <label for="email" class="form-label">Địa chỉ Email <span class="required">*</span></label>
                    <div class="input-with-icon">
                        <i class="fa-regular fa-envelope input-icon"></i>
                        <input type="email" name="email" id="email" class="form-control" placeholder="email@gmail.com" required>
                    </div>
                </div>

                <!-- Hàng Mật khẩu & Xác nhận mật khẩu -->
                <div class="form-row-2">
                    <div class="form-group">
                        <label for="password" class="form-label">Mật khẩu <span class="required">*</span></label>
                        <div class="input-with-icon">
                            <i class="fa-solid fa-lock input-icon"></i>
                            <input type="password" name="password" id="password" class="form-control" placeholder="Tối thiểu 6 ký tự" required>
                            <button type="button" class="btn-toggle-password" onclick="togglePasswordVisibility('password', this)">
                                <i class="fa-regular fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password" class="form-label">Nhập lại mật khẩu <span class="required">*</span></label>
                        <div class="input-with-icon">
                            <i class="fa-solid fa-shield-halved input-icon"></i>
                            <input type="password" name="confirm_password" id="confirm_password" class="form-control" placeholder="Khớp với mật khẩu trên" required>
                            <button type="button" class="btn-toggle-password" onclick="togglePasswordVisibility('confirm_password', this)">
                                <i class="fa-regular fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Đồng ý điều khoản -->
                <div class="form-group terms-checkbox-group">
                    <label class="custom-checkbox-label">
                        <input type="checkbox" name="agree_terms" id="agree_terms" checked required>
                        <span>Tôi đồng ý với <a href="<?= APP_URL ?>/tin-tuc" target="_blank">Điều khoản sử dụng</a> và <a href="<?= APP_URL ?>/chinh-sach-bao-mat" target="_blank">Chính sách bảo mật</a> của LongTech</span>
                    </label>
                </div>

                <!-- Nút Submit Đăng Ký -->
                <button type="submit" class="btn-auth-submit">
                    <i class="fa-solid fa-user-plus"></i> Đăng Ký Tài Khoản
                </button>
            </form>

            <!-- Footer của thẻ Auth -->
            <div class="auth-card-footer">
                <p>Đã có tài khoản LongTech? <a href="<?= APP_URL ?>/dang-nhap" class="auth-switch-link">Đăng nhập ngay tại đây</a></p>
            </div>
        </div>
    </div>
</div>

<script>
function togglePasswordVisibility(inputId, btn) {
    const input = document.getElementById(inputId);
    const icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

function validateRegisterForm(e) {
    const form = document.getElementById('registerForm');
    const p1 = form.password.value;
    const p2 = form.confirm_password.value;
    if (p1.length < 6) {
        showToast('Mật khẩu phải chứa ít nhất 6 ký tự!', 'error');
        return false;
    }
    if (p1 !== p2) {
        showToast('Mật khẩu xác nhận không khớp!', 'error');
        return false;
    }
    return true;
}
</script>

