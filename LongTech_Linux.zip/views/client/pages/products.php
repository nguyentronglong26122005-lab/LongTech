<?php
/**
 * ========================================================
 * LONGTECH - TRANG DANH SÁCH SẢN PHẨM (products.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

// Hàm trợ giúp tạo URL phân trang giữ nguyên các bộ lọc hiện tại
function buildPaginationUrl($targetPage) {
    $queryParams = $_GET;
    $queryParams['page'] = $targetPage;
    return '?' . http_build_query($queryParams);
}
?>

<div class="products-catalog-page">
    <div class="container">
        <!-- 1. BREADCRUMBS ĐIỀU HƯỚNG -->
        <nav class="breadcrumb-nav">
            <a href="<?= APP_URL ?>"><i class="fa-solid fa-house"></i> Trang chủ</a>
            <span class="bc-sep">/</span>
            <?php if (!empty($currentCategory)): ?>
                <span class="bc-current"><?= e($currentCategory['name']) ?></span>
            <?php elseif (!empty($filters['keyword'])): ?>
                <span class="bc-current">Tìm kiếm: "<?= e($filters['keyword']) ?>"</span>
            <?php elseif (($route ?? '') === 'khuyen-mai'): ?>
                <span class="bc-current">Săn Sale Khuyến Mãi</span>
            <?php else: ?>
                <span class="bc-current">Tất cả sản phẩm công nghệ</span>
            <?php endif; ?>
        </nav>

        <!-- 2. TIÊU ĐỀ & THANH CÔNG CỤ SẮP XẾP -->
        <div class="catalog-toolbar">
            <div class="toolbar-left">
                <h1 class="catalog-heading">
                    <?php if (!empty($currentCategory)): ?>
                        <?= e($currentCategory['name']) ?> Chính Hãng
                    <?php elseif (!empty($filters['keyword'])): ?>
                        Kết quả cho "<?= e($filters['keyword']) ?>"
                    <?php elseif (($route ?? '') === 'khuyen-mai'): ?>
                        Flash Sale & Khuyến Mãi Độc Quyền
                    <?php else: ?>
                        Thiết Bị Công Nghệ Chính Hãng
                    <?php endif; ?>
                </h1>
                <span class="result-count">Tìm thấy <strong><?= $totalProducts ?></strong> sản phẩm phù hợp</span>
            </div>

            <!-- Nút bật bộ lọc trên Mobile -->
            <button type="button" class="btn-toggle-filter-mobile" id="openFilterMobileBtn">
                <i class="fa-solid fa-filter"></i> Bộ Lọc & Tìm Kiếm
            </button>

            <!-- Bộ sắp xếp sản phẩm -->
            <div class="toolbar-sort">
                <label for="sortSelect" class="sort-label"><i class="fa-solid fa-arrow-down-short-wide"></i> Sắp xếp:</label>
                <select id="sortSelect" class="sort-select" onchange="applySorting(this.value)">
                    <option value="newest" <?= ($filters['sort'] ?? '') === 'newest' ? 'selected' : '' ?>>Mới nhất</option>
                    <option value="price_asc" <?= ($filters['sort'] ?? '') === 'price_asc' ? 'selected' : '' ?>>Giá: Thấp đến Cao</option>
                    <option value="price_desc" <?= ($filters['sort'] ?? '') === 'price_desc' ? 'selected' : '' ?>>Giá: Cao đến Thấp</option>
                    <option value="rating_desc" <?= ($filters['sort'] ?? '') === 'rating_desc' ? 'selected' : '' ?>>Đánh giá cao nhất</option>
                    <option value="views_desc" <?= ($filters['sort'] ?? '') === 'views_desc' ? 'selected' : '' ?>>Xem nhiều nhất</option>
                </select>
            </div>
        </div>

        <!-- 3. KHUNG CHÍNH: SIDEBAR LỌC + LƯỚI SẢN PHẨM -->
        <div class="catalog-main-layout">
            <!-- Sidebar Lọc bên trái -->
            <?php require_once VIEW_PATH . '/client/layouts/sidebar.php'; ?>

            <!-- Cột Lưới Sản Phẩm bên phải -->
            <div class="catalog-products-column">
                <?php if (!empty($products)): ?>
                    <div class="products-grid catalog-grid">
                        <?php foreach ($products as $product): ?>
                            <?php 
                                $discountPercent = 0;
                                if (!empty($product['sale_price']) && $product['sale_price'] < $product['price']) {
                                    $discountPercent = round((($product['price'] - $product['sale_price']) / $product['price']) * 100);
                                }
                            ?>
                            <div class="product-card">
                                <?php if ($discountPercent > 0): ?>
                                    <span class="discount-badge">Giảm <?= $discountPercent ?>%</span>
                                <?php endif; ?>

                                <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="product-thumb-link">
                                    <img src="<?= e($product['thumbnail']) ?>" alt="<?= e($product['name']) ?>" class="product-thumb" loading="lazy">
                                </a>

                                <div class="product-body">
                                    <span class="product-brand"><?= e($product['brand_name'] ?? 'Chính hãng') ?></span>
                                    <h4 class="product-name">
                                        <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>"><?= e($product['name']) ?></a>
                                    </h4>

                                    <div class="product-specs">
                                        <?php if (!empty($product['ram_options'])): ?>
                                            <span class="spec-tag"><?= e(explode(',', $product['ram_options'])[0]) ?></span>
                                        <?php endif; ?>
                                        <?php if (!empty($product['storage_options'])): ?>
                                            <span class="spec-tag"><?= e(explode(',', $product['storage_options'])[0]) ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <div class="product-pricing">
                                        <div class="price-current">
                                            <?= format_money(!empty($product['sale_price']) ? $product['sale_price'] : $product['price']) ?>
                                        </div>
                                        <?php if (!empty($product['sale_price']) && $product['sale_price'] < $product['price']): ?>
                                            <div class="price-original"><?= format_money($product['price']) ?></div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="product-rating">
                                        <div class="stars">
                                            <i class="fa-solid fa-star"></i>
                                            <span><?= number_format((float)$product['rating'], 1) ?></span>
                                        </div>
                                        <span class="stock-status in-stock"><i class="fa-solid fa-shield"></i> BH 12 tháng</span>
                                    </div>

                                    <div class="product-actions">
                                        <button type="button" class="btn-add-cart" onclick="addToCart(<?= $product['id'] ?>)">
                                            <i class="fa-solid fa-cart-plus"></i> Thêm giỏ
                                        </button>
                                        <a href="<?= APP_URL ?>/san-pham/<?= e($product['slug']) ?>" class="btn-buy-now">
                                            Chi tiết
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- 4. PHÂN TRANG (PAGINATION) -->
                    <?php if ($totalPages > 1): ?>
                        <div class="pagination-wrapper">
                            <ul class="pagination-list">
                                <!-- Nút Trang trước -->
                                <?php if ($currentPage > 1): ?>
                                    <li><a href="<?= buildPaginationUrl($currentPage - 1) ?>" class="page-link prev"><i class="fa-solid fa-chevron-left"></i> Trước</a></li>
                                <?php endif; ?>

                                <!-- Các số trang -->
                                <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                                    <?php if ($p == 1 || $p == $totalPages || ($p >= $currentPage - 2 && $p <= $currentPage + 2)): ?>
                                        <li>
                                            <a href="<?= buildPaginationUrl($p) ?>" class="page-link <?= $p == $currentPage ? 'active' : '' ?>">
                                                <?= $p ?>
                                            </a>
                                        </li>
                                    <?php elseif ($p == $currentPage - 3 || $p == $currentPage + 3): ?>
                                        <li class="page-ellipsis">...</li>
                                    <?php endif; ?>
                                <?php endfor; ?>

                                <!-- Nút Trang sau -->
                                <?php if ($currentPage < $totalPages): ?>
                                    <li><a href="<?= buildPaginationUrl($currentPage + 1) ?>" class="page-link next">Sau <i class="fa-solid fa-chevron-right"></i></a></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                <?php else: ?>
                    <!-- Trạng thái không có sản phẩm nào khớp -->
                    <div class="empty-products-state">
                        <div class="empty-icon-wrap"><i class="fa-solid fa-magnifying-glass"></i></div>
                        <h3>Không tìm thấy sản phẩm nào!</h3>
                        <p>Rất tiếc, hiện tại không có sản phẩm nào thỏa mãn tất cả tiêu chí bạn đã lọc.</p>
                        <a href="<?= APP_URL ?>/<?= !empty($route) ? e($route) : 'san-pham' ?>" class="btn-primary-tech" style="margin-top:16px;">
                            <i class="fa-solid fa-rotate-left"></i> Xóa bộ lọc và thử lại
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
function applySorting(sortValue) {
    const currentUrl = new URL(window.location.href);
    currentUrl.searchParams.set('sort', sortValue);
    currentUrl.searchParams.set('page', '1'); // Reset về trang 1
    window.location.href = currentUrl.toString();
}

// Xử lý bật/tắt Filter trên màn hình Mobile
document.addEventListener('DOMContentLoaded', function () {
    const openBtn = document.getElementById('openFilterMobileBtn');
    const closeBtn = document.getElementById('closeFilterBtn');
    const sidebar = document.getElementById('productFilterSidebar');

    if (openBtn && sidebar) {
        openBtn.addEventListener('click', function () {
            sidebar.classList.add('mobile-open');
            document.body.style.overflow = 'hidden';
        });
    }

    if (closeBtn && sidebar) {
        closeBtn.addEventListener('click', function () {
            sidebar.classList.remove('mobile-open');
            document.body.style.overflow = '';
        });
    }
});
</script>

