<?php
/**
 * ========================================================
 * LONGTECH - FOOTER CHUẨN GIAO DIỆN BÁN LẺ CELLPHONES (footer.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
?>
</main> <!-- Đóng thẻ .main-content từ header.php -->

<!-- 1. CAM KẾT VÀNG & TIỆN ÍCH DỊCH VỤ -->
<section class="trust-features-section">
    <div class="container">
        <div class="trust-features-grid">
            <div class="trust-box">
                <div class="trust-icon"><i class="fa-solid fa-award"></i></div>
                <div class="trust-text">
                    <h4>Sản phẩm chính hãng 100%</h4>
                    <p>Cam kết xuất xứ rõ ràng, đầy đủ hóa đơn VAT</p>
                </div>
            </div>
            <div class="trust-box">
                <div class="trust-icon"><i class="fa-solid fa-truck-fast"></i></div>
                <div class="trust-text">
                    <h4>Giao nhanh miễn phí</h4>
                    <p>Nội thành 2H, toàn quốc cho đơn từ <?= format_money(FREE_SHIPPING_MIN) ?></p>
                </div>
            </div>
            <div class="trust-box">
                <div class="trust-icon"><i class="fa-solid fa-arrows-rotate"></i></div>
                <div class="trust-text">
                    <h4>Lỗi 1 đổi 1 trong 30 ngày</h4>
                    <p>Phát sinh lỗi kỹ thuật đổi ngay máy mới</p>
                </div>
            </div>
            <div class="trust-box">
                <div class="trust-icon"><i class="fa-solid fa-screwdriver-wrench"></i></div>
                <div class="trust-text">
                    <h4>Bảo hành chính hãng 12 tháng</h4>
                    <p>Hệ thống trung tâm bảo hành tiêu chuẩn ủy quyền</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 2. MEGA FOOTER PHONG CÁCH CELLPHONES (4 CỘT CÂN ĐỐI - KHÔNG ĐỂ TRỐNG) -->
<footer class="cellphones-footer">
    <div class="container">
        <div class="cp-footer-top">
            <!-- CỘT 1: TỔNG ĐÀI, THANH TOÁN & FORM ĐĂNG KÝ NHẬN TIN -->
            <div class="cp-col">
                <h4 class="cp-heading">Tổng đài hỗ trợ miễn phí</h4>
                <ul class="cp-list-hotline">
                    <li>Gọi mua hàng <strong><a href="tel:<?= str_replace(' ', '', HOTLINE) ?>"><?= HOTLINE ?></a></strong> (7h30 - 22h00)</li>
                    <li>Gọi khiếu nại <strong><a href="tel:18002063">1800.2063</a></strong> (8h00 - 21h30)</li>
                    <li>Gọi bảo hành <strong><a href="tel:18002064">1800.2064</a></strong> (8h00 - 21h00)</li>
                </ul>

                <h4 class="cp-heading" style="margin-top: 14px;">Phương thức thanh toán</h4>
                <div class="payment-logos-grid">
                    <span class="pay-badge"><i class="fa-brands fa-apple"></i> Pay</span>
                    <span class="pay-badge vnpay">VNPAY</span>
                    <span class="pay-badge momo">MoMo</span>
                    <span class="pay-badge onepay">OnePay</span>
                    <span class="pay-badge mpos">mPOS</span>
                    <span class="pay-badge kredivo">Kredivo</span>
                    <span class="pay-badge zalopay">ZaloPay</span>
                    <span class="pay-badge fundiin">Fundiin</span>
                </div>

                <!-- ĐĂNG KÝ NHẬN TIN KHUYẾN MÃI (CHUẨN MẪU CELLPHONES) -->
                <div class="cp-newsletter-card">
                    <h5 class="nl-title">ĐĂNG KÝ NHẬN TIN KHUYẾN MÃI</h5>
                    <div class="nl-voucher-tag">
                        <strong>(*) Nhận ngay voucher 10%</strong>
                        <p>Voucher sẽ được gửi sau 24h, chỉ áp dụng cho khách hàng mới</p>
                    </div>
                    <form onsubmit="handleNewsletterSub(event)" class="nl-form">
                        <label class="nl-field-label" for="nlEmail">Email</label>
                        <input type="email" id="nlEmail" placeholder="Nhập email của bạn" required class="nl-input">

                        <label class="nl-field-label" for="nlPhone">Số điện thoại</label>
                        <input type="tel" id="nlPhone" placeholder="Nhập số điện thoại của bạn" class="nl-input">

                        <p class="nl-terms">Bằng việc đăng ký nhận tin, bạn đã đọc và đồng ý với <a href="<?= APP_URL ?>/chinh-sach-bao-mat">Chính sách bảo mật của LongTech.</a></p>
                        <button type="submit" class="nl-btn-submit">ĐĂNG KÝ NGAY</button>
                    </form>
                </div>
            </div>

            <!-- CỘT 2: THÔNG TIN VÀ CHÍNH SÁCH (ĐẦY ĐỦ 15 MỤC LẤP ĐẦY CHIỀU CAO) -->
            <div class="cp-col">
                <h4 class="cp-heading">Thông tin và chính sách</h4>
                <ul class="cp-links">
                    <li><a href="<?= APP_URL ?>/chinh-sach-van-chuyen">Mua hàng và thanh toán Online</a></li>
                    <li><a href="<?= APP_URL ?>/huong-dan-tra-gop">Mua hàng trả góp Online</a></li>
                    <li><a href="<?= APP_URL ?>/huong-dan-tra-gop">Mua hàng trả góp bằng thẻ tín dụng</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-van-chuyen">Chính sách giao hàng</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-doi-tra">Chính sách đổi trả</a></li>
                    <li><a href="<?= APP_URL ?>/tai-khoan">Tra điểm LongMember</a></li>
                    <li><a href="<?= APP_URL ?>/khuyen-mai">Xem ưu đãi LongMember</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-hanh">Tra thông tin bảo hành</a></li>
                    <li><a href="<?= APP_URL ?>/lien-he">Tra cứu hoá đơn điện tử</a></li>
                    <li><a href="<?= APP_URL ?>/lien-he">Thông tin hoá đơn mua hàng</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-hanh">Trung tâm bảo hành chính hãng</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-mat">Quy định về việc sao lưu dữ liệu</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-hanh">Chính sách khui hộp sản phẩm Apple</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-doi-tra">VAT Refund</a></li>
                </ul>
            </div>

            <!-- CỘT 3: DỊCH VỤ KHÁC + TẢI APP QR + ĐỊNH GIÁ MÁY CHUYÊN SÂU (GIỐNG HỆT ẢNH MẪU) -->
            <div class="cp-col">
                <h4 class="cp-heading">Dịch vụ và thông tin khác</h4>
                <ul class="cp-links">
                    <li><a href="<?= APP_URL ?>/lien-he">Khách hàng doanh nghiệp (B2B)</a></li>
                    <li><a href="<?= APP_URL ?>/khuyen-mai">Ưu đãi thanh toán</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-mat">Quy chế hoạt động</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-mat">Chính sách bảo mật thông tin cá nhân</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-hanh">Chính sách Bảo hành</a></li>
                    <li><a href="<?= APP_URL ?>/lien-he">Liên hệ hợp tác kinh doanh</a></li>
                    <li><a href="<?= APP_URL ?>/tuyen-dung">Tuyển dụng</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-hanh">Dịch vụ bảo hành mở rộng</a></li>
                </ul>

                <!-- KHỐI TẢI APP QR + STORE BADGES NGAY TRONG CỘT 3 -->
                <div class="cp-app-promo-block">
                    <div class="cp-app-promo-title">Mua sắm dễ dàng – Ưu đãi ngập tràn cùng app LongTech</div>
                    <div class="cp-app-qr-row">
                        <a href="javascript:void(0)" onclick="openAppDownloadModal('qr')" class="cp-qr-frame" title="Bấm để phóng to mã QR tải ứng dụng">
                            <img src="https://api.qrserver.com/v1/create-qr-code/?size=140x140&margin=4&data=<?= urlencode(APP_URL) ?>" alt="QR LongTech App" class="cp-qr-img" onerror="this.style.display='none'">
                            <span class="cp-qr-center-logo">L</span>
                        </a>
                        <div class="cp-store-buttons">
                            <a href="javascript:void(0)" onclick="openAppDownloadModal('android')" class="cp-store-btn">
                                <span class="store-icon play-color"><i class="fa-brands fa-google-play"></i></span>
                                <span class="store-txt">
                                    <small>TẢI NỘI DUNG TRÊN</small>
                                    <strong>Google Play</strong>
                                </span>
                            </a>
                            <a href="javascript:void(0)" onclick="openAppDownloadModal('ios')" class="cp-store-btn">
                                <span class="store-icon"><i class="fa-brands fa-apple"></i></span>
                                <span class="store-txt">
                                    <small>Tải về trên</small>
                                    <strong>App Store</strong>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- HỘP ĐỊNH GIÁ MÁY CHUYÊN SÂU VIỀN XANH DƯƠNG -->
                <div class="cp-tradein-widget" onclick="openTradeInModal()">
                    <div class="tradein-phone-icon">
                        <i class="fa-solid fa-mobile-screen"></i>
                        <span class="tradein-dollar">$</span>
                    </div>
                    <div class="tradein-info">
                        <strong>Định giá máy chuyên sâu</strong>
                        <span>Miễn phí • Chỉ 2 phút</span>
                    </div>
                    <button type="button" class="tradein-cta-btn">Định giá ngay</button>
                </div>
            </div>

            <!-- CỘT 4: KẾT NỐI & WEBSITE THÀNH VIÊN (BADGE ĐỎ NỔI BẬT) -->
            <div class="cp-col">
                <h4 class="cp-heading">Kết nối với LongTech</h4>
                <div class="cp-social-icons">
                    <a href="https://www.youtube.com/results?search_query=LongTech+Review+Cong+Nghe" target="_blank" rel="noopener" class="soc-btn yt" title="YouTube LongTech"><i class="fa-brands fa-youtube"></i></a>
                    <a href="https://www.facebook.com/" target="_blank" rel="noopener" class="soc-btn fb" title="Facebook LongTech"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="https://www.instagram.com/" target="_blank" rel="noopener" class="soc-btn ig" title="Instagram LongTech"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://www.tiktok.com/" target="_blank" rel="noopener" class="soc-btn tt" title="TikTok LongTech"><i class="fa-brands fa-tiktok"></i></a>
                    <a href="https://zalo.me/<?= preg_replace('/[^0-9]/', '', HOTLINE) ?>" target="_blank" rel="noopener" class="soc-btn zl" title="Zalo Official">Zalo</a>
                </div>

                <h4 class="cp-heading" style="margin-top: 14px;">Website thành viên</h4>
                <div class="cp-member-sites">
                    <div class="member-site-item">
                        <p class="member-site-desc">Hệ thống sửa chữa điện thoại và máy tính</p>
                        <a href="javascript:void(0)" onclick="openLongCareModal()" class="member-brand-badge badge-dienthoaivui">
                            <i class="fa-solid fa-screwdriver-wrench"></i>
                            <span><strong>LongCare.vn</strong> | Sửa chữa Tận Tâm</span>
                        </a>
                    </div>

                    <div class="member-site-item">
                        <p class="member-site-desc">Trung tâm bảo hành uỷ quyền Apple</p>
                        <a href="<?= APP_URL ?>/chinh-sach-bao-hanh" class="member-brand-badge badge-cares">
                            <span class="cares-main">Care<strong>L</strong></span>
                            <span class="cares-sub"><i class="fa-brands fa-apple"></i> Authorized Service</span>
                        </a>
                    </div>

                    <div class="member-site-item">
                        <p class="member-site-desc">Kênh thông tin giải trí công nghệ cho giới trẻ</p>
                        <a href="<?= APP_URL ?>/tin-tuc" class="member-brand-badge badge-schannel">
                            <span class="s-box">L</span>
                            <span class="schannel-txt"><strong>Channel</strong><small>network</small></span>
                        </a>
                    </div>

                    <div class="member-site-item">
                        <p class="member-site-desc">Trang thông tin công nghệ mới nhất</p>
                        <a href="<?= APP_URL ?>/tin-tuc" class="member-brand-badge badge-sforum">
                            <span class="s-box-outline">L</span>
                            <span class="sforum-txt">forum.vn</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 3. KHU VỰC ĐÁY NỀN XÁM NHẠT: TỪ KHÓA XU HƯỚNG 4 CỘT + PHÁP LÝ + CHỨNG NHẬN -->
    <div class="cp-footer-bottom-gray">
        <div class="container">
            <div class="cp-trend-keywords">
                <div class="trend-col">
                    <p><a href="<?= APP_URL ?>/dien-thoai">iPhone 16 Pro</a> | <a href="<?= APP_URL ?>/dien-thoai">iPhone 16 Pro Max</a></p>
                    <p><a href="<?= APP_URL ?>/dien-thoai">iPhone Air</a> | <a href="<?= APP_URL ?>/dien-thoai">iPhone 16</a> | <a href="<?= APP_URL ?>/dien-thoai">iPhone 15 Pro Max</a></p>
                    <p><a href="<?= APP_URL ?>/dien-thoai">iPhone 15</a> | <a href="<?= APP_URL ?>/dien-thoai">iPhone cũ</a> | <a href="<?= APP_URL ?>/laptop">MacBook Pro M3</a></p>
                </div>
                <div class="trend-col">
                    <p><a href="<?= APP_URL ?>/dien-thoai">Điện thoại</a> | <a href="<?= APP_URL ?>/dien-thoai">Điện thoại iPhone</a> | <a href="<?= APP_URL ?>/dien-thoai">Xiaomi</a></p>
                    <p><a href="<?= APP_URL ?>/dien-thoai">Điện thoại Samsung Galaxy</a> | <a href="<?= APP_URL ?>/dien-thoai">Điện thoại OPPO</a></p>
                    <p><a href="<?= APP_URL ?>/man-hinh-pc">Màn hình Gaming OLED</a> | <a href="<?= APP_URL ?>/may-tinh-bang">iPad Pro M4</a></p>
                </div>
                <div class="trend-col">
                    <p><a href="<?= APP_URL ?>/laptop">Laptop</a> | <a href="<?= APP_URL ?>/laptop">Laptop ASUS</a> | <a href="<?= APP_URL ?>/laptop">Laptop Dell</a> | <a href="<?= APP_URL ?>/laptop">Laptop HP</a></p>
                    <p><a href="<?= APP_URL ?>/am-thanh">Tai nghe Sony</a> | <a href="<?= APP_URL ?>/am-thanh">Loa Marshall</a> | <a href="<?= APP_URL ?>/phu-kien">AirPods Pro 2</a></p>
                    <p><a href="<?= APP_URL ?>/dien-thoai">Z Flip6</a> | <a href="<?= APP_URL ?>/dien-thoai">Z Fold6</a> | <a href="<?= APP_URL ?>/dien-thoai">S24 Ultra</a> | <a href="<?= APP_URL ?>/man-hinh-pc">Build PC</a></p>
                </div>
                <div class="trend-col">
                    <p><a href="<?= APP_URL ?>/phu-kien">Phụ kiện công nghệ</a> | <a href="<?= APP_URL ?>/gaming-console">Sony PS5 Slim</a></p>
                    <p><a href="<?= APP_URL ?>/gaming-console">Bàn phím cơ ROG</a> | <a href="<?= APP_URL ?>/phu-kien">Sạc nhanh Anker 65W</a></p>
                    <p><a href="<?= APP_URL ?>/dong-ho-thong-minh">Apple Watch Ultra 2</a> | <a href="<?= APP_URL ?>/dong-ho-thong-minh">Galaxy Watch Ultra</a></p>
                </div>
            </div>

            <!-- 4. THÔNG TIN BẢN QUYỀN & CHỨNG NHẬN BỘ CÔNG THƯƠNG CĂN GIỮA -->
            <div class="cp-copyright-area">
                <div class="company-legal-info">
                    <p>Công ty Cổ phần Công nghệ và Thương mại LONGTECH VIỆT NAM - GPĐKKD: 0108996688 cấp tại Sở KH &amp; ĐT TP. Hà Nội. Địa chỉ văn phòng: <?= STORE_ADDRESS ?>. Điện thoại: <?= HOTLINE ?> - Email: <?= CONTACT_EMAIL ?>.</p>
                </div>
                <div class="trust-cert-badges">
                    <span class="cert-pill bct">
                        <i class="fa-solid fa-circle-check"></i>
                        <span><small>ĐÃ THÔNG BÁO</small><strong>BỘ CÔNG THƯƠNG</strong></span>
                    </span>
                    <span class="cert-pill dmca">
                        <span class="dmca-tag">DMCA</span>
                        <span class="dmca-pro">PROTECTED</span>
                    </span>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- 5. BỘ NÚT TIỆN ÍCH NỔI GÓC DƯỚI BÊN PHẢI (FLOATING ACTION BUTTONS NHƯ CELLPHONES) -->
<div class="cp-floating-actions">
    <!-- Nút Cuộn Lên Đầu Trang -->
    <button type="button" class="floating-btn btn-back-to-top" id="btnBackToTop" onclick="scrollToTop()" title="Lên đầu trang">
        <span>Lên đầu</span>
        <i class="fa-solid fa-chevron-up"></i>
    </button>

    <!-- Nút Liên Hệ Nổi Màu Đỏ -->
    <button type="button" class="floating-btn btn-contact-quick" id="btnContactQuick" onclick="toggleContactPopup()" title="Liên hệ tư vấn">
        <span>Liên hệ</span>
        <i class="fa-solid fa-headphones"></i>
    </button>

    <!-- Popup liên hệ nhanh khi bấm nút -->
    <div class="floating-contact-popup" id="floatingContactPopup" style="display: none;">
        <div class="contact-popup-header">
            <h4><i class="fa-solid fa-headset text-danger"></i> Tư Vấn Khách Hàng</h4>
            <button type="button" onclick="toggleContactPopup()" class="close-popup-btn">&times;</button>
        </div>
        <div class="contact-popup-body">
            <a href="tel:<?= str_replace(' ', '', HOTLINE) ?>" class="contact-channel-item hotline">
                <div class="ch-icon"><i class="fa-solid fa-phone-volume"></i></div>
                <div>
                    <strong>Tổng đài tư vấn: <?= HOTLINE ?></strong>
                    <small>Miễn phí cuộc gọi (7h30 - 22h00)</small>
                </div>
            </a>
            <a href="https://zalo.me" target="_blank" class="contact-channel-item zalo">
                <div class="ch-icon" style="background: #0068ff; color: #fff;">Z</div>
                <div>
                    <strong>Chat qua Zalo Official</strong>
                    <small>Hỗ trợ báo giá và kỹ thuật 24/7</small>
                </div>
            </a>
            <a href="<?= APP_URL ?>/lien-he" class="contact-channel-item chat">
                <div class="ch-icon" style="background: #0084ff; color: #fff;"><i class="fa-brands fa-facebook-messenger"></i></div>
                <div>
                    <strong>Gửi tin nhắn Messenger</strong>
                    <small>Nhận thông tin ưu đãi tức thì</small>
                </div>
            </a>
        </div>
    </div>
</div>

<!-- 6. MODAL ĐẶT LỊCH SỬA CHỮA & BẢO DƯỠNG LONGCARE -->
<div id="longCareModal" style="display:none; position:fixed; inset:0; background:rgba(15,23,42,0.65); backdrop-filter:blur(3px); z-index:99999; align-items:center; justify-content:center; padding:16px;" onclick="if(event.target===this) closeLongCareModal()">
    <div style="background:#fff; border-radius:16px; max-width:480px; width:100%; box-shadow:0 20px 45px rgba(0,0,0,0.25); overflow:hidden;">
        <div style="background:linear-gradient(135deg,#0A2540,#1e3a8a); color:#fff; padding:16px 22px; display:flex; justify-content:space-between; align-items:center;">
            <h3 style="margin:0; font-size:16px; font-weight:700;">🛠️ LongCare - Trung Tâm Sửa Chữa Ủy Quyền</h3>
            <button type="button" onclick="closeLongCareModal()" style="background:transparent; border:none; color:#fff; font-size:22px; cursor:pointer;">&times;</button>
        </div>
        <form onsubmit="submitLongCareBooking(event)" style="padding:20px 22px;">
            <p style="font-size:13px; color:#475569; margin-bottom:14px; line-height:1.5;">
                Đặt lịch kiểm tra, vệ sinh máy miễn phí hoặc sửa chữa thay linh kiện chính hãng lấy ngay trong 60 phút:
            </p>
            <div style="margin-bottom:12px;">
                <label style="display:block; font-size:12.5px; font-weight:700; color:#0f172a; margin-bottom:4px;">Họ và tên khách hàng *</label>
                <input type="text" id="lcName" required placeholder="Nhập họ và tên..." value="<?= e(current_user()['full_name'] ?? '') ?>" style="width:100%; padding:9px 12px; border:1px solid #cbd5e1; border-radius:8px; font-size:13.5px;">
            </div>
            <div style="margin-bottom:12px;">
                <label style="display:block; font-size:12.5px; font-weight:700; color:#0f172a; margin-bottom:4px;">Số điện thoại liên hệ *</label>
                <input type="tel" id="lcPhone" required placeholder="Nhập số điện thoại..." value="<?= e(current_user()['phone'] ?? '') ?>" style="width:100%; padding:9px 12px; border:1px solid #cbd5e1; border-radius:8px; font-size:13.5px;">
            </div>
            <div style="margin-bottom:12px;">
                <label style="display:block; font-size:12.5px; font-weight:700; color:#0f172a; margin-bottom:4px;">Dòng máy & Tình trạng cần hỗ trợ *</label>
                <input type="text" id="lcDevice" required placeholder="VD: iPhone 15 Pro Max - Thay pin / Vệ sinh laptop..." style="width:100%; padding:9px 12px; border:1px solid #cbd5e1; border-radius:8px; font-size:13.5px;">
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; margin-top:16px;">
                <a href="<?= APP_URL ?>/chinh-sach-bao-hanh" style="font-size:12.5px; color:#2563eb; font-weight:600; text-decoration:none;">Xem bảng giá & bảo hành &rarr;</a>
                <button type="submit" style="background:#D70018; color:#fff; border:none; padding:10px 18px; border-radius:8px; font-weight:700; font-size:13px; cursor:pointer;">
                    Đặt Lịch Ngay
                </button>
            </div>
        </form>
    </div>
</div>

<!-- 7. MODAL TẢI ỨNG DỤNG LONGTECH APP (QR + GOOGLE PLAY + APP STORE) -->
<div id="appDownloadModal" style="display:none; position:fixed; inset:0; background:rgba(15,23,42,0.65); backdrop-filter:blur(3px); z-index:99999; align-items:center; justify-content:center; padding:16px;" onclick="if(event.target===this) closeAppDownloadModal()">
    <div style="background:#fff; border-radius:16px; max-width:440px; width:100%; box-shadow:0 20px 45px rgba(0,0,0,0.25); overflow:hidden; text-align:center;">
        <div style="background:linear-gradient(135deg,#D70018,#991b1b); color:#fff; padding:16px 22px; display:flex; justify-content:space-between; align-items:center;">
            <h3 style="margin:0; font-size:16px; font-weight:700;"><i class="fa-solid fa-mobile-screen-button"></i> Tải Ứng Dụng LongTech App</h3>
            <button type="button" onclick="closeAppDownloadModal()" style="background:transparent; border:none; color:#fff; font-size:22px; cursor:pointer;">&times;</button>
        </div>
        <div style="padding:24px 22px;">
            <p id="appModalSubtitle" style="font-size:13.5px; color:#334155; margin-bottom:14px; font-weight:500;">
                Quét mã QR bằng điện thoại để mở nhanh ứng dụng mua sắm LongTech nhận ngay Voucher giảm thêm 5%:
            </p>
            <div style="display:inline-block; padding:12px; border:2px solid #e2e8f0; border-radius:12px; background:#fff; margin-bottom:16px;">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=<?= urlencode(APP_URL) ?>" alt="QR Code LongTech App" style="width:150px; height:150px; display:block;" onerror="this.style.display='none'">
            </div>
            <div style="display:flex; gap:10px; justify-content:center; flex-wrap:wrap; margin-bottom:14px;">
                <a href="https://play.google.com/store/search?q=LongTech&c=apps" target="_blank" rel="noopener" style="background:#0f172a; color:#fff; padding:10px 16px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:600; display:inline-flex; align-items:center; gap:8px;">
                    <i class="fa-brands fa-google-play" style="color:#38bdf8; font-size:16px;"></i> Tải trên Google Play
                </a>
                <a href="https://www.apple.com/vn/app-store/" target="_blank" rel="noopener" style="background:#0f172a; color:#fff; padding:10px 16px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:600; display:inline-flex; align-items:center; gap:8px;">
                    <i class="fa-brands fa-apple" style="font-size:18px;"></i> Tải trên App Store
                </a>
            </div>
            <small style="color:#64748b; display:block;">Hoặc chọn <strong>"Thêm vào màn hình chính" (Add to Home Screen)</strong> trên trình duyệt điện thoại của bạn.</small>
        </div>
    </div>
</div>

<!-- 7B. MODAL ĐỊNH GIÁ MÁY CHUYÊN SÂU (THU CŨ ĐỔI MỚI CHỈ 2 PHÚT) -->
<div id="tradeInModal" style="display:none; position:fixed; inset:0; background:rgba(15,23,42,0.65); backdrop-filter:blur(3px); z-index:99999; align-items:center; justify-content:center; padding:16px;" onclick="if(event.target===this) closeTradeInModal()">
    <div style="background:#fff; border-radius:16px; max-width:480px; width:100%; box-shadow:0 20px 45px rgba(0,0,0,0.25); overflow:hidden;">
        <div style="background:linear-gradient(135deg,#1d4ed8,#0284c7); color:#fff; padding:16px 22px; display:flex; justify-content:space-between; align-items:center;">
            <h3 style="margin:0; font-size:16px; font-weight:700;"><i class="fa-solid fa-mobile-retro"></i> Định Giá Máy Chuyên Sâu (Miễn Phí 2 Phút)</h3>
            <button type="button" onclick="closeTradeInModal()" style="background:transparent; border:none; color:#fff; font-size:22px; cursor:pointer;">&times;</button>
        </div>
        <div style="padding:20px 22px;">
            <p style="font-size:13px; color:#475569; margin-bottom:14px; line-height:1.5;">
                Chọn dòng máy cũ và tình trạng hiện tại để nhận báo giá thu mua dự kiến kèm trợ giá lên đời tới <strong>3.000.000đ</strong>:
            </p>
            <div style="margin-bottom:12px;">
                <label style="display:block; font-size:12.5px; font-weight:700; color:#0f172a; margin-bottom:4px;">Dòng thiết bị cần định giá</label>
                <select id="tiDeviceSelect" onchange="calculateTradeInPrice()" style="width:100%; padding:9px 12px; border:1px solid #cbd5e1; border-radius:8px; font-size:13.5px;">
                    <option value="22500000">iPhone 15 Pro Max 256GB</option>
                    <option value="18200000">iPhone 14 Pro Max 256GB</option>
                    <option value="13500000">iPhone 13 Pro Max 128GB</option>
                    <option value="19000000">Samsung Galaxy S24 Ultra 256GB</option>
                    <option value="14200000">Samsung Galaxy S23 Ultra 256GB</option>
                    <option value="17500000">MacBook Air M2 13 inch 8GB/256GB</option>
                    <option value="15000000">iPad Pro M2 11 inch WiFi 128GB</option>
                </select>
            </div>
            <div style="margin-bottom:14px;">
                <label style="display:block; font-size:12.5px; font-weight:700; color:#0f172a; margin-bottom:4px;">Tình trạng ngoại hình & chức năng</label>
                <select id="tiCondSelect" onchange="calculateTradeInPrice()" style="width:100%; padding:9px 12px; border:1px solid #cbd5e1; border-radius:8px; font-size:13.5px;">
                    <option value="1">Loại 1: Đẹp như mới 99%, đầy đủ chức năng, pin &ge; 88%</option>
                    <option value="0.88">Loại 2: Trầy xước nhẹ viền/màn, hoạt động hoàn hảo</option>
                    <option value="0.72">Loại 3: Cấn móp nhẹ hoặc cần thay pin bảo dưỡng</option>
                </select>
            </div>
            <div style="background:#eff6ff; border:1.5px dashed #3b82f6; border-radius:12px; padding:14px; text-align:center; margin-bottom:16px;">
                <span style="font-size:12px; color:#1e40af; font-weight:600; display:block;">GIÁ THU MUA + TRỢ GIÁ LÊN ĐỜI DỰ KIẾN:</span>
                <strong id="tiEstimatedResult" style="font-size:24px; color:#D70018; font-weight:900; display:block; margin-top:4px;">24.500.000 ₫</strong>
                <small style="font-size:11.5px; color:#475569;">(Đã cộng thêm 2.000.000đ trợ giá thu cũ đổi mới tại LongTech)</small>
            </div>
            <div style="display:flex; justify-content:flex-end; gap:10px;">
                <button type="button" onclick="closeTradeInModal()" style="background:#f1f5f9; color:#334155; border:none; padding:10px 16px; border-radius:8px; font-weight:700; font-size:13px; cursor:pointer;">Đóng</button>
                <a href="<?= APP_URL ?>/dien-thoai" style="background:#2563eb; color:#fff; text-decoration:none; padding:10px 18px; border-radius:8px; font-weight:700; font-size:13px;">Chọn máy lên đời ngay &rarr;</a>
            </div>
        </div>
    </div>
</div>

<!-- 8. THANH ĐIỀU HƯỚNG DÀNH CHO MOBILE -->
<nav class="mobile-bottom-bar">
    <a href="<?= APP_URL ?>" class="bottom-tab <?= empty($_GET['url']) ? 'active' : '' ?>">
        <i class="fa-solid fa-house"></i>
        <span>Trang chủ</span>
    </a>
    <a href="<?= APP_URL ?>/dien-thoai" class="bottom-tab">
        <i class="fa-solid fa-layer-group"></i>
        <span>Danh mục</span>
    </a>
    <a href="<?= APP_URL ?>/khuyen-mai" class="bottom-tab">
        <i class="fa-solid fa-fire text-danger"></i>
        <span>Săn Sale</span>
    </a>
    <a href="<?= APP_URL ?>/gio-hang" class="bottom-tab">
        <div class="bottom-cart-wrap">
            <i class="fa-solid fa-cart-shopping"></i>
            <span class="bottom-cart-badge"><?= $cartCount ?></span>
        </div>
        <span>Giỏ hàng</span>
    </a>
    <a href="<?= is_logged_in() ? APP_URL . '/tai-khoan' : APP_URL . '/dang-nhap' ?>" class="bottom-tab">
        <i class="fa-regular fa-user"></i>
        <span><?= is_logged_in() ? 'Cá nhân' : 'Tài khoản' ?></span>
    </a>
</nav>

<!-- JavaScript & Tiện ích Cuộn trang / Liên hệ / Hệ sinh thái -->
<script>
    const APP_URL = "<?= APP_URL ?>";
    const CSRF_TOKEN = "<?= csrf_token() ?>";

    // Xử lý nút cuộn lên đầu trang (Back to top)
    window.addEventListener('scroll', function () {
        const topBtn = document.getElementById('btnBackToTop');
        if (topBtn) {
            if (window.scrollY > 200) {
                topBtn.style.display = 'flex';
            } else {
                topBtn.style.display = 'none';
            }
        }
    });

    function scrollToTop() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function toggleContactPopup() {
        const popup = document.getElementById('floatingContactPopup');
        if (popup) {
            popup.style.display = (popup.style.display === 'none' || popup.style.display === '') ? 'block' : 'none';
        }
    }

    function openLongCareModal() {
        const modal = document.getElementById('longCareModal');
        if (modal) modal.style.display = 'flex';
    }

    function closeLongCareModal() {
        const modal = document.getElementById('longCareModal');
        if (modal) modal.style.display = 'none';
    }

    function submitLongCareBooking(e) {
        e.preventDefault();
        const name = document.getElementById('lcName').value.trim();
        const phone = document.getElementById('lcPhone').value.trim();
        const device = document.getElementById('lcDevice').value.trim();
        if (!name || !phone || !device) return;
        alert('✅ Đặt lịch sửa chữa & bảo dưỡng tại LongCare thành công!\n\nKhách hàng: ' + name + '\nSĐT: ' + phone + '\nThiết bị: ' + device + '\n\nKỹ thuật viên LongCare sẽ liên hệ xác nhận với bạn trong 10 phút!');
        e.target.reset();
        closeLongCareModal();
    }

    function openAppDownloadModal(platform) {
        const modal = document.getElementById('appDownloadModal');
        const sub = document.getElementById('appModalSubtitle');
        if (sub) {
            if (platform === 'android') {
                sub.textContent = 'Quét mã QR hoặc bấm nút Google Play bên dưới để tải LongTech App cho điện thoại Android:';
            } else if (platform === 'ios') {
                sub.textContent = 'Quét mã QR hoặc bấm nút App Store bên dưới để tải LongTech App cho iPhone / iPad (iOS):';
            } else {
                sub.textContent = 'Quét mã QR bằng camera điện thoại để mở nhanh ứng dụng mua sắm LongTech:';
            }
        }
        if (modal) modal.style.display = 'flex';
    }

    function closeAppDownloadModal() {
        const modal = document.getElementById('appDownloadModal');
        if (modal) modal.style.display = 'none';
    }

    function openTradeInModal() {
        const modal = document.getElementById('tradeInModal');
        if (modal) {
            calculateTradeInPrice();
            modal.style.display = 'flex';
        }
    }

    function closeTradeInModal() {
        const modal = document.getElementById('tradeInModal');
        if (modal) modal.style.display = 'none';
    }

    function calculateTradeInPrice() {
        const base = parseFloat(document.getElementById('tiDeviceSelect')?.value || 22500000);
        const ratio = parseFloat(document.getElementById('tiCondSelect')?.value || 1);
        const bonus = 2000000;
        const total = Math.round((base * ratio + bonus) / 100000) * 100000;
        const el = document.getElementById('tiEstimatedResult');
        if (el) {
            el.textContent = total.toLocaleString('vi-VN') + ' ₫';
        }
    }

    function handleNewsletterSub(e) {
        e.preventDefault();
        const email = document.getElementById('nlEmail').value;
        const phone = document.getElementById('nlPhone').value;
        if (!email) return;

        alert('Chúc mừng bạn đã đăng ký nhận tin thành công! Mã Voucher 10% sẽ được gửi về email ' + email + ' trong ít phút.');
        e.target.reset();
    }
</script>
<script src="<?= ASSET_URL ?>/js/main.js?v=<?= time() ?>"></script>
<script src="<?= ASSET_URL ?>/js/validator.js?v=<?= time() ?>"></script>

</body>
</html>
