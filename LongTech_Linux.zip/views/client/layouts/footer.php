<?php
/**
 * ========================================================
 * LONGTECH - FOOTER CHUẨN GIAO DIỆN BÁN LẺ CELLPHONES (footer.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) { exit('Direct access not permitted'); }
?>
</main> <!-- Đóng thẻ .main-content từ header.php -->

<!-- 1. CAM KẾT VÀNG & TIỆN ÍCH DỊCH VỤ -->
<section class="trust-features-section">
    <div class="container">
        <div class="trust-features-grid">
            <div class="trust-box">
                <div class="trust-icon"><i class="fa-solid fa-award"></i></div>
                <div class="trust-text">
                    <h4>Sản phẩm chính hãng 100%</h4>
                    <p>Cam kết xuất xứ rõ ràng, đầy đủ hóa đơn VAT</p>
                </div>
            </div>
            <div class="trust-box">
                <div class="trust-icon"><i class="fa-solid fa-truck-fast"></i></div>
                <div class="trust-text">
                    <h4>Giao nhanh miễn phí</h4>
                    <p>Nội thành 2H, toàn quốc cho đơn từ <?= format_money(FREE_SHIPPING_MIN) ?></p>
                </div>
            </div>
            <div class="trust-box">
                <div class="trust-icon"><i class="fa-solid fa-arrows-rotate"></i></div>
                <div class="trust-text">
                    <h4>Lỗi 1 đổi 1 trong 30 ngày</h4>
                    <p>Phát sinh lỗi kỹ thuật đổi ngay máy mới</p>
                </div>
            </div>
            <div class="trust-box">
                <div class="trust-icon"><i class="fa-solid fa-screwdriver-wrench"></i></div>
                <div class="trust-text">
                    <h4>Bảo hành chính hãng 12 tháng</h4>
                    <p>Hệ thống trung tâm bảo hành tiêu chuẩn ủy quyền</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 2. MEGA FOOTER PHONG CÁCH CELLPHONES -->
<footer class="cellphones-footer">
    <div class="container">
        <div class="cp-footer-top">
            <!-- CỘT 1: TỔNG ĐÀI HỖ TRỢ & PHƯƠNG THỨC THANH TOÁN -->
            <div class="cp-col">
                <h4 class="cp-heading">Tổng đài hỗ trợ miễn phí</h4>
                <ul class="cp-list-hotline">
                    <li>Mua hàng - bảo hành: <a href="tel:<?= str_replace(' ', '', HOTLINE) ?>"><strong><?= HOTLINE ?></strong></a> <small>(7h30 - 22h00)</small></li>
                    <li>Khiếu nại - góp ý: <a href="tel:18002063"><strong>1800.2063</strong></a> <small>(8h00 - 21h30)</small></li>
                </ul>

                <h4 class="cp-heading" style="margin-top: 18px;">Phương thức thanh toán</h4>
                <div class="payment-logos-grid">
                    <span class="pay-badge"><i class="fa-brands fa-apple"></i> Pay</span>
                    <span class="pay-badge vnpay">VNPAY</span>
                    <span class="pay-badge momo">MoMo</span>
                    <span class="pay-badge onepay">OnePay</span>
                    <span class="pay-badge kredivo">Kredivo</span>
                    <span class="pay-badge zalopay">ZaloPay</span>
                </div>

                <!-- ĐĂNG KÝ NHẬN TIN KHUYẾN MÃI -->
                <div class="cp-newsletter-card">
                    <h5 class="nl-title">ĐĂNG KÝ NHẬN TIN KHUYẾN MÃI</h5>
                    <div class="nl-voucher-tag">
                        <strong>Nhận ngay voucher 10%</strong>
                        <p>Voucher sẽ được gửi sau 24h, áp dụng cho khách hàng mới</p>
                    </div>
                    <form onsubmit="handleNewsletterSub(event)" class="nl-form">
                        <input type="email" id="nlEmail" placeholder="Nhập email của bạn *" required class="nl-input">
                        <input type="tel" id="nlPhone" placeholder="Nhập số điện thoại của bạn" class="nl-input">
                        <p class="nl-terms">Bằng việc đăng ký, bạn đồng ý với <a href="<?= APP_URL ?>/chinh-sach-bao-mat">Chính sách bảo mật</a> của LongTech.</p>
                        <button type="submit" class="nl-btn-submit">ĐĂNG KÝ NGAY</button>
                    </form>
                </div>
            </div>

            <!-- CỘT 2: THÔNG TIN VỀ CHÍNH SÁCH -->
            <div class="cp-col">
                <h4 class="cp-heading">Thông tin về chính sách</h4>
                <ul class="cp-links">
                    <li><a href="<?= APP_URL ?>/chinh-sach-van-chuyen">Mua hàng và thanh toán Online</a></li>
                    <li><a href="<?= APP_URL ?>/huong-dan-tra-gop">Mua hàng trả góp 0% lãi suất</a></li>
                    <li><a href="<?= APP_URL ?>/huong-dan-tra-gop">Trả góp qua thẻ tín dụng</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-van-chuyen">Chính sách giao hàng hỏa tốc</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-doi-tra">Chính sách đổi trả 1-1</a></li>
                    <li><a href="<?= APP_URL ?>/tai-khoan">Tra điểm thưởng thành viên VIP</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-hanh">Tra thông tin bảo hành thiết bị</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-hanh">Chính sách khui hộp sản phẩm Apple</a></li>
                    <li><a href="<?= APP_URL ?>/lien-he">Tra cứu hóa đơn điện tử VAT</a></li>
                </ul>
            </div>

            <!-- CỘT 3: DỊCH VỤ VÀ THÔNG TIN KHÁC -->
            <div class="cp-col">
                <h4 class="cp-heading">Dịch vụ và thông tin khác</h4>
                <ul class="cp-links">
                    <li><a href="<?= APP_URL ?>/lien-he">Khách hàng doanh nghiệp (B2B)</a></li>
                    <li><a href="<?= APP_URL ?>/khuyen-mai">Ưu đãi liên kết ngân hàng</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-mat">Quy chế hoạt động sàn TMĐT</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-mat">Chính sách bảo mật dữ liệu khách hàng</a></li>
                    <li><a href="<?= APP_URL ?>/chinh-sach-bao-hanh">Dịch vụ bảo hành mở rộng rơi vỡ</a></li>
                    <li><a href="<?= APP_URL ?>/lien-he">Liên hệ hợp tác kinh doanh</a></li>
                    <li><a href="<?= APP_URL ?>/tuyen-dung">Cơ hội việc làm & Tuyển dụng</a></li>
                    <li><a href="<?= APP_URL ?>/tin-tuc">Bản tin công nghệ mới nhất</a></li>
                </ul>
            </div>

            <!-- CỘT 4: KẾT NỐI MẠNG XÃ HỘI & THÀNH VIÊN -->
            <div class="cp-col">
                <h4 class="cp-heading">Kết nối với LongTech</h4>
                <div class="cp-social-icons">
                    <a href="https://youtube.com" target="_blank" class="soc-btn yt" title="Youtube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="https://facebook.com" target="_blank" class="soc-btn fb" title="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="https://instagram.com" target="_blank" class="soc-btn ig" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://tiktok.com" target="_blank" class="soc-btn tt" title="TikTok"><i class="fa-brands fa-tiktok"></i></a>
                    <a href="https://zalo.me" target="_blank" class="soc-btn zl" title="Zalo Official">Zalo</a>
                </div>

                <h4 class="cp-heading" style="margin-top: 20px;">Hệ sinh thái công nghệ</h4>
                <div class="cp-ecosystem">
                    <div class="eco-box">
                        <strong>LongCare 🛠️</strong>
                        <small>Trung tâm sửa chữa & bảo dưỡng thiết bị ủy quyền</small>
                    </div>
                    <div class="eco-box">
                        <strong>LongStudio 🎥</strong>
                        <small>Kênh review và đánh giá công nghệ chuyên sâu</small>
                    </div>
                </div>

                <div class="cp-app-download" style="margin-top: 18px;">
                    <div style="font-size: 13px; font-weight: 700; color: #1e293b; margin-bottom: 8px;">Tải ứng dụng LongTech App</div>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <div class="qr-code-box">
                            <i class="fa-solid fa-qrcode" style="font-size: 42px; color: #D70018;"></i>
                        </div>
                        <div style="display: flex; flex-direction: column; gap: 6px;">
                            <span class="store-badge"><i class="fa-brands fa-google-play"></i> Google Play</span>
                            <span class="store-badge"><i class="fa-brands fa-apple"></i> App Store</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 3. THANH TỪ KHÓA TÌM KIẾM HOT (KEYWORD TREND BAR) -->
        <div class="cp-trend-keywords">
            <div class="trend-col">
                <strong>iPhone:</strong>
                <a href="<?= APP_URL ?>/dien-thoai">iPhone 16 Pro Max</a> | 
                <a href="<?= APP_URL ?>/dien-thoai">iPhone 16 Pro</a> | 
                <a href="<?= APP_URL ?>/dien-thoai">iPhone 15</a> | 
                <a href="<?= APP_URL ?>/dien-thoai">iPhone cũ giá rẻ</a>
            </div>
            <div class="trend-col">
                <strong>Samsung:</strong>
                <a href="<?= APP_URL ?>/dien-thoai">Galaxy S24 Ultra</a> | 
                <a href="<?= APP_URL ?>/dien-thoai">Galaxy Z Fold 6</a> | 
                <a href="<?= APP_URL ?>/dien-thoai">Galaxy Z Flip 6</a> | 
                <a href="<?= APP_URL ?>/dien-thoai">Galaxy A55 5G</a>
            </div>
            <div class="trend-col">
                <strong>Laptop & Tablet:</strong>
                <a href="<?= APP_URL ?>/laptop">MacBook Air M3</a> | 
                <a href="<?= APP_URL ?>/laptop">MacBook Pro M3</a> | 
                <a href="<?= APP_URL ?>/laptop">Dell XPS 13</a> | 
                <a href="<?= APP_URL ?>/laptop">Legion 5 Gaming</a> | 
                <a href="<?= APP_URL ?>/may-tinh-bang">iPad Pro M4</a>
            </div>
            <div class="trend-col">
                <strong>Phụ kiện HOT:</strong>
                <a href="<?= APP_URL ?>/phu-kien">AirPods Pro 2</a> | 
                <a href="<?= APP_URL ?>/phu-kien">Củ sạc Anker 65W</a> | 
                <a href="<?= APP_URL ?>/phu-kien">Chuột Logitech MX Master 3S</a> | 
                <a href="<?= APP_URL ?>/phu-kien">Apple Watch Series 10</a>
            </div>
        </div>

        <!-- 4. THÔNG TIN BẢN QUYỀN & CHỨNG NHẬN BỘ CÔNG THƯƠNG -->
        <div class="cp-copyright-area">
            <div class="company-legal-info">
                <p><strong>CÔNG TY CỔ PHẦN CÔNG NGHỆ VÀ THƯƠNG MẠI LONGTECH VIỆT NAM</strong></p>
                <p>Giấy phép ĐKKD số: 0108996688 do Sở KH & ĐT TP. Hà Nội cấp. Địa chỉ trụ sở: <?= STORE_ADDRESS ?></p>
                <p>Điện thoại hỗ trợ khách hàng: <?= HOTLINE ?> - Email chăm sóc: <?= CONTACT_EMAIL ?></p>
            </div>
            <div class="trust-cert-badges">
                <span class="cert-pill bct"><i class="fa-solid fa-shield-halved"></i> ĐÃ THÔNG BÁO BỘ CÔNG THƯƠNG</span>
                <span class="cert-pill dmca"><i class="fa-solid fa-copyright"></i> DMCA PROTECTED</span>
            </div>
        </div>
    </div>
</footer>

<!-- 5. BỘ NÚT TIỆN ÍCH NỔI GÓC DƯỚI BÊN PHẢI (FLOATING ACTION BUTTONS NHƯ CELLPHONES) -->
<div class="cp-floating-actions">
    <!-- Nút Cuộn Lên Đầu Trang -->
    <button type="button" class="floating-btn btn-back-to-top" id="btnBackToTop" onclick="scrollToTop()" title="Lên đầu trang">
        <span>Lên đầu</span>
        <i class="fa-solid fa-chevron-up"></i>
    </button>

    <!-- Nút Liên Hệ Nổi Màu Đỏ -->
    <button type="button" class="floating-btn btn-contact-quick" id="btnContactQuick" onclick="toggleContactPopup()" title="Liên hệ tư vấn">
        <span>Liên hệ</span>
        <i class="fa-solid fa-headphones"></i>
    </button>

    <!-- Popup liên hệ nhanh khi bấm nút -->
    <div class="floating-contact-popup" id="floatingContactPopup" style="display: none;">
        <div class="contact-popup-header">
            <h4><i class="fa-solid fa-headset text-danger"></i> Tư Vấn Khách Hàng</h4>
            <button type="button" onclick="toggleContactPopup()" class="close-popup-btn">&times;</button>
        </div>
        <div class="contact-popup-body">
            <a href="tel:<?= str_replace(' ', '', HOTLINE) ?>" class="contact-channel-item hotline">
                <div class="ch-icon"><i class="fa-solid fa-phone-volume"></i></div>
                <div>
                    <strong>Tổng đài tư vấn: <?= HOTLINE ?></strong>
                    <small>Miễn phí cuộc gọi (7h30 - 22h00)</small>
                </div>
            </a>
            <a href="https://zalo.me" target="_blank" class="contact-channel-item zalo">
                <div class="ch-icon" style="background: #0068ff; color: #fff;">Z</div>
                <div>
                    <strong>Chat qua Zalo Official</strong>
                    <small>Hỗ trợ báo giá và kỹ thuật 24/7</small>
                </div>
            </a>
            <a href="<?= APP_URL ?>/lien-he" class="contact-channel-item chat">
                <div class="ch-icon" style="background: #0084ff; color: #fff;"><i class="fa-brands fa-facebook-messenger"></i></div>
                <div>
                    <strong>Gửi tin nhắn Messenger</strong>
                    <small>Nhận thông tin ưu đãi tức thì</small>
                </div>
            </a>
        </div>
    </div>
</div>

<!-- 6. THANH ĐIỀU HƯỚNG DÀNH CHO MOBILE -->
<nav class="mobile-bottom-bar">
    <a href="<?= APP_URL ?>" class="bottom-tab <?= empty($_GET['url']) ? 'active' : '' ?>">
        <i class="fa-solid fa-house"></i>
        <span>Trang chủ</span>
    </a>
    <a href="<?= APP_URL ?>/dien-thoai" class="bottom-tab">
        <i class="fa-solid fa-layer-group"></i>
        <span>Danh mục</span>
    </a>
    <a href="<?= APP_URL ?>/khuyen-mai" class="bottom-tab">
        <i class="fa-solid fa-fire text-danger"></i>
        <span>Săn Sale</span>
    </a>
    <a href="<?= APP_URL ?>/gio-hang" class="bottom-tab">
        <div class="bottom-cart-wrap">
            <i class="fa-solid fa-cart-shopping"></i>
            <span class="bottom-cart-badge"><?= $cartCount ?></span>
        </div>
        <span>Giỏ hàng</span>
    </a>
    <a href="<?= is_logged_in() ? APP_URL . '/tai-khoan' : APP_URL . '/dang-nhap' ?>" class="bottom-tab">
        <i class="fa-regular fa-user"></i>
        <span><?= is_logged_in() ? 'Cá nhân' : 'Tài khoản' ?></span>
    </a>
</nav>

<!-- JavaScript & Tiện ích Cuộn trang / Liên hệ -->
<script>
    const APP_URL = "<?= APP_URL ?>";
    const CSRF_TOKEN = "<?= csrf_token() ?>";

    // Xử lý nút cuộn lên đầu trang (Back to top)
    window.addEventListener('scroll', function () {
        const topBtn = document.getElementById('btnBackToTop');
        if (topBtn) {
            if (window.scrollY > 300) {
                topBtn.style.display = 'flex';
            } else {
                topBtn.style.display = 'none';
            }
        }
    });

    function scrollToTop() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function toggleContactPopup() {
        const popup = document.getElementById('floatingContactPopup');
        if (popup) {
            popup.style.display = (popup.style.display === 'none' || popup.style.display === '') ? 'block' : 'none';
        }
    }

    function handleNewsletterSub(e) {
        e.preventDefault();
        const email = document.getElementById('nlEmail').value;
        const phone = document.getElementById('nlPhone').value;
        if (!email) return;

        alert('Chúc mừng bạn đã đăng ký nhận tin thành công! Mã Voucher 10% sẽ được gửi về email ' + email + ' trong ít phút.');
        e.target.reset();
    }
</script>
<script src="<?= ASSET_URL ?>/js/main.js?v=<?= time() ?>"></script>
<script src="<?= ASSET_URL ?>/js/validator.js?v=<?= time() ?>"></script>

</body>
</html>
