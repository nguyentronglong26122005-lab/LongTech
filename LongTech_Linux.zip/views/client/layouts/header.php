<?php
/**
 * ========================================================
 * LONGTECH - HEADER CHUẨN GIAO DIỆN NGƯỜI DÙNG (header.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

// Tính tổng số lượng sản phẩm trong giỏ hàng
$cartCount = 0;
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cartCount += (int)($item['quantity'] ?? 1);
    }
}
$currentUser = current_user();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <meta name="referrer" content="no-referrer">
    <title><?= e($pageTitle ?? 'LongTech - Thế Giới Công Nghệ Đỉnh Cao') ?></title>
    
    <!-- Google Fonts: Inter & Roboto -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    
    <!-- FontAwesome 6 Icons CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- CSS Stylesheet của LongTech -->
    <link rel="stylesheet" href="<?= ASSET_URL ?>/css/main.css?v=<?= time() ?>">
    <link rel="stylesheet" href="<?= ASSET_URL ?>/css/responsive.css?v=<?= time() ?>">
    
    <?php
    // Nạp cấu hình màu sắc động từ SiteSettingModel
    require_once ROOT_PATH . '/models/SiteSettingModel.php';
    $siteSettingModel = new SiteSettingModel();
    $liveSettings = $siteSettingModel->getAllSettings();
    $primaryColor = $liveSettings['site_primary_color'] ?? '#D70018';
    $secondaryColor = $liveSettings['site_secondary_color'] ?? '#0A2540';
    $fontFamily = $liveSettings['site_font'] ?? 'Inter';
    ?>
    <style>
        :root {
            --primary-color: <?= e($primaryColor) ?> !important;
            --secondary-color: <?= e($secondaryColor) ?> !important;
            --main-font: '<?= e($fontFamily) ?>', sans-serif !important;
        }
        body { font-family: var(--main-font); }

        /* Thanh công cụ Live Editor hiện đại */
        .live-admin-bar {
            background: linear-gradient(90deg, #090d16 0%, #0f172a 50%, #1e1b4b 100%);
            color: #f8fafc;
            padding: 8px 20px;
            font-size: 13px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99999;
            box-shadow: 0 4px 16px rgba(0,0,0,0.35);
            border-bottom: 1px solid rgba(56, 189, 248, 0.25);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            flex-wrap: wrap;
            gap: 10px;
        }

        /* Hiệu ứng đánh dấu các phần tử có thể sửa trực tiếp khi bật Live Editor */
        body.live-editable-active [data-live-editable="1"] {
            outline: 2px dashed rgba(14, 165, 233, 0.75) !important;
            outline-offset: 4px;
            cursor: text !important;
            border-radius: 6px;
            transition: all 0.2s ease;
            position: relative;
        }
        body.live-editable-active [data-live-editable="1"]:hover {
            outline: 2px solid #D70018 !important;
            background: rgba(215, 0, 24, 0.06) !important;
            box-shadow: 0 0 0 4px rgba(215, 0, 24, 0.12);
        }
        body.live-editable-active [data-live-editable="1"][contenteditable="true"] {
            outline: 2.5px solid #10b981 !important;
            background: #ffffff !important;
            color: #0f172a !important;
            padding: 2px 6px !important;
            box-shadow: 0 8px 24px rgba(16, 185, 129, 0.28) !important;
            z-index: 9999 !important;
        }

        /* Nhãn chỉ dẫn nổi khi đang gõ sửa trực tiếp */
        #liveFloatingHint {
            position: fixed;
            bottom: 24px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(15, 23, 42, 0.95);
            color: #fff;
            padding: 10px 20px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 600;
            z-index: 100000;
            display: none;
            align-items: center;
            gap: 10px;
            box-shadow: 0 12px 30px rgba(0,0,0,0.35);
            border: 1px solid rgba(56, 189, 248, 0.4);
            backdrop-filter: blur(8px);
        }

        /* Modal Xác Nhận Có / Không Hiện Đại */
        .live-confirm-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.65);
            backdrop-filter: blur(6px);
            z-index: 100005;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 16px;
        }
        .live-confirm-card {
            background: #ffffff;
            color: #0f172a;
            width: 100%;
            max-width: 480px;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.45);
            border: 1px solid #e2e8f0;
            animation: liveModalPop 0.22s cubic-bezier(0.22, 1, 0.36, 1);
        }
        @keyframes liveModalPop {
            from { opacity: 0; transform: scale(0.93) translateY(10px); }
            to { opacity: 1; transform: scale(1) translateY(0); }
        }

        /* Khung gợi ý tìm kiếm tức thì (Instant Search Dropdown) */
        .instant-search-dropdown {
            position: absolute;
            top: calc(100% + 6px);
            left: 0;
            right: 0;
            background: #ffffff;
            color: #0f172a;
            border-radius: 14px;
            box-shadow: 0 18px 38px rgba(15, 23, 42, 0.22);
            border: 1px solid #e2e8f0;
            z-index: 9999;
            display: none;
            overflow: hidden;
        }
        .instant-search-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 14px;
            border-bottom: 1px solid #f1f5f9;
            text-decoration: none;
            color: #0f172a;
            transition: background 0.18s;
        }
        .instant-search-item:hover {
            background: #fff1f2;
        }
        .instant-search-item img {
            width: 46px;
            height: 46px;
            object-fit: contain;
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 3px;
            flex-shrink: 0;
        }

        /* Nút Xem Nhanh (Quick View) trên thẻ sản phẩm */
        .quick-view-trigger {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background: rgba(15, 23, 42, 0.82);
            color: #fff;
            border: none;
            border-radius: 20px;
            padding: 5px 11px;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
            opacity: 0;
            transform: translateY(6px);
            transition: all 0.22s ease;
            z-index: 6;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            backdrop-filter: blur(4px);
        }
        .product-card:hover .quick-view-trigger {
            opacity: 1;
            transform: translateY(0);
        }
        .quick-view-trigger:hover {
            background: #D70018;
        }
    </style>
</head>
<body>

<?php
// Xuất JSON các nội dung giao diện đã được lưu trong site_settings để tự động áp dụng lên trang cho mọi người dùng
$savedInlineTexts = [];
foreach ($liveSettings as $k => $v) {
    if (str_starts_with((string)$k, 'live_inline_')) {
        $savedInlineTexts[$k] = $v;
    }
}
?>
<script>
window.LONGTECH_SAVED_INLINE_TEXTS = <?= json_encode($savedInlineTexts, JSON_UNESCAPED_UNICODE) ?>;
</script>

<?php if (has_role(['super_admin', 'admin']) || has_permission(['manage_appearance', 'manage_products'])): ?>
<!-- THANH ĐIỀU KHIỂN LIVE EDITOR HIỆN ĐẠI CHO QUẢN TRỊ VIÊN -->
<div class="live-admin-bar" id="liveAdminBar">
    <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
        <span style="background:linear-gradient(135deg,#D70018,#f97316); padding:4px 10px; border-radius:6px; font-weight:800; font-size:11px; letter-spacing:0.5px; box-shadow:0 2px 8px rgba(215,0,24,0.4);">
            <i class="fa-solid fa-bolt"></i> LIVE EDITOR 2.0
        </span>
        <span style="color:#cbd5e1; font-size:12.5px;">
            <i class="fa-solid fa-wand-magic-sparkles" style="color:#38bdf8;"></i> Chỉnh sửa trực tiếp trên trang:
        </span>
        <button type="button" id="toggleLiveEditBtn" onclick="toggleLiveEditing()" 
                style="background:#334155; color:#fff; border:1px solid #475569; padding:5px 14px; border-radius:8px; cursor:pointer; font-weight:700; font-size:12px; display:inline-flex; align-items:center; gap:6px; transition:all 0.2s;">
            <i class="fa-solid fa-pen-to-square"></i> Bật Chỉnh Sửa
        </button>
        <span id="liveEditCountBadge" style="display:none; background:rgba(16,185,129,0.18); color:#34d399; border:1px solid rgba(16,185,129,0.35); padding:3px 10px; border-radius:20px; font-size:11.5px; font-weight:700;">
            Click vào bất kỳ chữ / giá SP để sửa trực tiếp
        </span>
    </div>

    <div style="display:flex; align-items:center; gap:14px; flex-wrap:wrap;">
        <label style="display:inline-flex; align-items:center; gap:6px; font-size:12px; color:#cbd5e1; cursor:pointer;" title="Đổi màu chủ đạo trực tiếp">
            <i class="fa-solid fa-palette" style="color:#f43f5e;"></i> Màu chủ đạo:
            <input type="color" id="livePrimaryColorPicker" value="<?= e($primaryColor) ?>" onchange="previewAndConfirmColorChange(this.value)" style="width:24px; height:24px; border:none; border-radius:4px; cursor:pointer; background:transparent;">
        </label>
        <a href="<?= APP_URL ?>/admin.php?act=appearance/editor" style="color:#94a3b8; text-decoration:none; font-size:12px; font-weight:600;">
            <i class="fa-solid fa-sliders"></i> Bảng Bố Cục
        </a>
        <a href="<?= APP_URL ?>/admin.php" style="background:#2563eb; color:#fff; text-decoration:none; padding:5px 14px; border-radius:8px; font-weight:700; font-size:12px;">
            <i class="fa-solid fa-gauge-high"></i> Vào Trang Quản Trị
        </a>
    </div>
</div>

<!-- THANH CHỈ DẪN NỔI KHI ĐANG BẬT CHẾ ĐỘ SỬA TRỰC TIẾP -->
<div id="liveFloatingHint">
    <span style="width:10px; height:10px; border-radius:50%; background:#10b981; display:inline-block;"></span>
    <span id="liveFloatingHintText">Chế độ Sửa Trực Tiếp đang BẬT: Bấm vào Tên SP, Giá bán hoặc Tiêu đề bất kỳ để gõ sửa ngay trên trang!</span>
</div>

<!-- HỘP THOẠI XÁC NHẬN CÓ / KHÔNG SAU KHI SỬA TRỰC TIẾP -->
<div class="live-confirm-overlay" id="liveConfirmModal">
    <div class="live-confirm-card">
        <div style="background:linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color:#fff; padding:18px 22px; display:flex; align-items:center; justify-content:space-between;">
            <div style="display:flex; align-items:center; gap:10px;">
                <span style="width:34px; height:34px; border-radius:10px; background:rgba(56,189,248,0.18); color:#38bdf8; display:flex; align-items:center; justify-content:center; font-size:16px;">
                    <i class="fa-solid fa-circle-question"></i>
                </span>
                <div>
                    <h4 style="margin:0; font-size:16px; font-weight:800;">Xác Nhận Lưu Chỉnh Sửa?</h4>
                    <small id="liveConfirmTargetLabel" style="color:#94a3b8; font-size:12px;">Thay đổi trực tiếp trên trang</small>
                </div>
            </div>
            <button type="button" onclick="answerLiveConfirm(false)" style="background:none; border:none; color:#94a3b8; font-size:22px; cursor:pointer; line-height:1;">&times;</button>
        </div>

        <div style="padding:22px;">
            <p style="margin:0 0 14px; font-size:13.5px; color:#475569;">
                Bạn vừa chỉnh sửa trực tiếp nội dung trên trang. Bạn có muốn xác nhận lưu thay đổi này không?
            </p>

            <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:12px; padding:12px 14px; margin-bottom:12px;">
                <div style="font-size:11px; font-weight:700; color:#64748b; text-transform:uppercase; margin-bottom:4px;">Nội dung ban đầu:</div>
                <div id="liveConfirmOldVal" style="font-size:13.5px; color:#ef4444; text-decoration:line-through; word-break:break-word;"></div>
            </div>

            <div style="background:#f0fdf4; border:1px solid #bbf7d0; border-radius:12px; padding:12px 14px; margin-bottom:20px;">
                <div style="font-size:11px; font-weight:700; color:#15803d; text-transform:uppercase; margin-bottom:4px;">Nội dung mới sau khi sửa:</div>
                <div id="liveConfirmNewVal" style="font-size:14.5px; font-weight:700; color:#166534; word-break:break-word;"></div>
            </div>

            <div style="display:grid; grid-template-columns: 1fr 1.2fr; gap:12px;">
                <button type="button" onclick="answerLiveConfirm(false)" 
                        style="padding:11px 16px; border-radius:10px; border:1px solid #cbd5e1; background:#f1f5f9; color:#334155; font-weight:700; font-size:13.5px; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px;">
                    <i class="fa-solid fa-xmark"></i> Không, hoàn tác
                </button>
                <button type="button" id="btnLiveConfirmYes" onclick="answerLiveConfirm(true)" 
                        style="padding:11px 16px; border-radius:10px; border:none; background:linear-gradient(135deg, #16a34a, #15803d); color:#fff; font-weight:800; font-size:13.5px; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px; box-shadow:0 6px 16px rgba(22,163,74,0.3);">
                    <i class="fa-solid fa-check"></i> Có, xác nhận sửa
                </button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- MODAL XEM NHANH SẢN PHẨM (QUICK VIEW MODAL HIỆN ĐẠI CHO MỌI NGƯỜI DÙNG) -->
<div class="live-confirm-overlay" id="quickViewModal" onclick="if(event.target===this) closeQuickViewModal()">
    <div class="live-confirm-card" style="max-width:760px;">
        <div style="background:#0A2540; color:#fff; padding:14px 22px; display:flex; align-items:center; justify-content:space-between;">
            <span style="font-weight:800; font-size:14px;"><i class="fa-solid fa-eye text-warning"></i> XEM NHANH THÔNG SỐ SIÊU PHẨM</span>
            <button type="button" onclick="closeQuickViewModal()" style="background:none; border:none; color:#cbd5e1; font-size:22px; cursor:pointer;">&times;</button>
        </div>
        <div id="quickViewBody" style="padding:26px; display:grid; grid-template-columns: 1fr 1.25fr; gap:24px; align-items:center;">
            <!-- Nội dung nạp động bằng JS -->
        </div>
    </div>
</div>

<script>
// =========================================================================
// HỆ THỐNG LIVE INLINE EDITOR 2.0 + XÁC NHẬN CÓ/KHÔNG + TÌM KIẾM TỨC THÌ & QUICK VIEW
// =========================================================================
let isLiveEditing = false;
let pendingLiveEdit = null;

function extractSlugFromHref(href) {
    if (!href) return '';
    try {
        const u = new URL(href, window.location.origin);
        const parts = u.pathname.split('/').filter(Boolean);
        const idx = parts.indexOf('san-pham');
        if (idx !== -1 && parts[idx + 1]) return parts[idx + 1].split('#')[0];
        return parts[parts.length - 1] || '';
    } catch (e) {
        return '';
    }
}

// Khởi tạo định danh cho các phần tử trên trang & nạp nội dung đã lưu
function initLiveEditableElements() {
    const saved = window.LONGTECH_SAVED_INLINE_TEXTS || {};
    const pageKey = (window.location.pathname.split('/').pop() || 'home').replace(/[^a-zA-Z0-9_-]/g, '_');

    // 1. Gắn chỉnh sửa trực tiếp cho Sản phẩm trên thẻ Product Card
    document.querySelectorAll('.product-card').forEach(card => {
        const nameLink = card.querySelector('.product-name a');
        const priceEl  = card.querySelector('.price-current');
        const addBtn   = card.querySelector('button[onclick*="addToCart"]');
        let pid = 0;
        if (addBtn) {
            const m = addBtn.getAttribute('onclick').match(/addToCart\((\d+)/);
            if (m) pid = parseInt(m[1], 10);
        }
        const slug = nameLink ? extractSlugFromHref(nameLink.getAttribute('href')) : '';

        if (nameLink) {
            nameLink.setAttribute('data-live-editable', '1');
            nameLink.setAttribute('data-target-type', 'product');
            nameLink.setAttribute('data-field', 'name');
            nameLink.setAttribute('data-entity-id', String(pid));
            nameLink.setAttribute('data-entity-slug', slug);
            nameLink.setAttribute('data-label', 'Tên sản phẩm' + (pid ? ' #' + pid : ''));
        }
        if (priceEl) {
            priceEl.setAttribute('data-live-editable', '1');
            priceEl.setAttribute('data-target-type', 'product');
            priceEl.setAttribute('data-field', 'price');
            priceEl.setAttribute('data-entity-id', String(pid));
            priceEl.setAttribute('data-entity-slug', slug);
            priceEl.setAttribute('data-label', 'Giá bán sản phẩm' + (pid ? ' #' + pid : ''));
        }

        // Bổ sung nút Xem nhanh (Quick View) trên khung ảnh thẻ sản phẩm
        const thumbWrap = card.querySelector('.product-thumb-link');
        if (thumbWrap && slug && !card.querySelector('.quick-view-trigger')) {
            thumbWrap.style.position = 'relative';
            const qvBtn = document.createElement('button');
            qvBtn.type = 'button';
            qvBtn.className = 'quick-view-trigger';
            qvBtn.innerHTML = '<i class="fa-solid fa-eye"></i> Xem nhanh';
            qvBtn.onclick = function(ev) {
                ev.preventDefault();
                ev.stopPropagation();
                openQuickViewModal(slug);
            };
            thumbWrap.appendChild(qvBtn);
        }
    });

    // 2. Trang Chi tiết sản phẩm (Product Detail)
    const detailForm = document.getElementById('productBuyForm');
    if (detailForm) {
        const pidInput = detailForm.querySelector('input[name="product_id"]');
        const pid = pidInput ? parseInt(pidInput.value, 10) : 0;
        const dTitle = document.querySelector('.product-detail-title');
        const dPrice = document.querySelector('.detail-price-current');
        const dDesc  = document.querySelector('.product-short-desc');
        if (dTitle && pid) {
            dTitle.setAttribute('data-live-editable', '1');
            dTitle.setAttribute('data-target-type', 'product');
            dTitle.setAttribute('data-field', 'name');
            dTitle.setAttribute('data-entity-id', String(pid));
            dTitle.setAttribute('data-label', 'Tên sản phẩm #' + pid);
        }
        if (dPrice && pid) {
            dPrice.setAttribute('data-live-editable', '1');
            dPrice.setAttribute('data-target-type', 'product');
            dPrice.setAttribute('data-field', 'price');
            dPrice.setAttribute('data-entity-id', String(pid));
            dPrice.setAttribute('data-label', 'Giá bán sản phẩm #' + pid);
        }
        if (dDesc && pid) {
            dDesc.setAttribute('data-live-editable', '1');
            dDesc.setAttribute('data-target-type', 'product');
            dDesc.setAttribute('data-field', 'short_description');
            dDesc.setAttribute('data-entity-id', String(pid));
            dDesc.setAttribute('data-label', 'Mô tả ngắn sản phẩm #' + pid);
        }
    }

    // 3. Gắn chỉnh sửa trực tiếp cho Danh mục
    document.querySelectorAll('.category-card').forEach(card => {
        const slug = extractSlugFromHref(card.getAttribute('href'));
        const catName = card.querySelector('.category-name');
        if (catName && slug) {
            catName.setAttribute('data-live-editable', '1');
            catName.setAttribute('data-target-type', 'category');
            catName.setAttribute('data-field', 'name');
            catName.setAttribute('data-entity-slug', slug);
            catName.setAttribute('data-label', 'Tên danh mục (' + slug + ')');
        }
    });

    // 4. Gắn chỉnh sửa trực tiếp cho các Tiêu đề, Mô tả, Banner, Bento, Khẩu hiệu trên trang
    const generalSelectors = [
        '.section-title',
        '.section-desc',
        '.slide-title',
        '.slide-subtitle',
        '.flash-sale-title',
        '.flash-sale-subtitle',
        '.side-banner-info h3',
        '.side-banner-info p',
        '.bento-content h3',
        '.bento-content p',
        '.campaign-banner-text h3',
        '.campaign-banner-text p',
        '.mega-cyber-content h2',
        '.mega-cyber-content p',
        '.newsletter-text h3',
        '.newsletter-text p',
        '.cp-heading',
        '[data-editable]'
    ];
    let idxCounter = 0;
    document.querySelectorAll(generalSelectors.join(',')).forEach(el => {
        if (el.getAttribute('data-live-editable') === '1') return;
        idxCounter++;
        const customKey = el.getAttribute('data-editable') || ('live_inline_' + pageKey + '_' + el.tagName.toLowerCase() + '_' + idxCounter);
        el.setAttribute('data-live-editable', '1');
        el.setAttribute('data-target-type', 'setting');
        el.setAttribute('data-setting-key', customKey);
        el.setAttribute('data-label', 'Nội dung giao diện (' + customKey + ')');

        // Áp dụng nội dung đã lưu trong site_settings nếu có
        if (saved[customKey] !== undefined && saved[customKey] !== '') {
            // Nếu phần tử có chứa thẻ icon <i> ở đầu, giữ lại thẻ icon
            const iconEl = el.querySelector('i');
            if (iconEl && el.childNodes.length > 1) {
                const iconClone = iconEl.cloneNode(true);
                el.innerText = ' ' + saved[customKey];
                el.prepend(iconClone);
            } else {
                el.innerText = saved[customKey];
            }
        }
    });

    // 5. Gắn sự kiện Click & Blur/Enter để sửa trực tiếp tại chỗ
    document.querySelectorAll('[data-live-editable="1"]').forEach(el => {
        if (el.dataset.boundLiveEvent === '1') return;
        el.dataset.boundLiveEvent = '1';

        el.addEventListener('click', function(e) {
            if (!isLiveEditing) return;
            e.preventDefault();
            e.stopPropagation();

            if (this.getAttribute('contenteditable') === 'true') return;

            // Lưu lại giá trị gốc trước khi sửa
            const iconEl = this.querySelector('i');
            this.dataset.savedIconHtml = iconEl ? iconEl.outerHTML : '';
            this.dataset.originalText = this.innerText.trim();

            this.setAttribute('contenteditable', 'true');
            this.focus();

            // Đặt con trỏ vào cuối văn bản
            const range = document.createRange();
            range.selectNodeContents(this);
            range.collapse(false);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);

            const hintText = document.getElementById('liveFloatingHintText');
            if (hintText) {
                hintText.innerHTML = '⌨️ Đang sửa <strong>' + (this.dataset.label || 'Nội dung') + '</strong>: Nhấn <b>Enter</b> hoặc bấm ra ngoài để xác nhận • Nhấn <b>Esc</b> để hủy';
            }
        });

        el.addEventListener('keydown', function(e) {
            if (!isLiveEditing || this.getAttribute('contenteditable') !== 'true') return;
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.blur();
            } else if (e.key === 'Escape') {
                e.preventDefault();
                this.dataset.cancelEdit = '1';
                this.blur();
            }
        });

        el.addEventListener('blur', function() {
            if (this.getAttribute('contenteditable') !== 'true') return;
            this.removeAttribute('contenteditable');

            const oldVal = (this.dataset.originalText || '').trim();
            const newVal = this.innerText.trim();
            const savedIcon = this.dataset.savedIconHtml || '';

            if (this.dataset.cancelEdit === '1' || newVal === '' || newVal === oldVal) {
                delete this.dataset.cancelEdit;
                restoreElementDisplay(this, oldVal, savedIcon);
                return;
            }

            // Mở hộp thoại xác nhận Có / Không
            openLiveConfirmModal({
                element: this,
                label: this.dataset.label || 'Nội dung trên trang',
                oldVal: oldVal,
                newVal: newVal,
                savedIcon: savedIcon,
                targetType: this.dataset.targetType || 'setting',
                field: this.dataset.field || '',
                entityId: this.dataset.entityId || '0',
                entitySlug: this.dataset.entitySlug || '',
                settingKey: this.dataset.settingKey || ''
            });
        });
    });
}

function restoreElementDisplay(el, textVal, iconHtml) {
    if (!el) return;
    if (iconHtml) {
        el.innerHTML = iconHtml + ' ' + textVal.replace(/</g, '&lt;').replace(/>/g, '&gt;');
    } else {
        el.innerText = textVal;
    }
}

function toggleLiveEditing() {
    isLiveEditing = !isLiveEditing;
    const body  = document.body;
    const btn   = document.getElementById('toggleLiveEditBtn');
    const badge = document.getElementById('liveEditCountBadge');
    const hint  = document.getElementById('liveFloatingHint');

    if (isLiveEditing) {
        initLiveEditableElements();
        const totalEditable = document.querySelectorAll('[data-live-editable="1"]').length;
        body.classList.add('live-editable-active');
        btn.innerHTML = '<i class="fa-solid fa-circle-check"></i> Đang Bật Sửa Trực Tiếp (Click để tắt)';
        btn.style.background = 'linear-gradient(135deg, #16a34a, #15803d)';
        btn.style.borderColor = '#22c55e';
        if (badge) {
            badge.style.display = 'inline-block';
            badge.innerText = '✨ ' + totalEditable + ' mục trên trang có thể bấm để sửa trực tiếp';
        }
        if (hint) hint.style.display = 'inline-flex';
        if (typeof showToast === 'function') {
            showToast('Đã bật Chế độ Sửa Trực Tiếp! Hãy bấm vào Tên SP, Giá bán hoặc Tiêu đề bất kỳ trên trang để sửa.', 'success');
        }
    } else {
        body.classList.remove('live-editable-active');
        btn.innerHTML = '<i class="fa-solid fa-pen-to-square"></i> Bật Chỉnh Sửa';
        btn.style.background = '#334155';
        btn.style.borderColor = '#475569';
        if (badge) badge.style.display = 'none';
        if (hint) hint.style.display = 'none';
        if (typeof showToast === 'function') {
            showToast('Đã tắt chế độ chỉnh sửa trực tiếp.', 'info');
        }
    }
}

function openLiveConfirmModal(editData) {
    pendingLiveEdit = editData;
    document.getElementById('liveConfirmTargetLabel').innerText = editData.label;
    document.getElementById('liveConfirmOldVal').innerText = editData.oldVal;
    document.getElementById('liveConfirmNewVal').innerText = editData.newVal;
    document.getElementById('liveConfirmModal').style.display = 'flex';
}

function previewAndConfirmColorChange(newColor) {
    const oldColor = getComputedStyle(document.documentElement).getPropertyValue('--primary-color').trim() || '#D70018';
    document.documentElement.style.setProperty('--primary-color', newColor, 'important');
    document.documentElement.style.setProperty('--danger', newColor, 'important');
    openLiveConfirmModal({
        element: null,
        label: 'Màu chủ đạo giao diện Website',
        oldVal: oldColor,
        newVal: newColor,
        savedIcon: '',
        targetType: 'setting',
        field: '',
        entityId: '0',
        entitySlug: '',
        settingKey: 'site_primary_color',
        isColorChange: true
    });
}

function answerLiveConfirm(isConfirmed) {
    const modal = document.getElementById('liveConfirmModal');
    if (modal) modal.style.display = 'none';
    if (!pendingLiveEdit) return;

    const currentEdit = pendingLiveEdit;
    pendingLiveEdit = null;

    // Nếu bấm "Không, hoàn tác"
    if (!isConfirmed) {
        if (currentEdit.isColorChange) {
            document.documentElement.style.setProperty('--primary-color', currentEdit.oldVal, 'important');
            document.documentElement.style.setProperty('--danger', currentEdit.oldVal, 'important');
            const picker = document.getElementById('livePrimaryColorPicker');
            if (picker) picker.value = currentEdit.oldVal;
        } else if (currentEdit.element) {
            restoreElementDisplay(currentEdit.element, currentEdit.oldVal, currentEdit.savedIcon);
        }
        if (typeof showToast === 'function') {
            showToast('Đã hủy chỉnh sửa và khôi phục nội dung ban đầu.', 'info');
        }
        return;
    }

    // Nếu bấm "Có, xác nhận sửa" -> Gửi AJAX lưu vào CSDL
    const formData = new FormData();
    formData.append('csrf_token', '<?= csrf_token() ?>');
    formData.append('target_type', currentEdit.targetType);
    formData.append('field', currentEdit.field);
    formData.append('new_value', currentEdit.newVal);
    formData.append('entity_id', currentEdit.entityId);
    formData.append('entity_slug', currentEdit.entitySlug);
    formData.append('setting_key', currentEdit.settingKey);

    fetch('<?= APP_URL ?>/admin.php?act=appearance/live-inline-save', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(res => {
        if (res.status) {
            if (currentEdit.element) {
                const finalText = res.formatted_value || currentEdit.newVal;
                restoreElementDisplay(currentEdit.element, finalText, currentEdit.savedIcon);
            }
            if (typeof showToast === 'function') {
                showToast(res.message || 'Đã lưu thay đổi thành công!', 'success');
            }
        } else {
            if (currentEdit.element) {
                restoreElementDisplay(currentEdit.element, currentEdit.oldVal, currentEdit.savedIcon);
            }
            if (typeof showToast === 'function') {
                showToast(res.message || 'Không thể lưu thay đổi.', 'error');
            }
        }
    })
    .catch(() => {
        if (currentEdit.element) {
            restoreElementDisplay(currentEdit.element, currentEdit.oldVal, currentEdit.savedIcon);
        }
        if (typeof showToast === 'function') {
            showToast('Lỗi kết nối máy chủ khi lưu chỉnh sửa.', 'error');
        }
    });
}

// =========================================================================
// TÍNH NĂNG XEM NHANH SẢN PHẨM (QUICK VIEW MODAL) & TÌM KIẾM TỨC THÌ (INSTANT SEARCH)
// =========================================================================
function openQuickViewModal(slug) {
    const modal = document.getElementById('quickViewModal');
    const body  = document.getElementById('quickViewBody');
    if (!modal || !body) return;
    modal.style.display = 'flex';
    body.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:40px; color:#64748b;"><i class="fa-solid fa-spinner fa-spin fa-2x"></i><p style="margin-top:10px;">Đang tải thông tin siêu phẩm...</p></div>';

    fetch('<?= APP_URL ?>/api/live-search?slug=' + encodeURIComponent(slug))
        .then(r => r.json())
        .then(res => {
            if (!res.status || !res.product) {
                body.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:30px;">Không tìm thấy thông tin sản phẩm.</div>';
                return;
            }
            const p = res.product;
            body.innerHTML = `
                <div style="text-align:center; background:#fff; padding:16px; border-radius:14px; border:1px solid #e2e8f0;">
                    <img src="${p.thumbnail}" alt="${p.name}" style="max-height:260px; margin:0 auto; object-fit:contain;">
                </div>
                <div>
                    <span style="display:inline-block; background:#fee2e2; color:#D70018; padding:3px 10px; border-radius:20px; font-size:11px; font-weight:800; margin-bottom:8px;">
                        ${p.brand_name || 'CHÍNH HÃNG VN/A'}
                    </span>
                    <h3 style="font-size:20px; font-weight:800; color:#0f172a; margin:0 0 10px; line-height:1.35;">${p.name}</h3>
                    <div style="display:flex; align-items:baseline; gap:10px; margin-bottom:14px;">
                        <span style="font-size:24px; font-weight:900; color:#D70018;">${p.price_formatted}</span>
                        ${p.orig_formatted ? `<span style="font-size:14px; color:#94a3b8; text-decoration:line-through;">${p.orig_formatted}</span>` : ''}
                    </div>
                    <p style="font-size:13.5px; color:#475569; line-height:1.6; margin-bottom:16px;">
                        ${p.short_description || 'Sản phẩm chính hãng phân phối tại LongTech, bảo hành 1 đổi 1 trong 30 ngày.'}
                    </p>
                    <div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:20px; font-size:12px;">
                        ${p.screen && p.screen !== 'Không áp dụng' ? `<span style="background:#f1f5f9; padding:4px 10px; border-radius:6px; color:#334155;"><i class="fa-solid fa-display"></i> ${p.screen}</span>` : ''}
                        ${p.battery && p.battery !== 'Không áp dụng' ? `<span style="background:#f1f5f9; padding:4px 10px; border-radius:6px; color:#334155;"><i class="fa-solid fa-battery-full"></i> ${p.battery}</span>` : ''}
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                        <button type="button" onclick="addToCart(${p.id}); closeQuickViewModal();" style="padding:12px; border-radius:10px; border:1px solid #D70018; background:#fff1f2; color:#D70018; font-weight:800; cursor:pointer;">
                            <i class="fa-solid fa-cart-plus"></i> Thêm vào giỏ
                        </button>
                        <a href="<?= APP_URL ?>/san-pham/${p.slug}" style="padding:12px; border-radius:10px; background:#0A2540; color:#fff; text-align:center; font-weight:800; text-decoration:none;">
                            Xem chi tiết & Mua
                        </a>
                    </div>
                </div>
            `;
        });
}

function closeQuickViewModal() {
    const modal = document.getElementById('quickViewModal');
    if (modal) modal.style.display = 'none';
}

document.addEventListener('DOMContentLoaded', () => {
    initLiveEditableElements();

    // Khởi tạo Tìm kiếm tức thì (Instant Search Autocomplete)
    const searchForm  = document.querySelector('.search-form');
    const searchInput = document.querySelector('.search-input');
    if (searchForm && searchInput) {
        searchForm.style.overflow = 'visible';
        const dropdown = document.createElement('div');
        dropdown.className = 'instant-search-dropdown';
        searchForm.appendChild(dropdown);

        let searchTimer = null;
        searchInput.addEventListener('input', function() {
            const q = this.value.trim();
            clearTimeout(searchTimer);
            if (q.length < 1) {
                dropdown.style.display = 'none';
                return;
            }
            searchTimer = setTimeout(() => {
                fetch('<?= APP_URL ?>/api/live-search?q=' + encodeURIComponent(q))
                    .then(r => r.json())
                    .then(res => {
                        if (!res.status || !res.items || res.items.length === 0) {
                            dropdown.innerHTML = '<div style="padding:14px; font-size:13px; color:#64748b; text-align:center;">Không tìm thấy sản phẩm phù hợp với "' + q.replace(/</g, '&lt;') + '"</div>';
                            dropdown.style.display = 'block';
                            return;
                        }
                        dropdown.innerHTML = res.items.map(it => `
                            <a href="${it.url}" class="instant-search-item">
                                <img src="${it.thumbnail}" alt="${it.name}">
                                <div style="flex:1; min-width:0;">
                                    <div style="font-size:13.5px; font-weight:700; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${it.name}</div>
                                    <div style="font-size:12px; color:#D70018; font-weight:800;">${it.price_formatted} ${it.orig_formatted ? `<small style="color:#94a3b8; text-decoration:line-through; font-weight:400; margin-left:6px;">${it.orig_formatted}</small>` : ''}</div>
                                </div>
                                <i class="fa-solid fa-chevron-right" style="color:#cbd5e1; font-size:12px;"></i>
                            </a>
                        `).join('');
                        dropdown.style.display = 'block';
                    });
            }, 180);
        });

        document.addEventListener('click', (ev) => {
            if (!searchForm.contains(ev.target)) {
                dropdown.style.display = 'none';
            }
        });
    }
});
</script>

<!-- 1. THANH THÔNG BÁO CHỮ CHẠY (MARQUEE ANNOUNCEMENT TICKER) -->
<div class="announcement-bar">
    <div class="announcement-ticker">
        <div class="ticker-track">
            <span>🔥 <strong>SIÊU SALE CÔNG NGHỆ 2026:</strong> Giảm giá sốc đến 50% cho toàn bộ điện thoại, tablet, phụ kiện chính hãng!</span>
            <span>⚡ <strong>GIAO HÀNG HỎA TỐC:</strong> Miễn phí giao nhanh trong 2 giờ cho đơn hàng từ 2.000.000đ</span>
            <span>🛡️ <strong>BẢO HÀNH VIP:</strong> Lỗi 1 đổi 1 trong 30 ngày đầu, bảo hành 12 tháng chính hãng tại trung tâm LongTech</span>
            <span>💳 <strong>ƯU ĐÃI THANH TOÁN:</strong> Hỗ trợ trả góp 0% lãi suất qua thẻ tín dụng và quét mã VNPAY-QR giảm thêm 200.000đ</span>
            <!-- Lặp lại chuỗi để chạy liên tục không bị giật -->
            <span>🔥 <strong>SIÊU SALE CÔNG NGHỆ 2026:</strong> Giảm giá sốc đến 50% cho toàn bộ điện thoại, tablet, phụ kiện chính hãng!</span>
            <span>⚡ <strong>GIAO HÀNG HỎA TỐC:</strong> Miễn phí giao nhanh trong 2 giờ cho đơn hàng từ 2.000.000đ</span>
        </div>
    </div>
</div>

<!-- 2. THANH TIỆN ÍCH TRÊN CÙNG (TOP BAR) -->
<div class="topbar">
    <div class="container topbar-inner">
        <div class="topbar-left">
            <span class="policy-item"><i class="fa-solid fa-shield-halved"></i> 100% Hàng chính hãng</span>
            <span class="policy-item"><i class="fa-solid fa-truck-fast"></i> Giao nhanh 2H toàn quốc</span>
            <span class="policy-item"><i class="fa-solid fa-arrow-rotate-left"></i> Đổi trả 30 ngày lỗi 1-1</span>
        </div>
        <div class="topbar-right">
            <span class="topbar-hotline"><i class="fa-solid fa-phone-volume"></i> Hotline: <strong><?= HOTLINE ?></strong></span>
            <a href="<?= APP_URL ?>/tin-tuc" class="topbar-link"><i class="fa-regular fa-newspaper"></i> Bản tin công nghệ</a>
            <a href="<?= APP_URL ?>/lien-he" class="topbar-link"><i class="fa-regular fa-circle-question"></i> Trợ giúp</a>
        </div>
    </div>
</div>

<!-- 2. THANH HEADER CHÍNH -->
<header class="main-header">
    <div class="container header-container">
        <!-- Nút menu mobile (Hamburger) -->
        <button class="mobile-menu-toggle" id="mobileMenuBtn" aria-label="Mở Menu">
            <i class="fa-solid fa-bars"></i>
        </button>

        <!-- Logo LongTech -->
        <a href="<?= APP_URL ?>" class="brand-logo">
            <div class="logo-icon"><i class="fa-solid fa-microchip"></i></div>
            <div class="logo-text">LONG<span>TECH</span></div>
        </a>

        <!-- Nút Danh mục sản phẩm dạng Dropdown -->
        <div class="category-dropdown-btn" id="catBtn">
            <i class="fa-solid fa-layer-group"></i>
            <span>Danh Mục</span>
            <i class="fa-solid fa-chevron-down arrow-icon"></i>
            
            <!-- Menu Dropdown Danh Mục (8 ngành hàng công nghệ) -->
            <div class="category-dropdown-menu" style="min-width: 265px;">
                <a href="<?= APP_URL ?>/dien-thoai" class="cat-item">
                    <i class="fa-solid fa-mobile-screen-button" style="color:#D70018; width:18px; text-align:center;"></i>
                    <span style="flex:1;">Điện thoại Smartphone</span>
                    <span style="font-size:10px; background:#fee2e2; color:#D70018; padding:1px 6px; border-radius:10px; font-weight:800;">HOT</span>
                </a>
                <a href="<?= APP_URL ?>/may-tinh-bang" class="cat-item">
                    <i class="fa-solid fa-tablet-screen-button" style="color:#0284c7; width:18px; text-align:center;"></i>
                    <span style="flex:1;">Máy tính bảng Tablet</span>
                </a>
                <a href="<?= APP_URL ?>/laptop" class="cat-item">
                    <i class="fa-solid fa-laptop" style="color:#2563eb; width:18px; text-align:center;"></i>
                    <span style="flex:1;">Laptop & MacBook</span>
                </a>
                <a href="<?= APP_URL ?>/dong-ho-thong-minh" class="cat-item">
                    <i class="fa-solid fa-clock" style="color:#ea580c; width:18px; text-align:center;"></i>
                    <span style="flex:1;">Đồng hồ thông minh</span>
                    <span style="font-size:10px; background:#ffedd5; color:#ea580c; padding:1px 6px; border-radius:10px; font-weight:800;">MỚI</span>
                </a>
                <a href="<?= APP_URL ?>/am-thanh" class="cat-item">
                    <i class="fa-solid fa-volume-high" style="color:#7c3aed; width:18px; text-align:center;"></i>
                    <span style="flex:1;">Âm thanh & Loa Hi-End</span>
                    <span style="font-size:10px; background:#ede9fe; color:#7c3aed; padding:1px 6px; border-radius:10px; font-weight:800;">MỚI</span>
                </a>
                <a href="<?= APP_URL ?>/gaming-gear" class="cat-item">
                    <i class="fa-solid fa-gamepad" style="color:#16a34a; width:18px; text-align:center;"></i>
                    <span style="flex:1;">Gaming & PS5 Console</span>
                    <span style="font-size:10px; background:#dcfce7; color:#16a34a; padding:1px 6px; border-radius:10px; font-weight:800;">HOT</span>
                </a>
                <a href="<?= APP_URL ?>/man-hinh-pc" class="cat-item">
                    <i class="fa-solid fa-desktop" style="color:#0f172a; width:18px; text-align:center;"></i>
                    <span style="flex:1;">Màn hình & PC Đồ họa</span>
                </a>
                <a href="<?= APP_URL ?>/phu-kien" class="cat-item">
                    <i class="fa-solid fa-headphones" style="color:#64748b; width:18px; text-align:center;"></i>
                    <span style="flex:1;">Phụ kiện công nghệ</span>
                </a>
            </div>
        </div>

        <!-- Ô Tìm kiếm sản phẩm thông minh kèm từ khóa xu hướng -->
        <div class="header-search">
            <form action="<?= APP_URL ?>/tim-kiem" method="GET" class="search-form">
                <input type="text" name="keyword" class="search-input" placeholder="Tìm iPhone 16 Pro Max, PS5 Slim, Watch Ultra 2, MacBook M3..." value="<?= e($_GET['keyword'] ?? '') ?>" autocomplete="off" required>
                <button type="submit" class="search-btn" aria-label="Tìm kiếm">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>
            </form>
            <div class="header-Quick-tags">
                <a href="<?= APP_URL ?>/san-pham/iphone-16-pro-max-256gb">iPhone 16 Pro Max</a>
                <a href="<?= APP_URL ?>/san-pham/samsung-galaxy-z-fold6-5g-256gb">Galaxy Z Fold6</a>
                <a href="<?= APP_URL ?>/san-pham/apple-watch-ultra-2-49mm-titan-den">Watch Ultra 2</a>
                <a href="<?= APP_URL ?>/san-pham/may-choi-game-sony-ps5-slim">PS5 Slim</a>
                <a href="<?= APP_URL ?>/san-pham/loa-bluetooth-marshall-stanmore-iii">Marshall</a>
            </div>
        </div>

        <!-- Các nút hành động: Hotline, Đơn hàng, Giỏ hàng, Tài khoản -->
        <div class="header-actions">
            <!-- Hotline -->
            <a href="tel:<?= str_replace(' ', '', HOTLINE) ?>" class="action-btn hotline-action d-none-mobile">
                <div class="action-icon"><i class="fa-solid fa-headset"></i></div>
                <div class="action-info">
                    <span class="action-label">Hỗ trợ 24/7</span>
                    <span class="action-title"><?= HOTLINE ?></span>
                </div>
            </a>

            <!-- Giỏ hàng -->
            <a href="<?= APP_URL ?>/gio-hang" class="action-btn cart-action" id="headerCartBtn">
                <div class="action-icon">
                    <i class="fa-solid fa-cart-shopping"></i>
                    <span class="cart-badge" id="cartCountBadge"><?= $cartCount ?></span>
                </div>
                <div class="action-info d-none-mobile">
                    <span class="action-label">Giỏ hàng</span>
                    <span class="action-title">Xem ngay</span>
                </div>
            </a>

            <!-- Tài khoản Người dùng -->
            <div class="user-account-dropdown">
                <?php if ($currentUser): ?>
                    <div class="action-btn user-btn">
                        <div class="action-icon user-avatar-badge">
                            <i class="fa-solid fa-user-check"></i>
                        </div>
                        <div class="action-info d-none-mobile">
                            <span class="action-label">Xin chào,</span>
                            <span class="action-title"><?= e($currentUser['full_name'] ?? $currentUser['username']) ?></span>
                        </div>
                    </div>
                    <!-- Menu thả xuống của tài khoản -->
                    <div class="user-dropdown-menu">
                        <div class="dropdown-user-header">
                            <strong><?= e($currentUser['full_name']) ?></strong>
                            <small><?= e($currentUser['email']) ?></small>
                            <span class="badge-role"><?= e($currentUser['role_display'] ?? 'Thành viên') ?></span>
                        </div>
                        <hr>
                        <a href="<?= APP_URL ?>/tai-khoan"><i class="fa-solid fa-id-card"></i> Thông tin tài khoản</a>
                        <a href="<?= APP_URL ?>/tai-khoan/don-hang"><i class="fa-solid fa-box-open"></i> Đơn hàng của tôi</a>
                        <a href="<?= APP_URL ?>/tai-khoan/doi-mat-khau"><i class="fa-solid fa-key"></i> Đổi mật khẩu</a>
                        
                        <?php if (in_array($currentUser['role_name'] ?? '', ['super_admin', 'admin', 'product_manager', 'order_manager'])): ?>
                            <a href="<?= APP_URL ?>/admin.php" class="admin-link-btn" target="_blank">
                                <i class="fa-solid fa-gauge-high"></i> Vào Trang Quản Trị
                            </a>
                        <?php endif; ?>
                        
                        <hr>
                        <a href="<?= APP_URL ?>/dang-xuat" class="logout-link"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a>
                    </div>
                <?php else: ?>
                    <a href="<?= APP_URL ?>/dang-nhap" class="action-btn">
                        <div class="action-icon"><i class="fa-regular fa-user"></i></div>
                        <div class="action-info d-none-mobile">
                            <span class="action-label">Đăng nhập</span>
                            <span class="action-title">Tài khoản</span>
                        </div>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 3. THANH ĐIỀU HƯỚNG PHỤ (NAVIGATION BAR) -->
    <nav class="sub-navbar">
        <div class="container sub-navbar-inner">
            <ul class="nav-links">
                <li><a href="<?= APP_URL ?>" class="nav-link <?= empty($_GET['url']) ? 'active' : '' ?>"><i class="fa-solid fa-house"></i> Trang chủ</a></li>
                <li><a href="<?= APP_URL ?>/dien-thoai" class="nav-link"><i class="fa-solid fa-mobile-screen-button"></i> Điện thoại</a></li>
                <li><a href="<?= APP_URL ?>/laptop" class="nav-link"><i class="fa-solid fa-laptop"></i> Laptop</a></li>
                <li><a href="<?= APP_URL ?>/may-tinh-bang" class="nav-link"><i class="fa-solid fa-tablet-screen-button"></i> Tablet</a></li>
                <li><a href="<?= APP_URL ?>/dong-ho-thong-minh" class="nav-link"><i class="fa-solid fa-clock"></i> Smartwatch</a></li>
                <li><a href="<?= APP_URL ?>/am-thanh" class="nav-link"><i class="fa-solid fa-volume-high"></i> Âm thanh</a></li>
                <li><a href="<?= APP_URL ?>/gaming-gear" class="nav-link"><i class="fa-solid fa-gamepad"></i> Gaming & PS5</a></li>
                <li><a href="<?= APP_URL ?>/man-hinh-pc" class="nav-link"><i class="fa-solid fa-desktop"></i> Màn hình & PC</a></li>
                <li><a href="<?= APP_URL ?>/khuyen-mai" class="nav-link highlight-link"><i class="fa-solid fa-fire text-danger"></i> Săn Sale</a></li>
                <li><a href="<?= APP_URL ?>/tin-tuc" class="nav-link"><i class="fa-solid fa-video"></i> Review SP</a></li>
            </ul>
            <div class="nav-promo-tag">
                <i class="fa-solid fa-bolt"></i> Miễn phí giao hàng đơn từ <?= format_money(FREE_SHIPPING_MIN) ?>
            </div>
        </div>
    </nav>
</header>

<!-- 4. MOBILE NAVIGATION DRAWER (MENU TRƯỢT DI ĐỘNG) -->
<div class="mobile-drawer-overlay" id="mobileDrawerOverlay"></div>
<aside class="mobile-drawer" id="mobileDrawer">
    <div class="drawer-header">
        <div class="brand-logo">
            <div class="logo-icon"><i class="fa-solid fa-microchip"></i></div>
            <div class="logo-text">LONG<span>TECH</span></div>
        </div>
        <button class="drawer-close-btn" id="drawerCloseBtn">&times;</button>
    </div>
    <div class="drawer-user-box">
        <?php if ($currentUser): ?>
            <div class="user-greeting">
                <i class="fa-solid fa-circle-user"></i>
                <div>
                    <strong><?= e($currentUser['full_name']) ?></strong>
                    <small><?= e($currentUser['email']) ?></small>
                </div>
            </div>
            <div class="drawer-user-actions">
                <a href="<?= APP_URL ?>/tai-khoan" class="drawer-user-btn">Tài khoản</a>
                <a href="<?= APP_URL ?>/dang-xuat" class="drawer-user-btn text-danger">Đăng xuất</a>
            </div>
        <?php else: ?>
            <div class="drawer-auth-btns">
                <a href="<?= APP_URL ?>/dang-nhap" class="btn-drawer-login">Đăng nhập</a>
                <a href="<?= APP_URL ?>/dang-ky" class="btn-drawer-reg">Đăng ký</a>
            </div>
        <?php endif; ?>
    </div>
    <ul class="drawer-nav">
        <li><a href="<?= APP_URL ?>"><i class="fa-solid fa-house"></i> Trang chủ</a></li>
        <li><a href="<?= APP_URL ?>/dien-thoai"><i class="fa-solid fa-mobile-screen-button"></i> Điện thoại</a></li>
        <li><a href="<?= APP_URL ?>/may-tinh-bang"><i class="fa-solid fa-tablet-screen-button"></i> Máy tính bảng</a></li>
        <li><a href="<?= APP_URL ?>/laptop"><i class="fa-solid fa-laptop"></i> Laptop & MacBook</a></li>
        <li><a href="<?= APP_URL ?>/dong-ho-thong-minh"><i class="fa-solid fa-clock"></i> Đồng hồ thông minh</a></li>
        <li><a href="<?= APP_URL ?>/am-thanh"><i class="fa-solid fa-volume-high"></i> Âm thanh & Loa</a></li>
        <li><a href="<?= APP_URL ?>/gaming-gear"><i class="fa-solid fa-gamepad"></i> Gaming & PS5 Console</a></li>
        <li><a href="<?= APP_URL ?>/man-hinh-pc"><i class="fa-solid fa-desktop"></i> Màn hình & PC</a></li>
        <li><a href="<?= APP_URL ?>/phu-kien"><i class="fa-solid fa-headphones"></i> Phụ kiện công nghệ</a></li>
        <li><a href="<?= APP_URL ?>/khuyen-mai" class="text-danger"><i class="fa-solid fa-fire"></i> Săn Sale HOT</a></li>
        <li><a href="<?= APP_URL ?>/tin-tuc"><i class="fa-solid fa-video"></i> Review & Tin tức SP</a></li>
        <li><a href="<?= APP_URL ?>/lien-he"><i class="fa-solid fa-envelope"></i> Liên hệ & Góp ý</a></li>
        <?php if ($currentUser && in_array($currentUser['role_name'] ?? '', ['super_admin', 'admin', 'product_manager', 'order_manager'])): ?>
            <li><a href="<?= APP_URL ?>/admin.php" class="text-primary font-bold"><i class="fa-solid fa-gauge-high"></i> Quản Trị Hệ Thống</a></li>
        <?php endif; ?>
    </ul>
    <div class="drawer-footer">
        <p><i class="fa-solid fa-phone"></i> Hotline: <strong><?= HOTLINE ?></strong></p>
        <p><i class="fa-solid fa-location-dot"></i> <?= STORE_ADDRESS ?></p>
    </div>
</aside>

<!-- VÙNG HIỂN THỊ THÔNG BÁO FLASH MESSAGE -->
<div class="container flash-container">
    <?php if (has_flash('success')): ?>
        <div class="alert alert-success">
            <i class="fa-solid fa-circle-check"></i>
            <span><?= e(get_flash('success')) ?></span>
            <button class="alert-close" onclick="this.parentElement.remove();">&times;</button>
        </div>
    <?php endif; ?>

    <?php if (has_flash('error')): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-triangle-exclamation"></i>
            <span><?= e(get_flash('error')) ?></span>
            <button class="alert-close" onclick="this.parentElement.remove();">&times;</button>
        </div>
    <?php endif; ?>
</div>

<!-- NỘI DUNG CHÍNH (Bắt đầu thẻ main) -->
<main class="main-content">

