<?php
/**
 * ========================================================
 * LONGTECH - HEADER CHUẨN GIAO DIỆN NGƯỜI DÙNG (header.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

// Tính tổng số lượng sản phẩm trong giỏ hàng
$cartCount = 0;
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cartCount += (int)($item['quantity'] ?? 1);
    }
}
$currentUser = current_user();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <meta name="referrer" content="no-referrer">
    <title><?= e($pageTitle ?? 'LongTech - Thế Giới Công Nghệ Đỉnh Cao') ?></title>
    
    <!-- Google Fonts: Inter & Roboto -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    
    <!-- FontAwesome 6 Icons CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- CSS Stylesheet của LongTech -->
    <link rel="stylesheet" href="<?= ASSET_URL ?>/css/main.css?v=<?= time() ?>">
    <link rel="stylesheet" href="<?= ASSET_URL ?>/css/responsive.css?v=<?= time() ?>">
    
    <?php
    // Nạp cấu hình màu sắc động từ SiteSettingModel
    require_once ROOT_PATH . '/models/SiteSettingModel.php';
    $siteSettingModel = new SiteSettingModel();
    $liveSettings = $siteSettingModel->getAllSettings();
    $primaryColor = $liveSettings['site_primary_color'] ?? '#D70018';
    $secondaryColor = $liveSettings['site_secondary_color'] ?? '#0A2540';
    $fontFamily = $liveSettings['site_font'] ?? 'Inter';
    ?>
    <style>
        :root {
            --primary-color: <?= e($primaryColor) ?> !important;
            --secondary-color: <?= e($secondaryColor) ?> !important;
            --main-font: '<?= e($fontFamily) ?>', sans-serif !important;
        }
        body { font-family: var(--main-font); }
        .live-editable-active [data-editable] {
            outline: 2px dashed #0284c7 !important;
            outline-offset: 3px;
            cursor: pointer;
            position: relative;
            transition: all 0.2s;
        }
        .live-editable-active [data-editable]:hover {
            outline: 2px solid #D70018 !important;
            background: rgba(215, 0, 24, 0.05);
        }
        .live-admin-bar {
            background: #0f172a;
            color: #f8fafc;
            padding: 8px 20px;
            font-size: 13px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.25);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
    </style>
</head>
<body>

<?php if (has_role(['super_admin', 'admin'])): ?>
<!-- THANH ĐIỀU KHIỂN LIVE EDITOR NỔI CHO QUẢN TRỊ VIÊN -->
<div class="live-admin-bar" id="liveAdminBar">
    <div style="display:flex; align-items:center; gap:12px;">
        <span style="background:#D70018; padding:3px 8px; border-radius:4px; font-weight:700; font-size:11px; letter-spacing:0.5px;">ADMIN MODE</span>
        <span><i class="fa-solid fa-wand-magic-sparkles" style="color:#38bdf8;"></i> Chế độ chỉnh sửa trực quan (Live Editor):</span>
        <button type="button" id="toggleLiveEditBtn" onclick="toggleLiveEditing()" 
                style="background:#334155; color:#fff; border:1px solid #475569; padding:4px 12px; border-radius:6px; cursor:pointer; font-weight:600; font-size:12px;">
            <i class="fa-solid fa-pen-to-square"></i> Bật Chỉnh Sửa
        </button>
    </div>
    <div style="display:flex; align-items:center; gap:15px;">
        <a href="<?= APP_URL ?>/admin.php?act=appearance/editor" style="color:#94a3b8; text-decoration:none; font-size:12px; font-weight:600;">
            <i class="fa-solid fa-sliders"></i> Bảng Bố Cục Trang Chủ
        </a>
        <a href="<?= APP_URL ?>/admin.php" style="background:#2563eb; color:#fff; text-decoration:none; padding:4px 12px; border-radius:6px; font-weight:600; font-size:12px;">
            <i class="fa-solid fa-gauge-high"></i> Vào Trang Quản Trị
        </a>
    </div>
</div>

<script>
let isLiveEditing = false;
function toggleLiveEditing() {
    isLiveEditing = !isLiveEditing;
    const body = document.body;
    const btn = document.getElementById('toggleLiveEditBtn');
    if (isLiveEditing) {
        body.classList.add('live-editable-active');
        btn.innerHTML = '<i class="fa-solid fa-check"></i> Đang Bật (Click để tắt)';
        btn.style.background = '#16a34a';
        btn.style.borderColor = '#15803d';
        alert('Chế độ Chỉnh sửa Trực tiếp đang BẬT!\nBấm trực tiếp vào các khối tiêu đề hoặc thông tin để sửa nhanh nội dung.');
    } else {
        body.classList.remove('live-editable-active');
        btn.innerHTML = '<i class="fa-solid fa-pen-to-square"></i> Bật Chỉnh Sửa';
        btn.style.background = '#334155';
        btn.style.borderColor = '#475569';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-editable]').forEach(el => {
        el.addEventListener('click', (e) => {
            if (!isLiveEditing) return;
            e.preventDefault();
            e.stopPropagation();
            const key = el.getAttribute('data-editable');
            const currentVal = el.innerText.trim();
            const newVal = prompt('Chỉnh sửa nội dung cho [' + key + ']:', currentVal);
            if (newVal !== null && newVal !== currentVal) {
                el.innerText = newVal;
                // Gửi AJAX lưu cấu hình
                const formData = new FormData();
                formData.append('csrf_token', '<?= csrf_token() ?>');
                formData.append('settings[' + key + ']', newVal);
                fetch('<?= APP_URL ?>/admin.php?act=appearance/save-settings', {
                    method: 'POST',
                    body: formData
                })
                .then(r => r.json())
                .then(res => {
                    if (res.status) {
                        alert('Đã cập nhật [' + key + '] thành công!');
                    } else {
                        alert('Lỗi: ' + res.message);
                    }
                });
            }
        });
    });
});
</script>
<?php endif; ?>

<!-- 1. THANH THÔNG BÁO CHỮ CHẠY (MARQUEE ANNOUNCEMENT TICKER) -->
<div class="announcement-bar">
    <div class="announcement-ticker">
        <div class="ticker-track">
            <span>🔥 <strong>SIÊU SALE CÔNG NGHỆ 2026:</strong> Giảm giá sốc đến 50% cho toàn bộ điện thoại, tablet, phụ kiện chính hãng!</span>
            <span>⚡ <strong>GIAO HÀNG HỎA TỐC:</strong> Miễn phí giao nhanh trong 2 giờ cho đơn hàng từ 2.000.000đ</span>
            <span>🛡️ <strong>BẢO HÀNH VIP:</strong> Lỗi 1 đổi 1 trong 30 ngày đầu, bảo hành 12 tháng chính hãng tại trung tâm LongTech</span>
            <span>💳 <strong>ƯU ĐÃI THANH TOÁN:</strong> Hỗ trợ trả góp 0% lãi suất qua thẻ tín dụng và quét mã VNPAY-QR giảm thêm 200.000đ</span>
            <!-- Lặp lại chuỗi để chạy liên tục không bị giật -->
            <span>🔥 <strong>SIÊU SALE CÔNG NGHỆ 2026:</strong> Giảm giá sốc đến 50% cho toàn bộ điện thoại, tablet, phụ kiện chính hãng!</span>
            <span>⚡ <strong>GIAO HÀNG HỎA TỐC:</strong> Miễn phí giao nhanh trong 2 giờ cho đơn hàng từ 2.000.000đ</span>
        </div>
    </div>
</div>

<!-- 2. THANH TIỆN ÍCH TRÊN CÙNG (TOP BAR) -->
<div class="topbar">
    <div class="container topbar-inner">
        <div class="topbar-left">
            <span class="policy-item"><i class="fa-solid fa-shield-halved"></i> 100% Hàng chính hãng</span>
            <span class="policy-item"><i class="fa-solid fa-truck-fast"></i> Giao nhanh 2H toàn quốc</span>
            <span class="policy-item"><i class="fa-solid fa-arrow-rotate-left"></i> Đổi trả 30 ngày lỗi 1-1</span>
        </div>
        <div class="topbar-right">
            <span class="topbar-hotline"><i class="fa-solid fa-phone-volume"></i> Hotline: <strong><?= HOTLINE ?></strong></span>
            <a href="<?= APP_URL ?>/tin-tuc" class="topbar-link"><i class="fa-regular fa-newspaper"></i> Bản tin công nghệ</a>
            <a href="<?= APP_URL ?>/lien-he" class="topbar-link"><i class="fa-regular fa-circle-question"></i> Trợ giúp</a>
        </div>
    </div>
</div>

<!-- 2. THANH HEADER CHÍNH -->
<header class="main-header">
    <div class="container header-container">
        <!-- Nút menu mobile (Hamburger) -->
        <button class="mobile-menu-toggle" id="mobileMenuBtn" aria-label="Mở Menu">
            <i class="fa-solid fa-bars"></i>
        </button>

        <!-- Logo LongTech -->
        <a href="<?= APP_URL ?>" class="brand-logo">
            <div class="logo-icon"><i class="fa-solid fa-microchip"></i></div>
            <div class="logo-text">LONG<span>TECH</span></div>
        </a>

        <!-- Nút Danh mục sản phẩm dạng Dropdown -->
        <div class="category-dropdown-btn" id="catBtn">
            <i class="fa-solid fa-layer-group"></i>
            <span>Danh Mục</span>
            <i class="fa-solid fa-chevron-down arrow-icon"></i>
            
            <!-- Menu Dropdown Danh Mục -->
            <div class="category-dropdown-menu">
                <a href="<?= APP_URL ?>/dien-thoai" class="cat-item">
                    <i class="fa-solid fa-mobile-screen-button"></i> Điện thoại
                </a>
                <a href="<?= APP_URL ?>/may-tinh-bang" class="cat-item">
                    <i class="fa-solid fa-tablet-screen-button"></i> Máy tính bảng
                </a>
                <a href="<?= APP_URL ?>/laptop" class="cat-item">
                    <i class="fa-solid fa-laptop"></i> Laptop
                </a>
                <a href="<?= APP_URL ?>/phu-kien" class="cat-item">
                    <i class="fa-solid fa-headphones"></i> Phụ kiện công nghệ
                </a>
            </div>
        </div>

        <!-- Ô Tìm kiếm sản phẩm thông minh -->
        <div class="header-search">
            <form action="<?= APP_URL ?>/tim-kiem" method="GET" class="search-form">
                <input type="text" name="keyword" class="search-input" placeholder="Bạn cần tìm iPhone 15, Laptop ASUS, Galaxy S24..." value="<?= e($_GET['keyword'] ?? '') ?>" autocomplete="off" required>
                <button type="submit" class="search-btn" aria-label="Tìm kiếm">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>
            </form>
        </div>

        <!-- Các nút hành động: Hotline, Đơn hàng, Giỏ hàng, Tài khoản -->
        <div class="header-actions">
            <!-- Hotline -->
            <a href="tel:<?= str_replace(' ', '', HOTLINE) ?>" class="action-btn hotline-action d-none-mobile">
                <div class="action-icon"><i class="fa-solid fa-headset"></i></div>
                <div class="action-info">
                    <span class="action-label">Hỗ trợ 24/7</span>
                    <span class="action-title"><?= HOTLINE ?></span>
                </div>
            </a>

            <!-- Giỏ hàng -->
            <a href="<?= APP_URL ?>/gio-hang" class="action-btn cart-action" id="headerCartBtn">
                <div class="action-icon">
                    <i class="fa-solid fa-cart-shopping"></i>
                    <span class="cart-badge" id="cartCountBadge"><?= $cartCount ?></span>
                </div>
                <div class="action-info d-none-mobile">
                    <span class="action-label">Giỏ hàng</span>
                    <span class="action-title">Xem ngay</span>
                </div>
            </a>

            <!-- Tài khoản Người dùng -->
            <div class="user-account-dropdown">
                <?php if ($currentUser): ?>
                    <div class="action-btn user-btn">
                        <div class="action-icon user-avatar-badge">
                            <i class="fa-solid fa-user-check"></i>
                        </div>
                        <div class="action-info d-none-mobile">
                            <span class="action-label">Xin chào,</span>
                            <span class="action-title"><?= e($currentUser['full_name'] ?? $currentUser['username']) ?></span>
                        </div>
                    </div>
                    <!-- Menu thả xuống của tài khoản -->
                    <div class="user-dropdown-menu">
                        <div class="dropdown-user-header">
                            <strong><?= e($currentUser['full_name']) ?></strong>
                            <small><?= e($currentUser['email']) ?></small>
                            <span class="badge-role"><?= e($currentUser['role_display'] ?? 'Thành viên') ?></span>
                        </div>
                        <hr>
                        <a href="<?= APP_URL ?>/tai-khoan"><i class="fa-solid fa-id-card"></i> Thông tin tài khoản</a>
                        <a href="<?= APP_URL ?>/tai-khoan/don-hang"><i class="fa-solid fa-box-open"></i> Đơn hàng của tôi</a>
                        <a href="<?= APP_URL ?>/tai-khoan/doi-mat-khau"><i class="fa-solid fa-key"></i> Đổi mật khẩu</a>
                        
                        <?php if (in_array($currentUser['role_name'] ?? '', ['super_admin', 'admin', 'product_manager', 'order_manager'])): ?>
                            <a href="<?= APP_URL ?>/admin.php" class="admin-link-btn" target="_blank">
                                <i class="fa-solid fa-gauge-high"></i> Vào Trang Quản Trị
                            </a>
                        <?php endif; ?>
                        
                        <hr>
                        <a href="<?= APP_URL ?>/dang-xuat" class="logout-link"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a>
                    </div>
                <?php else: ?>
                    <a href="<?= APP_URL ?>/dang-nhap" class="action-btn">
                        <div class="action-icon"><i class="fa-regular fa-user"></i></div>
                        <div class="action-info d-none-mobile">
                            <span class="action-label">Đăng nhập</span>
                            <span class="action-title">Tài khoản</span>
                        </div>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 3. THANH ĐIỀU HƯỚNG PHỤ (NAVIGATION BAR) -->
    <nav class="sub-navbar">
        <div class="container sub-navbar-inner">
            <ul class="nav-links">
                <li><a href="<?= APP_URL ?>" class="nav-link <?= empty($_GET['url']) ? 'active' : '' ?>"><i class="fa-solid fa-house"></i> Trang chủ</a></li>
                <li><a href="<?= APP_URL ?>/dien-thoai" class="nav-link"><i class="fa-solid fa-mobile-screen-button"></i> Điện thoại</a></li>
                <li><a href="<?= APP_URL ?>/may-tinh-bang" class="nav-link"><i class="fa-solid fa-tablet-screen-button"></i> Máy tính bảng</a></li>
                <li><a href="<?= APP_URL ?>/laptop" class="nav-link"><i class="fa-solid fa-laptop"></i> Laptop</a></li>
                <li><a href="<?= APP_URL ?>/phu-kien" class="nav-link"><i class="fa-solid fa-headphones"></i> Phụ kiện</a></li>
                <li><a href="<?= APP_URL ?>/khuyen-mai" class="nav-link highlight-link"><i class="fa-solid fa-fire text-danger"></i> Săn Sale HOT</a></li>
                <li><a href="<?= APP_URL ?>/tin-tuc" class="nav-link"><i class="fa-solid fa-newspaper"></i> Tin tức</a></li>
                <li><a href="<?= APP_URL ?>/lien-he" class="nav-link"><i class="fa-solid fa-envelope"></i> Liên hệ</a></li>
            </ul>
            <div class="nav-promo-tag">
                <i class="fa-solid fa-bolt"></i> Miễn phí giao hàng đơn từ <?= format_money(FREE_SHIPPING_MIN) ?>
            </div>
        </div>
    </nav>
</header>

<!-- 4. MOBILE NAVIGATION DRAWER (MENU TRƯỢT DI ĐỘNG) -->
<div class="mobile-drawer-overlay" id="mobileDrawerOverlay"></div>
<aside class="mobile-drawer" id="mobileDrawer">
    <div class="drawer-header">
        <div class="brand-logo">
            <div class="logo-icon"><i class="fa-solid fa-microchip"></i></div>
            <div class="logo-text">LONG<span>TECH</span></div>
        </div>
        <button class="drawer-close-btn" id="drawerCloseBtn">&times;</button>
    </div>
    <div class="drawer-user-box">
        <?php if ($currentUser): ?>
            <div class="user-greeting">
                <i class="fa-solid fa-circle-user"></i>
                <div>
                    <strong><?= e($currentUser['full_name']) ?></strong>
                    <small><?= e($currentUser['email']) ?></small>
                </div>
            </div>
            <div class="drawer-user-actions">
                <a href="<?= APP_URL ?>/tai-khoan" class="drawer-user-btn">Tài khoản</a>
                <a href="<?= APP_URL ?>/dang-xuat" class="drawer-user-btn text-danger">Đăng xuất</a>
            </div>
        <?php else: ?>
            <div class="drawer-auth-btns">
                <a href="<?= APP_URL ?>/dang-nhap" class="btn-drawer-login">Đăng nhập</a>
                <a href="<?= APP_URL ?>/dang-ky" class="btn-drawer-reg">Đăng ký</a>
            </div>
        <?php endif; ?>
    </div>
    <ul class="drawer-nav">
        <li><a href="<?= APP_URL ?>"><i class="fa-solid fa-house"></i> Trang chủ</a></li>
        <li><a href="<?= APP_URL ?>/dien-thoai"><i class="fa-solid fa-mobile-screen-button"></i> Điện thoại</a></li>
        <li><a href="<?= APP_URL ?>/may-tinh-bang"><i class="fa-solid fa-tablet-screen-button"></i> Máy tính bảng</a></li>
        <li><a href="<?= APP_URL ?>/laptop"><i class="fa-solid fa-laptop"></i> Laptop</a></li>
        <li><a href="<?= APP_URL ?>/phu-kien"><i class="fa-solid fa-headphones"></i> Phụ kiện công nghệ</a></li>
        <li><a href="<?= APP_URL ?>/khuyen-mai" class="text-danger"><i class="fa-solid fa-fire"></i> Săn Sale HOT</a></li>
        <li><a href="<?= APP_URL ?>/tin-tuc"><i class="fa-solid fa-newspaper"></i> Tin tức công nghệ</a></li>
        <li><a href="<?= APP_URL ?>/lien-he"><i class="fa-solid fa-envelope"></i> Liên hệ & Góp ý</a></li>
        <?php if ($currentUser && in_array($currentUser['role_name'] ?? '', ['super_admin', 'admin', 'product_manager', 'order_manager'])): ?>
            <li><a href="<?= APP_URL ?>/admin.php" class="text-primary font-bold"><i class="fa-solid fa-gauge-high"></i> Quản Trị Hệ Thống</a></li>
        <?php endif; ?>
    </ul>
    <div class="drawer-footer">
        <p><i class="fa-solid fa-phone"></i> Hotline: <strong><?= HOTLINE ?></strong></p>
        <p><i class="fa-solid fa-location-dot"></i> <?= STORE_ADDRESS ?></p>
    </div>
</aside>

<!-- VÙNG HIỂN THỊ THÔNG BÁO FLASH MESSAGE -->
<div class="container flash-container">
    <?php if (has_flash('success')): ?>
        <div class="alert alert-success">
            <i class="fa-solid fa-circle-check"></i>
            <span><?= e(get_flash('success')) ?></span>
            <button class="alert-close" onclick="this.parentElement.remove();">&times;</button>
        </div>
    <?php endif; ?>

    <?php if (has_flash('error')): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-triangle-exclamation"></i>
            <span><?= e(get_flash('error')) ?></span>
            <button class="alert-close" onclick="this.parentElement.remove();">&times;</button>
        </div>
    <?php endif; ?>
</div>

<!-- NỘI DUNG CHÍNH (Bắt đầu thẻ main) -->
<main class="main-content">

