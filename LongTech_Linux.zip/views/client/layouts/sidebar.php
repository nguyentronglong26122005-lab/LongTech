<?php
/**
 * ========================================================
 * LONGTECH - SIDEBAR BỘ LỌC SẢN PHẨM (sidebar.php)
 * ========================================================
 */
if (!defined('ROOT_PATH')) {
    exit('Direct access not permitted');
}

$selectedBrands = isset($filters['brand_slugs']) 
    ? (is_array($filters['brand_slugs']) ? $filters['brand_slugs'] : explode(',', $filters['brand_slugs']))
    : [];

$currentSort = $filters['sort'] ?? 'newest';
$activePriceRange = $_GET['price_range'] ?? '';
$activeRam = $filters['ram'] ?? '';
$activeStorage = $filters['storage'] ?? '';
?>

<aside class="product-filter-sidebar" id="productFilterSidebar">
    <div class="sidebar-header-mobile">
        <h3><i class="fa-solid fa-filter"></i> Bộ Lọc Tìm Kiếm</h3>
        <button type="button" class="close-filter-btn" id="closeFilterBtn">&times;</button>
    </div>

    <form action="<?= APP_URL ?>/<?= !empty($route) ? e($route) : 'san-pham' ?>" method="GET" id="filterForm">
        <!-- Giữ lại từ khóa tìm kiếm và sắp xếp nếu có -->
        <?php if (!empty($filters['keyword'])): ?>
            <input type="hidden" name="keyword" value="<?= e($filters['keyword']) ?>">
        <?php endif; ?>
        <?php if (!empty($currentSort)): ?>
            <input type="hidden" name="sort" value="<?= e($currentSort) ?>">
        <?php endif; ?>

        <!-- 1. BỘ LỌC THEO DANH MỤC -->
        <div class="filter-group">
            <h4 class="filter-title"><i class="fa-solid fa-layer-group text-primary"></i> Danh Mục</h4>
            <ul class="filter-list">
                <li>
                    <a href="<?= APP_URL ?>/san-pham" class="filter-category-link <?= empty($currentCategory) && empty($route) ? 'active' : '' ?>">
                        <span>Tất cả sản phẩm</span>
                    </a>
                </li>
                <?php if (!empty($categories)): ?>
                    <?php foreach ($categories as $cat): ?>
                        <li>
                            <a href="<?= APP_URL ?>/<?= e($cat['slug']) ?>" class="filter-category-link <?= (!empty($currentCategory) && $currentCategory['id'] == $cat['id']) || ($route === $cat['slug']) ? 'active' : '' ?>">
                                <span><i class="fa-solid <?= e($cat['icon'] ?? 'fa-cube') ?>"></i> <?= e($cat['name']) ?></span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                <?php endif; ?>
            </ul>
        </div>

        <!-- 2. BỘ LỌC THEO THƯƠNG HIỆU -->
        <div class="filter-group">
            <h4 class="filter-title"><i class="fa-solid fa-tag text-secondary"></i> Thương Hiệu</h4>
            <div class="brand-checkboxes-grid">
                <?php if (!empty($brands)): ?>
                    <?php foreach ($brands as $brand): ?>
                        <label class="custom-filter-pill">
                            <input type="checkbox" name="brand[]" value="<?= e($brand['slug']) ?>" <?= in_array($brand['slug'], $selectedBrands) ? 'checked' : '' ?> onchange="document.getElementById('filterForm').submit()">
                            <span><?= e($brand['name']) ?></span>
                        </label>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- 3. BỘ LỌC THEO MỨC GIÁ -->
        <div class="filter-group">
            <h4 class="filter-title"><i class="fa-solid fa-money-bill-wave text-danger"></i> Khoảng Giá</h4>
            <div class="price-options-list">
                <label class="price-radio-label">
                    <input type="radio" name="price_range" value="" <?= empty($activePriceRange) ? 'checked' : '' ?> onchange="document.getElementById('filterForm').submit()">
                    <span>Tất cả mức giá</span>
                </label>
                <label class="price-radio-label">
                    <input type="radio" name="price_range" value="0-5000000" <?= $activePriceRange === '0-5000000' ? 'checked' : '' ?> onchange="document.getElementById('filterForm').submit()">
                    <span>Dưới 5 triệu</span>
                </label>
                <label class="price-radio-label">
                    <input type="radio" name="price_range" value="5000000-10000000" <?= $activePriceRange === '5000000-10000000' ? 'checked' : '' ?> onchange="document.getElementById('filterForm').submit()">
                    <span>Từ 5 - 10 triệu</span>
                </label>
                <label class="price-radio-label">
                    <input type="radio" name="price_range" value="10000000-20000000" <?= $activePriceRange === '10000000-20000000' ? 'checked' : '' ?> onchange="document.getElementById('filterForm').submit()">
                    <span>Từ 10 - 20 triệu</span>
                </label>
                <label class="price-radio-label">
                    <input type="radio" name="price_range" value="20000000+" <?= $activePriceRange === '20000000+' ? 'checked' : '' ?> onchange="document.getElementById('filterForm').submit()">
                    <span>Trên 20 triệu</span>
                </label>
            </div>
        </div>

        <!-- 4. BỘ LỌC DUNG LƯỢNG RAM -->
        <div class="filter-group">
            <h4 class="filter-title"><i class="fa-solid fa-microchip text-primary"></i> Dung Lượng RAM</h4>
            <div class="spec-pills-row">
                <?php foreach (['8GB', '12GB', '16GB', '32GB'] as $ramVal): ?>
                    <label class="custom-filter-pill">
                        <input type="radio" name="ram" value="<?= $ramVal ?>" <?= $activeRam === $ramVal ? 'checked' : '' ?> onchange="document.getElementById('filterForm').submit()">
                        <span><?= $ramVal ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- 5. BỘ LỌC BỘ NHỚ TRONG (STORAGE) -->
        <div class="filter-group">
            <h4 class="filter-title"><i class="fa-solid fa-hard-drive text-primary"></i> Bộ Nhớ Trong</h4>
            <div class="spec-pills-row">
                <?php foreach (['128GB', '256GB', '512GB', '1TB'] as $storageVal): ?>
                    <label class="custom-filter-pill">
                        <input type="radio" name="storage" value="<?= $storageVal ?>" <?= $activeStorage === $storageVal ? 'checked' : '' ?> onchange="document.getElementById('filterForm').submit()">
                        <span><?= $storageVal ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Nút Reset bộ lọc -->
        <div class="filter-reset-action">
            <a href="<?= APP_URL ?>/<?= !empty($route) ? e($route) : 'san-pham' ?>" class="btn-reset-filters">
                <i class="fa-solid fa-rotate-left"></i> Xóa tất cả bộ lọc
            </a>
        </div>
    </form>
</aside>

