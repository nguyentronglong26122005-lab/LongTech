# ========================================================
# LONGTECH - SCRIPT TỰ ĐỘNG ĐỒNG BỘ TOÀN BỘ CODE TỪ WORKSPACE SANG XAMPP
# ========================================================

$source = "E:\LongTech"
$dest   = "D:\XamPP\htdocs\LongTech"

Write-Host ">>> Bắt đầu sao chép code sang thư mục XAMPP ($dest)..." -ForegroundColor Cyan

if (!(Test-Path $dest)) {
    Write-Host "[!] Thư mục đích $dest không tồn tại. Vui lòng kiểm tra lại đường dẫn." -ForegroundColor Red
    exit
}

# Sao chép đè toàn bộ file mã nguồn
Copy-Item -Path "$source\*" -Destination $dest -Recurse -Force

Write-Host ">>> ĐÃ ĐỒNG BỘ THÀNH CÔNG TẤT CẢ FILE VÀO XAMPP!" -ForegroundColor Green
Write-Host "Bây giờ bạn hãy F5 (Refresh) lại trang admin trên trình duyệt: http://localhost/LongTech/admin.php" -ForegroundColor Yellow

