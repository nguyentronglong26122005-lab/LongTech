# LONGTECH - SYNC WORKSPACE TO XAMPP
$source = "E:\LongTech"
$dest   = "D:\XamPP\htdocs\LongTech"

Write-Host ">>> Syncing code to XAMPP ($dest)..." -ForegroundColor Cyan

if (!(Test-Path $dest)) {
    Write-Host "[!] Destination $dest does not exist." -ForegroundColor Red
    exit
}

Copy-Item -Path "$source\*" -Destination $dest -Recurse -Force
Write-Host ">>> SYNC COMPLETED SUCCESSFULLY!" -ForegroundColor Green
