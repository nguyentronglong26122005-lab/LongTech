<?php
/**
 * ========================================================
 * LONGTECH - CỔNG VÀO CHÍNH CỦA TRANG QUẢN TRỊ (admin.php)
 * ========================================================
 * - BẢO MẬT: Bắt buộc đăng nhập và kiểm tra quyền Server-Side
 * - CƠ CHẾ PHÊ DUYỆT (MAKER-CHECKER):
 *   + Super Admin: Thực thi trực tiếp và phê duyệt yêu cầu từ nhân viên
 *   + Nhân viên các vai trò: Khi thực hiện thao tác thêm/sửa/xóa sẽ gửi yêu cầu
 *     lên Super Admin duyệt; ngay khi Admin duyệt sẽ thực thi lập tức trên web.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/models/Database.php';
require_once __DIR__ . '/includes/auth_middleware.php';
require_once __DIR__ . '/models/ApprovalModel.php';

// 1. Kiểm tra kết nối CSDL
$db = Database::connect();

// 1.1 Đồng bộ quyền và chức năng mới nhất của tài khoản đang đăng nhập
if (is_logged_in()) {
    require_once __DIR__ . '/models/UserModel.php';
    $freshUser = (new UserModel())->findById((int)$_SESSION['user']['id']);
    if ($freshUser) {
        $_SESSION['user']['role_id']      = $freshUser['role_id'];
        $_SESSION['user']['role_name']    = $freshUser['role_name'];
        $_SESSION['user']['role_display'] = $freshUser['role_display'];
        $_SESSION['user']['permissions']  = $freshUser['permissions'] ?? null;
    }
}

// 2. Kiểm tra quyền truy cập Quản trị viên (Chặn Customer)
require_admin();

/**
 * Bộ chặn tự động: Khi thành viên được phân quyền (không phải Super Admin)
 * thực hiện thao tác thay đổi dữ liệu, tự động gửi yêu cầu lên Admin chờ duyệt.
 */
function intercept_staff_action_for_approval(string $act): void {
    // Super Admin hoặc tiến trình đang thực thi lệnh đã được Admin duyệt thì chạy thẳng
    if (current_role() === 'super_admin' || !empty($GLOBALS['IS_EXECUTING_APPROVED_ACTION'])) {
        return;
    }

    $isPost = ($_SERVER['REQUEST_METHOD'] === 'POST');

    // Bản đồ các thao tác cần gửi lên Admin duyệt
    $postActions = [
        'products/add'            => ['mod' => 'Sản phẩm & Kho',        'perm' => 'manage_products',   'ret' => '/admin.php?act=products'],
        'products/edit'           => ['mod' => 'Sản phẩm & Kho',        'perm' => 'manage_products',   'ret' => '/admin.php?act=products'],
        'categories/add-edit'     => ['mod' => 'Sản phẩm & Kho',        'perm' => 'manage_products',   'ret' => '/admin.php?act=categories'],
        'orders/update-status'    => ['mod' => 'Đơn hàng & Vận chuyển', 'perm' => 'manage_orders',     'ret' => '/admin.php?act=orders'],
        'banners/add-edit'        => ['mod' => 'Giao diện & Banner',    'perm' => 'manage_appearance', 'ret' => '/admin.php?act=banners'],
        'appearance/save-settings'=> ['mod' => 'Giao diện & Banner',    'perm' => 'manage_appearance', 'ret' => '/admin.php?act=appearance/editor'],
        'appearance/save-sections'=> ['mod' => 'Giao diện & Banner',    'perm' => 'manage_appearance', 'ret' => '/admin.php?act=appearance/editor'],
        'appearance/create-version'=>['mod' => 'Giao diện & Banner',    'perm' => 'manage_appearance', 'ret' => '/admin.php?act=appearance/editor'],
        'coupons/add-edit'        => ['mod' => 'Marketing & Tin tức',   'perm' => 'manage_marketing',  'ret' => '/admin.php?act=coupons'],
        'posts/add-edit'          => ['mod' => 'Marketing & Tin tức',   'perm' => 'manage_marketing',  'ret' => '/admin.php?act=posts'],
        'users/add'               => ['mod' => 'Tài khoản & Phân quyền','perm' => 'manage_users',      'ret' => '/admin.php?act=users'],
        'users/change-role'       => ['mod' => 'Tài khoản & Phân quyền','perm' => 'manage_users',      'ret' => '/admin.php?act=users'],
    ];

    $directActions = [
        'products/delete'            => ['mod' => 'Sản phẩm & Kho',        'perm' => 'manage_products',   'ret' => '/admin.php?act=products'],
        'categories/delete'          => ['mod' => 'Sản phẩm & Kho',        'perm' => 'manage_products',   'ret' => '/admin.php?act=categories'],
        'banners/delete'             => ['mod' => 'Giao diện & Banner',    'perm' => 'manage_appearance', 'ret' => '/admin.php?act=banners'],
        'appearance/restore-version' => ['mod' => 'Giao diện & Banner',    'perm' => 'manage_appearance', 'ret' => '/admin.php?act=appearance/editor'],
        'coupons/delete'             => ['mod' => 'Marketing & Tin tức',   'perm' => 'manage_marketing',  'ret' => '/admin.php?act=coupons'],
        'coupons/toggle'             => ['mod' => 'Marketing & Tin tức',   'perm' => 'manage_marketing',  'ret' => '/admin.php?act=coupons'],
        'posts/delete'               => ['mod' => 'Marketing & Tin tức',   'perm' => 'manage_marketing',  'ret' => '/admin.php?act=posts'],
        'reviews/approve'            => ['mod' => 'Sản phẩm & Kho',        'perm' => 'manage_products',   'ret' => '/admin.php?act=reviews'],
        'reviews/delete'             => ['mod' => 'Sản phẩm & Kho',        'perm' => 'manage_products',   'ret' => '/admin.php?act=reviews'],
        'contacts/delete'            => ['mod' => 'Marketing & Tin tức',   'perm' => 'manage_marketing',  'ret' => '/admin.php?act=contacts'],
        'users/toggle'               => ['mod' => 'Tài khoản & Phân quyền','perm' => 'manage_users',      'ret' => '/admin.php?act=users'],
        'system/maintenance'         => ['mod' => 'Tài khoản & Phân quyền','perm' => 'manage_users',      'ret' => '/admin.php?act=system/logs'],
    ];

    $matched = null;
    if ($isPost && isset($postActions[$act])) {
        $matched = $postActions[$act];
    } elseif (isset($directActions[$act])) {
        $matched = $directActions[$act];
    }

    if (!$matched) {
        return;
    }

    // Kiểm tra nhân viên có quyền ở phân hệ này không
    require_permission($matched['perm']);

    if ($isPost) {
        verify_csrf_token();
    }

    // Nếu nhân viên có tải file ảnh lên, lưu file ảnh ngay để giữ URL cho lúc Admin duyệt
    if ($isPost) {
        if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] === UPLOAD_ERR_OK) {
            $up = upload_image('thumbnail', 'products');
            if (!empty($up['status'])) {
                $_POST['thumbnail_url'] = $up['full_url'];
            }
        }
        if (isset($_FILES['image_file']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
            $up = upload_image('image_file', 'banners');
            if (!empty($up['status'])) {
                $_POST['image_url'] = $up['full_url'];
            }
        }
        if (!empty($_FILES['thumbnail_file']['name'])) {
            $up = upload_image($_FILES['thumbnail_file'], 'posts');
            if (!empty($up['status'])) {
                $_POST['thumbnail'] = $up['full_url'];
            }
        }
    }

    // Tạo tiêu đề và tóm tắt nội dung yêu cầu rõ ràng cho Admin duyệt
    $targetId = $_GET['id'] ?? ($_POST['id'] ?? ($_POST['order_id'] ?? ($_POST['user_id'] ?? '')));
    $titleMap = [
        'products/add'            => 'Thêm sản phẩm mới: ' . ($_POST['name'] ?? ''),
        'products/edit'           => 'Sửa sản phẩm #' . $targetId . ': ' . ($_POST['name'] ?? ''),
        'products/delete'         => 'Xóa sản phẩm #' . $targetId,
        'categories/add-edit'     => (!empty($targetId) ? "Sửa danh mục #{$targetId}: " : 'Thêm danh mục: ') . ($_POST['name'] ?? ''),
        'categories/delete'       => 'Xóa danh mục #' . $targetId,
        'orders/update-status'    => 'Cập nhật trạng thái đơn hàng #' . $targetId . ' sang "' . ($_POST['status'] ?? '') . '"',
        'banners/add-edit'        => (!empty($targetId) ? "Sửa Banner #{$targetId}: " : 'Thêm Banner mới: ') . ($_POST['title'] ?? ''),
        'banners/delete'          => 'Xóa Banner #' . $targetId,
        'appearance/save-settings'=> 'Cập nhật cài đặt Giao diện Website',
        'appearance/save-sections'=> 'Cập nhật bố cục các khối Trang chủ',
        'appearance/create-version'=> 'Tạo bản lưu Giao diện mới',
        'appearance/restore-version'=> 'Khôi phục phiên bản Giao diện #' . $targetId,
        'coupons/add-edit'        => (!empty($targetId) ? "Sửa mã giảm giá #{$targetId}: " : 'Thêm mã giảm giá: ') . ($_POST['code'] ?? ''),
        'coupons/delete'          => 'Xóa mã giảm giá #' . $targetId,
        'coupons/toggle'          => 'Bật/Tắt trạng thái mã giảm giá #' . $targetId,
        'posts/add-edit'          => (!empty($targetId) ? "Sửa bài viết #{$targetId}: " : 'Đăng bài viết mới: ') . ($_POST['title'] ?? ''),
        'posts/delete'            => 'Xóa bài viết #' . $targetId,
        'reviews/approve'         => 'Duyệt hiển thị đánh giá #' . $targetId,
        'reviews/delete'          => 'Xóa đánh giá khách hàng #' . $targetId,
        'contacts/delete'         => 'Xóa thư liên hệ #' . $targetId,
        'users/add'               => 'Thêm thành viên mới: @' . ($_POST['username'] ?? ''),
        'users/change-role'       => 'Cập nhật phân quyền thành viên #' . $targetId,
        'users/toggle'            => 'Khóa/Mở khóa tài khoản thành viên #' . $targetId,
        'system/maintenance'      => 'Thay đổi chế độ bảo trì hệ thống',
    ];
    $actionTitle = $titleMap[$act] ?? ('Thao tác: ' . $act);

    // Tóm tắt chi tiết các trường dữ liệu gửi lên
    $summaryParts = [];
    if (!empty($_POST['price']))          $summaryParts[] = 'Giá: ' . format_money($_POST['price']);
    if (!empty($_POST['sale_price']))     $summaryParts[] = 'Giá KM: ' . format_money($_POST['sale_price']);
    if (isset($_POST['stock_quantity']))  $summaryParts[] = 'Tồn kho: ' . (int)$_POST['stock_quantity'];
    if (!empty($_POST['product_code']))   $summaryParts[] = 'Mã SP: ' . $_POST['product_code'];
    if (!empty($_POST['status']))         $summaryParts[] = 'Trạng thái: ' . $_POST['status'];
    if (!empty($_POST['permissions']) && is_array($_POST['permissions'])) {
        $summaryParts[] = 'Vai trò tích chọn: ' . implode(', ', $_POST['permissions']);
    }
    $actionSummary = implode(' | ', $summaryParts);

    // Loại bỏ csrf_token khỏi dữ liệu lưu trữ
    $cleanPost = $_POST;
    unset($cleanPost['csrf_token']);

    $user = current_user();
    $approvalModel = new ApprovalModel();
    $reqId = $approvalModel->createRequest([
        'user_id'          => (int)($user['id'] ?? 0),
        'username'         => $user['username'] ?? 'staff',
        'full_name'        => $user['full_name'] ?? ($user['username'] ?? 'Nhân viên'),
        'user_permissions' => implode(',', get_user_permissions($user)),
        'action_key'       => $act,
        'module_name'      => $matched['mod'],
        'action_title'     => $actionTitle,
        'action_summary'   => $actionSummary,
        'get_data'         => $_GET,
        'post_data'        => $cleanPost
    ]);

    log_activity('request_approval', "Gửi yêu cầu chờ duyệt #{$reqId}: {$actionTitle}", $reqId);
    set_flash('warning', "⏳ Yêu cầu #{$reqId} ({$actionTitle}) đã được gửi lên Admin! Ngay khi Admin bấm Duyệt, thay đổi sẽ được thực hiện lập tức trên web.");
    redirect($matched['ret']);
}

/**
 * Hàm điều phối thực thi Controller theo $act (dùng cho cả luồng trực tiếp và luồng Admin bấm Duyệt)
 */
function dispatch_admin_action(string $act): void {
    switch ($act) {
        // B. QUẢN LÝ SẢN PHẨM & KHO HÀNG
        case 'products':
        case 'products/add':
        case 'products/edit':
        case 'products/delete':
        case 'products/export':
            require_once __DIR__ . '/controllers/admin/ProductManageController.php';
            $ctrl = new ProductManageController();
            if ($act === 'products/add')        $ctrl->add();
            elseif ($act === 'products/edit')   $ctrl->edit();
            elseif ($act === 'products/delete') $ctrl->delete();
            elseif ($act === 'products/export') $ctrl->exportCsv();
            else                                $ctrl->index();
            break;

        // C. QUẢN LÝ DANH MỤC
        case 'categories':
        case 'categories/add-edit':
        case 'categories/delete':
            require_once __DIR__ . '/controllers/admin/ProductManageController.php';
            $ctrl = new ProductManageController();
            if ($act === 'categories/add-edit') $ctrl->categoryAddEdit();
            elseif ($act === 'categories/delete')  $ctrl->categoryDelete();
            else                                   $ctrl->categories();
            break;

        // D. QUẢN LÝ BANNER & SLIDESHOW
        case 'banners':
        case 'banners/add-edit':
        case 'banners/delete':
            require_once __DIR__ . '/controllers/admin/BannerController.php';
            $ctrl = new BannerController();
            if ($act === 'banners/add-edit') $ctrl->addEdit();
            elseif ($act === 'banners/delete')  $ctrl->delete();
            else                                $ctrl->index();
            break;

        // D2. QUẢN LÝ GIAO DIỆN & LIVE EDITOR
        case 'appearance/editor':
        case 'appearance/save-settings':
        case 'appearance/save-sections':
        case 'appearance/create-version':
        case 'appearance/restore-version':
            require_once __DIR__ . '/controllers/admin/LiveEditorController.php';
            $ctrl = new LiveEditorController();
            if ($act === 'appearance/save-settings')       $ctrl->saveSettings();
            elseif ($act === 'appearance/save-sections')   $ctrl->saveSections();
            elseif ($act === 'appearance/create-version')  $ctrl->createVersion();
            elseif ($act === 'appearance/restore-version') $ctrl->restoreVersion();
            else                                           $ctrl->index();
            break;

        // E. QUẢN LÝ ĐƠN HÀNG
        case 'orders':
        case 'orders/detail':
        case 'orders/update-status':
        case 'orders/export':
            require_once __DIR__ . '/controllers/admin/OrderManageController.php';
            $ctrl = new OrderManageController();
            if ($act === 'orders/detail')            $ctrl->detail();
            elseif ($act === 'orders/update-status') $ctrl->updateStatus();
            elseif ($act === 'orders/export')        $ctrl->exportCsv();
            else                                     $ctrl->index();
            break;

        // F. QUẢN LÝ MÃ GIẢM GIÁ (COUPONS)
        case 'coupons':
        case 'coupons/add-edit':
        case 'coupons/delete':
        case 'coupons/toggle':
            require_once __DIR__ . '/controllers/admin/CouponController.php';
            $ctrl = new CouponController();
            if ($act === 'coupons/add-edit')   $ctrl->addEdit();
            elseif ($act === 'coupons/delete') $ctrl->delete();
            elseif ($act === 'coupons/toggle') $ctrl->toggle();
            else                               $ctrl->index();
            break;

        // G. QUẢN LÝ BÀI VIẾT / TIN TỨC
        case 'posts':
        case 'posts/add-edit':
        case 'posts/delete':
            require_once __DIR__ . '/controllers/admin/PostController.php';
            $ctrl = new PostController();
            if ($act === 'posts/add-edit')   $ctrl->addEdit();
            elseif ($act === 'posts/delete') $ctrl->delete();
            else                             $ctrl->index();
            break;

        // H. QUẢN LÝ ĐÁNH GIÁ SẢN PHẨM
        case 'reviews':
        case 'reviews/approve':
        case 'reviews/delete':
            require_once __DIR__ . '/controllers/admin/ReviewController.php';
            $ctrl = new ReviewController();
            if ($act === 'reviews/approve')   $ctrl->approve();
            elseif ($act === 'reviews/delete') $ctrl->delete();
            else                               $ctrl->index();
            break;

        // I. QUẢN LÝ LIÊN HỆ / GÓP Ý
        case 'contacts':
        case 'contacts/mark-read':
        case 'contacts/delete':
        case 'contacts/export-csv':
            require_once __DIR__ . '/controllers/admin/ContactController.php';
            $ctrl = new ContactController();
            if ($act === 'contacts/mark-read')      $ctrl->markRead();
            elseif ($act === 'contacts/delete')     $ctrl->delete();
            elseif ($act === 'contacts/export-csv') $ctrl->exportCsv();
            else                                    $ctrl->index();
            break;

        // J. QUẢN LÝ THÀNH VIÊN & PHÂN QUYỀN
        case 'users':
        case 'users/add':
        case 'users/toggle':
        case 'users/change-role':
        case 'users/export':
            require_once __DIR__ . '/controllers/admin/UserManageController.php';
            $ctrl = new UserManageController();
            if ($act === 'users/add')              $ctrl->add();
            elseif ($act === 'users/toggle')       $ctrl->toggleStatus();
            elseif ($act === 'users/change-role')  $ctrl->changeRole();
            elseif ($act === 'users/export')       $ctrl->exportCsv();
            else                                   $ctrl->index();
            break;

        // K. QUẢN TRỊ HỆ THỐNG & NHẬT KÝ (AUDIT LOGS)
        case 'system/logs':
        case 'system/maintenance':
        case 'system/backup':
            require_once __DIR__ . '/controllers/admin/SystemManageController.php';
            $ctrl = new SystemManageController();
            if ($act === 'system/maintenance') $ctrl->toggleMaintenance();
            elseif ($act === 'system/backup')  $ctrl->backupDatabase();
            else                               $ctrl->logs();
            break;

        // L. QUẢN LÝ PHÊ DUYỆT YÊU CẦU THAO TÁC (APPROVAL WORKFLOW)
        case 'approvals':
        case 'approvals/approve':
        case 'approvals/reject':
            require_once __DIR__ . '/controllers/admin/ApprovalController.php';
            $ctrl = new ApprovalController();
            if ($act === 'approvals/approve')     $ctrl->approve();
            elseif ($act === 'approvals/reject')  $ctrl->reject();
            else                                  $ctrl->index();
            break;

        // A. BẢNG ĐIỀU KHIỂN CHÍNH (DASHBOARD)
        case 'dashboard':
        default:
            require_once __DIR__ . '/controllers/admin/AdminController.php';
            (new AdminController())->index();
            break;
    }
}

// 3. Phân tích hành động quản trị
$act = trim($_GET['act'] ?? 'dashboard');

// 4. Chặn các thao tác ghi dữ liệu của nhân viên để gửi lên Admin duyệt
intercept_staff_action_for_approval($act);

// 5. Điều phối thực thi
dispatch_admin_action($act);
