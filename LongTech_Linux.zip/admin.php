<?php
/**
 * ========================================================
 * LONGTECH - CỔNG VÀO CHÍNH CỦA TRANG QUẢN TRỊ (admin.php)
 * ========================================================
 * - BẢO MẬT: Bắt buộc đăng nhập và kiểm tra quyền Server-Side
 * - Customer TUYỆT ĐỐI không được truy cập (Bị chặn 403 Forbidden)
 * - Routing điều phối toàn bộ Controllers Admin
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/models/Database.php';
require_once __DIR__ . '/includes/auth_middleware.php';

// 1. Kiểm tra kết nối CSDL
$db = Database::connect();

// 2. Kiểm tra quyền truy cập Quản trị viên (Chặn Customer)
require_admin();

// 3. Phân tích hành động quản trị
$act = trim($_GET['act'] ?? 'dashboard');

switch ($act) {

    // A. BẢNG ĐIỀU KHIỂN CHÍNH (DASHBOARD)
    case 'dashboard':
    default:
        require_once __DIR__ . '/controllers/admin/AdminController.php';
        (new AdminController())->index();
        break;

    // B. QUẢN LÝ SẢN PHẨM & KHO HÀNG
    case 'products':
    case 'products/add':
    case 'products/edit':
    case 'products/delete':
    case 'products/export':
        require_once __DIR__ . '/controllers/admin/ProductManageController.php';
        $ctrl = new ProductManageController();
        if ($act === 'products/add')     $ctrl->add();
        elseif ($act === 'products/edit')   $ctrl->edit();
        elseif ($act === 'products/delete') $ctrl->delete();
        elseif ($act === 'products/export') $ctrl->exportCsv();
        else                                 $ctrl->index();
        break;

    // C. QUẢN LÝ DANH MỤC
    case 'categories':
    case 'categories/add-edit':
    case 'categories/delete':
        require_once __DIR__ . '/controllers/admin/ProductManageController.php';
        $ctrl = new ProductManageController();
        if ($act === 'categories/add-edit') $ctrl->categoryAddEdit();
        elseif ($act === 'categories/delete')  $ctrl->categoryDelete();
        else                                    $ctrl->categories();
        break;

    // D. QUẢN LÝ BANNER & SLIDESHOW
    case 'banners':
    case 'banners/add-edit':
    case 'banners/delete':
        require_once __DIR__ . '/controllers/admin/BannerController.php';
        $ctrl = new BannerController();
        if ($act === 'banners/add-edit') $ctrl->addEdit();
        elseif ($act === 'banners/delete')  $ctrl->delete();
        else                                 $ctrl->index();
        break;

    // D2. QUẢN LÝ GIAO DIỆN & LIVE EDITOR
    case 'appearance/editor':
    case 'appearance/save-settings':
    case 'appearance/save-sections':
    case 'appearance/create-version':
    case 'appearance/restore-version':
        require_once __DIR__ . '/controllers/admin/LiveEditorController.php';
        $ctrl = new LiveEditorController();
        if ($act === 'appearance/save-settings')    $ctrl->saveSettings();
        elseif ($act === 'appearance/save-sections')   $ctrl->saveSections();
        elseif ($act === 'appearance/create-version')  $ctrl->createVersion();
        elseif ($act === 'appearance/restore-version') $ctrl->restoreVersion();
        else                                           $ctrl->index();
        break;

    // E. QUẢN LÝ ĐƠN HÀNG
    case 'orders':
    case 'orders/detail':
    case 'orders/update-status':
    case 'orders/export':
        require_once __DIR__ . '/controllers/admin/OrderManageController.php';
        $ctrl = new OrderManageController();
        if ($act === 'orders/detail')        $ctrl->detail();
        elseif ($act === 'orders/update-status') $ctrl->updateStatus();
        elseif ($act === 'orders/export')        $ctrl->exportCsv();
        else                                      $ctrl->index();
        break;

    // F. QUẢN LÝ MÃ GIẢM GIÁ (COUPONS)
    case 'coupons':
    case 'coupons/add-edit':
    case 'coupons/delete':
    case 'coupons/toggle':
        require_once __DIR__ . '/controllers/admin/CouponController.php';
        $ctrl = new CouponController();
        if ($act === 'coupons/add-edit') $ctrl->addEdit();
        elseif ($act === 'coupons/delete')  $ctrl->delete();
        elseif ($act === 'coupons/toggle')  $ctrl->toggle();
        else                                 $ctrl->index();
        break;

    // G. QUẢN LÝ BÀI VIẾT / TIN TỨC
    case 'posts':
    case 'posts/add-edit':
    case 'posts/delete':
        require_once __DIR__ . '/controllers/admin/PostController.php';
        $ctrl = new PostController();
        if ($act === 'posts/add-edit') $ctrl->addEdit();
        elseif ($act === 'posts/delete')  $ctrl->delete();
        else                               $ctrl->index();
        break;

    // H. QUẢN LÝ ĐÁNH GIÁ SẢN PHẨM
    case 'reviews':
    case 'reviews/approve':
    case 'reviews/delete':
        require_once __DIR__ . '/controllers/admin/ReviewController.php';
        $ctrl = new ReviewController();
        if ($act === 'reviews/approve') $ctrl->approve();
        elseif ($act === 'reviews/delete')  $ctrl->delete();
        else                                 $ctrl->index();
        break;

    // I. QUẢN LÝ LIÊN HỆ / GÓP Ý
    case 'contacts':
    case 'contacts/mark-read':
    case 'contacts/delete':
    case 'contacts/export-csv':
        require_once __DIR__ . '/controllers/admin/ContactController.php';
        $ctrl = new ContactController();
        if ($act === 'contacts/mark-read')   $ctrl->markRead();
        elseif ($act === 'contacts/delete')     $ctrl->delete();
        elseif ($act === 'contacts/export-csv') $ctrl->exportCsv();
        else                                     $ctrl->index();
        break;

    // J. QUẢN LÝ THÀNH VIÊN & PHÂN QUYỀN
    case 'users':
    case 'users/toggle':
    case 'users/change-role':
    case 'users/export':
        require_once __DIR__ . '/controllers/admin/UserManageController.php';
        $ctrl = new UserManageController();
        if ($act === 'users/toggle')      $ctrl->toggleStatus();
        elseif ($act === 'users/change-role') $ctrl->changeRole();
        elseif ($act === 'users/export')      $ctrl->exportCsv();
        else                                   $ctrl->index();
        break;

    // K. QUẢN TRỊ HỆ THỐNG & NHẬT KÝ (AUDIT LOGS)
    case 'system/logs':
    case 'system/maintenance':
    case 'system/backup':
        require_once __DIR__ . '/controllers/admin/SystemManageController.php';
        $ctrl = new SystemManageController();
        if ($act === 'system/maintenance') $ctrl->toggleMaintenance();
        elseif ($act === 'system/backup')  $ctrl->backupDatabase();
        else                                $ctrl->logs();
        break;
}
