-- ========================================================
-- LONGTECH E-COMMERCE - CÆ  Sá» Dá»® LIá»†U CHUáº¨N
-- Báº£ng mĂ£: utf8mb4 / Collation: utf8mb4_unicode_ci
-- ========================================================




SET FOREIGN_KEY_CHECKS = 0;

-- 1. Báº£ng PhĂ¢n Quyá»n (roles)
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(50) NOT NULL UNIQUE,
  `display_name` VARCHAR(100) NOT NULL,
  `description` VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`) VALUES
(1, 'super_admin', 'Super Admin', 'ToĂ n quyá»n quáº£n trá»‹ cao nháº¥t há»‡ thá»‘ng'),
(2, 'admin', 'Admin Quáº£n trá»‹', 'Quáº£n lĂ½ sáº£n pháº©m, Ä‘Æ¡n hĂ ng, ngÆ°á»i dĂ¹ng vĂ  ná»™i dung'),
(3, 'product_manager', 'NhĂ¢n viĂªn Sáº£n pháº©m', 'Quáº£n lĂ½ thĂªm, sá»­a, xem sáº£n pháº©m vĂ  kiá»ƒm kĂª tá»“n kho'),
(4, 'order_manager', 'NhĂ¢n viĂªn ÄÆ¡n hĂ ng', 'Xem Ä‘Æ¡n, xá»­ lĂ½ Ä‘Æ¡n vĂ  cáº­p nháº­t tráº¡ng thĂ¡i giao nháº­n'),
(5, 'customer', 'KhĂ¡ch hĂ ng', 'Mua hĂ ng, quáº£n lĂ½ Ä‘Æ¡n cĂ¡ nhĂ¢n, viáº¿t Ä‘Ă¡nh giĂ¡ sáº£n pháº©m');

-- 2. Báº£ng NgÆ°á»i DĂ¹ng (users)
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `role_id` INT NOT NULL DEFAULT 5,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NULL,
  `address` VARCHAR(255) NULL,
  `avatar` VARCHAR(255) NULL,
  `status` ENUM('active', 'locked') DEFAULT 'active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Máº­t kháº©u máº·c Ä‘á»‹nh:
-- admin / admin@longtech.vn -> admin123 (bcrypt: $2y$10$w6M6E0v5xK9oQ2Z.T4F4fO8GZ2YkR5iXl8sH3pG7vW1u6sX4Q6a7i hoáº·c plain check)
-- customer / customer@gmail.com -> 123456
INSERT INTO `users` (`id`, `role_id`, `username`, `email`, `password`, `full_name`, `phone`, `address`, `status`) VALUES
(1, 1, 'admin', 'admin@longtech.vn', '$2y$10$fV3.vO2B0mQzHhK2HnJg3OGGv4qWj6hG2p5n5v1s8l.yL6W2p6g4W', 'Quáº£n Trá»‹ ViĂªn Cáº¥p Cao', '0988889999', 'HĂ  Ná»™i, Viá»‡t Nam', 'active'),
(2, 5, 'customer', 'customer@gmail.com', '$2y$10$fV3.vO2B0mQzHhK2HnJg3OGGv4qWj6hG2p5n5v1s8l.yL6W2p6g4W', 'Nguyá»…n VÄƒn Long', '0912345678', 'Sá»‘ 45 Cáº§u Giáº¥y, HĂ  Ná»™i', 'active');

-- 3. Báº£ng Danh Má»¥c Sáº£n Pháº©m (categories)
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `icon` VARCHAR(50) NULL,
  `image` VARCHAR(255) NULL,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `sort_order` INT DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`id`, `name`, `slug`, `icon`, `sort_order`) VALUES
(1, 'Äiá»‡n thoáº¡i', 'dien-thoai', 'fa-mobile-screen-button', 1),
(2, 'MĂ¡y tĂ­nh báº£ng', 'may-tinh-bang', 'fa-tablet-screen-button', 2),
(3, 'Laptop', 'laptop', 'fa-laptop', 3),
(4, 'Phá»¥ kiá»‡n', 'phu-kien', 'fa-headphones', 4);

-- 4. Báº£ng ThÆ°Æ¡ng Hiá»‡u (brands)
DROP TABLE IF EXISTS `brands`;
CREATE TABLE `brands` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `logo` VARCHAR(255) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `brands` (`id`, `name`, `slug`) VALUES
(1, 'Apple', 'apple'),
(2, 'Samsung', 'samsung'),
(3, 'Xiaomi', 'xiaomi'),
(4, 'OPPO', 'oppo'),
(5, 'Vivo', 'vivo'),
(6, 'ASUS', 'asus'),
(7, 'Lenovo', 'lenovo'),
(8, 'Dell', 'dell'),
(9, 'HP', 'hp'),
(10, 'Acer', 'acer'),
(11, 'Anker', 'anker'),
(12, 'Logitech', 'logitech');

-- 5. Báº£ng Sáº£n Pháº©m (products)
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT NOT NULL,
  `brand_id` INT NOT NULL,
  `product_code` VARCHAR(50) NOT NULL UNIQUE,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `price` DECIMAL(15,2) NOT NULL,
  `sale_price` DECIMAL(15,2) NULL,
  `stock_quantity` INT NOT NULL DEFAULT 0,
  `thumbnail` VARCHAR(255) NOT NULL,
  `short_description` TEXT NULL,
  `description` LONGTEXT NULL,
  `colors` VARCHAR(255) NULL,
  `storage_options` VARCHAR(255) NULL,
  `ram_options` VARCHAR(255) NULL,
  `screen` VARCHAR(100) NULL,
  `camera` VARCHAR(100) NULL,
  `battery` VARCHAR(100) NULL,
  `warranty_months` INT DEFAULT 12,
  `rating` DECIMAL(3,1) DEFAULT 5.0,
  `view_count` INT DEFAULT 0,
  `is_featured` TINYINT(1) DEFAULT 0,
  `is_hot_deal` TINYINT(1) DEFAULT 0,
  `is_new` TINYINT(1) DEFAULT 1,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`brand_id`) REFERENCES `brands`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12 Sáº£n pháº©m máº«u Ä‘á»‰nh cao cĂ´ng nghá»‡ theo cĂ¡c danh má»¥c
INSERT INTO `products` (`id`, `category_id`, `brand_id`, `product_code`, `name`, `slug`, `price`, `sale_price`, `stock_quantity`, `thumbnail`, `short_description`, `description`, `colors`, `storage_options`, `ram_options`, `screen`, `camera`, `battery`, `warranty_months`, `rating`, `is_featured`, `is_hot_deal`, `is_new`) VALUES
(1, 1, 1, 'IP15PM-256', 'iPhone 15 Pro Max 256GB', 'iphone-15-pro-max-256gb', 34990000, 29890000, 25, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvaS9wL2lwaG9uZS0xNS1wcm8tbWF4XzMtMy5wbmc.webp', 'SiĂªu pháº©m khung viá»n Titan, chip A17 Pro Ä‘á»‰nh cao vĂ  camera tiá»m vá»ng 5x.', '<p>iPhone 15 Pro Max lĂ  Ä‘á»‰nh cao thiáº¿t káº¿ cĂ´ng nghá»‡ vá»›i khung vá» Titan cao cáº¥p siĂªu nháº¹, cá»¥m camera tiĂªn tiáº¿n há»— trá»£ quay chuáº©n Apple ProRes, mĂ n hĂ¬nh Super Retina XDR ProMotion 120Hz mÆ°á»£t mĂ .</p>', 'Titan Tá»± NhiĂªn, Titan Xanh, Titan Äen, Titan Tráº¯ng', '256GB, 512GB, 1TB', '8GB', '6.7 inch Super Retina XDR OLED', 'ChĂ­nh 48MP & Phá»¥ 12MP, 12MP', '4.422 mAh, Sáº¡c nhanh 20W', 12, 5.0, 1, 1, 1),

(2, 1, 2, 'SS-S24U-256', 'Samsung Galaxy S24 Ultra 5G 256GB', 'samsung-galaxy-s24-ultra-5g-256gb', 33990000, 28490000, 18, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3Qvcy8yL3MyNF91bHRyYV92YW5nXzEucG5n.webp', 'Khung viá»n Titanium, trang bá»‹ quyá»n nÄƒng Galaxy AI vÆ°á»£t trá»™i cĂ¹ng bĂºt S-Pen Ä‘a nÄƒng.', '<p>Galaxy S24 Ultra trang bá»‹ vi xá»­ lĂ½ Snapdragon 8 Gen 3 for Galaxy, há»‡ sinh thĂ¡i trĂ­ tuá»‡ nhĂ¢n táº¡o Galaxy AI Ä‘á»™t phĂ¡, camera Ä‘á»™ phĂ¢n giáº£i khá»§ng 200MP zoom quang 100x.</p>', 'XĂ¡m Titan, Äen Titan, TĂ­m Titan, VĂ ng Titan', '256GB, 512GB, 1TB', '12GB', '6.8 inch Dynamic AMOLED 2X 120Hz', '200MP + 50MP + 12MP + 10MP', '5.000 mAh, Sáº¡c nhanh 45W', 12, 4.9, 1, 1, 1),

(3, 1, 3, 'XM-14-256', 'Xiaomi 14 5G 256GB', 'xiaomi-14-5g-256gb', 22990000, 18990000, 12, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QveC9pL3hpYW9taS0xNC10cmFpc3VuZ18xXzEucG5n.webp', 'Há»‡ thá»‘ng á»‘ng kĂ­nh quang há»c Leica danh tiáº¿ng káº¿t há»£p chip Snapdragon 8 Gen 3.', '<p>Xiaomi 14 lĂ  sá»± káº¿t há»£p hoĂ n háº£o giá»¯a kĂ­ch thÆ°á»›c nhá» gá»n cáº§m náº¯m tuyá»‡t vá»i vĂ  cáº¥u hĂ¬nh pháº§n cá»©ng tá»‘i thÆ°á»£ng cĂ¹ng cáº£m biáº¿n Light Fusion 900.</p>', 'Äen, Xanh Ngá»c, Tráº¯ng', '256GB, 512GB', '12GB', '6.36 inch AMOLED 1.5K 120Hz', 'Leica 50MP + 50MP + 50MP', '4.610 mAh, Sáº¡c HyperCharge 90W', 18, 4.8, 1, 0, 1),

(4, 1, 4, 'OP-R11-256', 'OPPO Reno11 5G 256GB', 'oppo-reno11-5g-256gb', 10990000, 8990000, 30, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3Qvby9wL29wcG8tcmVuby0xMS14YW5oLTFfMi5wbmc.webp', 'ChuyĂªn gia chĂ¢n dung chá»¥p nĂ©t tá»«ng khoáº£nh kháº¯c vá»›i cĂ´ng nghá»‡ sáº¡c SUPERVOOC 67W.', '<p>Thiáº¿t káº¿ máº·t lÆ°ng há»a tiáº¿t sĂ³ng biá»ƒn Ä‘á»™c Ä‘Ă¡o, camera tele chĂ¢n dung 32MP chuyĂªn nghiá»‡p, mĂ n hĂ¬nh cong 3D sang trá»ng.</p>', 'Xanh SĂ³ng Biá»ƒn, XĂ¡m Hoa CÆ°Æ¡ng', '256GB', '8GB', '6.7 inch AMOLED 120Hz', '50MP + 32MP + 8MP', '5.000 mAh, Sáº¡c SUPERVOOC 67W', 12, 4.7, 0, 1, 0),

(5, 2, 1, 'IPAD-PRO-M2', 'iPad Pro 11 inch M2 WiFi 128GB', 'ipad-pro-11-inch-m2-wifi-128gb', 23990000, 20490000, 15, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvaS9wL2lwYWQtcHJvLTEzLXNhbmctY2VsZi5wbmc.webp', 'Sá»©c máº¡nh Ä‘á»™t phĂ¡ tá»« vi xá»­ lĂ½ Apple Silicon M2, tÆ°Æ¡ng thĂ­ch Apple Pencil Hover.', '<p>MĂ¡y tĂ­nh báº£ng chuyĂªn nghiá»‡p Ä‘á»‰nh cao cho Ä‘á»“ há»a, sĂ¡ng táº¡o ná»™i dung vĂ  giáº£i trĂ­ vá»›i mĂ n hĂ¬nh Liquid Retina sáº¯c nĂ©t cĂ¹ng Face ID báº£o máº­t.</p>', 'XĂ¡m KhĂ´ng Gian, Báº¡c', '128GB, 256GB, 512GB', '8GB', '11 inch Liquid Retina 120Hz', '12MP Rá»™ng + 10MP SiĂªu rá»™ng, LiDAR', '7.538 mAh, Sáº¡c nhanh 20W', 12, 5.0, 1, 0, 1),

(6, 2, 2, 'SS-TAB-S9', 'Samsung Galaxy Tab S9 WiFi 128GB', 'samsung-galaxy-tab-s9-wifi-128gb', 19990000, 15990000, 10, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3Qvcy9hL3NhbXN1bmctZ2FsYXh5LXRhYi1zOS0xXzEucG5n.webp', 'MĂ n hĂ¬nh Dynamic AMOLED 2X sá»‘ng Ä‘á»™ng, khĂ¡ng nÆ°á»›c IP68, táº·ng kĂ¨m bĂºt S-Pen.', '<p>Tablet cao cáº¥p chá»‘ng nÆ°á»›c chuáº©n IP68 Ä‘áº§u tiĂªn trĂªn dĂ²ng Tab S, Ă¢m thanh 4 loa AKG chuáº©n Dolby Atmos mang láº¡i ráº¡p phim táº¡i nhĂ .</p>', 'XĂ¡m Graphite, Kem', '128GB, 256GB', '8GB, 12GB', '11 inch Dynamic AMOLED 2X 120Hz', '13MP Sau, 12MP TrÆ°á»›c', '8.400 mAh, Sáº¡c nhanh 45W', 12, 4.8, 1, 1, 0),

(7, 3, 6, 'ASUS-ROG-G16', 'Laptop ASUS ROG Strix G16 G614JVR', 'laptop-asus-rog-strix-g16-g614jvr', 48990000, 42990000, 8, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvdGV4dF9kYW5na18yMF9fMi5wbmc.webp', 'Cá»— mĂ¡y chiáº¿n game tá»‘i thÆ°á»£ng i9-14900HX, RTX 4080 vĂ  mĂ n hĂ¬nh chuáº©n 240Hz Nebula.', '<p>DĂ nh riĂªng cho game thá»§ vĂ  streamer chuyĂªn nghiá»‡p vá»›i há»‡ thá»‘ng táº£n nhiá»‡t 3 quáº¡t lĂ m mĂ¡t kim loáº¡i lá»ng Conductonaut Extreme.</p>', 'XĂ¡m Eclipse', '1TB NVMe PCIe 4.0 SSD', '32GB DDR5 5600MHz', '16 inch QHD+ 240Hz 100% DCI-P3', '720p HD Webcam', '90Whr, Bá»™ sáº¡c 330W', 24, 5.0, 1, 1, 1),

(8, 3, 8, 'DELL-XPS-13', 'Laptop Dell XPS 13 9340 Core Ultra 7', 'laptop-dell-xps-13-9340-core-ultra-7', 45990000, 41990000, 6, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvdGV4dF9kYW5na18yNF9fMS5wbmc.webp', 'Tuyá»‡t tĂ¡c siĂªu má»ng nháº¹, bĂ n phĂ­m vĂ´ cá»±c cáº£m á»©ng liá»n máº¡ch vĂ  mĂ n hĂ¬nh OLED 3K.', '<p>Thiáº¿t káº¿ tá»« nhĂ´m CNC nguyĂªn khá»‘i vĂ  kĂ­nh cÆ°á»ng lá»±c Gorilla Glass 3, thá»i lÆ°á»£ng pin cáº£ ngĂ y dĂ i vĂ  há»— trá»£ xá»­ lĂ½ AI NPU tháº¿ há»‡ má»›i.</p>', 'Báº¡c Platinum, Than ChĂ¬ Graphite', '512GB, 1TB SSD', '16GB, 32GB LPDDR5x', '13.4 inch OLED 3K Touch 120Hz', '1080p FHD IR Camera', '55Whr, Sáº¡c Type-C 60W', 24, 4.9, 1, 0, 1),

(9, 3, 7, 'LEN-LEG-SLIM', 'Laptop Lenovo Legion Slim 5 16IRH8', 'laptop-lenovo-legion-slim-5-16irh8', 32990000, 27990000, 11, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvbC9lL2xlbm92by1sZWdpb24tc2xpbS01LTE2aXJoOC04Mnk3MDA3NHZuLWNlbGxwaG9uZXMtY2hhbi10cmFuZy0wMDEucG5n.webp', 'Laptop Gaming má»ng nháº¹ chip Core i7-13700H, card Ä‘á»“ há»a RTX 4060 8GB máº¡nh máº½.', '<p>CĂ¢n báº±ng tuyá»‡t Ä‘á»‘i giá»¯a hiá»‡u nÄƒng cĂ y game Ä‘á»“ há»a náº·ng vĂ  tĂ­nh cÆ¡ Ä‘á»™ng vÄƒn phĂ²ng vá»›i thiáº¿t káº¿ sang trá»ng khĂ´ng quĂ¡ háº§m há»‘.</p>', 'XĂ¡m BĂ£o Storm Grey', '512GB NVMe SSD', '16GB DDR5', '16 inch WQXGA (2560x1600) 165Hz', '1080p FHD Webcam', '80Whr, Sáº¡c nhanh 230W', 24, 4.8, 0, 1, 0),

(10, 4, 1, 'APP-AIRPODS-P2', 'Tai nghe Apple AirPods Pro 2 Type-C', 'tai-nghe-apple-airpods-pro-2-type-c', 6190000, 5390000, 50, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvYS9wL2FwcGxlLWFpcnBvZHMtcHJvLTItdXNiLWMtMS5wbmc.webp', 'Chá»‘ng á»“n chá»§ Ä‘á»™ng ANC gáº¥p 2 láº§n, tĂ­ch há»£p cá»•ng sáº¡c Type-C vĂ  Ă¢m thanh thĂ­ch á»©ng.', '<p>Chip H2 thĂ´ng minh tĂ¡i táº¡o Ă¢m trÆ°á»ng chi tiáº¿t, há»™p sáº¡c há»— trá»£ tĂ¬m kiáº¿m Precision Finding chuáº©n khĂ¡ng bá»¥i nÆ°á»›c IP54.</p>', 'Tráº¯ng', 'KhĂ´ng Ă¡p dá»¥ng', 'KhĂ´ng Ă¡p dá»¥ng', 'KhĂ´ng Ă¡p dá»¥ng', 'KhĂ´ng Ă¡p dá»¥ng', 'Pin 6 giá» nghe liĂªn tá»¥c (30 giá» kĂ¨m há»™p)', 12, 5.0, 1, 1, 1),

(11, 4, 11, 'ANKER-735-65W', 'Cá»§ sáº¡c nhanh Anker GaNPrime 65W 3 cá»•ng', 'cu-sac-nhanh-anker-ganprime-65w-3-cong', 1390000, 990000, 80, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvYy91L2N1LXNhYy1hbmtlci03MzUtZ2FucHJpbWUtNjV3LWEyNjY4XzFfMS5wbmc.webp', 'CĂ´ng nghá»‡ sáº¡c bĂ¡n dáº«n GaNPrime Ä‘a cá»•ng sáº¡c Ä‘á»“ng thá»i Laptop, iPad vĂ  Smartphone.', '<p>KĂ­ch thÆ°á»›c siĂªu nhá» gá»n nháº¹ hÆ¡n 53% so vá»›i cá»§ sáº¡c tiĂªu chuáº©n, tĂ­ch há»£p kiá»ƒm soĂ¡t nhiá»‡t Ä‘á»™ an toĂ n ActiveShield 2.0.</p>', 'Äen, Báº¡c', 'KhĂ´ng Ă¡p dá»¥ng', 'KhĂ´ng Ă¡p dá»¥ng', 'KhĂ´ng Ă¡p dá»¥ng', 'KhĂ´ng Ă¡p dá»¥ng', 'CĂ´ng suáº¥t tá»‘i Ä‘a 65W, 2x USB-C + 1x USB-A', 18, 4.9, 0, 1, 1),

(12, 4, 12, 'LOGI-MX-MASTER-3S', 'Chuá»™t khĂ´ng dĂ¢y Logitech MX Master 3S', 'chuot-khong-day-logitech-mx-master-3s', 2490000, 2090000, 40, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvYy9oL2NodW90LWtob25nLWRheS1sb2dpdGVjaC1teC1tYXN0ZXItM3MteGFtLmpwZw.webp', 'Biá»ƒu tÆ°á»£ng cĂ´ng thĂ¡i há»c cho láº­p trĂ¬nh viĂªn vĂ  designer, cuá»™n MagSpeed Ăªm Ă¡i.', '<p>Cáº£m biáº¿n 8.000 DPI lÆ°á»›t mÆ°á»£t trĂªn má»i bá» máº·t kĂ­nh, click yĂªn tÄ©nh Quiet Clicks giáº£m 90% tiáº¿ng á»“n, káº¿t ná»‘i 3 thiáº¿t bá»‹ cĂ¹ng lĂºc.</p>', 'Äen Graphite, XĂ¡m Nháº¡t Pale Grey', 'KhĂ´ng Ă¡p dá»¥ng', 'KhĂ´ng Ă¡p dá»¥ng', 'KhĂ´ng Ă¡p dá»¥ng', 'KhĂ´ng Ă¡p dá»¥ng', 'Pin sáº¡c USB-C dĂ¹ng tá»›i 70 ngĂ y', 12, 5.0, 1, 0, 1);

-- 6. Báº£ng HĂ¬nh áº¢nh Phá»¥ Cá»§a Sáº£n Pháº©m (product_images)
DROP TABLE IF EXISTS `product_images`;
CREATE TABLE `product_images` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `image_url` VARCHAR(255) NOT NULL,
  `sort_order` INT DEFAULT 0,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Báº£ng ÄÆ¡n HĂ ng (orders)
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_code` VARCHAR(30) NOT NULL UNIQUE,
  `user_id` INT NULL,
  `customer_name` VARCHAR(100) NOT NULL,
  `customer_email` VARCHAR(100) NOT NULL,
  `customer_phone` VARCHAR(20) NOT NULL,
  `customer_address` VARCHAR(255) NOT NULL,
  `city` VARCHAR(100) NOT NULL,
  `district` VARCHAR(100) NOT NULL,
  `ward` VARCHAR(100) NOT NULL,
  `note` TEXT NULL,
  `payment_method` ENUM('cod', 'bank_transfer') DEFAULT 'cod',
  `payment_status` ENUM('unpaid', 'paid') DEFAULT 'unpaid',
  `shipping_fee` DECIMAL(15,2) DEFAULT 30000,
  `discount_amount` DECIMAL(15,2) DEFAULT 0,
  `subtotal` DECIMAL(15,2) NOT NULL,
  `total_amount` DECIMAL(15,2) NOT NULL,
  `status` ENUM('pending', 'confirmed', 'processing', 'shipping', 'completed', 'cancelled', 'refunded') DEFAULT 'pending',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dá»¯ liá»‡u máº«u Ä‘Æ¡n hĂ ng
INSERT INTO `orders` (`id`, `order_code`, `user_id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `city`, `district`, `ward`, `payment_method`, `payment_status`, `shipping_fee`, `discount_amount`, `subtotal`, `total_amount`, `status`) VALUES
(1, 'LT-20261103-01', 2, 'Nguyá»…n VÄƒn Long', 'customer@gmail.com', '0912345678', 'Sá»‘ 45 Cáº§u Giáº¥y', 'HĂ  Ná»™i', 'Quáº­n Cáº§u Giáº¥y', 'PhÆ°á»ng Dá»‹ch Vá»ng', 'cod', 'unpaid', 0, 0, 29890000, 29890000, 'processing');

-- 8. Báº£ng Chi Tiáº¿t ÄÆ¡n HĂ ng (order_items)
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `product_price` DECIMAL(15,2) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `color` VARCHAR(50) NULL,
  `storage` VARCHAR(50) NULL,
  `total_price` DECIMAL(15,2) NOT NULL,
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_name`, `product_price`, `quantity`, `color`, `storage`, `total_price`) VALUES
(1, 1, 1, 'iPhone 15 Pro Max 256GB', 29890000, 1, 'Titan Tá»± NhiĂªn', '256GB', 29890000);

-- 9. Báº£ng ÄĂ¡nh GiĂ¡ Sáº£n Pháº©m (reviews)
DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `rating` TINYINT NOT NULL CHECK (`rating` BETWEEN 1 AND 5),
  `comment` TEXT NOT NULL,
  `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'approved',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `reviews` (`id`, `product_id`, `user_id`, `rating`, `comment`, `status`) VALUES
(1, 1, 2, 5, 'MĂ¡y Ä‘áº¹p, nháº¹ hÆ¡n báº£n 14 ráº¥t nhiá»u, viá»n titan sang trá»ng, camera chá»¥p Ä‘Ăªm xuáº¥t sáº¯c!', 'approved');

-- 10. Báº£ng Danh SĂ¡ch YĂªu ThĂ­ch (wishlists)
DROP TABLE IF EXISTS `wishlists`;
CREATE TABLE `wishlists` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_user_product` (`user_id`, `product_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Báº£ng MĂ£ Giáº£m GiĂ¡ (coupons)
DROP TABLE IF EXISTS `coupons`;
CREATE TABLE `coupons` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `type` ENUM('percentage', 'fixed_amount') DEFAULT 'percentage',
  `value` DECIMAL(15,2) NOT NULL,
  `min_order_value` DECIMAL(15,2) DEFAULT 0,
  `max_discount` DECIMAL(15,2) NULL,
  `usage_limit` INT DEFAULT 100,
  `used_count` INT DEFAULT 0,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `status` ENUM('active', 'inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `coupons` (`id`, `code`, `type`, `value`, `min_order_value`, `max_discount`, `usage_limit`, `used_count`, `start_date`, `end_date`, `status`) VALUES
(1, 'LONGTECH50K', 'fixed_amount', 50000, 500000, 50000, 500, 12, '2026-01-01', '2026-12-31', 'active'),
(2, 'VIP10', 'percentage', 10, 2000000, 1000000, 200, 5, '2026-01-01', '2026-12-31', 'active');

-- 12. Báº£ng Banner Quáº£ng CĂ¡o (banners)
DROP TABLE IF EXISTS `banners`;
CREATE TABLE `banners` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `subtitle` VARCHAR(255) NULL,
  `image_url` VARCHAR(255) NOT NULL,
  `link` VARCHAR(255) DEFAULT '#',
  `position` ENUM('home_slider', 'home_sidebar', 'sale_popup') DEFAULT 'home_slider',
  `sort_order` INT DEFAULT 0,
  `status` ENUM('active', 'inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `banners` (`id`, `title`, `subtitle`, `image_url`, `link`, `position`, `sort_order`, `status`) VALUES
(1, 'iPhone 15 Pro Max - Titan Tá»± NhiĂªn', 'Äá»‰nh cao cĂ´ng nghá»‡ Ä‘á»‰nh phong bá»©t phĂ¡ má»i giá»›i háº¡n', 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?q=80&w=1200&auto=format&fit=crop', 'dien-thoai/iphone-15-pro-max-256gb', 'home_slider', 1, 'active'),
(2, 'Samsung Galaxy S24 Ultra - Quyá»n NÄƒng AI', 'Má»Ÿ ra ká»· nguyĂªn Ä‘iá»‡n thoáº¡i thĂ´ng minh tháº¿ há»‡ má»›i', 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?q=80&w=1200&auto=format&fit=crop', 'dien-thoai/samsung-galaxy-s24-ultra-5g-256gb', 'home_slider', 2, 'active');

-- 13. Báº£ng Tin Tá»©c CĂ´ng Nghá»‡ (posts)
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `summary` TEXT NOT NULL,
  `content` LONGTEXT NOT NULL,
  `thumbnail` VARCHAR(255) NOT NULL,
  `author_id` INT NULL,
  `status` ENUM('published', 'draft') DEFAULT 'published',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`author_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `posts` (`id`, `title`, `slug`, `summary`, `content`, `thumbnail`, `author_id`) VALUES
(1, 'ÄĂ¡nh giĂ¡ chi tiáº¿t Galaxy S24 Ultra sau 1 thĂ¡ng sá»­ dá»¥ng: Galaxy AI Ä‘á»‰nh Ä‘áº¿n Ä‘Ă¢u?', 'danh-gia-chi-tiet-galaxy-s24-ultra-sau-1-thang', 'Tráº£i nghiá»‡m thá»±c táº¿ cĂ¡c tĂ­nh nÄƒng dá»‹ch trá»±c tiáº¿p cuá»™c gá»i, khoanh trĂ²n Ä‘á»ƒ tĂ¬m kiáº¿m vĂ  camera 200MP.', '<p>Galaxy S24 Ultra thá»ƒ hiá»‡n sá»± toĂ n diá»‡n tá»« mĂ n hĂ¬nh pháº³ng chá»‘ng chĂ³i tá»‘t nháº¥t phĂ¢n khĂºc Ä‘áº¿n hiá»‡u nÄƒng Snapdragon 8 Gen 3 for Galaxy máº¡nh máº½.</p>', 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=600&auto=format&fit=crop', 1),
(2, 'Top 5 máº«u laptop má»ng nháº¹ cho láº­p trĂ¬nh viĂªn vĂ  sinh viĂªn ká»¹ thuáº­t 2026', 'top-5-mau-laptop-mong-nhe-cho-lap-trinh-vien', 'Tá»•ng há»£p nhá»¯ng cá»— mĂ¡y cĂ¢n báº±ng thá»i lÆ°á»£ng pin, mĂ n hĂ¬nh chuáº©n mĂ u sáº¯c vĂ  hiá»‡u nÄƒng CPU nhiá»u nhĂ¢n.', '<p>Lá»±a chá»n laptop phĂ¹ há»£p giĂºp tÄƒng hiá»‡u suáº¥t lĂ m viá»‡c vÆ°á»£t trá»™i vá»›i cĂ¡c Ä‘áº¡i diá»‡n tiĂªu biá»ƒu nhÆ° Dell XPS vĂ  Asus ROG.</p>', 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=600&auto=format&fit=crop', 1);

-- 14. Báº£ng LiĂªn Há»‡ & GĂ³p Ă (contacts)
DROP TABLE IF EXISTS `contacts`;
CREATE TABLE `contacts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `status` ENUM('unread', 'read', 'replied') DEFAULT 'unread',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;


