-- ========================================================
-- LONGTECH E-COMMERCE - CƠ SỞ DỮ LIỆU CHUẨN
-- Bảng mã: utf8mb4 / Collation: utf8mb4_unicode_ci
-- ========================================================

CREATE DATABASE IF NOT EXISTS `longtech` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `longtech`;

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Bảng Phân Quyền (roles)
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(50) NOT NULL UNIQUE,
  `display_name` VARCHAR(100) NOT NULL,
  `description` VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`) VALUES
(1, 'super_admin', 'Super Admin', 'Toàn quyền quản trị cao nhất hệ thống'),
(2, 'admin', 'Admin Quản trị', 'Quản lý sản phẩm, đơn hàng, người dùng và nội dung'),
(3, 'product_manager', 'Nhân viên Sản phẩm', 'Quản lý thêm, sửa, xem sản phẩm và kiểm kê tồn kho'),
(4, 'order_manager', 'Nhân viên Đơn hàng', 'Xem đơn, xử lý đơn và cập nhật trạng thái giao nhận'),
(5, 'customer', 'Khách hàng', 'Mua hàng, quản lý đơn cá nhân, viết đánh giá sản phẩm');

-- 2. Bảng Người Dùng (users)
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `role_id` INT NOT NULL DEFAULT 5,
  `permissions` TEXT NULL,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NULL,
  `address` VARCHAR(255) NULL,
  `avatar` VARCHAR(255) NULL,
  `status` ENUM('active', 'locked') DEFAULT 'active',
  `require_password_change` TINYINT(1) DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Mật khẩu mặc định:
-- admin / admin@longtech.vn -> admin123
-- customer / customer@gmail.com -> 123456
INSERT INTO `users` (`id`, `role_id`, `username`, `email`, `password`, `full_name`, `phone`, `address`, `status`) VALUES
(1, 1, 'admin', 'admin@longtech.vn', '$2y$10$AT7nJITcX4xpC8jxN7n63.uZZUup4AaOOqcGIavlYXkP4xsxdpVVO', 'Quản Trị Viên Cấp Cao', '0988889999', 'Hà Nội, Việt Nam', 'active'),
(2, 5, 'customer', 'customer@gmail.com', '$2y$10$r9hiEgXjLAeJdo86cEQkpeLeTxVIpqVfcT5Y3mPJeiNJq65I/l.9O', 'Nguyễn Văn Long', '0912345678', 'Số 45 Cầu Giấy, Hà Nội', 'active');

-- 3. Bảng Danh Mục Sản Phẩm (categories)
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `icon` VARCHAR(50) NULL,
  `image` VARCHAR(255) NULL,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `sort_order` INT DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`id`, `name`, `slug`, `icon`, `sort_order`) VALUES
(1, 'Điện thoại', 'dien-thoai', 'fa-mobile-screen-button', 1),
(2, 'Máy tính bảng', 'may-tinh-bang', 'fa-tablet-screen-button', 2),
(3, 'Laptop', 'laptop', 'fa-laptop', 3),
(4, 'Phụ kiện', 'phu-kien', 'fa-headphones', 4),
(5, 'Đồng hồ thông minh', 'dong-ho-thong-minh', 'fa-clock', 5),
(6, 'Âm thanh & Loa', 'am-thanh', 'fa-volume-high', 6),
(7, 'Gaming & Console', 'gaming-gear', 'fa-gamepad', 7),
(8, 'Màn hình & PC', 'man-hinh-pc', 'fa-desktop', 8);

-- 4. Bảng Thương Hiệu (brands)
DROP TABLE IF EXISTS `brands`;
CREATE TABLE `brands` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `logo` VARCHAR(255) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `brands` (`id`, `name`, `slug`) VALUES
(1, 'Apple', 'apple'),
(2, 'Samsung', 'samsung'),
(3, 'Xiaomi', 'xiaomi'),
(4, 'OPPO', 'oppo'),
(5, 'Vivo', 'vivo'),
(6, 'ASUS', 'asus'),
(7, 'Lenovo', 'lenovo'),
(8, 'Dell', 'dell'),
(9, 'HP', 'hp'),
(10, 'Acer', 'acer'),
(11, 'Anker', 'anker'),
(12, 'Logitech', 'logitech'),
(13, 'Sony', 'sony'),
(14, 'Marshall', 'marshall'),
(15, 'Garmin', 'garmin'),
(16, 'LG', 'lg');

-- 5. Bảng Sản Phẩm (products)
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT NOT NULL,
  `brand_id` INT NOT NULL,
  `product_code` VARCHAR(50) NOT NULL UNIQUE,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `price` DECIMAL(15,2) NOT NULL,
  `sale_price` DECIMAL(15,2) NULL,
  `stock_quantity` INT NOT NULL DEFAULT 0,
  `thumbnail` VARCHAR(255) NOT NULL,
  `short_description` TEXT NULL,
  `description` LONGTEXT NULL,
  `colors` VARCHAR(255) NULL,
  `storage_options` VARCHAR(255) NULL,
  `ram_options` VARCHAR(255) NULL,
  `screen` VARCHAR(100) NULL,
  `camera` VARCHAR(100) NULL,
  `battery` VARCHAR(100) NULL,
  `warranty_months` INT DEFAULT 12,
  `rating` DECIMAL(3,1) DEFAULT 5.0,
  `view_count` INT DEFAULT 0,
  `is_featured` TINYINT(1) DEFAULT 0,
  `is_hot_deal` TINYINT(1) DEFAULT 0,
  `is_new` TINYINT(1) DEFAULT 1,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`brand_id`) REFERENCES `brands`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12 Sản phẩm mẫu đỉnh cao công nghệ theo các danh mục
INSERT INTO `products` (`id`, `category_id`, `brand_id`, `product_code`, `name`, `slug`, `price`, `sale_price`, `stock_quantity`, `thumbnail`, `short_description`, `description`, `colors`, `storage_options`, `ram_options`, `screen`, `camera`, `battery`, `warranty_months`, `rating`, `is_featured`, `is_hot_deal`, `is_new`) VALUES
(1, 1, 1, 'IP15PM-256', 'iPhone 15 Pro Max 256GB', 'iphone-15-pro-max-256gb', 34990000, 29890000, 25, 'assets/uploads/products/1793809755_2716485aa03a.png', 'Siêu phẩm khung viền Titan, chip A17 Pro đỉnh cao và camera tiềm vọng 5x.', '<p>iPhone 15 Pro Max là đỉnh cao thiết kế công nghệ với khung vỏ Titan cao cấp siêu nhẹ, cụm camera tiên tiến hỗ trợ quay chuẩn Apple ProRes, màn hình Super Retina XDR ProMotion 120Hz mượt mà.</p>', 'Titan Tự Nhiên, Titan Xanh, Titan Đen, Titan Trắng', '256GB, 512GB, 1TB', '8GB', '6.7 inch Super Retina XDR OLED', 'Chính 48MP & Phụ 12MP, 12MP', '4.422 mAh, Sạc nhanh 20W', 12, 5.0, 1, 1, 1),

(2, 1, 2, 'SS-S24U-256', 'Samsung Galaxy S24 Ultra 5G 256GB', 'samsung-galaxy-s24-ultra-5g-256gb', 33990000, 28490000, 18, 'assets/uploads/products/1793809745_c0e380be3c3f.png', 'Khung viền Titanium, trang bị quyền năng Galaxy AI vượt trội cùng bút S-Pen đa năng.', '<p>Galaxy S24 Ultra trang bị vi xử lý Snapdragon 8 Gen 3 for Galaxy, hệ sinh thái trí tuệ nhân tạo Galaxy AI đột phá, camera độ phân giải khủng 200MP zoom quang 100x.</p>', 'Xám Titan, Đen Titan, Tím Titan, Vàng Titan', '256GB, 512GB, 1TB', '12GB', '6.8 inch Dynamic AMOLED 2X 120Hz', '200MP + 50MP + 12MP + 10MP', '5.000 mAh, Sạc nhanh 45W', 12, 4.9, 1, 1, 1),

(3, 1, 3, 'XM-14-256', 'Xiaomi 14 5G 256GB', 'xiaomi-14-5g-256gb', 22990000, 18990000, 12, 'assets/uploads/products/1793809734_f929dc8b6176.png', 'Hệ thống ống kính quang học Leica danh tiếng kết hợp chip Snapdragon 8 Gen 3.', '<p>Xiaomi 14 là sự kết hợp hoàn hảo giữa kích thước nhỏ gọn cầm nắm tuyệt vời và cấu hình phần cứng tối thượng cùng cảm biến Light Fusion 900.</p>', 'Đen, Xanh Ngọc, Trắng', '256GB, 512GB', '12GB', '6.36 inch AMOLED 1.5K 120Hz', 'Leica 50MP + 50MP + 50MP', '4.610 mAh, Sạc HyperCharge 90W', 18, 4.8, 1, 0, 1),

(4, 1, 4, 'OP-R11-256', 'OPPO Reno11 5G 256GB', 'oppo-reno11-5g-256gb', 10990000, 8990000, 30, 'assets/uploads/products/1793809722_2ac73279ab32.png', 'Chuyên gia chân dung chụp nét từng khoảnh khắc với công nghệ sạc SUPERVOOC 67W.', '<p>Thiết kế mặt lưng họa tiết sóng biển độc đáo, camera tele chân dung 32MP chuyên nghiệp, màn hình cong 3D sang trọng.</p>', 'Xanh Sóng Biển, Xám Hoa Cương', '256GB', '8GB', '6.7 inch AMOLED 120Hz', '50MP + 32MP + 8MP', '5.000 mAh, Sạc SUPERVOOC 67W', 12, 4.7, 0, 1, 0),

(5, 2, 1, 'IPAD-PRO-M2', 'iPad Pro 11 inch M2 WiFi 128GB', 'ipad-pro-11-inch-m2-wifi-128gb', 23990000, 20490000, 15, 'assets/uploads/products/1793809710_f9e65b394bef.png', 'Sức mạnh đột phá từ vi xử lý Apple Silicon M2, tương thích Apple Pencil Hover.', '<p>Máy tính bảng chuyên nghiệp đỉnh cao cho đồ họa, sáng tạo nội dung và giải trí với màn hình Liquid Retina sắc nét cùng Face ID bảo mật.</p>', 'Xám Không Gian, Bạc', '128GB, 256GB, 512GB', '8GB', '11 inch Liquid Retina 120Hz', '12MP Rộng + 10MP Siêu rộng, LiDAR', '7.538 mAh, Sạc nhanh 20W', 12, 5.0, 1, 0, 1),

(6, 2, 2, 'SS-TAB-S9', 'Samsung Galaxy Tab S9 WiFi 128GB', 'samsung-galaxy-tab-s9-wifi-128gb', 19990000, 15990000, 10, 'assets/uploads/products/1793809699_f7488efc68e4.png', 'Màn hình Dynamic AMOLED 2X sống động, kháng nước IP68, tặng kèm bút S-Pen.', '<p>Tablet cao cấp chống nước chuẩn IP68 đầu tiên trên dòng Tab S, âm thanh 4 loa AKG chuẩn Dolby Atmos mang lại rạp phim tại nhà.</p>', 'Xám Graphite, Kem', '128GB, 256GB', '8GB, 12GB', '11 inch Dynamic AMOLED 2X 120Hz', '13MP Sau, 12MP Trước', '8.400 mAh, Sạc nhanh 45W', 12, 4.8, 1, 1, 0),

(7, 3, 6, 'ASUS-ROG-G16', 'Laptop ASUS ROG Strix G16 G614JVR', 'laptop-asus-rog-strix-g16-g614jvr', 48990000, 42990000, 8, 'assets/uploads/products/1793809689_d08e00dd79ba.png', 'Cỗ máy chiến game tối thượng i9-14900HX, RTX 4080 và màn hình chuẩn 240Hz Nebula.', '<p>Dành riêng cho game thủ và streamer chuyên nghiệp với hệ thống tản nhiệt 3 quạt làm mát kim loại lỏng Conductonaut Extreme.</p>', 'Xám Eclipse', '1TB NVMe PCIe 4.0 SSD', '32GB DDR5 5600MHz', '16 inch QHD+ 240Hz 100% DCI-P3', '720p HD Webcam', '90Whr, Bộ sạc 330W', 24, 5.0, 1, 1, 1),

(8, 3, 8, 'DELL-XPS-13', 'Laptop Dell XPS 13 9340 Core Ultra 7', 'laptop-dell-xps-13-9340-core-ultra-7', 45990000, 41990000, 6, 'assets/uploads/products/1793809671_7784e5f8f562.png', 'Tuyệt tác siêu mỏng nhẹ, bàn phím vô cực cảm ứng liền mạch và màn hình OLED 3K.', '<p>Thiết kế từ nhôm CNC nguyên khối và kính cường lực Gorilla Glass 3, thời lượng pin cả ngày dài và hỗ trợ xử lý AI NPU thế hệ mới.</p>', 'Bạc Platinum, Than Chì Graphite', '512GB, 1TB SSD', '16GB, 32GB LPDDR5x', '13.4 inch OLED 3K Touch 120Hz', '1080p FHD IR Camera', '55Whr, Sạc Type-C 60W', 24, 4.9, 1, 0, 1),

(9, 3, 7, 'LEN-LEG-SLIM', 'Laptop Lenovo Legion Slim 5 16IRH8', 'laptop-lenovo-legion-slim-5-16irh8', 32990000, 27990000, 11, 'assets/uploads/products/1793809657_346c0d86e1e4.png', 'Laptop Gaming mỏng nhẹ chip Core i7-13700H, card đồ họa RTX 4060 8GB mạnh mẽ.', '<p>Cân bằng tuyệt đối giữa hiệu năng cày game đồ họa nặng và tính cơ động văn phòng với thiết kế sang trọng không quá hầm hố.</p>', 'Xám Bão Storm Grey', '512GB NVMe SSD', '16GB DDR5', '16 inch WQXGA (2560x1600) 165Hz', '1080p FHD Webcam', '80Whr, Sạc nhanh 230W', 24, 4.8, 0, 1, 0),

(10, 4, 1, 'APP-AIRPODS-P2', 'Tai nghe Apple AirPods Pro 2 Type-C', 'tai-nghe-apple-airpods-pro-2-type-c', 6190000, 5390000, 50, 'assets/uploads/products/1793809647_9e2615259e18.png', 'Chống ồn chủ động ANC gấp 2 lần, tích hợp cổng sạc Type-C và âm thanh thích ứng.', '<p>Chip H2 thông minh tái tạo âm trường chi tiết, hộp sạc hỗ trợ tìm kiếm Precision Finding chuẩn kháng bụi nước IP54.</p>', 'Trắng', 'Không áp dụng', 'Không áp dụng', 'Không áp dụng', 'Không áp dụng', 'Pin 6 giờ nghe liên tục (30 giờ kèm hộp)', 12, 5.0, 1, 1, 1),

(11, 4, 11, 'ANKER-735-65W', 'Củ sạc nhanh Anker GaNPrime 65W 3 cổng', 'cu-sac-nhanh-anker-ganprime-65w-3-cong', 1390000, 990000, 80, 'assets/uploads/products/1793809636_f60965de2420.png', 'Công nghệ sạc bán dẫn GaNPrime đa cổng sạc đồng thời Laptop, iPad và Smartphone.', '<p>Kích thước siêu nhỏ gọn nhẹ hơn 53% so với củ sạc tiêu chuẩn, tích hợp kiểm soát nhiệt độ an toàn ActiveShield 2.0.</p>', 'Đen, Bạc', 'Không áp dụng', 'Không áp dụng', 'Không áp dụng', 'Không áp dụng', 'Công suất tối đa 65W, 2x USB-C + 1x USB-A', 18, 4.9, 0, 1, 1),

(12, 4, 12, 'LOGI-MX-MASTER-3S', 'Chuột không dây Logitech MX Master 3S', 'chuot-khong-day-logitech-mx-master-3s', 2490000, 2090000, 40, 'assets/uploads/products/1793809625_6bf85845d382.png', 'Biểu tượng công thái học cho lập trình viên và designer, cuộn MagSpeed êm ái.', '<p>Cảm biến 8.000 DPI lướt mượt trên mọi bề mặt kính, click yên tĩnh Quiet Clicks giảm 90% tiếng ồn, kết nối 3 thiết bị cùng lúc.</p>', 'Đen Graphite, Xám Nhạt Pale Grey', 'Không áp dụng', 'Không áp dụng', 'Không áp dụng', 'Không áp dụng', 'Pin sạc USB-C dùng tới 70 ngày', 12, 5.0, 1, 0, 1),

(13, 1, 1, 'IP16PM-256-DESERT', 'iPhone 16 Pro Max 256GB Titan Sa Mạc', 'iphone-16-pro-max-256gb', 34990000, 31990000, 35, 'assets/uploads/products/prod_13.png', 'Siêu phẩm mới nhất với nút Camera Control thông minh, chip A18 Pro 3nm và màn hình 6.9 inch viền siêu mỏng.', '<p>iPhone 16 Pro Max sở hữu diện mạo Titan Sa Mạc đẳng cấp, vi xử lý Apple A18 Pro tích hợp Apple Intelligence, quay video 4K 120fps Dolby Vision và thời lượng pin dài nhất lịch sử iPhone.</p>', 'Titan Sa Mạc, Titan Tự Nhiên, Titan Đen, Titan Trắng', '256GB, 512GB, 1TB', '8GB LPDDR5X', '6.9 inch Super Retina XDR ProMotion 120Hz', '48MP Fusion + 48MP Ultra Wide + 12MP Tele 5x', '4.685 mAh, Sạc nhanh MagSafe 25W', 12, 5.0, 1, 1, 1),

(14, 1, 2, 'SS-ZFOLD6-256', 'Samsung Galaxy Z Fold6 5G 256GB', 'samsung-galaxy-z-fold6-5g-256gb', 43990000, 38990000, 14, 'assets/uploads/products/prod_14.png', 'Tuyệt tác màn hình gập siêu mỏng nhẹ, bản lề FlexHinge bền bỉ kết hợp quyền năng Galaxy AI toàn diện.', '<p>Galaxy Z Fold6 nâng tầm đa nhiệm với màn hình chính 7.6 inch độ sáng 2.600 nits, tính năng Khoanh tròn để tìm kiếm, Phiên dịch viên AI hai màn hình và vi xử lý Snapdragon 8 Gen 3 for Galaxy.</p>', 'Xám Metal, Hồng Rosé, Xanh Navy', '256GB, 512GB, 1TB', '12GB', 'Chính 7.6 inch & Phụ 6.3 inch Dynamic AMOLED 2X 120Hz', '50MP + 12MP + 10MP Zoom quang 3x', '4.400 mAh, Sạc nhanh 25W', 12, 5.0, 1, 1, 1),

(15, 2, 1, 'IPAD-PRO-M4-13', 'iPad Pro M4 13 inch WiFi 256GB', 'ipad-pro-m4-13-inch-wifi-256gb', 37990000, 34490000, 16, 'assets/uploads/products/prod_15.png', 'Thiết bị mỏng nhất lịch sử Apple (5.1mm), màn hình Ultra Retina XDR OLED hai lớp và siêu chip M4.', '<p>iPad Pro M4 13 inch định nghĩa lại chuẩn mực máy tính bảng chuyên nghiệp với tấm nền Tandem OLED rực rỡ, hỗ trợ Apple Pencil Pro bóp cảm biến lực và bàn phím Magic Keyboard nhôm nguyên khối.</p>', 'Đen Không Gian, Bạc', '256GB, 512GB, 1TB, 2TB', '8GB, 16GB', '13 inch Ultra Retina XDR Tandem OLED 120Hz', '12MP Pro + Cảm biến LiDAR Scanner', '38.99 Wh, Sạc nhanh USB-C Thunderbolt 4', 12, 5.0, 1, 0, 1),

(16, 3, 1, 'MBP-14-M3PRO-512', 'MacBook Pro 14 inch M3 Pro 18GB/512GB', 'macbook-pro-14-m3-pro-512gb', 49990000, 45990000, 12, 'assets/uploads/products/prod_16.png', 'Sắc Đen Không Gian (Space Black) sang trọng, chip M3 Pro 11 nhân CPU xử lý đồ họa và AI chuyên nghiệp.', '<p>MacBook Pro 14 M3 Pro trang bị màn hình Liquid Retina XDR 1.600 nits, đầy đủ cổng HDMI, khe thẻ SDXC, MagSafe 3 cùng thời lượng pin bền bỉ 18 giờ liên tục.</p>', 'Đen Space Black, Bạc Silver', '512GB, 1TB SSD', '18GB, 36GB Unified Memory', '14.2 inch Liquid Retina XDR 120Hz Mini-LED', '1080p FaceTime HD Camera', '72.4 Wh, Sạc nhanh 70W/96W MagSafe 3', 12, 5.0, 1, 1, 1),

(17, 5, 1, 'AW-ULTRA2-BLACK', 'Apple Watch Ultra 2 49mm 4G Viền Titan Đen', 'apple-watch-ultra-2-49mm-titan-den', 21990000, 19890000, 20, 'assets/uploads/products/prod_17.png', 'Phiên bản Satin Black Titanium mới nhất, màn hình Sapphire 3.000 nits, GPS băng tần kép chuẩn quân đội.', '<p>Apple Watch Ultra 2 Titan Đen là chiếc đồng hồ thông minh thể thao và thám hiểm đỉnh cao nhất hiện nay, chống nước độ sâu 100m, thao tác chạm hai lần Double Tap và pin lên tới 72 giờ.</p>', 'Titan Đen Satin, Titan Tự Nhiên', '64GB', 'Chip S9 SiP 4 nhân Neural Engine', '49mm Retina LTPO OLED 3000 nits kính Sapphire', 'Cảm biến nhịp tim, SpO2, ECG, Nhiệt độ nước', 'Pin tới 36 giờ (72 giờ chế độ tiết kiệm)', 12, 5.0, 1, 1, 1),

(18, 5, 2, 'SS-WATCH-ULTRA-47', 'Samsung Galaxy Watch Ultra LTE 47mm Titanium', 'samsung-galaxy-watch-ultra-47mm', 16990000, 14490000, 18, 'assets/uploads/products/prod_18.png', 'Khung vỏ Titanium Grade 4 siêu bền, nút Quick Button phản hồi tức thì, trợ lý sức khỏe Galaxy AI.', '<p>Thiết kế đệm Cushion Design mạnh mẽ, vi xử lý Exynos W1000 3nm đầu tiên trên smartwatch, theo dõi chỉ số năng lượng Energy Score và kháng nước 10ATM.</p>', 'Xám Titan, Trắng Titan, Bạc Titan', '32GB', '2GB RAM', '1.5 inch Super AMOLED Sapphire 3000 nits', 'BioActive Sensor thế hệ mới + Đo huyết áp/ECG', '590 mAh (Dùng tới 100 giờ Power Saving)', 12, 4.9, 1, 0, 1),

(19, 6, 13, 'SONY-WH1000XM5', 'Tai nghe chụp tai Sony WH-1000XM5 Chống ồn ANC', 'tai-nghe-sony-wh-1000xm5', 8490000, 6890000, 28, 'assets/uploads/products/prod_19.png', 'Ông vua chống ồn chủ động với 8 micro và 2 bộ xử lý QN1 + V1, chuẩn âm thanh Hi-Res Audio LDAC.', '<p>Sony WH-1000XM5 mang lại không gian âm nhạc tĩnh lặng tuyệt đối, đệm tai da mềm mại đeo êm cả ngày dài, đàm thoại lọc gió AI siêu trong trẻo.</p>', 'Đen Matte, Bạc Platinum, Xanh Midnight', 'Không áp dụng', 'Bộ xử lý chống ồn HD QN1 + Integrated V1', 'Driver sợi carbon 30mm Hi-Res Audio', '8 Micro chống ồn & Beamforming đàm thoại', 'Pin 30 giờ (Sạc nhanh 3 phút nghe 3 giờ)', 12, 5.0, 1, 1, 1),

(20, 6, 14, 'MARSHALL-STANMORE-3', 'Loa Bluetooth Marshall Stanmore III Chính hãng', 'loa-bluetooth-marshall-stanmore-iii', 10990000, 8790000, 15, 'assets/uploads/products/prod_20.png', 'Thiết kế cổ điển biểu tượng nước Anh, âm trường rộng mở Dynamic Loudness công suất 80W uy lực.', '<p>Marshall Stanmore III là tâm điểm sang trọng cho mọi không gian phòng khách và studio với cụm núm xoay đồng thau tinh xảo, hỗ trợ Bluetooth 5.2 LE Audio.</p>', 'Đen Classic, Kem Cream, NâuVintage', 'Không áp dụng', 'Amply Class D 80W (1x50W Woofer + 2x15W Tweeter)', 'Bảng điều khiển đồng thau Analog Bass/Treble', 'Bluetooth 5.2, RCA, AUX 3.5mm', 'Nguồn điện trực tiếp 100-240V', 12, 5.0, 1, 0, 1),

(21, 7, 13, 'SONY-PS5-SLIM', 'Máy chơi game Sony PlayStation 5 Slim (PS5 Slim)', 'may-choi-game-sony-ps5-slim', 14990000, 12690000, 22, 'assets/uploads/products/prod_21.png', 'Thiết kế mới gọn hơn 30%, ổ cứng SSD 1TB tốc độ siêu thanh, đồ họa 4K 120Hz Ray Tracing đỉnh cao.', '<p>Trải nghiệm thế giới game AAA sống động cùng tay cầm không dây DualSense phản hồi xúc giác Haptic Feedback và cò bấm thích ứng Adaptive Triggers độc quyền.</p>', 'Trắng Glacier White', '1TB Custom NVMe SSD', '16GB GDDR6', 'Xuất hình 4K 120Hz / 8K HDR HDMI 2.1', 'Tay cầm DualSense Wireless kèm theo máy', 'Tản nhiệt kim loại lỏng êm ái', 12, 5.0, 1, 1, 1),

(22, 7, 6, 'ASUS-ROG-AZOTH', 'Bàn phím cơ không dây ASUS ROG Azoth OLED Custom', 'ban-phim-co-asus-rog-azoth', 6990000, 5790000, 19, 'assets/uploads/products/prod_22.png', 'Bàn phím cơ Custom 75% cấu trúc Gasket Mount 3 lớp tiêu âm, màn hình OLED thông minh và Hotswap.', '<p>Trang bị switch cơ học ROG NX được lube sẵn mượt mà, kết nối 3 chế độ SpeedNova 2.4GHz / Bluetooth / USB-C, đi kèm bộ kit lube switch cao cấp.</p>', 'Đen Gunmetal, Trắng Moonlight', 'Bộ nhớ lưu 6 Profile Macro', 'Màn hình OLED 2 inch + Núm xoay 3 chiều', 'Layout 75% nhỏ gọn, Keycap PBT Doubleshot', 'Switch ROG NX Hotswap 5-pin', 'Pin lên đến 2.000 giờ (Tắt LED & OLED)', 24, 4.9, 0, 1, 1),

(23, 8, 16, 'LG-ULTRAGEAR-OLED-27', 'Màn hình Gaming LG UltraGear OLED 27 inch 240Hz', 'man-hinh-lg-ultragear-oled-27-240hz', 22990000, 18490000, 9, 'assets/uploads/products/prod_23.png', 'Tấm nền OLED QHD tần số quét 240Hz, tốc độ phản hồi 0.03ms (GtG) nhanh nhất thế giới.', '<p>Màn hình chuẩn Esports đỉnh cao với độ tương phản 1.500.000:1, dải màu 98.5% DCI-P3, tương thích NVIDIA G-SYNC và AMD FreeSync Premium Pro.</p>', 'Đen Viền Siêu Mỏng', '2x HDMI 2.1, 1x DisplayPort 1.4, USB 3.0 Hub', 'Tương thích G-SYNC & FreeSync Premium Pro', '27 inch QHD (2560x1440) OLED 240Hz 0.03ms', 'Chống chói Anti-Glare Low Reflection', 'Chân đế công thái học xoay dọc Pivot, nâng hạ', 24, 5.0, 1, 1, 1),

(24, 8, 1, 'APPLE-MAC-STUDIO-M2MAX', 'Apple Mac Studio M2 Max 32GB/512GB SSD', 'apple-mac-studio-m2-max-512gb', 54990000, 48990000, 7, 'assets/uploads/products/prod_24.png', 'Trạm làm việc siêu nhỏ gọn sức mạnh quái vật 12 nhân CPU, 30 nhân GPU, hỗ trợ xuất 5 màn hình Pro Display.', '<p>Mac Studio M2 Max là cỗ máy trong mơ cho kỹ sư AI, dựng phim 8K, thiết kế 3D Cinema 4D và phòng thu âm chuyên nghiệp với 4 cổng Thunderbolt 4 và Wi-Fi 6E.</p>', 'Bạc Aluminum', '512GB, 1TB, 2TB SSD siêu tốc', '32GB, 64GB Unified Memory (400GB/s)', 'Hỗ trợ tới 5 màn hình độ phân giải 6K/8K', '4x Thunderbolt 4, 10Gb Ethernet, HDMI, SDXC', 'Tản nhiệt kép siêu tĩnh lặng', 12, 5.0, 1, 0, 1);

-- 6. Bảng Hình Ảnh Phụ Của Sản Phẩm (product_images)
DROP TABLE IF EXISTS `product_images`;
CREATE TABLE `product_images` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `image_url` VARCHAR(255) NOT NULL,
  `sort_order` INT DEFAULT 0,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Bảng Đơn Hàng (orders)
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_code` VARCHAR(30) NOT NULL UNIQUE,
  `user_id` INT NULL,
  `customer_name` VARCHAR(100) NOT NULL,
  `customer_email` VARCHAR(100) NOT NULL,
  `customer_phone` VARCHAR(20) NOT NULL,
  `customer_address` VARCHAR(255) NOT NULL,
  `city` VARCHAR(100) NOT NULL,
  `district` VARCHAR(100) NOT NULL,
  `ward` VARCHAR(100) NOT NULL,
  `note` TEXT NULL,
  `payment_method` ENUM('cod', 'bank_transfer') DEFAULT 'cod',
  `payment_status` ENUM('unpaid', 'paid') DEFAULT 'unpaid',
  `shipping_fee` DECIMAL(15,2) DEFAULT 30000,
  `discount_amount` DECIMAL(15,2) DEFAULT 0,
  `subtotal` DECIMAL(15,2) NOT NULL,
  `total_amount` DECIMAL(15,2) NOT NULL,
  `status` ENUM('pending', 'confirmed', 'processing', 'shipping', 'completed', 'cancelled', 'refunded') DEFAULT 'pending',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dữ liệu mẫu đơn hàng
INSERT INTO `orders` (`id`, `order_code`, `user_id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `city`, `district`, `ward`, `payment_method`, `payment_status`, `shipping_fee`, `discount_amount`, `subtotal`, `total_amount`, `status`) VALUES
(1, 'LT-20261103-01', 2, 'Nguyễn Văn Long', 'customer@gmail.com', '0912345678', 'Số 45 Cầu Giấy', 'Hà Nội', 'Quận Cầu Giấy', 'Phường Dịch Vọng', 'cod', 'unpaid', 0, 0, 29890000, 29890000, 'processing');

-- 8. Bảng Chi Tiết Đơn Hàng (order_items)
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `product_price` DECIMAL(15,2) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `color` VARCHAR(50) NULL,
  `storage` VARCHAR(50) NULL,
  `total_price` DECIMAL(15,2) NOT NULL,
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_name`, `product_price`, `quantity`, `color`, `storage`, `total_price`) VALUES
(1, 1, 1, 'iPhone 15 Pro Max 256GB', 29890000, 1, 'Titan Tự Nhiên', '256GB', 29890000);

-- 9. Bảng Đánh Giá Sản Phẩm (reviews)
DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `rating` TINYINT NOT NULL CHECK (`rating` BETWEEN 1 AND 5),
  `comment` TEXT NOT NULL,
  `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'approved',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `reviews` (`id`, `product_id`, `user_id`, `rating`, `comment`, `status`) VALUES
(1, 1, 2, 5, 'Máy đẹp, nhẹ hơn bản 14 rất nhiều, viền titan sang trọng, camera chụp đêm xuất sắc!', 'approved');

-- 10. Bảng Danh Sách Yêu Thích (wishlists)
DROP TABLE IF EXISTS `wishlists`;
CREATE TABLE `wishlists` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_user_product` (`user_id`, `product_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Bảng Mã Giảm Giá (coupons)
DROP TABLE IF EXISTS `coupons`;
CREATE TABLE `coupons` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `type` ENUM('percentage', 'fixed_amount') DEFAULT 'percentage',
  `value` DECIMAL(15,2) NOT NULL,
  `min_order_value` DECIMAL(15,2) DEFAULT 0,
  `max_discount` DECIMAL(15,2) NULL,
  `usage_limit` INT DEFAULT 100,
  `used_count` INT DEFAULT 0,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `status` ENUM('active', 'inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `coupons` (`id`, `code`, `type`, `value`, `min_order_value`, `max_discount`, `usage_limit`, `used_count`, `start_date`, `end_date`, `status`) VALUES
(1, 'LONGTECH50K', 'fixed_amount', 50000, 500000, 50000, 500, 12, '2026-01-01', '2026-12-31', 'active'),
(2, 'VIP10', 'percentage', 10, 2000000, 1000000, 200, 5, '2026-01-01', '2026-12-31', 'active');

-- 12. Bảng Banner Quảng Cáo (banners)
DROP TABLE IF EXISTS `banners`;
CREATE TABLE `banners` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `subtitle` VARCHAR(255) NULL,
  `image_url` VARCHAR(255) NOT NULL,
  `link` VARCHAR(255) DEFAULT '#',
  `position` ENUM('home_slider', 'home_sidebar', 'sale_popup') DEFAULT 'home_slider',
  `sort_order` INT DEFAULT 0,
  `status` ENUM('active', 'inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `banners` (`id`, `title`, `subtitle`, `image_url`, `link`, `position`, `sort_order`, `status`) VALUES
(1, 'iPhone 16 Pro Max Titan Sa Mạc', 'Siêu chip A18 Pro 3nm • Nút Camera Control • Giảm ngay 3.000.000đ + Trả góp 0%', 'assets/uploads/products/prod_13.png', 'san-pham/iphone-16-pro-max-256gb', 'home_slider', 1, 'active'),
(2, 'Samsung Galaxy Z Fold6 & S24 Ultra AI', 'Quyền năng Galaxy AI thế hệ mới • Thu cũ đổi mới trợ giá tới 4.000.000đ', 'assets/uploads/products/prod_14.png', 'san-pham/samsung-galaxy-z-fold6-5g-256gb', 'home_slider', 2, 'active'),
(3, 'MacBook Pro 14 M3 Pro Space Black', 'Đỉnh cao đồ họa & Lập trình AI • Màn hình Liquid Retina XDR 120Hz • Ưu đãi HSSV 5%', 'assets/uploads/products/prod_16.png', 'san-pham/macbook-pro-14-m3-pro-512gb', 'home_slider', 3, 'active'),
(4, 'iPad Pro M4 13 inch Ultra Retina OLED', 'Thiết kế mỏng nhất lịch sử 5.1mm • Tương thích Apple Pencil Pro & Magic Keyboard', 'assets/uploads/products/prod_15.png', 'san-pham/ipad-pro-m4-13-inch-wifi-256gb', 'home_slider', 4, 'active'),
(5, 'Apple Watch Ultra 2 49mm Titan Đen Satin', 'Chuẩn kháng nước 100m • Màn hình Sapphire 3000 nits • GPS Băng tần kép chính xác', 'assets/uploads/products/prod_17.png', 'san-pham/apple-watch-ultra-2-49mm-titan-den', 'home_slider', 5, 'active'),
(6, 'Đại Tiệc Gaming: PS5 Slim & ASUS ROG Strix', 'Chiến mượt mọi tựa game AAA 4K 120Hz • Tặng kèm gói bảo hành VIP 24 tháng', 'assets/uploads/products/prod_21.png', 'gaming-gear', 'home_slider', 6, 'active'),
(7, 'Không Gian Âm Thanh Marshall & Sony XM5', 'Đỉnh cao chống ồn ANC & Loa cổ điển Anh Quốc • Giảm sốc tới 20% cuối tuần', 'assets/uploads/products/prod_20.png', 'am-thanh', 'home_slider', 7, 'active'),
(8, 'Màn Hình LG UltraGear OLED 240Hz & Mac Studio', 'Tốc độ phản hồi 0.03ms nhanh nhất thế giới • Trạm đồ họa 8K chuyên nghiệp', 'assets/uploads/products/prod_23.png', 'man-hinh-pc', 'home_slider', 8, 'active');

-- 13. Bảng Tin Tức Công Nghệ (posts)
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `summary` TEXT NOT NULL,
  `content` LONGTEXT NOT NULL,
  `thumbnail` VARCHAR(255) NOT NULL,
  `author_id` INT NULL,
  `status` ENUM('published', 'draft') DEFAULT 'published',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`author_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `posts` (`id`, `title`, `slug`, `summary`, `content`, `thumbnail`, `author_id`) VALUES
(1, 'Đánh giá chi tiết Galaxy S24 Ultra sau 1 tháng sử dụng: Galaxy AI đỉnh đến đâu?', 'danh-gia-chi-tiet-galaxy-s24-ultra-sau-1-thang', 'Trải nghiệm thực tế các tính năng dịch trực tiếp cuộc gọi, khoanh tròn để tìm kiếm và camera 200MP.', '<p>Galaxy S24 Ultra thể hiện sự toàn diện từ màn hình phẳng chống chói tốt nhất phân khúc đến hiệu năng Snapdragon 8 Gen 3 for Galaxy mạnh mẽ.</p>', 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=600&auto=format&fit=crop', 1),
(2, 'Top 5 mẫu laptop mỏng nhẹ cho lập trình viên và sinh viên kỹ thuật 2026', 'top-5-mau-laptop-mong-nhe-cho-lap-trinh-vien', 'Tổng hợp những cỗ máy cân bằng thời lượng pin, màn hình chuẩn màu sắc và hiệu năng CPU nhiều nhân.', '<p>Lựa chọn laptop phù hợp giúp tăng hiệu suất làm việc vượt trội với các đại diện tiêu biểu như Dell XPS và Asus ROG.</p>', 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=600&auto=format&fit=crop', 1);

-- 14. Bảng Liên Hệ & Góp Ý (contacts)
DROP TABLE IF EXISTS `contacts`;
CREATE TABLE `contacts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `status` ENUM('unread', 'read', 'replied') DEFAULT 'unread',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

