-- ========================================================
-- LONGTECH E-COMMERCE - CƠ SỞ DỮ LIỆU CHUẨN
-- Bảng mã: utf8mb4 / Collation: utf8mb4_unicode_ci
-- ========================================================

CREATE DATABASE IF NOT EXISTS `longtech` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `longtech`;

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Bảng Phân Quyền (roles)
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(50) NOT NULL UNIQUE,
  `display_name` VARCHAR(100) NOT NULL,
  `description` VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`) VALUES
(1, 'super_admin', 'Super Admin', 'Toàn quyền quản trị cao nhất hệ thống'),
(2, 'admin', 'Admin Quản trị', 'Quản lý sản phẩm, đơn hàng, người dùng và nội dung'),
(3, 'product_manager', 'Nhân viên Sản phẩm', 'Quản lý thêm, sửa, xem sản phẩm và kiểm kê tồn kho'),
(4, 'order_manager', 'Nhân viên Đơn hàng', 'Xem đơn, xử lý đơn và cập nhật trạng thái giao nhận'),
(5, 'customer', 'Khách hàng', 'Mua hàng, quản lý đơn cá nhân, viết đánh giá sản phẩm');

-- 2. Bảng Người Dùng (users)
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `role_id` INT NOT NULL DEFAULT 5,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NULL,
  `address` VARCHAR(255) NULL,
  `avatar` VARCHAR(255) NULL,
  `status` ENUM('active', 'locked') DEFAULT 'active',
  `require_password_change` TINYINT(1) DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Mật khẩu mặc định:
-- admin / admin@longtech.vn -> admin123
-- customer / customer@gmail.com -> 123456
INSERT INTO `users` (`id`, `role_id`, `username`, `email`, `password`, `full_name`, `phone`, `address`, `status`) VALUES
(1, 1, 'admin', 'admin@longtech.vn', '$2y$10$AT7nJITcX4xpC8jxN7n63.uZZUup4AaOOqcGIavlYXkP4xsxdpVVO', 'Quản Trị Viên Cấp Cao', '0988889999', 'Hà Nội, Việt Nam', 'active'),
(2, 5, 'customer', 'customer@gmail.com', '$2y$10$r9hiEgXjLAeJdo86cEQkpeLeTxVIpqVfcT5Y3mPJeiNJq65I/l.9O', 'Nguyễn Văn Long', '0912345678', 'Số 45 Cầu Giấy, Hà Nội', 'active');

-- 3. Bảng Danh Mục Sản Phẩm (categories)
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `icon` VARCHAR(50) NULL,
  `image` VARCHAR(255) NULL,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `sort_order` INT DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`id`, `name`, `slug`, `icon`, `sort_order`) VALUES
(1, 'Điện thoại', 'dien-thoai', 'fa-mobile-screen-button', 1),
(2, 'Máy tính bảng', 'may-tinh-bang', 'fa-tablet-screen-button', 2),
(3, 'Laptop', 'laptop', 'fa-laptop', 3),
(4, 'Phụ kiện', 'phu-kien', 'fa-headphones', 4);

-- 4. Bảng Thương Hiệu (brands)
DROP TABLE IF EXISTS `brands`;
CREATE TABLE `brands` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `logo` VARCHAR(255) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `brands` (`id`, `name`, `slug`) VALUES
(1, 'Apple', 'apple'),
(2, 'Samsung', 'samsung'),
(3, 'Xiaomi', 'xiaomi'),
(4, 'OPPO', 'oppo'),
(5, 'Vivo', 'vivo'),
(6, 'ASUS', 'asus'),
(7, 'Lenovo', 'lenovo'),
(8, 'Dell', 'dell'),
(9, 'HP', 'hp'),
(10, 'Acer', 'acer'),
(11, 'Anker', 'anker'),
(12, 'Logitech', 'logitech');

-- 5. Bảng Sản Phẩm (products)
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT NOT NULL,
  `brand_id` INT NOT NULL,
  `product_code` VARCHAR(50) NOT NULL UNIQUE,
  `name` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `price` DECIMAL(15,2) NOT NULL,
  `sale_price` DECIMAL(15,2) NULL,
  `stock_quantity` INT NOT NULL DEFAULT 0,
  `thumbnail` VARCHAR(255) NOT NULL,
  `short_description` TEXT NULL,
  `description` LONGTEXT NULL,
  `colors` VARCHAR(255) NULL,
  `storage_options` VARCHAR(255) NULL,
  `ram_options` VARCHAR(255) NULL,
  `screen` VARCHAR(100) NULL,
  `camera` VARCHAR(100) NULL,
  `battery` VARCHAR(100) NULL,
  `warranty_months` INT DEFAULT 12,
  `rating` DECIMAL(3,1) DEFAULT 5.0,
  `view_count` INT DEFAULT 0,
  `is_featured` TINYINT(1) DEFAULT 0,
  `is_hot_deal` TINYINT(1) DEFAULT 0,
  `is_new` TINYINT(1) DEFAULT 1,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`brand_id`) REFERENCES `brands`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12 Sản phẩm mẫu đỉnh cao công nghệ theo các danh mục
INSERT INTO `products` (`id`, `category_id`, `brand_id`, `product_code`, `name`, `slug`, `price`, `sale_price`, `stock_quantity`, `thumbnail`, `short_description`, `description`, `colors`, `storage_options`, `ram_options`, `screen`, `camera`, `battery`, `warranty_months`, `rating`, `is_featured`, `is_hot_deal`, `is_new`) VALUES
(1, 1, 1, 'IP15PM-256', 'iPhone 15 Pro Max 256GB', 'iphone-15-pro-max-256gb', 34990000, 29890000, 25, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvaS9wL2lwaG9uZS0xNS1wcm8tbWF4XzMtMy5wbmc.webp', 'Siêu phẩm khung viền Titan, chip A17 Pro đỉnh cao và camera tiềm vọng 5x.', '<p>iPhone 15 Pro Max là đỉnh cao thiết kế công nghệ với khung vỏ Titan cao cấp siêu nhẹ, cụm camera tiên tiến hỗ trợ quay chuẩn Apple ProRes, màn hình Super Retina XDR ProMotion 120Hz mượt mà.</p>', 'Titan Tự Nhiên, Titan Xanh, Titan Đen, Titan Trắng', '256GB, 512GB, 1TB', '8GB', '6.7 inch Super Retina XDR OLED', 'Chính 48MP & Phụ 12MP, 12MP', '4.422 mAh, Sạc nhanh 20W', 12, 5.0, 1, 1, 1),

(2, 1, 2, 'SS-S24U-256', 'Samsung Galaxy S24 Ultra 5G 256GB', 'samsung-galaxy-s24-ultra-5g-256gb', 33990000, 28490000, 18, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3Qvcy8yL3MyNF91bHRyYV92YW5nXzEucG5n.webp', 'Khung viền Titanium, trang bị quyền năng Galaxy AI vượt trội cùng bút S-Pen đa năng.', '<p>Galaxy S24 Ultra trang bị vi xử lý Snapdragon 8 Gen 3 for Galaxy, hệ sinh thái trí tuệ nhân tạo Galaxy AI đột phá, camera độ phân giải khủng 200MP zoom quang 100x.</p>', 'Xám Titan, Đen Titan, Tím Titan, Vàng Titan', '256GB, 512GB, 1TB', '12GB', '6.8 inch Dynamic AMOLED 2X 120Hz', '200MP + 50MP + 12MP + 10MP', '5.000 mAh, Sạc nhanh 45W', 12, 4.9, 1, 1, 1),

(3, 1, 3, 'XM-14-256', 'Xiaomi 14 5G 256GB', 'xiaomi-14-5g-256gb', 22990000, 18990000, 12, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QveC9pL3hpYW9taS0xNC10cmFpc3VuZ18xXzEucG5n.webp', 'Hệ thống ống kính quang học Leica danh tiếng kết hợp chip Snapdragon 8 Gen 3.', '<p>Xiaomi 14 là sự kết hợp hoàn hảo giữa kích thước nhỏ gọn cầm nắm tuyệt vời và cấu hình phần cứng tối thượng cùng cảm biến Light Fusion 900.</p>', 'Đen, Xanh Ngọc, Trắng', '256GB, 512GB', '12GB', '6.36 inch AMOLED 1.5K 120Hz', 'Leica 50MP + 50MP + 50MP', '4.610 mAh, Sạc HyperCharge 90W', 18, 4.8, 1, 0, 1),

(4, 1, 4, 'OP-R11-256', 'OPPO Reno11 5G 256GB', 'oppo-reno11-5g-256gb', 10990000, 8990000, 30, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3Qvby9wL29wcG8tcmVuby0xMS14YW5oLTFfMi5wbmc.webp', 'Chuyên gia chân dung chụp nét từng khoảnh khắc với công nghệ sạc SUPERVOOC 67W.', '<p>Thiết kế mặt lưng họa tiết sóng biển độc đáo, camera tele chân dung 32MP chuyên nghiệp, màn hình cong 3D sang trọng.</p>', 'Xanh Sóng Biển, Xám Hoa Cương', '256GB', '8GB', '6.7 inch AMOLED 120Hz', '50MP + 32MP + 8MP', '5.000 mAh, Sạc SUPERVOOC 67W', 12, 4.7, 0, 1, 0),

(5, 2, 1, 'IPAD-PRO-M2', 'iPad Pro 11 inch M2 WiFi 128GB', 'ipad-pro-11-inch-m2-wifi-128gb', 23990000, 20490000, 15, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvaS9wL2lwYWQtcHJvLTEzLXNhbmctY2VsZi5wbmc.webp', 'Sức mạnh đột phá từ vi xử lý Apple Silicon M2, tương thích Apple Pencil Hover.', '<p>Máy tính bảng chuyên nghiệp đỉnh cao cho đồ họa, sáng tạo nội dung và giải trí với màn hình Liquid Retina sắc nét cùng Face ID bảo mật.</p>', 'Xám Không Gian, Bạc', '128GB, 256GB, 512GB', '8GB', '11 inch Liquid Retina 120Hz', '12MP Rộng + 10MP Siêu rộng, LiDAR', '7.538 mAh, Sạc nhanh 20W', 12, 5.0, 1, 0, 1),

(6, 2, 2, 'SS-TAB-S9', 'Samsung Galaxy Tab S9 WiFi 128GB', 'samsung-galaxy-tab-s9-wifi-128gb', 19990000, 15990000, 10, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3Qvcy9hL3NhbXN1bmctZ2FsYXh5LXRhYi1zOS0xXzEucG5n.webp', 'Màn hình Dynamic AMOLED 2X sống động, kháng nước IP68, tặng kèm bút S-Pen.', '<p>Tablet cao cấp chống nước chuẩn IP68 đầu tiên trên dòng Tab S, âm thanh 4 loa AKG chuẩn Dolby Atmos mang lại rạp phim tại nhà.</p>', 'Xám Graphite, Kem', '128GB, 256GB', '8GB, 12GB', '11 inch Dynamic AMOLED 2X 120Hz', '13MP Sau, 12MP Trước', '8.400 mAh, Sạc nhanh 45W', 12, 4.8, 1, 1, 0),

(7, 3, 6, 'ASUS-ROG-G16', 'Laptop ASUS ROG Strix G16 G614JVR', 'laptop-asus-rog-strix-g16-g614jvr', 48990000, 42990000, 8, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvdGV4dF9kYW5na18yMF9fMi5wbmc.webp', 'Cỗ máy chiến game tối thượng i9-14900HX, RTX 4080 và màn hình chuẩn 240Hz Nebula.', '<p>Dành riêng cho game thủ và streamer chuyên nghiệp với hệ thống tản nhiệt 3 quạt làm mát kim loại lỏng Conductonaut Extreme.</p>', 'Xám Eclipse', '1TB NVMe PCIe 4.0 SSD', '32GB DDR5 5600MHz', '16 inch QHD+ 240Hz 100% DCI-P3', '720p HD Webcam', '90Whr, Bộ sạc 330W', 24, 5.0, 1, 1, 1),

(8, 3, 8, 'DELL-XPS-13', 'Laptop Dell XPS 13 9340 Core Ultra 7', 'laptop-dell-xps-13-9340-core-ultra-7', 45990000, 41990000, 6, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvdGV4dF9kYW5na18yNF9fMS5wbmc.webp', 'Tuyệt tác siêu mỏng nhẹ, bàn phím vô cực cảm ứng liền mạch và màn hình OLED 3K.', '<p>Thiết kế từ nhôm CNC nguyên khối và kính cường lực Gorilla Glass 3, thời lượng pin cả ngày dài và hỗ trợ xử lý AI NPU thế hệ mới.</p>', 'Bạc Platinum, Than Chì Graphite', '512GB, 1TB SSD', '16GB, 32GB LPDDR5x', '13.4 inch OLED 3K Touch 120Hz', '1080p FHD IR Camera', '55Whr, Sạc Type-C 60W', 24, 4.9, 1, 0, 1),

(9, 3, 7, 'LEN-LEG-SLIM', 'Laptop Lenovo Legion Slim 5 16IRH8', 'laptop-lenovo-legion-slim-5-16irh8', 32990000, 27990000, 11, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvbC9lL2xlbm92by1sZWdpb24tc2xpbS01LTE2aXJoOC04Mnk3MDA3NHZuLWNlbGxwaG9uZXMtY2hhbi10cmFuZy0wMDEucG5n.webp', 'Laptop Gaming mỏng nhẹ chip Core i7-13700H, card đồ họa RTX 4060 8GB mạnh mẽ.', '<p>Cân bằng tuyệt đối giữa hiệu năng cày game đồ họa nặng và tính cơ động văn phòng với thiết kế sang trọng không quá hầm hố.</p>', 'Xám Bão Storm Grey', '512GB NVMe SSD', '16GB DDR5', '16 inch WQXGA (2560x1600) 165Hz', '1080p FHD Webcam', '80Whr, Sạc nhanh 230W', 24, 4.8, 0, 1, 0),

(10, 4, 1, 'APP-AIRPODS-P2', 'Tai nghe Apple AirPods Pro 2 Type-C', 'tai-nghe-apple-airpods-pro-2-type-c', 6190000, 5390000, 50, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvYS9wL2FwcGxlLWFpcnBvZHMtcHJvLTItdXNiLWMtMS5wbmc.webp', 'Chống ồn chủ động ANC gấp 2 lần, tích hợp cổng sạc Type-C và âm thanh thích ứng.', '<p>Chip H2 thông minh tái tạo âm trường chi tiết, hộp sạc hỗ trợ tìm kiếm Precision Finding chuẩn kháng bụi nước IP54.</p>', 'Trắng', 'Không áp dụng', 'Không áp dụng', 'Không áp dụng', 'Không áp dụng', 'Pin 6 giờ nghe liên tục (30 giờ kèm hộp)', 12, 5.0, 1, 1, 1),

(11, 4, 11, 'ANKER-735-65W', 'Củ sạc nhanh Anker GaNPrime 65W 3 cổng', 'cu-sac-nhanh-anker-ganprime-65w-3-cong', 1390000, 990000, 80, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvYy91L2N1LXNhYy1hbmtlci03MzUtZ2FucHJpbWUtNjV3LWEyNjY4XzFfMS5wbmc.webp', 'Công nghệ sạc bán dẫn GaNPrime đa cổng sạc đồng thời Laptop, iPad và Smartphone.', '<p>Kích thước siêu nhỏ gọn nhẹ hơn 53% so với củ sạc tiêu chuẩn, tích hợp kiểm soát nhiệt độ an toàn ActiveShield 2.0.</p>', 'Đen, Bạc', 'Không áp dụng', 'Không áp dụng', 'Không áp dụng', 'Không áp dụng', 'Công suất tối đa 65W, 2x USB-C + 1x USB-A', 18, 4.9, 0, 1, 1),

(12, 4, 12, 'LOGI-MX-MASTER-3S', 'Chuột không dây Logitech MX Master 3S', 'chuot-khong-day-logitech-mx-master-3s', 2490000, 2090000, 40, 'https://cdn2.cellphones.com.vn/insecure/rs:fill:0:358/q:90/none/none/djA/aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bi9tZWRpYS9jYXRhbG9nL3Byb2R1Y3QvYy9oL2NodW90LWtob25nLWRheS1sb2dpdGVjaC1teC1tYXN0ZXItM3MteGFtLmpwZw.webp', 'Biểu tượng công thái học cho lập trình viên và designer, cuộn MagSpeed êm ái.', '<p>Cảm biến 8.000 DPI lướt mượt trên mọi bề mặt kính, click yên tĩnh Quiet Clicks giảm 90% tiếng ồn, kết nối 3 thiết bị cùng lúc.</p>', 'Đen Graphite, Xám Nhạt Pale Grey', 'Không áp dụng', 'Không áp dụng', 'Không áp dụng', 'Không áp dụng', 'Pin sạc USB-C dùng tới 70 ngày', 12, 5.0, 1, 0, 1);

-- 6. Bảng Hình Ảnh Phụ Của Sản Phẩm (product_images)
DROP TABLE IF EXISTS `product_images`;
CREATE TABLE `product_images` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `image_url` VARCHAR(255) NOT NULL,
  `sort_order` INT DEFAULT 0,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Bảng Đơn Hàng (orders)
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_code` VARCHAR(30) NOT NULL UNIQUE,
  `user_id` INT NULL,
  `customer_name` VARCHAR(100) NOT NULL,
  `customer_email` VARCHAR(100) NOT NULL,
  `customer_phone` VARCHAR(20) NOT NULL,
  `customer_address` VARCHAR(255) NOT NULL,
  `city` VARCHAR(100) NOT NULL,
  `district` VARCHAR(100) NOT NULL,
  `ward` VARCHAR(100) NOT NULL,
  `note` TEXT NULL,
  `payment_method` ENUM('cod', 'bank_transfer') DEFAULT 'cod',
  `payment_status` ENUM('unpaid', 'paid') DEFAULT 'unpaid',
  `shipping_fee` DECIMAL(15,2) DEFAULT 30000,
  `discount_amount` DECIMAL(15,2) DEFAULT 0,
  `subtotal` DECIMAL(15,2) NOT NULL,
  `total_amount` DECIMAL(15,2) NOT NULL,
  `status` ENUM('pending', 'confirmed', 'processing', 'shipping', 'completed', 'cancelled', 'refunded') DEFAULT 'pending',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dữ liệu mẫu đơn hàng
INSERT INTO `orders` (`id`, `order_code`, `user_id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `city`, `district`, `ward`, `payment_method`, `payment_status`, `shipping_fee`, `discount_amount`, `subtotal`, `total_amount`, `status`) VALUES
(1, 'LT-20261103-01', 2, 'Nguyễn Văn Long', 'customer@gmail.com', '0912345678', 'Số 45 Cầu Giấy', 'Hà Nội', 'Quận Cầu Giấy', 'Phường Dịch Vọng', 'cod', 'unpaid', 0, 0, 29890000, 29890000, 'processing');

-- 8. Bảng Chi Tiết Đơn Hàng (order_items)
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `product_price` DECIMAL(15,2) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `color` VARCHAR(50) NULL,
  `storage` VARCHAR(50) NULL,
  `total_price` DECIMAL(15,2) NOT NULL,
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_name`, `product_price`, `quantity`, `color`, `storage`, `total_price`) VALUES
(1, 1, 1, 'iPhone 15 Pro Max 256GB', 29890000, 1, 'Titan Tự Nhiên', '256GB', 29890000);

-- 9. Bảng Đánh Giá Sản Phẩm (reviews)
DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `product_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `rating` TINYINT NOT NULL CHECK (`rating` BETWEEN 1 AND 5),
  `comment` TEXT NOT NULL,
  `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'approved',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `reviews` (`id`, `product_id`, `user_id`, `rating`, `comment`, `status`) VALUES
(1, 1, 2, 5, 'Máy đẹp, nhẹ hơn bản 14 rất nhiều, viền titan sang trọng, camera chụp đêm xuất sắc!', 'approved');

-- 10. Bảng Danh Sách Yêu Thích (wishlists)
DROP TABLE IF EXISTS `wishlists`;
CREATE TABLE `wishlists` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_user_product` (`user_id`, `product_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Bảng Mã Giảm Giá (coupons)
DROP TABLE IF EXISTS `coupons`;
CREATE TABLE `coupons` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `type` ENUM('percentage', 'fixed_amount') DEFAULT 'percentage',
  `value` DECIMAL(15,2) NOT NULL,
  `min_order_value` DECIMAL(15,2) DEFAULT 0,
  `max_discount` DECIMAL(15,2) NULL,
  `usage_limit` INT DEFAULT 100,
  `used_count` INT DEFAULT 0,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `status` ENUM('active', 'inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `coupons` (`id`, `code`, `type`, `value`, `min_order_value`, `max_discount`, `usage_limit`, `used_count`, `start_date`, `end_date`, `status`) VALUES
(1, 'LONGTECH50K', 'fixed_amount', 50000, 500000, 50000, 500, 12, '2026-01-01', '2026-12-31', 'active'),
(2, 'VIP10', 'percentage', 10, 2000000, 1000000, 200, 5, '2026-01-01', '2026-12-31', 'active');

-- 12. Bảng Banner Quảng Cáo (banners)
DROP TABLE IF EXISTS `banners`;
CREATE TABLE `banners` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `subtitle` VARCHAR(255) NULL,
  `image_url` VARCHAR(255) NOT NULL,
  `link` VARCHAR(255) DEFAULT '#',
  `position` ENUM('home_slider', 'home_sidebar', 'sale_popup') DEFAULT 'home_slider',
  `sort_order` INT DEFAULT 0,
  `status` ENUM('active', 'inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `banners` (`id`, `title`, `subtitle`, `image_url`, `link`, `position`, `sort_order`, `status`) VALUES
(1, 'iPhone 15 Pro Max - Titan Tự Nhiên', 'Đỉnh cao công nghệ đỉnh phong bứt phá mọi giới hạn', 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?q=80&w=1200&auto=format&fit=crop', 'dien-thoai/iphone-15-pro-max-256gb', 'home_slider', 1, 'active'),
(2, 'Samsung Galaxy S24 Ultra - Quyền Năng AI', 'Mở ra kỷ nguyên điện thoại thông minh thế hệ mới', 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?q=80&w=1200&auto=format&fit=crop', 'dien-thoai/samsung-galaxy-s24-ultra-5g-256gb', 'home_slider', 2, 'active');

-- 13. Bảng Tin Tức Công Nghệ (posts)
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `summary` TEXT NOT NULL,
  `content` LONGTEXT NOT NULL,
  `thumbnail` VARCHAR(255) NOT NULL,
  `author_id` INT NULL,
  `status` ENUM('published', 'draft') DEFAULT 'published',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`author_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `posts` (`id`, `title`, `slug`, `summary`, `content`, `thumbnail`, `author_id`) VALUES
(1, 'Đánh giá chi tiết Galaxy S24 Ultra sau 1 tháng sử dụng: Galaxy AI đỉnh đến đâu?', 'danh-gia-chi-tiet-galaxy-s24-ultra-sau-1-thang', 'Trải nghiệm thực tế các tính năng dịch trực tiếp cuộc gọi, khoanh tròn để tìm kiếm và camera 200MP.', '<p>Galaxy S24 Ultra thể hiện sự toàn diện từ màn hình phẳng chống chói tốt nhất phân khúc đến hiệu năng Snapdragon 8 Gen 3 for Galaxy mạnh mẽ.</p>', 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=600&auto=format&fit=crop', 1),
(2, 'Top 5 mẫu laptop mỏng nhẹ cho lập trình viên và sinh viên kỹ thuật 2026', 'top-5-mau-laptop-mong-nhe-cho-lap-trinh-vien', 'Tổng hợp những cỗ máy cân bằng thời lượng pin, màn hình chuẩn màu sắc và hiệu năng CPU nhiều nhân.', '<p>Lựa chọn laptop phù hợp giúp tăng hiệu suất làm việc vượt trội với các đại diện tiêu biểu như Dell XPS và Asus ROG.</p>', 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=600&auto=format&fit=crop', 1);

-- 14. Bảng Liên Hệ & Góp Ý (contacts)
DROP TABLE IF EXISTS `contacts`;
CREATE TABLE `contacts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `status` ENUM('unread', 'read', 'replied') DEFAULT 'unread',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

