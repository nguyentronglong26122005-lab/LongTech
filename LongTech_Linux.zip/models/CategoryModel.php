<?php
/**
 * ========================================================
 * LONGTECH - MODEL QUẢN LÝ DANH MỤC (CategoryModel.php)
 * ========================================================
 */

require_once __DIR__ . '/Database.php';

class CategoryModel {
    private PDO $db;

    public function __construct() {
        $this->db = Database::connect();
    }

    /**
     * Lấy danh sách tất cả danh mục đang hoạt động
     */
    public function getActiveCategories(): array {
        $sql = "SELECT * FROM `categories` WHERE `status` = 'active' ORDER BY `sort_order` ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }

    /**
     * Lấy toàn bộ danh mục cho trang quản trị
     */
    public function getAllCategories(): array {
        $sql = "SELECT c.*, COUNT(p.id) AS total_products 
                FROM `categories` c 
                LEFT JOIN `products` p ON c.id = p.category_id 
                GROUP BY c.id 
                ORDER BY c.sort_order ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll();
    }

    /**
     * Lấy chi tiết danh mục theo ID
     */
    public function getById(int $id): ?array {
        $stmt = $this->db->prepare("SELECT * FROM `categories` WHERE `id` = :id");
        $stmt->execute([':id' => $id]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    /**
     * Lấy chi tiết danh mục theo Slug
     */
    public function getBySlug(string $slug): ?array {
        $stmt = $this->db->prepare("SELECT * FROM `categories` WHERE `slug` = :slug");
        $stmt->execute([':slug' => $slug]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    /**
     * Thêm danh mục mới
     */
    public function createCategory(array $data): bool {
        $sql = "INSERT INTO `categories` (`name`, `slug`, `icon`, `image`, `status`, `sort_order`) 
                VALUES (:name, :slug, :icon, :image, :status, :sort_order)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':name'       => $data['name'],
            ':slug'       => $data['slug'],
            ':icon'       => $data['icon'] ?? 'fa-cube',
            ':image'      => $data['image'] ?? null,
            ':status'     => $data['status'] ?? 'active',
            ':sort_order' => (int)($data['sort_order'] ?? 0)
        ]);
    }

    /**
     * Cập nhật danh mục
     */
    public function updateCategory(int $id, array $data): bool {
        $sql = "UPDATE `categories` SET 
                `name` = :name, 
                `slug` = :slug, 
                `icon` = :icon, 
                `status` = :status, 
                `sort_order` = :sort_order 
                WHERE `id` = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':name'       => $data['name'],
            ':slug'       => $data['slug'],
            ':icon'       => $data['icon'] ?? 'fa-cube',
            ':status'     => $data['status'] ?? 'active',
            ':sort_order' => (int)($data['sort_order'] ?? 0),
            ':id'         => $id
        ]);
    }

    /**
     * Xóa danh mục
     */
    public function deleteCategory(int $id): bool {
        $stmt = $this->db->prepare("DELETE FROM `categories` WHERE `id` = :id");
        return $stmt->execute([':id' => $id]);
    }
}

