<?php
/**
 * ========================================================
 * LONGTECH - MODEL CẤU HÌNH GIAO DIỆN & LIVE EDITOR (SiteSettingModel.php)
 * ========================================================
 */

require_once __DIR__ . '/Database.php';

class SiteSettingModel {
    private PDO $db;

    public function __construct() {
        $this->db = Database::connect();
        $this->ensureTablesExist();
    }

    /**
     * Tự động khởi tạo các bảng cài đặt giao diện nếu chưa có
     */
    private function ensureTablesExist(): void {
        try {
            $this->db->exec("
                CREATE TABLE IF NOT EXISTS `site_settings` (
                    `key_name` VARCHAR(100) PRIMARY KEY,
                    `value_data` LONGTEXT NULL,
                    `field_type` VARCHAR(50) DEFAULT 'text',
                    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    `updated_by` INT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

                CREATE TABLE IF NOT EXISTS `homepage_sections` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `section_key` VARCHAR(50) NOT NULL UNIQUE,
                    `title` VARCHAR(150) NOT NULL,
                    `sort_order` INT DEFAULT 0,
                    `is_visible` TINYINT(1) DEFAULT 1,
                    `custom_config` LONGTEXT NULL,
                    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

                CREATE TABLE IF NOT EXISTS `site_versions` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `version_name` VARCHAR(150) NOT NULL,
                    `settings_json` LONGTEXT NOT NULL,
                    `sections_json` LONGTEXT NOT NULL,
                    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                    `created_by` INT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
            ");

            // Khởi tạo cài đặt mặc định nếu bảng đang rỗng
            $count = (int)$this->db->query("SELECT COUNT(*) FROM `site_settings`")->fetchColumn();
            if ($count === 0) {
                $defaults = [
                    'site_name'        => 'LongTech - Thế Giới Công Nghệ Hàng Đầu',
                    'site_logo_text'   => 'LONGTECH',
                    'site_primary_color' => '#D70018',
                    'site_secondary_color' => '#0A2540',
                    'site_font'        => 'Inter',
                    'hotline'          => '1900 6868',
                    'contact_email'    => 'support@longtech.vn',
                    'store_address'    => 'Số 123 Đường Công Nghệ, Quận Cầu Giấy, Hà Nội',
                    'facebook_url'     => 'https://facebook.com/longtech',
                    'youtube_url'      => 'https://youtube.com/longtech',
                    'seo_title'        => 'LongTech - Điện thoại, Laptop, Tablet, Phụ kiện chính hãng giá rẻ',
                    'seo_description'  => 'LongTech phân phối thiết bị công nghệ chính hãng Apple, Samsung, Xiaomi với bảo hành 12 tháng, giao hàng hỏa tốc trong 2 giờ.',
                    'seo_keywords'     => 'dien thoai, laptop, tablet, apple, samsung, xiaomi, longtech',
                    'live_mode_draft'  => '0'
                ];
                $stmt = $this->db->prepare("INSERT INTO `site_settings` (`key_name`, `value_data`) VALUES (:k, :v)");
                foreach ($defaults as $k => $v) {
                    $stmt->execute([':k' => $k, ':v' => $v]);
                }
            }

            // Khởi tạo các khối trang chủ mặc định
            $secCount = (int)$this->db->query("SELECT COUNT(*) FROM `homepage_sections`")->fetchColumn();
            if ($secCount === 0) {
                $sections = [
                    ['section_key' => 'hero_banner',     'title' => 'Banner Slider Chính',      'sort_order' => 1, 'is_visible' => 1],
                    ['section_key' => 'categories_bar',  'title' => 'Danh Mục Thiết Bị Nổi Bật', 'sort_order' => 2, 'is_visible' => 1],
                    ['section_key' => 'hot_deals',       'title' => 'Flash Sale Giá Sốc Hôm Nay','sort_order' => 3, 'is_visible' => 1],
                    ['section_key' => 'featured_products','title' => 'Sản Phẩm Bán Chạy Nhất',   'sort_order' => 4, 'is_visible' => 1],
                    ['section_key' => 'brand_showcase',  'title' => 'Thương Hiệu Đối Tác',       'sort_order' => 5, 'is_visible' => 1],
                    ['section_key' => 'latest_news',     'title' => 'Tin Tức & Đánh Giá Mới',    'sort_order' => 6, 'is_visible' => 1],
                ];
                $stmtSec = $this->db->prepare("INSERT INTO `homepage_sections` (`section_key`, `title`, `sort_order`, `is_visible`) VALUES (:k, :t, :s, :v)");
                foreach ($sections as $s) {
                    $stmtSec->execute([':k' => $s['section_key'], ':t' => $s['title'], ':s' => $s['sort_order'], ':v' => $s['is_visible']]);
                }
            }
        } catch (PDOException $e) {
            // Đã tồn tại hoặc ghi nhận lỗi nhẹ
        }
    }

    /**
     * Lấy toàn bộ cấu hình website dạng key-value
     */
    public function getAllSettings(): array {
        $rows = $this->db->query("SELECT `key_name`, `value_data` FROM `site_settings`")->fetchAll(PDO::FETCH_KEY_PAIR);
        return $rows ?: [];
    }

    /**
     * Lấy 1 cài đặt cụ thể
     */
    public function getSetting(string $key, string $default = ''): string {
        $stmt = $this->db->prepare("SELECT `value_data` FROM `site_settings` WHERE `key_name` = :k LIMIT 1");
        $stmt->execute([':k' => $key]);
        $val = $stmt->fetchColumn();
        return ($val !== false && $val !== null) ? (string)$val : $default;
    }

    /**
     * Lưu nhiều cài đặt
     */
    public function saveSettings(array $settings, ?int $userId = null): bool {
        $stmt = $this->db->prepare(
            "INSERT INTO `site_settings` (`key_name`, `value_data`, `updated_by`) 
             VALUES (:k, :v, :u)
             ON DUPLICATE KEY UPDATE `value_data` = VALUES(`value_data`), `updated_by` = VALUES(`updated_by`)"
        );
        foreach ($settings as $k => $v) {
            $stmt->execute([':k' => $k, ':v' => $v, ':u' => $userId]);
        }
        return true;
    }

    /**
     * Lấy danh sách các khối trang chủ đã sắp xếp
     */
    public function getHomepageSections(): array {
        $stmt = $this->db->query("SELECT * FROM `homepage_sections` ORDER BY `sort_order` ASC, `id` ASC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Cập nhật sắp xếp và trạng thái ẩn/hiện các khối
     */
    public function updateHomepageSections(array $sections): bool {
        $stmt = $this->db->prepare("UPDATE `homepage_sections` SET `sort_order` = :order, `is_visible` = :vis WHERE `section_key` = :key");
        foreach ($sections as $sec) {
            $stmt->execute([
                ':order' => (int)($sec['sort_order'] ?? 0),
                ':vis'   => !empty($sec['is_visible']) ? 1 : 0,
                ':key'   => $sec['section_key']
            ]);
        }
        return true;
    }

    /**
     * Lưu phiên bản lịch sử
     */
    public function createVersion(string $versionName, ?int $userId = null): int {
        $settings = $this->getAllSettings();
        $sections = $this->getHomepageSections();

        $stmt = $this->db->prepare(
            "INSERT INTO `site_versions` (`version_name`, `settings_json`, `sections_json`, `created_by`, `created_at`) 
             VALUES (:name, :set_json, :sec_json, :u, NOW())"
        );
        $stmt->execute([
            ':name'     => $versionName,
            ':set_json' => json_encode($settings, JSON_UNESCAPED_UNICODE),
            ':sec_json' => json_encode($sections, JSON_UNESCAPED_UNICODE),
            ':u'        => $userId
        ]);
        return (int)$this->db->lastInsertId();
    }

    /**
     * Khôi phục từ một phiên bản lịch sử
     */
    public function restoreVersion(int $versionId, ?int $userId = null): bool {
        $stmt = $this->db->prepare("SELECT * FROM `site_versions` WHERE `id` = :id LIMIT 1");
        $stmt->execute([':id' => $versionId]);
        $ver = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$ver) return false;

        $settings = json_decode($ver['settings_json'], true) ?? [];
        $sections = json_decode($ver['sections_json'], true) ?? [];

        if (!empty($settings)) {
            $this->saveSettings($settings, $userId);
        }
        if (!empty($sections)) {
            $this->updateHomepageSections($sections);
        }
        return true;
    }

    /**
     * Lấy danh sách các phiên bản đã lưu
     */
    public function getVersionList(): array {
        $stmt = $this->db->query("SELECT v.*, u.full_name AS creator_name FROM `site_versions` v LEFT JOIN `users` u ON v.created_by = u.id ORDER BY v.created_at DESC LIMIT 20");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

