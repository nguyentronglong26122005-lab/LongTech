<?php
/**
 * ========================================================
 * LONGTECH - MODEL QUẢN LÝ ĐƠN HÀNG & MÃ GIẢM GIÁ (OrderModel.php)
 * ========================================================
 * - Quản lý CSDL bảng `orders`, `order_items`, `coupons`, `contacts`
 * - Sử dụng PDO Transaction đảm bảo toàn vẹn dữ liệu
 * - Tự động trừ tồn kho khi đặt hàng và hoàn lại tồn kho khi hủy đơn
 * - Xử lý tính toán mã giảm giá (Coupon)
 */

require_once __DIR__ . '/Database.php';

class OrderModel {
    private PDO $db;

    public function __construct() {
        $this->db = Database::connect();
    }

    /**
     * 1. Tạo đơn hàng mới kèm trừ tồn kho tự động (PDO Transaction)
     */
    public function createOrder(array $orderData, array $cartItems): array {
        try {
            $this->db->beginTransaction();

            // Tạo mã đơn hàng duy nhất dạng: LT-YYYYMMDD-XXXX
            $orderCode = 'LT-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));

            $sqlOrder = "INSERT INTO `orders` (
                `order_code`, `user_id`, `customer_name`, `customer_email`, `customer_phone`,
                `customer_address`, `city`, `district`, `ward`, `note`,
                `payment_method`, `payment_status`, `shipping_fee`, `discount_amount`,
                `subtotal`, `total_amount`, `status`
            ) VALUES (
                :order_code, :user_id, :customer_name, :customer_email, :customer_phone,
                :customer_address, :city, :district, :ward, :note,
                :payment_method, :payment_status, :shipping_fee, :discount_amount,
                :subtotal, :total_amount, 'pending'
            )";

            $stmtOrder = $this->db->prepare($sqlOrder);
            $stmtOrder->execute([
                ':order_code'        => $orderCode,
                ':user_id'           => $orderData['user_id'] ?? null,
                ':customer_name'     => $orderData['customer_name'],
                ':customer_email'    => $orderData['customer_email'],
                ':customer_phone'    => $orderData['customer_phone'],
                ':customer_address'  => $orderData['customer_address'],
                ':city'              => $orderData['city'],
                ':district'          => $orderData['district'],
                ':ward'              => $orderData['ward'],
                ':note'              => $orderData['note'] ?? null,
                ':payment_method'    => $orderData['payment_method'] ?? 'cod',
                ':payment_status'    => ($orderData['payment_method'] === 'bank_transfer') ? 'unpaid' : 'unpaid',
                ':shipping_fee'      => (float)($orderData['shipping_fee'] ?? 0),
                ':discount_amount'   => (float)($orderData['discount_amount'] ?? 0),
                ':subtotal'          => (float)$orderData['subtotal'],
                ':total_amount'      => (float)$orderData['total_amount']
            ]);

            $orderId = (int)$this->db->lastInsertId();

            // Chuẩn bị câu lệnh thêm chi tiết đơn và trừ tồn kho
            $sqlItem = "INSERT INTO `order_items` (
                `order_id`, `product_id`, `product_name`, `product_price`, `quantity`, `color`, `storage`, `total_price`
            ) VALUES (
                :order_id, :product_id, :product_name, :product_price, :quantity, :color, :storage, :total_price
            )";
            $stmtItem = $this->db->prepare($sqlItem);

            $sqlUpdateStock = "UPDATE `products` SET `stock_quantity` = GREATEST(0, `stock_quantity` - :qty) WHERE `id` = :pid";
            $stmtStock = $this->db->prepare($sqlUpdateStock);

            foreach ($cartItems as $item) {
                $lineTotal = (float)$item['price'] * (int)$item['quantity'];

                $stmtItem->execute([
                    ':order_id'      => $orderId,
                    ':product_id'    => $item['id'],
                    ':product_name'  => $item['name'],
                    ':product_price' => (float)$item['price'],
                    ':quantity'      => (int)$item['quantity'],
                    ':color'         => $item['color'] ?? null,
                    ':storage'       => $item['storage'] ?? null,
                    ':total_price'   => $lineTotal
                ]);

                // Tự động trừ số lượng tồn kho của sản phẩm
                $stmtStock->execute([
                    ':qty' => (int)$item['quantity'],
                    ':pid' => $item['id']
                ]);
            }

            // Nếu có áp dụng coupon, tăng số lần đã sử dụng
            if (!empty($orderData['coupon_code'])) {
                $stmtCoupon = $this->db->prepare("UPDATE `coupons` SET `used_count` = `used_count` + 1 WHERE `code` = :code");
                $stmtCoupon->execute([':code' => $orderData['coupon_code']]);
            }

            $this->db->commit();

            return [
                'status'     => true,
                'order_id'   => $orderId,
                'order_code' => $orderCode,
                'message'    => 'Đặt hàng thành công!'
            ];
        } catch (Exception $e) {
            $this->db->rollBack();
            return [
                'status'  => false,
                'message' => 'Lỗi xử lý đơn hàng: ' . $e->getMessage()
            ];
        }
    }

    /**
     * 2. Lấy thông tin đơn hàng theo ID
     */
    public function getOrderById(int $orderId): ?array {
        $stmt = $this->db->prepare("SELECT * FROM `orders` WHERE `id` = :id LIMIT 1");
        $stmt->execute([':id' => $orderId]);
        $order = $stmt->fetch();
        return $order ?: null;
    }

    /**
     * 3. Lấy thông tin đơn hàng theo Mã Đơn
     */
    public function getOrderByCode(string $orderCode): ?array {
        $stmt = $this->db->prepare("SELECT * FROM `orders` WHERE `order_code` = :code LIMIT 1");
        $stmt->execute([':code' => $orderCode]);
        $order = $stmt->fetch();
        return $order ?: null;
    }

    /**
     * 4. Lấy danh sách sản phẩm trong đơn hàng
     */
    public function getOrderItems(int $orderId): array {
        $sql = "SELECT oi.*, p.thumbnail, p.slug 
                FROM `order_items` oi
                LEFT JOIN `products` p ON oi.product_id = p.id
                WHERE oi.`order_id` = :oid";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':oid' => $orderId]);
        return $stmt->fetchAll();
    }

    /**
     * 5. Kiểm tra và áp dụng Mã giảm giá (Coupon)
     */
    public function applyCoupon(string $code, float $subtotal): array {
        $code = strtoupper(trim($code));
        $today = date('Y-m-d');

        $stmt = $this->db->prepare("SELECT * FROM `coupons` WHERE `code` = :code AND `status` = 'active' LIMIT 1");
        $stmt->execute([':code' => $code]);
        $coupon = $stmt->fetch();

        if (!$coupon) {
            return ['status' => false, 'message' => 'Mã giảm giá không tồn tại hoặc đã hết hạn.'];
        }

        if ($today < $coupon['start_date'] || $today > $coupon['end_date']) {
            return ['status' => false, 'message' => 'Mã giảm giá hiện tại chưa đến đợt hoặc đã hết hạn áp dụng.'];
        }

        if ($coupon['used_count'] >= $coupon['usage_limit']) {
            return ['status' => false, 'message' => 'Mã giảm giá đã đạt giới hạn lượt sử dụng.'];
        }

        if ($subtotal < (float)$coupon['min_order_value']) {
            return [
                'status'  => false,
                'message' => 'Đơn hàng chưa đạt giá trị tối thiểu ' . format_money($coupon['min_order_value']) . ' để áp dụng mã này.'
            ];
        }

        // Tính số tiền giảm giá
        $discount = 0;
        if ($coupon['type'] === 'percentage') {
            $discount = $subtotal * ((float)$coupon['value'] / 100);
            if (!empty($coupon['max_discount']) && $discount > (float)$coupon['max_discount']) {
                $discount = (float)$coupon['max_discount'];
            }
        } else {
            // Giảm số tiền cố định
            $discount = (float)$coupon['value'];
        }

        $discount = min($discount, $subtotal);

        return [
            'status'   => true,
            'message'  => 'Áp dụng mã giảm giá thành công! Bạn được giảm ' . format_money($discount),
            'discount' => $discount,
            'coupon'   => $coupon
        ];
    }

    /**
     * 6. Hủy đơn hàng và tự động hoàn lại số lượng tồn kho
     */
    public function cancelOrder(int $orderId, int $userId = 0): bool {
        try {
            $this->db->beginTransaction();

            $sqlCheck = "SELECT * FROM `orders` WHERE `id` = :id";
            if ($userId > 0) {
                $sqlCheck .= " AND `user_id` = :uid";
            }
            $stmtCheck = $this->db->prepare($sqlCheck);
            $params = [':id' => $orderId];
            if ($userId > 0) $params[':uid'] = $userId;
            $stmtCheck->execute($params);
            $order = $stmtCheck->fetch();

            if (!$order || in_array($order['status'], ['completed', 'cancelled', 'shipping'])) {
                $this->db->rollBack();
                return false;
            }

            // Cập nhật trạng thái hủy đơn
            $stmtUpdate = $this->db->prepare("UPDATE `orders` SET `status` = 'cancelled' WHERE `id` = :id");
            $stmtUpdate->execute([':id' => $orderId]);

            // Lấy danh sách sản phẩm của đơn để hoàn kho
            $items = $this->getOrderItems($orderId);
            $stmtRestore = $this->db->prepare("UPDATE `products` SET `stock_quantity` = `stock_quantity` + :qty WHERE `id` = :pid");

            foreach ($items as $item) {
                $stmtRestore->execute([
                    ':qty' => (int)$item['quantity'],
                    ':pid' => $item['product_id']
                ]);
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }

    /**
     * 7. Lưu tin nhắn liên hệ / góp ý
     */
    public function saveContact(array $data): bool {
        $sql = "INSERT INTO `contacts` (`full_name`, `email`, `phone`, `subject`, `message`, `status`) 
                VALUES (:full_name, :email, :phone, :subject, :message, 'unread')";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':full_name' => $data['full_name'],
            ':email'     => $data['email'],
            ':phone'     => $data['phone'] ?? null,
            ':subject'   => $data['subject'],
            ':message'   => $data['message']
        ]);
    }

    /**
     * 8. Lấy tất cả đơn hàng cho trang Admin
     */
    public function getAllOrders(string $statusFilter = '', string $keyword = ''): array {
        $sql = "SELECT * FROM `orders` WHERE 1=1";
        $params = [];

        if (!empty($statusFilter)) {
            $sql .= " AND `status` = :st";
            $params[':st'] = $statusFilter;
        }

        if (!empty($keyword)) {
            $sql .= " AND (`order_code` LIKE :kw OR `customer_name` LIKE :kw OR `customer_phone` LIKE :kw)";
            $params[':kw'] = "%$keyword%";
        }

        $sql .= " ORDER BY `created_at` DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * 9. Cập nhật trạng thái đơn hàng (Dành cho Admin / NV Đơn hàng)
     * Tự động hoàn tồn kho nếu chuyển sang 'cancelled'
     */
    public function updateOrderStatus(int $orderId, string $newStatus, string $paymentStatus = ''): bool {
        try {
            $this->db->beginTransaction();

            $order = $this->getOrderById($orderId);
            if (!$order) {
                $this->db->rollBack();
                return false;
            }

            $oldStatus = $order['status'];

            // Nếu hủy đơn mà trước đó chưa hủy -> tự động hoàn kho
            if ($newStatus === 'cancelled' && $oldStatus !== 'cancelled') {
                $items = $this->getOrderItems($orderId);
                $stmtRestore = $this->db->prepare("UPDATE `products` SET `stock_quantity` = `stock_quantity` + :qty WHERE `id` = :pid");
                foreach ($items as $item) {
                    $stmtRestore->execute([
                        ':qty' => (int)$item['quantity'],
                        ':pid' => $item['product_id']
                    ]);
                }
            }
            // Nếu khôi phục đơn từ 'cancelled' sang trạng thái khác -> trừ kho lại
            elseif ($oldStatus === 'cancelled' && $newStatus !== 'cancelled') {
                $items = $this->getOrderItems($orderId);
                $stmtDeduct = $this->db->prepare("UPDATE `products` SET `stock_quantity` = GREATEST(0, `stock_quantity` - :qty) WHERE `id` = :pid");
                foreach ($items as $item) {
                    $stmtDeduct->execute([
                        ':qty' => (int)$item['quantity'],
                        ':pid' => $item['product_id']
                    ]);
                }
            }

            $sql = "UPDATE `orders` SET `status` = :st";
            $params = [':st' => $newStatus, ':id' => $orderId];

            if (!empty($paymentStatus)) {
                $sql .= ", `payment_status` = :pst";
                $params[':pst'] = $paymentStatus;
            }

            $sql .= " WHERE `id` = :id";
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }
}

