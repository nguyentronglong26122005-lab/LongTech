<?php
/**
 * ========================================================
 * LONGTECH - LỚP KẾT NỐI CƠ SỞ DỮ LIỆU (Database.php)
 * ========================================================
 * - Sử dụng PDO Prepared Statements chống SQL Injection
 * - Áp dụng mẫu thiết kế Singleton tối ưu tài nguyên kết nối
 * - XỬ LÝ ĐẶC THÙ: Bắt buộc kết nối MySQL thành công mới hiển thị website;
 *   nếu mất kết nối hoặc sai cấu hình, website TUYỆT ĐỐI không hiện ra
 *   mà lập tức hiển thị trang thông báo yêu cầu kết nối SQL chi tiết.
 */

// Đảm bảo file cấu hình đã được nạp
if (!defined('DB_HOST')) {
    require_once __DIR__ . '/../config.php';
}

class Database {
    private static ?PDO $instance = null;

    /**
     * Khởi tạo kết nối PDO duy nhất (Singleton Pattern)
     */
    public static function connect(): PDO {
        if (self::$instance === null) {
            $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
            ];

            try {
                self::$instance = new PDO($dsn, DB_USER, DB_PASS, $options);
            } catch (PDOException $e) {
                // Khi kết nối thất bại, TUYỆT ĐỐI KHÔNG hiển thị website chính
                // Gọi hàm hiển thị giao diện thông báo yêu cầu kết nối CSDL và dừng hẳn chương trình
                self::renderConnectionErrorScreen($e->getMessage());
                exit();
            }
        }

        return self::$instance;
    }

    /**
     * Hiển thị giao diện thông báo lỗi kết nối CSDL chuẩn giao diện, có hướng dẫn XAMPP & .env
     */
    private static function renderConnectionErrorScreen(string $errorMessage): void {
        // Thiết lập mã HTTP 500
        http_response_code(500);
        ?>
        <!DOCTYPE html>
        <html lang="vi">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Yêu Cầu Kết Nối Cơ Sở Dữ Liệu - LongTech</title>
            <style>
                * { box-sizing: border-box; margin: 0; padding: 0; }
                body {
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                    background-color: #f0f4f8;
                    color: #1e293b;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    min-height: 100vh;
                    padding: 20px;
                }
                .error-card {
                    background: #ffffff;
                    max-width: 680px;
                    width: 100%;
                    border-radius: 16px;
                    box-shadow: 0 10px 25px -5px rgba(10, 37, 64, 0.1), 0 8px 10px -6px rgba(10, 37, 64, 0.1);
                    border-top: 6px solid #D70018;
                    overflow: hidden;
                }
                .error-header {
                    padding: 28px 32px 20px;
                    border-bottom: 1px solid #e2e8f0;
                    text-align: center;
                }
                .logo-brand {
                    font-size: 26px;
                    font-weight: 800;
                    color: #0A2540;
                    letter-spacing: -0.5px;
                    margin-bottom: 12px;
                }
                .logo-brand span { color: #FF6B35; }
                .icon-alert {
                    width: 56px;
                    height: 56px;
                    background: #fee2e2;
                    color: #D70018;
                    border-radius: 50%;
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 28px;
                    margin-bottom: 14px;
                }
                .title {
                    font-size: 22px;
                    font-weight: 700;
                    color: #0A2540;
                    margin-bottom: 6px;
                }
                .subtitle {
                    color: #64748b;
                    font-size: 15px;
                    line-height: 1.5;
                }
                .error-body {
                    padding: 28px 32px;
                }
                .detail-box {
                    background: #fff1f2;
                    border: 1px solid #fecdd3;
                    border-radius: 8px;
                    padding: 14px 18px;
                    font-size: 13px;
                    color: #9f1239;
                    font-family: Consolas, monospace;
                    margin-bottom: 24px;
                    word-break: break-all;
                }
                .instructions-title {
                    font-size: 16px;
                    font-weight: 700;
                    color: #0A2540;
                    margin-bottom: 12px;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }
                .step-list {
                    list-style: none;
                    counter-reset: step-counter;
                }
                .step-list li {
                    counter-increment: step-counter;
                    position: relative;
                    padding-left: 36px;
                    margin-bottom: 14px;
                    font-size: 14px;
                    line-height: 1.6;
                    color: #334155;
                }
                .step-list li::before {
                    content: counter(step-counter);
                    position: absolute;
                    left: 0;
                    top: 1px;
                    width: 24px;
                    height: 24px;
                    background: #0A2540;
                    color: #ffffff;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 12px;
                    font-weight: 700;
                }
                .code-pill {
                    background: #e2e8f0;
                    padding: 2px 6px;
                    border-radius: 4px;
                    font-family: monospace;
                    font-size: 13px;
                    color: #0f172a;
                }
                .action-footer {
                    background: #f8fafc;
                    padding: 20px 32px;
                    border-top: 1px solid #e2e8f0;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    flex-wrap: wrap;
                    gap: 12px;
                }
                .btn-retry {
                    display: inline-flex;
                    align-items: center;
                    gap: 8px;
                    background: #0A2540;
                    color: #ffffff;
                    font-weight: 600;
                    font-size: 14px;
                    padding: 10px 22px;
                    border-radius: 8px;
                    text-decoration: none;
                    transition: background 0.2s;
                    border: none;
                    cursor: pointer;
                }
                .btn-retry:hover { background: #FF6B35; }
                .support-text {
                    font-size: 13px;
                    color: #64748b;
                }
            </style>
        </head>
        <body>
            <div class="error-card">
                <div class="error-header">
                    <div class="logo-brand">LONG<span>TECH</span></div>
                    <div class="icon-alert">⚠️</div>
                    <h1 class="title">Yêu Cầu Kết Nối Cơ Sở Dữ Liệu</h1>
                    <p class="subtitle">Website không thể hiển thị do chưa kết nối được đến máy chủ MySQL. Vui lòng cấu hình CSDL để tiếp tục sử dụng hệ thống.</p>
                </div>
                <div class="error-body">
                    <div class="detail-box">
                        <strong>Thông báo lỗi hệ thống:</strong> <?= htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8') ?>
                    </div>

                    <div class="instructions-title">
                        <span>🛠️</span> Các bước khắc phục trên XAMPP Localhost:
                    </div>
                    <ol class="step-list">
                        <li>
                            <strong>Khởi động dịch vụ MySQL:</strong> Mở bảng điều khiển <strong>XAMPP Control Panel</strong>, tìm dòng <strong>MySQL</strong> và bấm nút <strong>Start</strong> (màu xanh lá).
                        </li>
                        <li>
                            <strong>Tạo cơ sở dữ liệu:</strong> Truy cập vào <a href="http://localhost/phpmyadmin/" target="_blank" style="color: #0A2540; font-weight: 600;">phpMyAdmin</a>, tạo một database mới có tên là <span class="code-pill"><?= htmlspecialchars(DB_NAME) ?></span> với Collation là <span class="code-pill">utf8mb4_unicode_ci</span>.
                        </li>
                        <li>
                            <strong>Import dữ liệu mẫu:</strong> Bấm vào tab <strong>Import</strong> trong phpMyAdmin và chọn file <span class="code-pill">longtech.sql</span> nằm ngay thư mục gốc của dự án để tạo toàn bộ bảng và dữ liệu khởi tạo.
                        </li>
                        <li>
                            <strong>Kiểm tra file cấu hình .env:</strong> Đảm bảo các thông số trong file <span class="code-pill">.env</span> khớp với môi trường XAMPP (mặc định: host=<span class="code-pill">127.0.0.1</span>, port=<span class="code-pill">3306</span>, user=<span class="code-pill">root</span>, password=<span class="code-pill">rỗng</span>).
                        </li>
                    </ol>
                </div>
                <div class="action-footer">
                    <span class="support-text">Mã dự án: LongTech Core Engine v1.0</span>
                    <button class="btn-retry" onclick="window.location.reload();">
                        🔄 Thử kết nối lại
                    </button>
                </div>
            </div>
        </body>
        </html>
        <?php
    }

    /**
     * Ngăn chặn clone và unserialize instance để bảo đảm Singleton
     */
    private function __construct() {}
    private function __clone() {}
    public function __wakeup() {
        throw new Exception("Không thể unserialize lớp Database Singleton.");
    }
}

