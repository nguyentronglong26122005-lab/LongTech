<?php
/**
 * ========================================================
 * LONGTECH - MODEL HỎI ĐÁP KHÁCH HÀNG (FaqModel.php)
 * Quản lý câu hỏi và câu trả lời kiểu CellphoneS
 * ========================================================
 */

require_once __DIR__ . '/Database.php';

class FaqModel {
    private PDO $db;

    public function __construct() {
        $this->db = Database::connect();
        $this->ensureTables();
    }

    private function ensureTables(): void {
        try {
            $this->db->exec("
                CREATE TABLE IF NOT EXISTS `product_questions` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `product_id` INT NULL,
                    `user_id` INT NULL,
                    `author_name` VARCHAR(100) NOT NULL,
                    `author_phone` VARCHAR(20) NULL,
                    `question_text` TEXT NOT NULL,
                    `status` ENUM('approved', 'pending', 'hidden') DEFAULT 'approved',
                    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

                CREATE TABLE IF NOT EXISTS `question_replies` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `question_id` INT NOT NULL,
                    `user_id` INT NULL,
                    `reply_text` TEXT NOT NULL,
                    `is_admin` TINYINT(1) DEFAULT 1,
                    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (`question_id`) REFERENCES `product_questions`(`id`) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
            ");

            // Tạo vài câu hỏi mẫu nếu đang rỗng
            $count = (int)$this->db->query("SELECT COUNT(*) FROM `product_questions`")->fetchColumn();
            if ($count === 0) {
                $stmtQ = $this->db->prepare("INSERT INTO `product_questions` (`author_name`, `question_text`, `status`, `created_at`) VALUES (:name, :q, 'approved', NOW())");
                $stmtQ->execute([
                    ':name' => 'Tô Tuấn',
                    ':q'    => 'Tôi cần mua iPhone 16 Pro Max 256GB thanh toán trực tiếp qua chuyển khoản ngân hàng thì có được giảm thêm ưu đãi gì không ạ?'
                ]);
                $qId = (int)$this->db->lastInsertId();

                $stmtR = $this->db->prepare("INSERT INTO `question_replies` (`question_id`, `reply_text`, `is_admin`, `created_at`) VALUES (:qid, :r, 1, NOW())");
                $stmtR->execute([
                    ':qid' => $qId,
                    ':r'   => "Chào anh Tuấn! Dạ khi thanh toán chuyển khoản trực tiếp hoặc quét mã VNPAY-QR tại LongTech, bên em đang có ưu đãi chiết khấu thêm 1% tối đa 300.000đ và tặng kèm gói dán cường lực cao cấp anh nhé. Anh có thể để lại số điện thoại hoặc đặt hàng online để nhân viên bên em giữ hàng cho mình ạ!"
                ]);
            }
        } catch (PDOException $e) {
            // Đã tồn tại
        }
    }

    /**
     * Lấy danh sách câu hỏi kèm câu trả lời
     */
    public function getQuestions(?int $productId = null, int $limit = 10): array {
        $sql = "SELECT q.*, (SELECT COUNT(*) FROM `question_replies` r WHERE r.question_id = q.id) AS reply_count 
                FROM `product_questions` q 
                WHERE q.status = 'approved'";
        $params = [];

        if ($productId !== null && $productId > 0) {
            $sql .= " AND (q.product_id = :pid OR q.product_id IS NULL)";
            $params[':pid'] = $productId;
        }

        $sql .= " ORDER BY q.created_at DESC LIMIT " . (int)$limit;
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Nạp replies cho từng câu hỏi
        $replyStmt = $this->db->prepare(
            "SELECT r.*, u.full_name AS admin_name 
             FROM `question_replies` r 
             LEFT JOIN `users` u ON r.user_id = u.id 
             WHERE r.question_id = :qid 
             ORDER BY r.created_at ASC"
        );

        foreach ($questions as &$q) {
            $replyStmt->execute([':qid' => $q['id']]);
            $q['replies'] = $replyStmt->fetchAll(PDO::FETCH_ASSOC);
        }

        return $questions;
    }

    /**
     * Thêm câu hỏi mới từ khách
     */
    public function addQuestion(string $authorName, string $question, ?string $phone = null, ?int $productId = null, ?int $userId = null): int {
        $stmt = $this->db->prepare(
            "INSERT INTO `product_questions` (`product_id`, `user_id`, `author_name`, `author_phone`, `question_text`, `status`, `created_at`) 
             VALUES (:pid, :uid, :name, :phone, :q, 'approved', NOW())"
        );
        $stmt->execute([
            ':pid'   => $productId,
            ':uid'   => $userId,
            ':name'  => $authorName,
            ':phone' => $phone,
            ':q'     => $question
        ]);
        return (int)$this->db->lastInsertId();
    }

    /**
     * Thêm câu trả lời (từ Quản trị viên QTV)
     */
    public function addReply(int $questionId, string $replyText, ?int $userId = null): bool {
        $stmt = $this->db->prepare(
            "INSERT INTO `question_replies` (`question_id`, `user_id`, `reply_text`, `is_admin`, `created_at`) 
             VALUES (:qid, :uid, :r, 1, NOW())"
        );
        return $stmt->execute([
            ':qid' => $questionId,
            ':uid' => $userId,
            ':r'   => $replyText
        ]);
    }

    /**
     * Lấy toàn bộ câu hỏi cho Admin quản lý
     */
    public function getAllForAdmin(): array {
        $stmt = $this->db->query("SELECT q.*, p.name AS product_name FROM `product_questions` q LEFT JOIN `products` p ON q.product_id = p.id ORDER BY q.created_at DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

