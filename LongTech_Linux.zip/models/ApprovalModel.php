<?php
/**
 * ========================================================
 * LONGTECH - MODEL QUẢN LÝ PHÊ DUYỆT THAO TÁC (ApprovalModel.php)
 * ========================================================
 * Lưu trữ và xử lý các yêu cầu thao tác của nhân viên gửi lên Admin duyệt
 */

require_once __DIR__ . '/Database.php';

class ApprovalModel {
    private PDO $db;

    public function __construct() {
        $this->db = Database::connect();
        $this->ensureTable();
    }

    /**
     * Tự động khởi tạo bảng pending_approvals nếu chưa tồn tại
     */
    private function ensureTable(): void {
        try {
            $this->db->exec("
                CREATE TABLE IF NOT EXISTS `pending_approvals` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `user_id` INT NOT NULL,
                    `username` VARCHAR(100) NOT NULL,
                    `full_name` VARCHAR(150) NULL,
                    `user_permissions` VARCHAR(255) NULL,
                    `action_key` VARCHAR(100) NOT NULL,
                    `module_name` VARCHAR(100) NOT NULL,
                    `action_title` VARCHAR(255) NOT NULL,
                    `action_summary` TEXT NULL,
                    `get_data` LONGTEXT NULL,
                    `post_data` LONGTEXT NULL,
                    `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
                    `admin_note` VARCHAR(255) NULL,
                    `reviewed_by` VARCHAR(100) NULL,
                    `reviewed_at` DATETIME NULL,
                    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
            ");
        } catch (Throwable $e) {
            // Bỏ qua nếu lỗi quyền
        }
    }

    /**
     * Tạo yêu cầu phê duyệt mới từ nhân viên
     */
    public function createRequest(array $data): int {
        $stmt = $this->db->prepare("
            INSERT INTO `pending_approvals` (
                `user_id`, `username`, `full_name`, `user_permissions`,
                `action_key`, `module_name`, `action_title`, `action_summary`,
                `get_data`, `post_data`, `status`, `created_at`
            ) VALUES (
                :uid, :uname, :fname, :uperms,
                :akey, :mod, :title, :summary,
                :gdata, :pdata, 'pending', NOW()
            )
        ");
        $stmt->execute([
            ':uid'     => (int)$data['user_id'],
            ':uname'   => $data['username'],
            ':fname'   => $data['full_name'] ?? $data['username'],
            ':uperms'  => $data['user_permissions'] ?? '',
            ':akey'    => $data['action_key'],
            ':mod'     => $data['module_name'],
            ':title'   => $data['action_title'],
            ':summary' => $data['action_summary'] ?? '',
            ':gdata'   => json_encode($data['get_data'] ?? [], JSON_UNESCAPED_UNICODE),
            ':pdata'   => json_encode($data['post_data'] ?? [], JSON_UNESCAPED_UNICODE)
        ]);
        return (int)$this->db->lastInsertId();
    }

    /**
     * Lấy chi tiết 1 yêu cầu theo ID
     */
    public function getById(int $id): ?array {
        $stmt = $this->db->prepare("SELECT * FROM `pending_approvals` WHERE `id` = :id LIMIT 1");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * Lấy danh sách yêu cầu (Admin xem toàn bộ, Nhân viên xem của chính mình)
     */
    public function getRequests(string $statusFilter = '', ?int $onlyUserId = null): array {
        $sql = "SELECT * FROM `pending_approvals` WHERE 1=1";
        $params = [];

        if ($statusFilter !== '' && in_array($statusFilter, ['pending', 'approved', 'rejected'], true)) {
            $sql .= " AND `status` = :st";
            $params[':st'] = $statusFilter;
        }
        if ($onlyUserId !== null && $onlyUserId > 0) {
            $sql .= " AND `user_id` = :uid";
            $params[':uid'] = $onlyUserId;
        }

        $sql .= " ORDER BY CASE WHEN `status` = 'pending' THEN 0 ELSE 1 END ASC, `id` DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Đếm số lượng yêu cầu đang chờ duyệt (pending)
     */
    public function countPending(?int $onlyUserId = null): int {
        try {
            if ($onlyUserId !== null && $onlyUserId > 0) {
                $stmt = $this->db->prepare("SELECT COUNT(*) FROM `pending_approvals` WHERE `status` = 'pending' AND `user_id` = :uid");
                $stmt->execute([':uid' => $onlyUserId]);
                return (int)$stmt->fetchColumn();
            }
            return (int)$this->db->query("SELECT COUNT(*) FROM `pending_approvals` WHERE `status` = 'pending'")->fetchColumn();
        } catch (Throwable $e) {
            return 0;
        }
    }

    /**
     * Cập nhật trạng thái yêu cầu (approved / rejected)
     */
    public function updateStatus(int $id, string $status, string $reviewedBy, string $note = ''): bool {
        $stmt = $this->db->prepare("
            UPDATE `pending_approvals`
            SET `status` = :st, `reviewed_by` = :by, `admin_note` = :note, `reviewed_at` = NOW()
            WHERE `id` = :id
        ");
        return $stmt->execute([
            ':st'   => $status,
            ':by'   => $reviewedBy,
            ':note' => $note,
            ':id'   => $id
        ]);
    }
}

