<?php
/**
 * ========================================================
 * LONGTECH - MODEL QUẢN LÝ TÀI KHOẢN NGƯỜI DÙNG (UserModel.php)
 * ========================================================
 * - Thao tác CSDL bảng `users` và `roles` bằng PDO Prepared Statements
 * - Cơ chế băm mật khẩu an toàn chuẩn PHP password_hash / password_verify
 * - Kiểm tra trạng thái tài khoản (khóa/mở) và phân quyền 5 cấp độ
 */

require_once __DIR__ . '/Database.php';

class UserModel {
    private PDO $db;

    public function __construct() {
        $this->db = Database::connect();
        $this->ensureSchema();
    }

    /**
     * Tự động bổ sung cột permissions và require_password_change nếu chưa có
     */
    private function ensureSchema(): void {
        static $checked = false;
        if ($checked) return;
        $checked = true;

        try {
            $cols = $this->db->query("SHOW COLUMNS FROM `users`")->fetchAll(PDO::FETCH_COLUMN);
            if (!in_array('permissions', $cols, true)) {
                $this->db->exec("ALTER TABLE `users` ADD COLUMN `permissions` TEXT NULL AFTER `role_id`");
            }
            if (!in_array('require_password_change', $cols, true)) {
                $this->db->exec("ALTER TABLE `users` ADD COLUMN `require_password_change` TINYINT(1) DEFAULT 0 AFTER `status`");
            }
        } catch (Throwable $e) {
            // Bỏ qua nếu chưa có bảng
        }
    }

    /**
     * 1. Tìm tài khoản theo Email hoặc Username kèm thông tin Quyền hạn
     */
    public function findByUsernameOrEmail(string $keyword): ?array {
        $sql = "SELECT u.*, r.name AS role_name, r.display_name AS role_display 
                FROM `users` u 
                LEFT JOIN `roles` r ON u.role_id = r.id 
                WHERE u.email = :email_kw OR u.username = :user_kw 
                LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':email_kw' => $keyword,
            ':user_kw'  => $keyword
        ]);
        $user = $stmt->fetch();
        return $user ?: null;
    }

    /**
     * 2. Tìm tài khoản theo ID
     */
    public function findById(int $id): ?array {
        $sql = "SELECT u.*, r.name AS role_name, r.display_name AS role_display 
                FROM `users` u 
                LEFT JOIN `roles` r ON u.role_id = r.id 
                WHERE u.id = :id 
                LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        $user = $stmt->fetch();
        return $user ?: null;
    }

    /**
     * 3. Kiểm tra đăng nhập (Xác thực mật khẩu và trạng thái hoạt động)
     */
    public function authenticate(string $usernameOrEmail, string $password): array {
        $user = $this->findByUsernameOrEmail($usernameOrEmail);

        if (!$user) {
            return [
                'status'  => false,
                'message' => 'Tài khoản hoặc email không tồn tại trên hệ thống.'
            ];
        }

        // Kiểm tra tài khoản có bị khóa không
        if ($user['status'] === 'locked') {
            return [
                'status'  => false,
                'message' => 'Tài khoản của bạn đã bị tạm khóa bởi quản trị viên. Vui lòng liên hệ hỗ trợ!'
            ];
        }

        // Xác thực mật khẩu qua password_verify
        $isMatch = password_verify($password, $user['password']);

        // Hỗ trợ dự phòng nếu cập nhật thủ công plain text trong phpMyAdmin: tự động băm lại mật khẩu chuẩn
        if (!$isMatch && ($user['password'] === $password || $user['password'] === md5($password))) {
            $isMatch = true;
            // Tự động nâng cấp băm mật khẩu mới chuẩn bcrypt
            $newHash = password_hash($password, PASSWORD_BCRYPT);
            $updateStmt = $this->db->prepare("UPDATE `users` SET `password` = :pwd WHERE `id` = :id");
            $updateStmt->execute([':pwd' => $newHash, ':id' => $user['id']]);
        }

        if (!$isMatch) {
            return [
                'status'  => false,
                'message' => 'Mật khẩu đăng nhập không chính xác. Vui lòng thử lại!'
            ];
        }

        return [
            'status'  => true,
            'message' => 'Đăng nhập thành công!',
            'user'    => $user
        ];
    }

    /**
     * 4. Đăng ký tài khoản khách hàng mới (Mặc định role_id = 5: Customer)
     */
    public function register(array $data): array {
        // Kiểm tra xem username đã tồn tại chưa
        $stmtUser = $this->db->prepare("SELECT id FROM `users` WHERE `username` = :user LIMIT 1");
        $stmtUser->execute([':user' => $data['username']]);
        if ($stmtUser->fetch()) {
            return ['status' => false, 'message' => 'Tên đăng nhập đã có người sử dụng.'];
        }

        // Kiểm tra xem email đã tồn tại chưa
        $stmtEmail = $this->db->prepare("SELECT id FROM `users` WHERE `email` = :email LIMIT 1");
        $stmtEmail->execute([':email' => $data['email']]);
        if ($stmtEmail->fetch()) {
            return ['status' => false, 'message' => 'Địa chỉ email đã được đăng ký trên hệ thống.'];
        }

        // Băm mật khẩu bằng Bcrypt
        $passwordHash = password_hash($data['password'], PASSWORD_BCRYPT);

        $sql = "INSERT INTO `users` (`role_id`, `username`, `email`, `password`, `full_name`, `phone`, `address`, `status`) 
                VALUES (5, :username, :email, :password, :full_name, :phone, :address, 'active')";
        $stmt = $this->db->prepare($sql);

        $result = $stmt->execute([
            ':username'  => $data['username'],
            ':email'     => $data['email'],
            ':password'  => $passwordHash,
            ':full_name' => $data['full_name'],
            ':phone'     => $data['phone'] ?? null,
            ':address'   => $data['address'] ?? null
        ]);

        if ($result) {
            $newUserId = (int)$this->db->lastInsertId();
            return [
                'status'  => true,
                'message' => 'Đăng ký tài khoản thành công!',
                'user_id' => $newUserId
            ];
        }

        return ['status' => false, 'message' => 'Đã xảy ra lỗi khi tạo tài khoản.'];
    }

    /**
     * 5. Cập nhật thông tin cá nhân
     */
    public function updateProfile(int $userId, array $data): bool {
        $sql = "UPDATE `users` SET 
                `full_name` = :full_name, 
                `phone` = :phone, 
                `address` = :address 
                WHERE `id` = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':full_name' => $data['full_name'],
            ':phone'     => $data['phone'] ?? null,
            ':address'   => $data['address'] ?? null,
            ':id'        => $userId
        ]);
    }

    /**
     * 6. Đổi mật khẩu tài khoản
     */
    public function changePassword(int $userId, string $oldPassword, string $newPassword): array {
        $user = $this->findById($userId);
        if (!$user) {
            return ['status' => false, 'message' => 'Người dùng không tồn tại.'];
        }

        if (!password_verify($oldPassword, $user['password']) && $user['password'] !== $oldPassword) {
            return ['status' => false, 'message' => 'Mật khẩu cũ không đúng!'];
        }

        $newHash = password_hash($newPassword, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare("UPDATE `users` SET `password` = :pwd, `require_password_change` = 0 WHERE `id` = :id");
        $success = $stmt->execute([':pwd' => $newHash, ':id' => $userId]);

        if ($success && isset($_SESSION['user']['id']) && $_SESSION['user']['id'] === $userId) {
            $_SESSION['user']['require_password_change'] = 0;
        }

        return $success 
            ? ['status' => true, 'message' => 'Đổi mật khẩu thành công!']
            : ['status' => false, 'message' => 'Không thể đổi mật khẩu, vui lòng thử lại sau.'];
    }

    /**
     * 7. Lấy danh sách đơn hàng đã mua của User
     */
    public function getUserOrders(int $userId): array {
        $sql = "SELECT * FROM `orders` WHERE `user_id` = :user_id ORDER BY `created_at` DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll();
    }

    /**
     * 8. Đếm số lượng đơn hàng của User
     */
    public function countUserOrders(int $userId): int {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM `orders` WHERE `user_id` = :uid");
        $stmt->execute([':uid' => $userId]);
        return (int)$stmt->fetchColumn();
    }

    /**
     * 9. Lấy danh sách toàn bộ Users cho trang Admin
     */
    public function getAllUsers(string $keyword = '', string $roleFilter = '', string $statusFilter = ''): array {
        $sql = "SELECT u.*, r.display_name AS role_display, 
                (SELECT COUNT(*) FROM `orders` o WHERE o.user_id = u.id) AS total_orders
                FROM `users` u 
                LEFT JOIN `roles` r ON u.role_id = r.id 
                WHERE 1=1";
        $params = [];

        if (!empty($keyword)) {
            $sql .= " AND (u.username LIKE :kw OR u.email LIKE :kw OR u.full_name LIKE :kw OR u.phone LIKE :kw)";
            $params[':kw'] = "%$keyword%";
        }

        if (!empty($roleFilter)) {
            $sql .= " AND r.name = :role";
            $params[':role'] = $roleFilter;
        }

        if (!empty($statusFilter)) {
            $sql .= " AND u.status = :status";
            $params[':status'] = $statusFilter;
        }

        $sql .= " ORDER BY u.id DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * 10. Khóa / Mở khóa tài khoản người dùng
     */
    public function toggleUserStatus(int $userId): bool {
        $user = $this->findById($userId);
        if (!$user) return false;

        $newStatus = ($user['status'] === 'active') ? 'locked' : 'active';
        $stmt = $this->db->prepare("UPDATE `users` SET `status` = :st WHERE `id` = :id");
        return $stmt->execute([':st' => $newStatus, ':id' => $userId]);
    }

    /**
     * 11. Lấy danh sách toàn bộ các vai trò (5 Roles)
     */
    public function getAllRoles(): array {
        $stmt = $this->db->query("SELECT * FROM `roles` ORDER BY `id` ASC");
        return $stmt->fetchAll();
    }

    /**
     * 12. Thay đổi vai trò (Role) và danh sách chức năng phân quyền (Multi-Permissions)
     */
    public function updateUserRole(int $userId, int $roleId, ?array $permissions = null): bool {
        if ($permissions !== null) {
            $permStr = implode(',', array_unique(array_filter(array_map('trim', $permissions))));
            $stmt = $this->db->prepare("UPDATE `users` SET `role_id` = :rid, `permissions` = :perms WHERE `id` = :id");
            return $stmt->execute([':rid' => $roleId, ':perms' => $permStr, ':id' => $userId]);
        }

        // Nếu chỉ đổi role nhanh mà không truyền permissions thì reset permissions về null để lấy mặc định của role đó
        $stmt = $this->db->prepare("UPDATE `users` SET `role_id` = :rid, `permissions` = NULL WHERE `id` = :id");
        return $stmt->execute([':rid' => $roleId, ':id' => $userId]);
    }
}

