<?php
/**
 * ========================================================
 * LONGTECH - MODEL TRUY VẤN SẢN PHẨM (ProductModel.php)
 * ========================================================
 */

require_once __DIR__ . '/Database.php';

class ProductModel {
    private PDO $db;

    public function __construct() {
        $this->db = Database::connect();
    }

    /**
     * Lấy danh sách sản phẩm nổi bật
     */
    public function getFeatured(int $limit = 8): array {
        $sql = "SELECT p.*, b.name AS brand_name, c.name AS category_name 
                FROM `products` p
                LEFT JOIN `brands` b ON p.brand_id = b.id
                LEFT JOIN `categories` c ON p.category_id = c.id
                WHERE p.`status` = 'active' AND p.`is_featured` = 1
                ORDER BY p.`id` DESC 
                LIMIT :limit";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Lấy danh sách sản phẩm Flash Sale / Hot Deal
     */
    public function getHotDeals(int $limit = 6): array {
        $sql = "SELECT p.*, b.name AS brand_name, c.name AS category_name,
                ROUND(((p.price - p.sale_price) / p.price) * 100) AS discount_percent
                FROM `products` p
                LEFT JOIN `brands` b ON p.brand_id = b.id
                LEFT JOIN `categories` c ON p.category_id = c.id
                WHERE p.`status` = 'active' AND p.`is_hot_deal` = 1 AND p.`sale_price` IS NOT NULL AND p.`sale_price` < p.`price`
                ORDER BY p.`id` DESC 
                LIMIT :limit";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Lấy danh sách sản phẩm mới nhất
     */
    public function getNewProducts(int $limit = 8): array {
        $sql = "SELECT p.*, b.name AS brand_name, c.name AS category_name 
                FROM `products` p
                LEFT JOIN `brands` b ON p.brand_id = b.id
                LEFT JOIN `categories` c ON p.category_id = c.id
                WHERE p.`status` = 'active' AND p.`is_new` = 1
                ORDER BY p.`created_at` DESC 
                LIMIT :limit";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Lấy chi tiết sản phẩm theo Slug kèm ảnh, danh mục, thương hiệu
     */
    public function getBySlug(string $slug): ?array {
        $sql = "SELECT p.*, b.name AS brand_name, b.slug AS brand_slug, 
                       c.name AS category_name, c.slug AS category_slug,
                       ROUND(((p.price - p.sale_price) / p.price) * 100) AS discount_percent
                FROM `products` p
                LEFT JOIN `brands` b ON p.brand_id = b.id
                LEFT JOIN `categories` c ON p.category_id = c.id
                WHERE p.`slug` = :slug AND p.`status` = 'active'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':slug' => $slug]);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    /**
     * Lấy chi tiết sản phẩm theo ID
     */
    public function getById(int $id): ?array {
        $sql = "SELECT p.*, b.name AS brand_name, c.name AS category_name,
                       ROUND(((p.price - p.sale_price) / p.price) * 100) AS discount_percent
                FROM `products` p
                LEFT JOIN `brands` b ON p.brand_id = b.id
                LEFT JOIN `categories` c ON p.category_id = c.id
                WHERE p.`id` = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        $res = $stmt->fetch();
        return $res ?: null;
    }

    /**
     * Lấy album ảnh phụ của sản phẩm
     */
    public function getProductImages(int $productId): array {
        $sql = "SELECT * FROM `product_images` WHERE `product_id` = :pid ORDER BY `sort_order` ASC, `id` ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':pid' => $productId]);
        return $stmt->fetchAll();
    }

    /**
     * Lấy danh sách sản phẩm liên quan cùng danh mục
     */
    public function getRelatedProducts(int $categoryId, int $excludeId, int $limit = 4): array {
        $sql = "SELECT p.*, b.name AS brand_name, c.name AS category_name,
                       ROUND(((p.price - p.sale_price) / p.price) * 100) AS discount_percent
                FROM `products` p
                LEFT JOIN `brands` b ON p.brand_id = b.id
                LEFT JOIN `categories` c ON p.category_id = c.id
                WHERE p.`category_id` = :cat_id AND p.`id` != :exclude_id AND p.`status` = 'active'
                ORDER BY p.`id` DESC 
                LIMIT :limit";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':cat_id', $categoryId, PDO::PARAM_INT);
        $stmt->bindValue(':exclude_id', $excludeId, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Truy vấn danh sách sản phẩm kèm lọc đa tiêu chí và phân trang
     */
    public function getFilteredProducts(array $filters, int $page = 1, int $limit = 12): array {
        $offset = ($page - 1) * $limit;
        list($whereSql, $params) = $this->buildFilterConditions($filters);

        // Xử lý sắp xếp (sort)
        $orderBy = "p.`id` DESC"; // Mặc định: mới nhất
        $sort = $filters['sort'] ?? '';
        switch ($sort) {
            case 'price_asc':
                $orderBy = "COALESCE(NULLIF(p.`sale_price`, 0), p.`price`) ASC";
                break;
            case 'price_desc':
                $orderBy = "COALESCE(NULLIF(p.`sale_price`, 0), p.`price`) DESC";
                break;
            case 'rating_desc':
                $orderBy = "p.`rating` DESC, p.`id` DESC";
                break;
            case 'name_asc':
                $orderBy = "p.`name` ASC";
                break;
            case 'views_desc':
                $orderBy = "p.`view_count` DESC";
                break;
            case 'hot_deals':
                $orderBy = "p.`is_hot_deal` DESC, p.`id` DESC";
                break;
            default:
                $orderBy = "p.`id` DESC";
                break;
        }

        $sql = "SELECT p.*, b.name AS brand_name, b.slug AS brand_slug, c.name AS category_name, c.slug AS category_slug,
                       ROUND(((p.price - p.sale_price) / p.price) * 100) AS discount_percent
                FROM `products` p
                LEFT JOIN `brands` b ON p.brand_id = b.id
                LEFT JOIN `categories` c ON p.category_id = c.id
                WHERE $whereSql
                ORDER BY $orderBy
                LIMIT :limit OFFSET :offset";

        $stmt = $this->db->prepare($sql);
        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val);
        }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    /**
     * Đếm tổng số lượng sản phẩm thỏa mãn bộ lọc để phân trang
     */
    public function countFilteredProducts(array $filters): int {
        list($whereSql, $params) = $this->buildFilterConditions($filters);
        $sql = "SELECT COUNT(*) FROM `products` p
                LEFT JOIN `brands` b ON p.brand_id = b.id
                LEFT JOIN `categories` c ON p.category_id = c.id
                WHERE $whereSql";
        $stmt = $this->db->prepare($sql);
        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val);
        }
        $stmt->execute();
        return (int)$stmt->fetchColumn();
    }

    /**
     * Xây dựng điều kiện WHERE động cho bộ lọc
     */
    private function buildFilterConditions(array $filters): array {
        $conditions = ["p.`status` = 'active'"];
        $params = [];

        // Lọc theo danh mục
        if (!empty($filters['category_id'])) {
            $conditions[] = "p.`category_id` = :cat_id";
            $params[':cat_id'] = $filters['category_id'];
        } elseif (!empty($filters['category_slug'])) {
            $conditions[] = "c.`slug` = :cat_slug";
            $params[':cat_slug'] = $filters['category_slug'];
        }

        // Lọc theo thương hiệu (hỗ trợ nhiều thương hiệu qua mảng)
        if (!empty($filters['brand_slugs'])) {
            $slugs = is_array($filters['brand_slugs']) ? $filters['brand_slugs'] : explode(',', $filters['brand_slugs']);
            $slugs = array_map('trim', $slugs);
            if (!empty($slugs)) {
                $brandPlaceholders = [];
                foreach ($slugs as $i => $bSlug) {
                    $key = ":bslug_$i";
                    $brandPlaceholders[] = $key;
                    $params[$key] = $bSlug;
                }
                $conditions[] = "b.`slug` IN (" . implode(',', $brandPlaceholders) . ")";
            }
        }

        // Lọc theo khoảng giá
        if (isset($filters['min_price']) && is_numeric($filters['min_price']) && $filters['min_price'] > 0) {
            $conditions[] = "COALESCE(NULLIF(p.`sale_price`, 0), p.`price`) >= :min_price";
            $params[':min_price'] = (float)$filters['min_price'];
        }
        if (isset($filters['max_price']) && is_numeric($filters['max_price']) && $filters['max_price'] > 0) {
            $conditions[] = "COALESCE(NULLIF(p.`sale_price`, 0), p.`price`) <= :max_price";
            $params[':max_price'] = (float)$filters['max_price'];
        }

        // Lọc theo RAM
        if (!empty($filters['ram'])) {
            $conditions[] = "p.`ram_options` LIKE :ram_kw";
            $params[':ram_kw'] = "%" . $filters['ram'] . "%";
        }

        // Lọc theo Bộ nhớ trong
        if (!empty($filters['storage'])) {
            $conditions[] = "p.`storage_options` LIKE :storage_kw";
            $params[':storage_kw'] = "%" . $filters['storage'] . "%";
        }

        // Lọc Flash Sale / Khuyến mãi
        if (!empty($filters['is_hot_deal'])) {
            $conditions[] = "p.`is_hot_deal` = 1";
        }

        // Lọc theo từ khóa tìm kiếm (theo tên sản phẩm, mã sản phẩm, thương hiệu)
        if (!empty($filters['keyword'])) {
            $conditions[] = "(p.`name` LIKE :kw OR p.`product_code` LIKE :kw OR b.`name` LIKE :kw)";
            $params[':kw'] = "%" . trim($filters['keyword']) . "%";
        }

        $whereSql = implode(' AND ', $conditions);
        return [$whereSql, $params];
    }

    /**
     * Tăng số lượt xem sản phẩm
     */
    public function incrementViewCount(int $productId): void {
        $stmt = $this->db->prepare("UPDATE `products` SET `view_count` = `view_count` + 1 WHERE `id` = :id");
        $stmt->execute([':id' => $productId]);
    }

    /**
     * Lấy đánh giá đã duyệt của sản phẩm
     */
    public function getProductReviews(int $productId): array {
        $sql = "SELECT r.*, u.full_name, u.username, u.avatar 
                FROM `reviews` r
                LEFT JOIN `users` u ON r.user_id = u.id
                WHERE r.`product_id` = :pid AND r.`status` = 'approved'
                ORDER BY r.`created_at` DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':pid' => $productId]);
        return $stmt->fetchAll();
    }

    /**
     * Thêm đánh giá mới (Người dùng đã đăng nhập)
     */
    public function addReview(int $productId, int $userId, int $rating, string $comment): bool {
        $sql = "INSERT INTO `reviews` (`product_id`, `user_id`, `rating`, `comment`, `status`) 
                VALUES (:pid, :uid, :rating, :comment, 'pending')";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':pid'     => $productId,
            ':uid'     => $userId,
            ':rating'  => max(1, min(5, $rating)),
            ':comment' => trim($comment)
        ]);
    }

    /**
     * Lấy danh sách thương hiệu theo danh mục
     */
    public function getBrands(): array {
        $sql = "SELECT * FROM `brands` ORDER BY `name` ASC";
        return $this->db->query($sql)->fetchAll();
    }

    public function getAllBrands(): array {
        return $this->getBrands();
    }

    public function getBanners(string $position = 'home_slider'): array {
        $sql = "SELECT * FROM `banners` WHERE `position` = :pos AND `status` = 'active' ORDER BY `sort_order` ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':pos' => $position]);
        return $stmt->fetchAll();
    }

    public function getLatestPosts(int $limit = 3): array {
        $sql = "SELECT * FROM `posts` WHERE `status` = 'published' ORDER BY `created_at` DESC LIMIT :limit";
        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * ========================================================
     * CÁC PHƯƠNG THỨC QUẢN TRỊ SẢN PHẨM (ADMIN CRUD)
     * ========================================================
     */

    /**
     * Lấy toàn bộ sản phẩm cho bảng quản lý Admin kèm tìm kiếm và lọc
     */
    public function getAllAdminProducts(string $keyword = '', int $categoryId = 0, int $brandId = 0, string $stockFilter = ''): array {
        $sql = "SELECT p.*, b.name AS brand_name, c.name AS category_name 
                FROM `products` p
                LEFT JOIN `brands` b ON p.brand_id = b.id
                LEFT JOIN `categories` c ON p.category_id = c.id
                WHERE 1=1";
        $params = [];

        if (!empty($keyword)) {
            $sql .= " AND (p.name LIKE :kw OR p.product_code LIKE :kw OR b.name LIKE :kw)";
            $params[':kw'] = "%$keyword%";
        }

        if ($categoryId > 0) {
            $sql .= " AND p.category_id = :cid";
            $params[':cid'] = $categoryId;
        }

        if ($brandId > 0) {
            $sql .= " AND p.brand_id = :bid";
            $params[':bid'] = $brandId;
        }

        // Lọc theo tồn kho: low (<= 5), out (0), in (> 5)
        if ($stockFilter === 'low') {
            $sql .= " AND p.stock_quantity <= 5 AND p.stock_quantity > 0";
        } elseif ($stockFilter === 'out') {
            $sql .= " AND p.stock_quantity = 0";
        } elseif ($stockFilter === 'in') {
            $sql .= " AND p.stock_quantity > 5";
        }

        $sql .= " ORDER BY p.id DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Thêm sản phẩm mới vào CSDL
     */
    public function createProduct(array $data): int {
        $sql = "INSERT INTO `products` (
            `category_id`, `brand_id`, `product_code`, `name`, `slug`,
            `price`, `sale_price`, `stock_quantity`, `thumbnail`, `short_description`,
            `description`, `colors`, `storage_options`, `ram_options`, `screen`,
            `camera`, `battery`, `warranty_months`, `is_featured`, `is_hot_deal`,
            `is_new`, `status`
        ) VALUES (
            :category_id, :brand_id, :product_code, :name, :slug,
            :price, :sale_price, :stock_quantity, :thumbnail, :short_description,
            :description, :colors, :storage_options, :ram_options, :screen,
            :camera, :battery, :warranty_months, :is_featured, :is_hot_deal,
            :is_new, :status
        )";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':category_id'       => (int)$data['category_id'],
            ':brand_id'          => (int)$data['brand_id'],
            ':product_code'      => $data['product_code'],
            ':name'              => $data['name'],
            ':slug'              => $data['slug'],
            ':price'             => (float)$data['price'],
            ':sale_price'        => !empty($data['sale_price']) ? (float)$data['sale_price'] : null,
            ':stock_quantity'    => (int)($data['stock_quantity'] ?? 0),
            ':thumbnail'         => $data['thumbnail'],
            ':short_description' => $data['short_description'] ?? null,
            ':description'       => $data['description'] ?? null,
            ':colors'            => $data['colors'] ?? null,
            ':storage_options'   => $data['storage_options'] ?? null,
            ':ram_options'       => $data['ram_options'] ?? null,
            ':screen'            => $data['screen'] ?? null,
            ':camera'            => $data['camera'] ?? null,
            ':battery'           => $data['battery'] ?? null,
            ':warranty_months'   => (int)($data['warranty_months'] ?? 12),
            ':is_featured'       => !empty($data['is_featured']) ? 1 : 0,
            ':is_hot_deal'       => !empty($data['is_hot_deal']) ? 1 : 0,
            ':is_new'            => !empty($data['is_new']) ? 1 : 0,
            ':status'            => $data['status'] ?? 'active'
        ]);

        return (int)$this->db->lastInsertId();
    }

    /**
     * Cập nhật thông tin sản phẩm
     */
    public function updateProduct(int $id, array $data): bool {
        $sql = "UPDATE `products` SET 
            `category_id` = :category_id,
            `brand_id` = :brand_id,
            `product_code` = :product_code,
            `name` = :name,
            `slug` = :slug,
            `price` = :price,
            `sale_price` = :sale_price,
            `stock_quantity` = :stock_quantity,
            `thumbnail` = :thumbnail,
            `short_description` = :short_description,
            `description` = :description,
            `colors` = :colors,
            `storage_options` = :storage_options,
            `ram_options` = :ram_options,
            `screen` = :screen,
            `camera` = :camera,
            `battery` = :battery,
            `warranty_months` = :warranty_months,
            `is_featured` = :is_featured,
            `is_hot_deal` = :is_hot_deal,
            `is_new` = :is_new,
            `status` = :status
            WHERE `id` = :id";

        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':category_id'       => (int)$data['category_id'],
            ':brand_id'          => (int)$data['brand_id'],
            ':product_code'      => $data['product_code'],
            ':name'              => $data['name'],
            ':slug'              => $data['slug'],
            ':price'             => (float)$data['price'],
            ':sale_price'        => !empty($data['sale_price']) ? (float)$data['sale_price'] : null,
            ':stock_quantity'    => (int)($data['stock_quantity'] ?? 0),
            ':thumbnail'         => $data['thumbnail'],
            ':short_description' => $data['short_description'] ?? null,
            ':description'       => $data['description'] ?? null,
            ':colors'            => $data['colors'] ?? null,
            ':storage_options'   => $data['storage_options'] ?? null,
            ':ram_options'       => $data['ram_options'] ?? null,
            ':screen'            => $data['screen'] ?? null,
            ':camera'            => $data['camera'] ?? null,
            ':battery'           => $data['battery'] ?? null,
            ':warranty_months'   => (int)($data['warranty_months'] ?? 12),
            ':is_featured'       => !empty($data['is_featured']) ? 1 : 0,
            ':is_hot_deal'       => !empty($data['is_hot_deal']) ? 1 : 0,
            ':is_new'            => !empty($data['is_new']) ? 1 : 0,
            ':status'            => $data['status'] ?? 'active',
            ':id'                => $id
        ]);
    }

    /**
     * Xóa sản phẩm
     */
    public function deleteProduct(int $id): bool {
        $stmt = $this->db->prepare("DELETE FROM `products` WHERE `id` = :id");
        return $stmt->execute([':id' => $id]);
    }

    /**
     * Thêm ảnh vào album ảnh phụ
     */
    public function addProductImage(int $productId, string $imageUrl): bool {
        $stmt = $this->db->prepare("INSERT INTO `product_images` (`product_id`, `image_url`) VALUES (:pid, :url)");
        return $stmt->execute([':pid' => $productId, ':url' => $imageUrl]);
    }

    /**
     * Xóa 1 ảnh phụ
     */
    public function deleteProductImage(int $imageId): bool {
        $stmt = $this->db->prepare("DELETE FROM `product_images` WHERE `id` = :id");
        return $stmt->execute([':id' => $imageId]);
    }
}
